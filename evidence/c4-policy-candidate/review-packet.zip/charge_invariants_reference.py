#!/usr/bin/env python3
"""Gated Q/sum(q^2) references; diagnostic Ewald constants, no correction claim."""
from pathlib import Path
import json
import mpmath as mp
from candidate_reference import BASE,INPUT,SCI,M,controls,load,save,sha

mp.mp.dps=110
h=load(SCI/'ligand_endpoints_v0_1/hybrid_model.json')
native=load(SCI/'ligand_endpoints_v0_1/B/parameters.json')
qA=[M(row[0])for row in h['endpoint_parameters']['A']['particles']]
qB=[M(row[0])for row in h['endpoint_parameters']['B']['particles']]
onlyA=h['unique_atoms']['A'];onlyB=h['unique_atoms']['B'];common=[i for i in range(45)if i not in onlyA+onlyB]
uA=mp.fsum(qA[i]for i in onlyA);uB=mp.fsum(qB[i]for i in onlyB);uA2=mp.fsum(qA[i]**2 for i in onlyA);uB2=mp.fsum(qB[i]**2 for i in onlyB)
grid=[mp.mpf(0),mp.mpf(1)/6,mp.mpf(1)/3,mp.mpf('.5'),mp.mpf(2)/3,mp.mpf(5)/6,mp.mpf(1)]
k=M(native['nonbonded']['coulomb_prefactor']);alpha=mp.mpf('.75');report={'schema':'orvia.staged-charge-invariants-reference.v1','status':'passed_charge_accounting_identities','diagnosticAlphaNmInverse':alpha,'alphaSelectedForProduction':False,'physicalFiniteSizeCorrectionAccepted':False,'uniformBackgroundIsNotPhysicalFiniteSizeCorrection':True,'sourceChargeRenormalized':False,'legs':{},'scientificAcceptance':False,'onChainImplemented':False,'fullHamiltonianEvaluated':False,'scriptSha256':sha(Path(__file__))}
for leg in ['complex33','solvent33']:
 a=load(INPUT/'legs'/leg/'A.parameters.json.gz');b=load(INPUT/'legs'/leg/'B.parameters.json.gz');QA=mp.fsum(M(r[0])for r in a['particles']);QB=mp.fsum(M(r[0])for r in b['particles']);A2=mp.fsum(M(r[0])**2 for r in a['particles']);B2=mp.fsum(M(r[0])**2 for r in b['particles']);CA2=A2-uA2;CB2=B2-uB2;cross=CA2+mp.fsum(qA[i]*(qB[i]-qA[i])for i in common)
 dirname='cardiac_adppi_ff03_m3l_33_782_solvated_v0_1'if leg=='complex33'else'ligand_adppi_ff03_m3l_33_782_solvated_v0_1';box=load(SCI/dirname/'particle_cost_inputs.json.gz')['box_nm'];volume=mp.fprod(map(M,box));rows=[]
 for lam in grid:
  c=controls(lam);t=c['t'];Q=(1-t)*(QA-uA)+t*(QB-uB)+c['qGateA']*uA+c['qGateB']*uB;sum2=(1-t)**2*CA2+2*t*(1-t)*cross+t*t*CB2+c['qGateA']**2*uA2+c['qGateB']**2*uB2
  ligand_q=[qA[i]*c['qGateA']if i in onlyA else qB[i]*c['qGateB']if i in onlyB else(1-t)*qA[i]+t*qB[i]for i in range(45)]
  explicit2=A2-mp.fsum(v*v for v in qA)+mp.fsum(v*v for v in ligand_q);assert abs(explicit2-sum2)<mp.mpf('1e-95')
  rows.append({'lambda':lam,'totalChargeE':Q,'sumSquaredChargesE2':sum2,'uniqueChargesExactlyZeroDuringCoreTransform':all(ligand_q[i]==0for i in onlyA+onlyB)if mp.mpf(1)/3<=lam<=mp.mpf(2)/3 else None,'diagnosticSelfEnergyKjMol':-k*alpha/mp.sqrt(mp.pi)*sum2,'diagnosticUniformBackgroundKjMol':-mp.pi*k*Q*Q/(2*alpha*alpha*volume)})
 assert abs(rows[0]['totalChargeE']-QA)<mp.mpf('1e-100')and abs(rows[-1]['totalChargeE']-QB)<mp.mpf('1e-100')
 assert abs(rows[0]['sumSquaredChargesE2']-A2)<mp.mpf('1e-95')and abs(rows[-1]['sumSquaredChargesE2']-B2)<mp.mpf('1e-95')
 # Each phase's Q is affine in monotone S, so extrema occur at phase boundaries.
 report['legs'][leg]={'rows':rows,'maximumChargeMagnitudeCertifiedByPhaseEndpoints':max(abs(r['totalChargeE'])for r in rows),'maximumDiagnosticBackgroundMagnitude':max(abs(r['diagnosticUniformBackgroundKjMol'])for r in rows),'allGatedChargeConsumers':['real','reciprocal_structure_factor','reciprocal_force','self','uniform_background','exception_desired_product'],'periodicCorrectionAndReciprocalConvergenceAccepted':False}
save(BASE/'charge-invariants.json',report)
print('gated charge invariants PASS',sha(BASE/'charge-invariants.json'))
