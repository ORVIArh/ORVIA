#!/usr/bin/env python3
"""Actual Mg/C41 pair witness: existing path vs proposed staged path only."""
from pathlib import Path
import hashlib,json
import mpmath as mp
from candidate_reference import BASE,SCI,M,controls,load,parameters,pair,save,sha

mp.mp.dps=110
h=load(SCI/'ligand_endpoints_v0_1/hybrid_model.json')
endpoint=load(SCI/'ligand_endpoints_v0_1/B/parameters.json')
native=load(BASE.parent/'full-hybrid-inputs/legs/complex33/B.parameters.json.gz')
mapping=load(BASE.parent/'full-hybrid-inputs/legs/complex33/global-map.json.gz')
qM,sM,eM=map(M,native['particles'][mapping['nativeGlobalMap'][12132]])
qC,sC,eC=map(M,h['endpoint_parameters']['B']['particles'][41])
C=M(float('97.6502078')*(4.184*0.1**4));p=parameters((sM+sC)/2,mp.sqrt(eM*eC),C)
k=M(endpoint['nonbonded']['coulomb_prefactor']);alpha=mp.mpf('.75')
def electrostatic(q,r):
 if not q:return mp.mpf(0)
 if r==0:raise ValueError('Active Coulomb point collision outside domain')
 return k*qM*q*mp.erfc(alpha*r)/r
def old(lam,r):
 rho=r**6+mp.mpf('.5')*p['sigma']**6*(1-lam)**2
 return lam*(p['A']/rho**2-p['B']/rho)+electrostatic(lam*qC,r)
def proposed(lam,r):
 c=controls(lam)
 return pair(c['aB'],r,p)+electrostatic(c['qGateB']*qC,r)
radii=[mp.mpf(x)for x in ['.1','.03','.01','.003','.001','.0001','.00001']]
rows=[{'rNm':r,'oldLambda0p5':old(mp.mpf('.5'),r),'candidateLambda0p5':proposed(mp.mpf('.5'),r),'candidateLambda5over6':proposed(mp.mpf(5)/6,r)}for r in radii]
assert all(rows[i+1]['oldLambda0p5']<rows[i]['oldLambda0p5']for i in range(len(rows)-1))
limit=proposed(mp.mpf('.5'),mp.mpf(0));assert mp.isfinite(limit)
assert rows[-1]['candidateLambda5over6']>rows[-2]['candidateLambda5over6']>0
assert controls(mp.mpf(5)/6)['aB']==1 and controls(mp.mpf(5)/6)['qGateB']>0
report={'schema':'orvia.actual-Mg-C41-staged-charge-witness.v1','status':'passed_pair_counterexample_and_staging_tests','actualAtoms':{'MgNative':12132,'MgHybrid':mapping['nativeGlobalMap'][12132],'C41Hybrid':mapping['ligandHybridToGlobal'][41]},'sourceExceptionProof':{'path':'endpoint-stability/mg-c41-collision-path.json','sha256':sha(BASE/'endpoint-stability/mg-c41-collision-path.json')},'diagnosticEwaldAlphaNmInverse':alpha,'coulombPrefactor':k,'pairPhysicalParameters':p,'oldPathCoulombStrengthAt0p5':k*qM*qC/2,'candidatePairEnergyAtOverlapLambda0p5':limit,'curves':rows,'reason':'At softened-core phase all unique-atom charges and desired exception charge products are exactly zero. During recharge, physical r^-12 core is fully restored; this is a new staged protocol, not the current on-chain implementation.','globalNativeEndpointBoundedness':False,'fullHamiltonianEvaluated':False,'onChainImplemented':False,'scientificAcceptance':False,'productionReady':False,'scriptSha256':sha(Path(__file__))}
save(BASE/'staged-charge-pair-witness.json',report)
print('staged pair witness PASS',sha(BASE/'staged-charge-pair-witness.json'))
