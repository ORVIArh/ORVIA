#!/usr/bin/env python3
"""Unaccepted staged SC12-6-4 mathematics and bounded source-specific tests."""
from pathlib import Path
from collections import Counter
import gzip,hashlib,json,math,traceback
import mpmath as mp

BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]
INPUT=ROOT/'output/full-hybrid-inputs'
SCI=ROOT/'work/scientific-preparation/data/prepared_candidate'
mp.mp.dps=110
M=lambda x:mp.mpf(float(x)) if isinstance(x,float) else mp.mpf(x)
def load(p):
 p=Path(p);return json.loads(gzip.decompress(p.read_bytes())if p.suffix=='.gz'else p.read_bytes())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def clean(x):
 if isinstance(x,mp.mpf):return mp.nstr(x,110)
 if isinstance(x,dict):return {k:clean(v)for k,v in x.items()}
 if isinstance(x,list):return list(map(clean,x))
 return x
def save(p,x):p.write_text(json.dumps(clean(x),indent=2,allow_nan=False)+'\n')
def S(x):
 x=M(x)
 if x<=0:return mp.mpf(0)
 if x>=1:return mp.mpf(1)
 return x*x*x*(10+x*(-15+6*x))
def Sp(x):
 x=M(x)
 return 30*x*x*(x-1)**2 if 0<x<1 else mp.mpf(0)
def controls(lam):
 lam=M(lam);third=mp.mpf(1)/3
 if lam<=third:t,tp,qa,qb=mp.mpf(0),mp.mpf(0),1-S(3*lam),mp.mpf(0)
 elif lam>=2*third:t,tp,qa,qb=mp.mpf(1),mp.mpf(0),mp.mpf(0),S(3*lam-2)
 else:t,tp,qa,qb=S(3*lam-1),3*Sp(3*lam-1),mp.mpf(0),mp.mpf(0)
 return {'t':t,'tprime':tp,'aA':1-t,'aB':t,'aAprime':-tp,'aBprime':tp,'qGateA':qa,'qGateB':qb}
def parameters(sigma,epsilon,c4):
 s,e,c=map(M,[sigma,epsilon,c4]);assert s>0 and e>0 and c>=0
 A=4*e*s**12;B=4*e*s**6;kappa=c/(4*e*s**4);D=s**6/(1+kappa)
 return dict(sigma=s,epsilon=e,C=c,A=A,B=B,D=D,kappa=kappa)
def V(rho,p):return p['A']/rho**2-p['B']/rho-p['C']/rho**(mp.mpf(2)/3)
def Vp(rho,p):return -2*p['A']/rho**3+p['B']/rho**2+mp.mpf(2)/3*p['C']/rho**(mp.mpf(5)/3)
def pair(a,r,p,alpha=mp.mpf('.5')):
 a,r=M(a),M(r)
 if a==0:return mp.mpf(0)
 rho=r**6+alpha*p['D']*(1-a)**2
 if rho==0:raise ValueError('Native active collision is outside domain')
 return a*V(rho,p)
def pair_derivatives(a,r,p,alpha=mp.mpf('.5')):
 a,r=M(a),M(r);rho=r**6+alpha*p['D']*(1-a)**2
 if rho==0:raise ValueError('Native active collision is outside domain')
 return 6*a*r**5*Vp(rho,p),V(rho,p)-2*a*alpha*p['D']*(1-a)*Vp(rho,p)
def J(z):return mp.hyp2f1(mp.mpf(2)/3,mp.mpf(1)/6,mp.mpf(7)/6,-M(z))
def Jp(z):return -mp.mpf(2)/21*mp.hyp2f1(mp.mpf(5)/3,mp.mpf(7)/6,mp.mpf(13)/6,-M(z))
def Jseries(z,terms=25):
 z=M(z);value=mp.mpf(0);derivative=mp.mpf(0);coefficient=mp.mpf(1)
 for n in range(terms):
  term=(-1)**n*coefficient/(6*n+1);value+=term*z**n
  if n:derivative+=n*term*z**(n-1)
  coefficient*= (mp.mpf(n)+mp.mpf(2)/3)/(n+1)
 return value,derivative,coefficient*z**terms/(6*terms+1),terms*coefficient*z**(terms-1)/(6*terms+1)
def tail(groups,common_weight,common_count,lam,volume,rc=mp.mpf(1),alpha=mp.mpf('.5')):
 c=controls(lam);N=M(common_count)+c['aA']+4*c['aB'];Np=c['aAprime']+4*c['aBprime'];T=-common_weight/rc;Tp=mp.mpf(0)
 for g in groups:
  a,ap=(c['aA'],c['aAprime'])if g['group']=='A'else(c['aB'],c['aBprime']);p=g['pair'];delta=alpha*p['D']*(1-a)**2;z=delta/rc**6;zp=-2*alpha*p['D']*(1-a)*ap/rc**6
  assert 0<=z<=mp.mpf(1)/16
  T-=a*p['C']/rc*J(z);Tp-=p['C']/rc*(ap*J(z)+a*Jp(z)*zp)
 factor=4*mp.pi/volume
 return factor*N/(N+1)*T,factor*(Np/(N+1)**2*T+N/(N+1)*Tp)

def main():
 policy=load(BASE/'policy-preregistration.json');report={'schema':'orvia.c4-policy-candidate-reference-tests.v1','status':'in_progress','passedMathematicalTests':False,'policySha256':sha(BASE/'policy-preregistration.json'),'scriptSha256':sha(Path(__file__)),'counts':{},'checks':[],'failures':[],'modelScope':'ADPPI candidate only; original vanadate model remains blocked/unsubstituted','scientificAcceptance':False,'periodicChargeCorrectionPolicyAccepted':False,'onChainImplemented':False,'productionReady':False}
 save(BASE/'candidate-validation.json',report)
 def check(ok,label,**data):
  report['checks'].append({'passed':bool(ok),'criterion':label,**data})
  if not ok:raise AssertionError(label)
 def close(a,b,atol=mp.mpf('1e-60'),rtol=mp.mpf('1e-55')):return abs(a-b)<=atol+rtol*abs(b)
 try:
  h=load(SCI/'ligand_endpoints_v0_1/hybrid_model.json');mapping=load(INPUT/'legs/complex33/global-map.json.gz');pA=load(INPUT/'legs/complex33/A.parameters.json.gz');pB=load(INPUT/'legs/complex33/B.parameters.json.gz');c4=load(INPUT/'legs/complex33/c4.unresolved.json.gz')['nativeWrittenTables']
  sources=[SCI/'ligand_endpoints_v0_1/hybrid_model.json',INPUT/'legs/complex33/global-map.json.gz',INPUT/'legs/complex33/A.parameters.json.gz',INPUT/'legs/complex33/B.parameters.json.gz',INPUT/'legs/complex33/c4.unresolved.json.gz',INPUT/'legs/solvent33/A.parameters.json.gz',INPUT/'legs/solvent33/B.parameters.json.gz']
  report['sources']=[{'path':str(p.relative_to(ROOT)),'sha256':sha(p)}for p in sources]
  groups=[];mg=mapping['nativeGlobalMap'][12132];qm,sm,em=pB['particles'][mg];cfac=4.184*0.1**4;C_h=M(float('35.6179363')*cfac);C_c=M(float('97.6502078')*cfac)
  for group in ['A','B']:
   for atom in h['unique_atoms'][group]:
    q,s,e=h['endpoint_parameters'][group]['particles'][atom]
    physical_type=int(c4['ATOM_TYPE_INDEX'][mapping['ligandHybridToGlobal'][atom]])-1 if group=='B'else21
    assert group=='B'or load(INPUT/'legs/complex33/c4.unresolved.json.gz')['unionOnlyPhysicalTypeAssignmentCandidate']['nativeTypeIndex']==physical_type+1
    type_count=math.isqrt(len(c4['NONBONDED_PARM_INDEX']));index=int(c4['NONBONDED_PARM_INDEX'][32*type_count+physical_type])-1
    C=M(float(c4['LENNARD_JONES_CCOEF'][index])*cfac)
    check(C==(C_c if atom==41 else C_h),'Unique C4 comes from actual written native type/matrix lookup',hybridAtom=atom,nativeTypeIndex=physical_type+1)
    pars=parameters((M(sm)+M(s))/2,mp.sqrt(M(em)*M(e)),C)
    groups.append({'hybridAtom':atom,'globalAtom':mapping['ligandHybridToGlobal'][atom],'group':group,'physicalCharge':M(q),'pair':pars})
  save(BASE/'explicit-activity-metadata.json',{'schema':'orvia.c4-explicit-alchemical-activity.v1','groupSource':'frozen hybrid.unique_atoms; never zero-field inference','Aunique':h['unique_atoms']['A'],'Bunique':h['unique_atoms']['B'],'commonLigand':[i for i in range(45)if i not in h['unique_atoms']['A']+h['unique_atoms']['B']],'commonEnvironment':'all other global atoms','immutableMg':mg,'activityRules':{'Aunique':'1-S(3lambda-1)','Bunique':'S(3lambda-1)','common':'1'},'chargeRules':{'Aunique':'qA*[1-S(3lambda)]','Bunique':'qB*S(3lambda-2)','common':'(1-S(3lambda-1))*qA+S(3lambda-1)*qB'},'groups':groups,'accepted':False})
  activities=[mp.mpf(x)for x in policy['tests']['activityGrid']];radii=[mp.mpf(10)**(-8+mp.mpf(i)/5)for i in range(41)];endpoint_radii=[mp.mpf(x)for x in policy['tests']['endpointIdentityRadiiNm']];lamgrid=[mp.mpf(x)if '/'not in x else mp.mpf(x.split('/')[0])/int(x.split('/')[1])for x in policy['tests']['lambdaGrid']]
  curves=[];derivative_tests=0;endpoint_tests=0;maximum_derivative_error=mp.mpf(0)
  for g in groups:
   p=g['pair'];low=p['D']/p['sigma']**6;high=mp.mpf(2)
   for _ in range(400):
    mid=(low+high)/2
    if 6*mid+4*p['kappa']*mid**(mp.mpf(4)/3)<12:low=mid
    else:high=mid
   rho_star=(low+high)/2*p['sigma']**6;rstar=rho_star**(mp.mpf(1)/6)
   check(p['D']<rho_star,'C4-aware soft length below native combined minimum',hybridAtom=g['hybridAtom'],D=p['D'],nativeMinimumR6=rho_star)
   check(6*p['B']*p['D']+4*p['C']*p['D']**(mp.mpf(4)/3)<12*p['A'],'Source-specific exact repulsive-core inequality',hybridAtom=g['hybridAtom'])
   for r in endpoint_radii:
    check(close(pair(1,r,p),V(r**6,p),mp.mpf('1e-85'),mp.mpf('1e-80')),'Native active pair endpoint identity',hybridAtom=g['hybridAtom'],r=r);check(pair(0,r,p)==0,'Inactive pair endpoint exactly zero');endpoint_tests+=2
   for a in activities:
    for r in radii+([mp.mpf(0)]if a<1 else[]):
     E=pair(a,r,p);dr,da=pair_derivatives(a,r,p);numeric_r=mp.diff(lambda x:pair(a,x,p),r);numeric_a=mp.diff(lambda x:pair(x,r,p),a)
     check(mp.isfinite(E)and close(dr,numeric_r)and close(da,numeric_a),'Analytic radial/activity derivative',hybridAtom=g['hybridAtom'],activity=a,r=r);derivative_tests+=1;maximum_derivative_error=max(maximum_derivative_error,abs(dr-numeric_r),abs(da-numeric_a))
   for a in [mp.mpf('.001'),mp.mpf('.1'),mp.mpf('.5'),mp.mpf('.9')]:
    delta=mp.mpf('.5')*p['D']*(1-a)**2;radius=(rho_star-delta)**(mp.mpf(1)/6)
    check(radius>rstar*mp.mpf('.5')**(mp.mpf(1)/6),'Native-core minimum stays away from overlap',hybridAtom=g['hybridAtom'],activity=a)
   curves.append({'hybridAtom':g['hybridAtom'],'pair':p,'nativeMinimumRadiusNm':rstar,'nativeMinimumR6OverSigma6':rho_star/p['sigma']**6,'naiveSigmaSoftcoreOverlapWellAtActivity0p001':Vp(mp.mpf('.5')*p['sigma']**6*(1-mp.mpf('.001'))**2,p)>0,'candidateOverlapEnergyAtActivity0p001':pair(mp.mpf('.001'),0,p),'radii':[{'rNm':r,'native':pair(1,r,p),'candidate_a0p001':pair(mp.mpf('.001'),r,p),'candidate_a0p5':pair(mp.mpf('.5'),r,p)}for r in radii]})
  save(BASE/'actual-unique-pair-curves.json',curves)
  report['counts'].update(uniquePairs=len(groups),endpointPairChecks=endpoint_tests,derivativePoints=derivative_tests);report['maximumAbsoluteDerivativeResidual']=maximum_derivative_error
  # Joint-softcore tail integral: independent quadrature and alternating series.
  tail_tests=[]
  for z in [mp.mpf(0),mp.mpf('1e-8'),mp.mpf('1e-5'),mp.mpf('1e-3'),mp.mpf(1)/16]:
   value,prime,error_bound,prime_bound=Jseries(z);quad=mp.quad(lambda t:(1+z*t**6)**(-mp.mpf(2)/3),[0,1]);quad_prime=mp.quad(lambda t:-mp.mpf(2)/3*t**6*(1+z*t**6)**(-mp.mpf(5)/3),[0,1])
   check(abs(value-J(z))<=error_bound+mp.mpf('1e-100')and abs(prime-Jp(z))<=prime_bound+mp.mpf('1e-100'),'Certified 25-term tail and derivative series',z=z)
   check(close(quad,J(z))and close(quad_prime,Jp(z)),'Independent tail integral quadrature',z=z)
   check(error_bound<=mp.mpf('1e-30')and prime_bound<=mp.mpf('1e-28'),'Preregistered uniform tail approximation bounds',z=z)
   tail_tests.append({'z':z,'J':J(z),'Jprime':Jp(z),'seriesError':abs(value-J(z)),'derivativeSeriesError':abs(prime-Jp(z)),'certifiedBounds':[error_bound,prime_bound]})
  save(BASE/'tail-integral-checks.json',tail_tests)
  # Weighted physical count matches native finite-N endpoint convention.
  ntypes=int(math.isqrt(len(c4['NONBONDED_PARM_INDEX'])));raw_coeff=list(map(float,c4['LENNARD_JONES_CCOEF']));raw_types=[int(x)-1 for x in c4['ATOM_TYPE_INDEX']]
  C=lambda i,j:M(raw_coeff[int(c4['NONBONDED_PARM_INDEX'][i*ntypes+j])-1]*cfac)
  common_weight=mp.fsum(C(32,t)for i,t in enumerate(raw_types)if i!=12132)+C(32,32)-mp.fsum(g['pair']['C']for g in groups if g['group']=='B');box=[M(x)for x in load(SCI/'cardiac_adppi_ff03_m3l_33_782_solvated_v0_1/particle_cost_inputs.json.gz')['box_nm']];volume=mp.fprod(box);Ncommon=132931
  check(C(32,32)>0,'Native singleton Mg self-class LRC retained',C4=C(32,32))
  tail_curves=[]
  for lam in lamgrid:
   value,derivative=tail(groups,common_weight,Ncommon,lam,volume);numeric=mp.diff(lambda x:tail(groups,common_weight,Ncommon,x,volume)[0],lam)
   check(close(derivative,numeric),'Complete LRC lambda derivative including effective-N term',lam=lam)
   tail_curves.append({'lambda':lam,'controls':controls(lam),'tailEnergy':value,'tailLambdaDerivative':derivative,'effectivePhysicalAtoms':Ncommon+controls(lam)['aA']+4*controls(lam)['aB']})
  for lam,group,count in [(0,'A',132932),(1,'B',132935)]:
   value,_=tail(groups,common_weight,Ncommon,M(lam),volume);native=-4*mp.pi*count/(count+1)/volume*(common_weight+mp.fsum(g['pair']['C']for g in groups if g['group']==group))
   check(close(value,native,mp.mpf('1e-85'),mp.mpf('1e-80')),'Native physical-count C4 tail endpoint identity',endpoint=group)
  save(BASE/'staged-tail-curves.json',tail_curves)
  # Full source charges, explicit activity masks and coherent exception products.
  netcharges={};exception_checks=0;common=[i for i in range(45)if i not in h['unique_atoms']['A']+h['unique_atoms']['B']]
  check(all(h['endpoint_parameters']['A']['particles'][i][1:]==h['endpoint_parameters']['B']['particles'][i][1:]for i in common),'Actual common ligand LJ cores unchanged through common-charge transformation')
  for leg in ['complex33','solvent33']:
   aa=load(INPUT/'legs'/leg/'A.parameters.json.gz');bb=load(INPUT/'legs'/leg/'B.parameters.json.gz');QA=mp.fsum(M(r[0])for r in aa['particles']);QB=mp.fsum(M(r[0])for r in bb['particles']);uniqueA=mp.fsum(g['physicalCharge']for g in groups if g['group']=='A');uniqueB=mp.fsum(g['physicalCharge']for g in groups if g['group']=='B');rows=[]
   for lam in lamgrid:
    c=controls(lam);Q=(1-c['t'])*(QA-uniqueA)+c['t']*(QB-uniqueB)+c['qGateA']*uniqueA+c['qGateB']*uniqueB
    rows.append({'lambda':lam,'totalChargeE':Q,'backgroundQSquared':Q*Q})
   netcharges[leg]={'nativeEndpointA':QA,'nativeEndpointB':QB,'curve':rows,'maximumAbsoluteSampledCharge':max(abs(x['totalChargeE'])for x in rows),'physicalFiniteSizeCorrectionAccepted':False,'chargeNeutralizedOrRenormalized':False}
  def q_at(i,lam):
   c=controls(lam);qa=M(h['endpoint_parameters']['A']['particles'][i][0]);qb=M(h['endpoint_parameters']['B']['particles'][i][0])
   if i in h['unique_atoms']['A']:return qa*c['qGateA']
   if i in h['unique_atoms']['B']:return qb*c['qGateB']
   return (1-c['t'])*qa+c['t']*qb
  exA=h['endpoint_parameters']['A']['exceptions'];exB=h['endpoint_parameters']['B']['exceptions']
  for rowA,rowB in zip(exA,exB):
   i,j=rowA[:2];assert rowB[:2]==[i,j];prodA=M(h['endpoint_parameters']['A']['particles'][i][0])*M(h['endpoint_parameters']['A']['particles'][j][0]);prodB=M(h['endpoint_parameters']['B']['particles'][i][0])*M(h['endpoint_parameters']['B']['particles'][j][0]);dA,dB=M(rowA[2]),M(rowB[2]);assert prodA or dA==0;assert prodB or dB==0
   scaleA=dA/prodA if prodA else dB/prodB if prodB else mp.mpf(0);scaleB=dB/prodB if prodB else scaleA
   for lam in lamgrid:
    c=controls(lam);desired=((1-c['t'])*scaleA+c['t']*scaleB)*q_at(i,lam)*q_at(j,lam)
    if lam==0:check(close(desired,dA,mp.mpf('1e-85'),mp.mpf('1e-80')),'Exact mathematical exception A endpoint')
    if lam==1:check(close(desired,dB,mp.mpf('1e-85'),mp.mpf('1e-80')),'Exact mathematical exception B endpoint')
    if mp.mpf(1)/3<=lam<=mp.mpf(2)/3 and(i in h['unique_atoms']['A']+h['unique_atoms']['B']or j in h['unique_atoms']['A']+h['unique_atoms']['B']):check(desired==0,'Unique exception Coulomb exactly off during softened-core phase')
    exception_checks+=1
  for lam in lamgrid:
   c=controls(lam)
   check(c['qGateA']==0 or c['aA']==1,'Charged A-unique atom always retains full physical core',lam=lam)
   check(c['qGateB']==0 or c['aB']==1,'Charged B-unique atom always retains full physical core',lam=lam)
  report['counts']['exceptionStateChecks']=exception_checks;save(BASE/'net-charge-curves.json',netcharges)
  report.update(status='passed_bounded_mathematical_candidate_tests_unaccepted',passedMathematicalTests=True,limitations=['No on-chain implementation/arithmetic/gas validation.','No complete staged Hamiltonian/MBAR/trajectory or ensemble overlap validation.','Exact endpoints mean source-defined mathematical component potentials; not bitwise cross-backend equivalence.','Global native point-charge boundedness is false; existing endpoint domain/model assumptions cannot be repaired while preserving exact endpoints.','Intermediate charge is nonneutral and periodic finite-size/background policy remains unaccepted.','Native unswitched C4 hard-cutoff jump is preserved; global radial smoothness at cutoff is not claimed.','Original vanadate system is not replaced or accepted by this ADPPI candidate.'])
 except Exception as e:report['status']='failed';report['failures'].append({'message':str(e),'traceback':traceback.format_exc()});raise
 finally:save(BASE/'candidate-validation.json',report)
 print(json.dumps({'status':report['status'],'checks':len(report['checks']),'counts':report['counts'],'reportSha256':sha(BASE/'candidate-validation.json')}))

if __name__=='__main__':main()
