#!/usr/bin/env python3
"""Separate exact identity/exception/bonded coverage proof for Mg→ghost C41."""
from pathlib import Path
from fractions import Fraction as F
import gzip,hashlib,json,traceback
import numpy as np
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
ASSEMBLY=ROOT/'output/full-hybrid-inputs';LEG=ASSEMBLY/'legs/complex33'
LIG=ROOT/'work/scientific-preparation/data/prepared_candidate/ligand_endpoints_v0_1/hybrid_model.json'
INVENTORY=ROOT/'work/scientific-preparation/data/prepared_candidate/cardiac_adppi_ff03_m3l_33_782_solvated_v0_1/force_inventory.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(gzip.decompress(p.read_bytes())if p.suffix=='.gz'else p.read_bytes())
def save(p,r):p.write_text(json.dumps(r,indent=2,sort_keys=True,allow_nan=False)+'\n')
report={'schema':'orvia.actual-mg-ghost-collision-path-proof.v1','status':'in_progress','passedIdentityAndCoverage':False,'scientificAcceptance':False,'physicalPolicyAccepted':False,'noContextOrDynamicsOrOptimization':True,'sources':[],'failures':[]}
target=OUT/'mg-c41-collision-path.json';save(target,report)
try:
 catalog=read(LEG/'catalog-candidate.json');mapping=read(LEG/'global-map.json.gz');model=read(LIG);inventory=read(INVENTORY)
 N=catalog['counts']['hybrid'];local_b=model['endpoint_maps']['B'].index(41);native_c=mapping['ligandNativeStart']+local_b;carbon=mapping['ligandHybridToGlobal'][41];mg_native=12132;mg=mapping['nativeGlobalMap'][mg_native];pair=tuple(sorted((carbon,mg)))
 assert native_c==12042 and carbon==12042 and mg==12133 and pair==(12042,12133)
 source_paths={Path(__file__),LEG/'catalog-candidate.json',LEG/'global-map.json.gz',LIG,INVENTORY};endpoint_checks={};stream_records=[]
 for endpoint in ['A','B']:
  path=LEG/(endpoint+'.parameters.json.gz');source_paths.add(path);params=read(path);assert sha(path)==catalog['parameters'][endpoint]['sha256'];pairs=[tuple(row[:2])for row in params['exceptions']];assert pair not in pairs
  check={'parameterFileSha256':sha(path),'parameterExceptionRecords':len(pairs),'pairAbsentFromParameterExceptions':True,'parameterExceptionsInvolvingMg':sum(mg in row for row in pairs),'bondedTermsInvolvingMg':{}}
  for role,width,atom_fields,field in [('exceptions',6,2,'exceptions'),('bonds',4,2,'harmonic_bonds'),('angles',5,3,'harmonic_angles'),('torsions',7,4,'periodic_torsions')]:
   record=catalog['streams'][endpoint+'.'+role];p=ASSEMBLY/record['path'];source_paths.add(p);assert sha(p)==record['gzipSha256'];raw=gzip.decompress(p.read_bytes());assert hashlib.sha256(raw).hexdigest()==record['rawSha256']and len(raw)==record['wordCount']*32
   values=np.frombuffer(raw,dtype='>u8').astype(np.uint64).reshape(-1,width,4);assert not np.any(values[:,:atom_fields,:3]);indices=values[:,:atom_fields,3];involving=int(np.count_nonzero(np.any(indices==mg,axis=1)));assert involving==0
   if role=='exceptions':
    found=bool(np.any((indices[:,0]==pair[0])&(indices[:,1]==pair[1])));assert not found;check['pairAbsentFromRawExceptionStream']=True;check['rawExceptionKind1Or2NeitherContainsPair']=True
   else:check['bondedTermsInvolvingMg'][role]={'parameterRecords':len(params[field]),'parameterMgRecords':sum(mg in row[:atom_fields]for row in params[field]),'rawWordMgRecords':involving};assert check['bondedTermsInvolvingMg'][role]['parameterMgRecords']==0
   stream_records.append({'endpoint':endpoint,'role':role,'path':str(p.relative_to(ROOT)),'gzipSha256':record['gzipSha256'],'rawSha256':record['rawSha256'],'wordCount':record['wordCount'],'records':len(values),'MgRecords':involving})
  endpoint_checks[endpoint]=check
 constraints_path=ASSEMBLY/catalog['mandatoryConstraints']['path'];source_paths.add(constraints_path);constraints=read(constraints_path);assert sha(constraints_path)==catalog['mandatoryConstraints']['sha256'];mg_constraints=[row for row in constraints['constraints']if mg in row[:2]];assert not mg_constraints
 xyz=np.asarray(read(LEG/'A.parameters.json.gz')['positions_nm']);assert xyz.shape==(N,3)and np.array_equal(xyz,np.asarray(read(LEG/'B.parameters.json.gz')['positions_nm']))
 # Exact rational periodic analysis of every fixed center relative to C41.
 # Same finite binary64 source values are embedded exactly in the bytes32 stream.
 box=[F(float(v))for v in inventory['box_nm']];center=tuple(F(float(v))for v in xyz[carbon]);minimum=None;nearest=None;wrapped_seen={};duplicate_fixed=[]
 for atom,row in enumerate(xyz):
  if atom==mg:continue
  exact=tuple(F(float(v))for v in row);wrapped=tuple(x%length for x,length in zip(exact,box))
  if wrapped in wrapped_seen:duplicate_fixed.append([wrapped_seen[wrapped],atom])
  else:wrapped_seen[wrapped]=atom
  if atom==carbon:continue
  d=[]
  for value,origin,length in zip(exact,center,box):
   delta=value-origin;delta-=int(delta/length)*length
   if delta>length/2:delta-=length
   elif delta< -length/2:delta+=length
   d.append(delta)
  distance_inf=max(map(abs,d));assert distance_inf>0
  if minimum is None or distance_inf<minimum:minimum=distance_inf;nearest=atom
 assert not duplicate_fixed
 radius=minimum/4
 pos_record=catalog['streams']['positions'];pos_path=ASSEMBLY/pos_record['path'];source_paths.add(pos_path);assert sha(pos_path)==pos_record['gzipSha256'];assert hashlib.sha256(gzip.decompress(pos_path.read_bytes())).hexdigest()==pos_record['rawSha256']
 report.update({'globalPair':list(pair),'nativeBPair':[native_c,mg_native],'unionLigandAtom':41,'nativeLigandBLocalIndex':local_b,'MgNativeIndex':mg_native,'MgGlobalHybridIndex':mg,'ligandGlobalHybridIndex':carbon,'exceptionAndBondedChecks':endpoint_checks,'rawStreamsVerified':stream_records,'constraintRecords':len(constraints['constraints']),'MgConstraintRecords':0,'notOneFour':True,
  'sourceForceInventory':inventory,'positionsStream':pos_record,
  'exactPeriodicGeometry':{'arithmetic':'Exact Fraction of original finite binary64 coordinates/box, identical to their exact binary128 embeddings. No float-distance assumption.','fixedCentersIncludingAllGhosts':N-1,'fixedPeriodicCoordinateDuplicates':duplicate_fixed,'minimumTargetToOtherFixedCenterLInfinityNmFraction':str(minimum),'minimumTargetToOtherFixedCenterLInfinityNm':float(minimum),'nearestFixedAtomByLInfinity':nearest,'approachRadiusNmFraction':str(radius),'approachRadiusNm':float(radius),'path':'Keep C41 and every other atom fixed. Move only Mg on any generic ray to within r<radius of C41. By periodic LInfinity triangle inequality, every Mg-other-center separation remains at least3*minimum/4>0; all fixed-fixed separations are unchanged and nonzero.'},
  'fullHamiltonianArgument':{'normalPair':'Neither endpoint raw exception stream contains (12042,12133); no kind1 exclusion or kind2 direct/1-4 entry exists. It is an ordinary normal pair.','bondedAndConstraints':'Mg appears in zero A/B bonds, angles, torsions or mapped water constraints. Moving Mg changes none of these terms or any bonded anchor.',
  'otherPhysicalTerms':'On the compact approach neighborhood all other Mg-center distances have a certified strictly positive lower bound; finite-coefficient LJ/C4/real electrostatic terms are bounded there. Existing fixed-fixed terms remain constant. A cutoff crossing may give a finite discontinuity, not a compensating divergence.',
  'finiteModeReciprocal':'Fixed charges/box/alpha and a finite reciprocal cube yield finite sums of bounded sine/cosine functions of Mg position, hence bounded energy.','selfBackgroundAndClassLrc':'Self/background depend on charges and box, and class-count C4 LRC depends on fixed lambda/types/counts/box. They are constant along this coordinate path.',
  'targetPair':'At interiorlambda=.5, actualC41 charge=-0.04656135229910604 andMgcharge=+2. CurrentsoftcoreLJ hasfinite r→0 limit23.1194444720867kJ/mol, while realEwald=-12.9380455804352/r+O(1). Any proposed finite softcore C4 remains bounded and cannot cancel this attractive1/r.',
  'result':'For this actual source-bound pair, the simultaneous charged-ghost/softened-LJ path has U_total→−infinity in the continuum model. A C4-only softening policy cannot establish full-Hamiltonian stability; explicit compatible charge staging or electrostatic regularization is necessary.'}})
 for p in sorted(source_paths):report['sources'].append({'path':str(p.relative_to(ROOT)),'sha256':sha(p),'bytes':p.stat().st_size})
 for item in report['sources']:assert sha(ROOT/item['path'])==item['sha256']
 report['status']='passed_identity_coverage_and_exact_local_geometry';report['passedIdentityAndCoverage']=True
except Exception as e:report['status']='failed';report['failures'].append({'message':str(e),'traceback':traceback.format_exc()});raise
finally:save(target,report)
print(json.dumps({'status':report['status'],'pair':report.get('globalPair'),'exactRadiusNm':report.get('exactPeriodicGeometry',{}).get('approachRadiusNm'),'reportSha256':sha(target)}))
