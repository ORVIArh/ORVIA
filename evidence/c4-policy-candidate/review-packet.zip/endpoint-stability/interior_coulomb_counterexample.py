#!/usr/bin/env python3
"""Source-bound analytic counterexample; no EVM/Context/trajectory claim."""
from pathlib import Path
import gzip,hashlib,json,shutil
import mpmath as mp
mp.mp.dps=100
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
LIG=ROOT/'work/scientific-preparation/data/prepared_candidate/ligand_endpoints_v0_1/hybrid_model.json'
PARAMS=ROOT/'output/full-hybrid-inputs/legs/complex33/B.parameters.json.gz'
MAPPING=ROOT/'output/full-hybrid-inputs/legs/complex33/global-map.json.gz'
H=ROOT/'ORVIA/contracts/core/AlchemicalHamiltonianEvaluator.sol'
LJ=ROOT/'ORVIA/contracts/kernels/SoftcoreLennardJonesKernel.sol'
EWALD=ROOT/'ORVIA/contracts/kernels/EwaldRealSpaceKernel.sol'
def read(p):return json.loads(gzip.decompress(p.read_bytes())if p.suffix=='.gz'else p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
model=read(LIG);parameters=read(PARAMS);mapping=read(MAPPING)
ghost=41;global_ghost=mapping['ligandHybridToGlobal'][ghost];native_mg=12132;global_mg=mapping['nativeGlobalMap'][native_mg]
qa,sa,ea=model['endpoint_parameters']['A']['particles'][ghost];qb,sb,eb=model['endpoint_parameters']['B']['particles'][ghost]
qm,sm,em=parameters['particles'][global_mg];assert qa==0 and ea==0 and qb<0 and qm==2 and eb>0 and em>0
assert not any(global_mg in row[:2]for row in parameters['exceptions'])
lambda_=mp.mpf(1)/2;soft_alpha=mp.mpf(1)/2;ewald_alpha=mp.mpf(1);prefactor=mp.mpf(138.93545764438198)
sigma=(mp.mpf(sm)+mp.mpf(sb))/2;epsilon=mp.sqrt(mp.mpf(em)*mp.mpf(eb));s6=sigma**6;qghost=(1-lambda_)*mp.mpf(qa)+lambda_*mp.mpf(qb);strength=prefactor*mp.mpf(qm)*qghost
curve=[]
for text in ['0.5','0.1','0.05','0.02','0.01','0.005','0.001','0.0001','1e-6','1e-9','1e-12']:
 r=mp.mpf(text);rho=r**6+soft_alpha*s6*(1-lambda_)**2;ratio=s6/rho;lj=lambda_*4*epsilon*(ratio**2-ratio);coulomb=strength*mp.erfc(ewald_alpha*r)/r
 curve.append({'rNm':text,'existingSoftcoreLJKjMol':mp.nstr(lj,90),'existingUnsoftenedEwaldRealKjMol':mp.nstr(coulomb,90),'pairSumKjMol':mp.nstr(lj+coulomb,90)})
source_records=[]
for p in [Path(__file__),LIG,PARAMS,MAPPING,H,LJ,EWALD]:source_records.append({'path':str(p.relative_to(ROOT)),'sha256':sha(p),'bytes':p.stat().st_size})
for p in [H,LJ,EWALD]:shutil.copyfile(p,OUT/('captured-'+p.name))
result={'schema':'orvia.actual-ghost-interior-coulomb-counterexample.v1','status':'analytic_counterexample_source_bound','scientificAcceptance':False,'policyAccepted':False,'gpuOrEvmOrContextExecuted':False,'integratorSteps':0,'optimizerRun':False,
 'atoms':{'ghostUnion':ghost,'ghostGlobalHybrid':global_ghost,'ghostPhysicalB':model['endpoint_maps']['B'].index(ghost),'MgNative':native_mg,'MgGlobalHybrid':global_mg},
 'actualParameters':{'ghostA':{'q':qa,'sigmaNm':sa,'epsilonKjMol':ea},'ghostB':{'q':qb,'sigmaNm':sb,'epsilonKjMol':eb},'Mg':{'q':qm,'sigmaNm':sm,'epsilonKjMol':em}},
 'diagnosticOnlyUnselectedProductionChoices':{'lambda':'1/2','softcoreAlpha':'1/2','ewaldAlphaNmInverse':1,'coulombPrefactor':float(prefactor),'explanation':'Any positive finite softening at an interior lambda and any finite positive Ewald alpha give the same Coulomb singularity. These values illustrate existing equations, not a production protocol selection.'},
 'mathematics':{'rhoB':'r^6+alpha*sigmaB^6*(1-lambda)^2','softcoreLJ':'lambda*4*epsilonB*((sigmaB^6/rhoB)^2-sigmaB^6/rhoB); inactive A contribution is exactly0',
 'interiorLJLimitR0KjMol':mp.nstr(lambda_*4*epsilon*((1/(soft_alpha*(1-lambda_)**2))**2-1/(soft_alpha*(1-lambda_)**2)),90),
 'ghostInteriorChargeE':mp.nstr(qghost,90),'attractiveCoulombStrengthKjNmMol':mp.nstr(strength,90),'ewaldReal':'strength*erfc(alphaEwald*r)/r = strength/r+O(1), strength<0',
 'conclusion':'Moving only the free unconstrained Mg toward fixed charged ghost C41 gives U_total(r)=strength/r+O(1)→−infinity at interior lambda. All ghost bonded anchors stay fixed; finite C4 softening cannot cancel an unsoftened attractive1/r divergence.',
 'zeroSeparationGuard':'The native EVM primitive rejects exact r2=0. That does not remove the continuum near-zero attractive singularity; finite arithmetic-domain failure is a separate implementation boundary, not physical regularization.',
 'endpointLimits':'At B endpoint the native unsoftened positive LJ r^-12 repulsion returns; at A endpoint this unique B charge/epsilon is zero. The defect concerns the simultaneous intermediate path.'},'curve':curve,
 'necessaryCandidateRemedy':['An explicit charge/VDW schedule with changing-atom charges zero throughout softened-core stages, and charges changed only while repulsive native cores exist, or a consistent electrostatic softcore policy.',
 'Any electrostatic softcore or staged Ewald policy must define real, reciprocal, self/background and lambda derivatives consistently and preserve exact endpoint potentials.','A C4-only candidate must keep full-Hamiltonian scientific acceptance false until this separate interior issue is resolved.'],
 'sources':source_records}
for row in source_records:assert sha(ROOT/row['path'])==row['sha256']
(OUT/'interior-coulomb-counterexample.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print('reportSha256',sha(OUT/'interior-coulomb-counterexample.json'))
