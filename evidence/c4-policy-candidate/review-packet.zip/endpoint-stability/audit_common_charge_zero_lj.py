#!/usr/bin/env python3
"""Grouped exact source/sign audit; never enumerates millions of forces."""
from pathlib import Path
from collections import Counter
from fractions import Fraction as F
import gzip,hashlib,json,traceback
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];INPUT=ROOT/'output/full-hybrid-inputs'
MODEL=ROOT/'work/scientific-preparation/data/prepared_candidate/ligand_endpoints_v0_1/hybrid_model.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(gzip.decompress(p.read_bytes())if p.suffix=='.gz'else p.read_bytes())
def save(p,r):p.write_text(json.dumps(r,indent=2,sort_keys=True,allow_nan=False)+'\n')
report={'schema':'orvia.common-charge-zero-lj-source-audit.v1','status':'in_progress','passedNarrowSignAndBoundChecks':False,'scientificAcceptance':False,'ContextOrForceOrDynamicsExecuted':False,'sources':[],'legs':{},'failures':[]}
destination=OUT/'common-charge-zero-lj.json';save(destination,report)
try:
 h=read(MODEL);unique=set(h['unique_atoms']['A']+h['unique_atoms']['B']);common=[i for i in range(45)if i not in unique];assert len(common)==40
 ap=h['endpoint_parameters']['A']['particles'];bp=h['endpoint_parameters']['B']['particles'];records=[]
 for i in common:
  qa,sa,ea=ap[i];qb,sb,eb=bp[i];assert(sa,ea)==(sb,eb)and sa>0 and ea>0 and qa*qb>0
  records.append({'hybridIndex':i,'qA':qa,'qB':qb,'sigmaNm':sa,'epsilonKjMol':ea,'qChanges':qa!=qb,'sameNonzeroChargeSign':True,'absoluteChargeBoundForAllConvexT':max(abs(qa),abs(qb))})
 source_paths={Path(__file__),MODEL};report['commonLigand']={'atoms':40,'unchangedPositiveLJCores':40,'chargeChanged':sum(r['qChanges']for r in records),'positiveAtBothEndpoints':sum(r['qA']>0for r in records),'negativeAtBothEndpoints':sum(r['qA']<0for r in records),'signFlipsOrEndpointZero':0,'records':records}
 for leg in ['complex33','solvent33']:
  directory=INPUT/'legs'/leg;catalog_path=directory/'catalog-candidate.json';map_path=directory/'global-map.json.gz';Apath=directory/'A.parameters.json.gz';Bpath=directory/'B.parameters.json.gz';source_paths.update([catalog_path,map_path,Apath,Bpath]);catalog=read(catalog_path);mapping=read(map_path);A=read(Apath);B=read(Bpath)
  assert sha(Apath)==catalog['parameters']['A']['sha256']and sha(Bpath)==catalog['parameters']['B']['sha256']
  G=mapping['ligandHybridToGlobal'];ligand=set(G);env=[i for i in range(A['atom_count'])if i not in ligand];common_global={G[i]for i in common}
  assert all(A['particles'][i]==B['particles'][i]for i in env)
  zeros=[i for i in env if A['particles'][i][2]==0];assert all(A['particles'][i][0]>0for i in zeros)
  assert all(A['particles'][G[i]]==ap[i]and B['particles'][G[i]]==bp[i]for i in common)
  exception_cross={}
  for endpoint,p in [('A',A),('B',B)]:
   all_cross=[r[:2]for r in p['exceptions']if(r[0]in ligand) !=(r[1]in ligand)];zero_cross=[r[:2]for r in p['exceptions']if((r[0]in common_global and r[1]in zeros)or(r[1]in common_global and r[0]in zeros))];assert not all_cross and not zero_cross
   exception_cross[endpoint]={'allLigandEnvironmentExceptions':len(all_cross),'commonLigandZeroLJEnvironmentExceptions':len(zero_cross),'exceptionRecords':len(p['exceptions']),'rawExceptionStreamSha256':catalog['streams'][endpoint+'.exceptions']['rawSha256']}
  nneg=report['commonLigand']['negativeAtBothEndpoints'];npos=report['commonLigand']['positiveAtBothEndpoints']
  histogram=Counter(A['particles'][i][0]for i in zeros)
  # The algebra uses exact source fractions. Checking the forty source slopes
  # once proves every fixed-q environment product without per-pair force work.
  for row in records:
   qa,qb=F(row['qA']),F(row['qB']);assert qa*qb>0
   for qenv in histogram:
    u=F(qenv);assert u>0
    assert qa*u*qb*u>0
    assert max(abs(qa*u),abs(qb*u))==u*max(abs(qa),abs(qb))
  report['legs'][leg]={'hybridAtoms':A['atom_count'],'environmentAtoms':len(env),'allEnvironmentParticleRowsExactlyUnchanged':True,'zeroLJEnvironmentAtoms':len(zeros),'zeroLJEnvironmentChargeSigns':{'positive':len(zeros),'negative':0,'zero':0},'chargeHistogram':[{'chargeE':q,'count':n}for q,n in sorted(histogram.items())],
   'commonZeroLJEnvironmentOrdinaryPairs':40*len(zeros),'attractiveAtBothEndpointsAndEveryInteriorT':nneg*len(zeros),'repulsiveAtBothEndpointsAndEveryInteriorT':npos*len(zeros),'newAttractivePairsAtAnyConvexT':0,'signChangingPairs':0,'exceptionCoverage':exception_cross}
 report['mathematicalClaim']={'scope':'Common ligand atoms versus unchanged zero-LJ environment only. No global stability or new unique-atom charge claim.',
  'control':'t=S(3lambda−1), withS clamped to[0,1]. q_common(t)=(1−t)qA+tqB; environment charge is fixed.',
  'identity':'q_common(t)*q_env=(1−t)*(qA*q_env)+t*(qB*q_env). Product is a convex combination of its native endpoint values.',
  'bound':'Absolute product never exceeds max(abs(qA*q_env),abs(qB*q_env)). A newly attractive product cannot appear unless at least one endpoint is attractive. Actual source has no common charge sign flips, so every pair keeps its sign.',
  'commonCommon':'Both common ligand particles have unchanged positive LJ epsilon/sigma, so their pair has positive A12; products can vary quadratically, but no softened-core loss of repulsion occurs for these unchanged cores.',
  'knownLimit':'Existing native attractive zero-LJ point-charge pairs remain mathematically singular. This grouped sign/bound check does not remove the native Cl–HO pathology or admit a complete ensemble.'}
 for p in sorted(source_paths):report['sources'].append({'path':str(p.relative_to(ROOT)),'sha256':sha(p),'bytes':p.stat().st_size})
 for item in report['sources']:assert sha(ROOT/item['path'])==item['sha256']
 report['status']='passed_grouped_source_convexity_and_exception_audit';report['passedNarrowSignAndBoundChecks']=True
except Exception as e:report['status']='failed';report['failures'].append({'message':str(e),'traceback':traceback.format_exc()});raise
finally:save(destination,report)
print(json.dumps({'status':report['status'],'legs':{k:{x:v[x]for x in ['zeroLJEnvironmentAtoms','commonZeroLJEnvironmentOrdinaryPairs','attractiveAtBothEndpointsAndEveryInteriorT','newAttractivePairsAtAnyConvexT']}for k,v in report['legs'].items()},'sha256':sha(destination)}))
