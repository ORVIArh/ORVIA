#!/usr/bin/env python3
"""Independent native endpoint singularity audit; no Context or dynamics."""
from pathlib import Path
from collections import Counter,defaultdict
import gzip,hashlib,json,math,traceback
import numpy as np
import parmed

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
SCI=ROOT/'work/scientific-preparation/data/prepared_candidate'
BASE=SCI/'cardiac_adppi_ff03_m3l_33_782_solvated_v0_1'
TOPOLOGY=BASE/'complex_1264.prmtop.gz'
COORDINATES=BASE/'particle_cost_inputs.json.gz'
CONSTRAINTS=BASE/'water_constraints.json.gz'
COULOMB=138.93545764438198
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(gzip.decompress(p.read_bytes()))
def save(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+'\n')
def identity(a):return {'atom':a.idx,'name':a.name,'amberType':a.type,'typeIndex1Based':a.nb_idx,'residue':a.residue.name,'residueIndex':a.residue.idx,'chargeE':a.charge,'diagonalEpsilonKcalMol':a.epsilon,'massDa':a.mass,'bondedPartners':[b.idx for b in a.bond_partners]}

report={'schema':'orvia.native-c4-endpoint-stability-audit.v1','status':'in_progress','passedAudit':False,'scientificAcceptance':False,'productionReady':False,'ContextCreated':False,'optimizerRun':False,'dynamicsPerformed':False,'scriptSha256':digest(Path(__file__)),'sources':[{'path':str(p.relative_to(ROOT)),'sha256':digest(p),'bytes':p.stat().st_size}for p in [TOPOLOGY,COORDINATES,CONSTRAINTS]],'failures':[]}
save(OUT/'native-stability.json',report)
try:
 s=parmed.load_file(str(TOPOLOGY));raw=s.parm_data;nt=raw['POINTERS'][1];n=len(s.atoms)
 mg=[a for a in s.atoms if a.atomic_number==12];assert len(mg)==1;mg=mg[0]
 def coefficients(a,b):
  i=raw['NONBONDED_PARM_INDEX'][(a.nb_idx-1)*nt+b.nb_idx-1]-1
  assert i>=0
  return {'nativeParameterIndex0Based':i,'A12KcalAngstrom12':raw['LENNARD_JONES_ACOEF'][i],'B6KcalAngstrom6':raw['LENNARD_JONES_BCOEF'][i],'C4KcalAngstrom4':raw['LENNARD_JONES_CCOEF'][i]}
 exclusions=set();cursor=0
 for i,count in enumerate(raw['NUMBER_EXCLUDED_ATOMS']):
  for j in raw['EXCLUDED_ATOMS_LIST'][cursor:cursor+count]:
   if j>0:exclusions.add(tuple(sorted((i,j-1))))
  cursor+=count
 assert cursor==len(raw['EXCLUDED_ATOMS_LIST'])and len(exclusions)==186900
 constraints=read(CONSTRAINTS);constrained={i for a,b,d in constraints['constraints']for i in [a,b]}
 costs=read(COORDINATES);xyz=np.asarray(costs['positions_nm']);assert xyz.shape==(n,3)
 positive=[];danger=[];zero_lj=[];groups=defaultdict(list)
 for a in s.atoms:
  if a.idx==mg.idx:continue
  c=coefficients(mg,a);item={**identity(a),**c,'excludedFromC4':tuple(sorted((mg.idx,a.idx)))in exclusions,'chargeProductWithMg':mg.charge*a.charge}
  if c['A12KcalAngstrom12']==0:zero_lj.append(item)
  if c['C4KcalAngstrom4']>0:
   positive.append(item);groups[(a.type,a.nb_idx)].append(item)
   if c['A12KcalAngstrom12']==0:danger.append(item)
 zero_group=Counter((a['amberType'],a['typeIndex1Based'],a['residue']=='WAT',a['C4KcalAngstrom4'],math.copysign(1,a['chargeE']))for a in zero_lj)
 report['native']={'atoms':n,'types':nt,'Mg':identity(mg),'MgHasBonds':bool(mg.bond_partners),'MgConstrained':mg.idx in constrained,'nativeExceptionPairs':len(exclusions),'constraintPairs':len(constraints['constraints'])}
 report['MgC4Audit']={'positiveC4PhysicalPairs':len(positive),'positiveC4PairsExcluded':sum(a['excludedFromC4']for a in positive),'positiveC4WithZeroA12':len(danger),'zeroA12MgPairs':len(zero_lj),'zeroA12NonWater':sum(a['residue']not in ('WAT','HOH')for a in zero_lj),'allPositiveC4HavePositiveA12':all(a['A12KcalAngstrom12']>0 for a in positive),'minimumPositiveA12KcalAngstrom12':min(a['A12KcalAngstrom12']for a in positive),'zeroA12Groups':[{'amberType':k[0],'typeIndex1Based':k[1],'water':k[2],'C4KcalAngstrom4':k[3],'chargeSign':k[4],'count':v}for k,v in sorted(zero_group.items())],
  'positiveC4TypeGroups':[{'amberType':k[0],'typeIndex1Based':k[1],'atoms':len(v),'A12KcalAngstrom12':v[0]['A12KcalAngstrom12'],'B6KcalAngstrom6':v[0]['B6KcalAngstrom6'],'C4KcalAngstrom4':v[0]['C4KcalAngstrom4']}for k,v in sorted(groups.items())],
  'conclusion':'The proposed C4-without-LJ-repulsion endpoint counterexample is absent in these actual native bytes. Every physical Mg pair with C4>0 has A12>0; its A12/r12 term dominates finite B6/r6, C4/r4 and Coulomb1/r at r→0.'}
 save(OUT/'zero-A12-Mg-pairs.json',{'pairs':zero_lj})
 # Find a distinct inherited native singularity without moving any bonded anchor:
 # move a free chloride toward a fixed positive zero-LJ water H.
 negative_free=[a for a in s.atoms if a.charge<0 and not a.bond_partners and a.idx not in constrained]
 witnesses=[]
 for moving in negative_free:
  for target in s.atoms:
   if target.idx==moving.idx or target.charge<=0:continue
   c=coefficients(moving,target)
   if c['A12KcalAngstrom12']==0 and c['B6KcalAngstrom6']==0 and c['C4KcalAngstrom4']==0 and tuple(sorted((moving.idx,target.idx)))not in exclusions:
    witnesses.append((moving,target,c));break
 if witnesses:
  moving,target,c=witnesses[0];dist=np.linalg.norm(xyz-xyz[target.idx],axis=1);dist[[target.idx,moving.idx]]=np.inf;nearest=float(dist.min());key=COULOMB*moving.charge*target.charge
  assert nearest>0 and key<0
  witness={'movingAtom':identity(moving),'fixedTarget':identity(target),'pairCoefficients':c,'excluded':False,'movingAtomConstrained':moving.idx in constrained,'movingAtomHasBondedTerms':bool(moving.bond_partners),'CoulombPrefactorKjNmMolE2':COULOMB,'chargeProduct':moving.charge*target.charge,'attractiveCoulombCoefficientKjNmMol':key,'closestOtherFixedAtomDistanceNm':nearest,'safeApproachBallRadiusNm':nearest/4,'path':'Move only the unbonded/unconstrained negative ion toward the fixed positive zero-LJ H along a generic ray. All other coordinates, including every bonded anchor and water constraint, remain fixed.','asymptote':'U_total(r)=K/r+O(1), K<0, asr→0. PairA12=B6=C4=0. Other atom centers lie outside a positive-radius approach ball; their finite coefficient interactions stay bounded. Fixed-box finite-mode Ewald reciprocal/self/background remain bounded.','scope':'An inherited point-charge/zero-LJ mathematical endpoint singularity, not a new C4 instability or demonstrated practical MD collapse.','nativeEndpointsAndGloballyBoundedUnrestrictedHamiltonianCompatible':False}
  curve=[{'separationNm':10.**(-k),'pairCoulombEnergyKjMol':key/(10.**(-k)),'LJ':0.,'C4':0.}for k in range(1,16)]
  save(OUT/'native-coulomb-collapse-witness.json',witness);save(OUT/'native-coulomb-pair-asymptote.json',{'scope':'Exactpairenergyonly; not fullforce/fullconfiguration energies','curve':curve})
  report['inheritedCoulombZeroLJWitness']={'found':True,'negativeFreeIonCount':len(negative_free),'witnessCount':len(witnesses),'witness':witness,'warning':'This prevents a global bounded-below/full-configuration-space theorem while preserving unrestricted native endpoints exactly. It does not establish a sampled practical instability, and any new domain/core restriction would require an explicit physical model policy.'}
 else:report['inheritedCoulombZeroLJWitness']={'found':False,'negativeFreeIonCount':len(negative_free),'scope':'No free-negative-ion witness found; this is not a universal boundedness proof.'}
 report['conclusions']={'C4SpecificZeroRepulsionCounterexample':bool(danger),'C4PairShortRangeRepulsionPresentForActualPositiveC4':not danger,'c4CandidateAdvice':'Couple C4 and its associated LJ via a common softened radial variable for changing interactions; do not claim that solves independent Coulomb/zero-LJ endpoint or interior-softcore singularities.','endpointPreservationCaveat':'Exact native endpoint preservation and globally bounded unrestricted Hamiltonian can be mutually incompatible because of inherited native Coulomb terms. A restricted/admissible distance domain is a separate model policy, not an invisible implementation fix.'}
 for item in report['sources']:assert digest(ROOT/item['path'])==item['sha256']
 report['status']='completed_source_bound_stability_audit';report['passedAudit']=True
except Exception as e:report['status']='failed';report['failures'].append({'message':str(e),'traceback':traceback.format_exc()});raise
finally:save(OUT/'native-stability.json',report)
print(json.dumps({'status':report['status'],'MgC4PositivePairs':report.get('MgC4Audit',{}).get('positiveC4PhysicalPairs'),'C4ZeroA12Pairs':report.get('MgC4Audit',{}).get('positiveC4WithZeroA12'),'inheritedWitness':report.get('inheritedCoulombZeroLJWitness',{}).get('found'),'reportSha256':digest(OUT/'native-stability.json')}))
