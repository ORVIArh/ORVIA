#!/usr/bin/env python3
"""Independent source/tail golden and explicit caller-boundary implementation."""
from pathlib import Path
from collections import Counter
import gzip,hashlib,importlib.util,inspect,json,math,tempfile,traceback
import mpmath as mp
import numpy as np
import openmm as mm
from openmm import app,unit,version
from candidate_reference import BASE,ROOT,INPUT,SCI,M,load,sha,save,parameters,tail

mp.mp.dps=110
def switch(r,rs,rc):
 if r<=rs:return mp.mpf(1),mp.mpf(0)
 if r>=rc:return mp.mpf(0),mp.mpf(0)
 x=(r-rs)/(rc-rs)
 return 1-10*x**3+15*x**4-6*x**5,-30*x*x*(1-x)**2/(rc-rs)
def caller(a,r,p,rc=mp.mpf(1),rs=mp.mpf('.9')):
 if r>=rc or a==0:return mp.mpf(0),mp.mpf(0)
 rho=r**6+mp.mpf('.5')*p['D']*(1-a)**2
 lj=p['A']/rho**2-p['B']/rho;c4=-p['C']/rho**(mp.mpf(2)/3);s,sp=switch(r,rs,rc)
 drlj=6*r**5*(-2*p['A']/rho**3+p['B']/rho**2);drc4=4*p['C']*r**5/rho**(mp.mpf(5)/3)
 return a*(s*lj+c4),a*(sp*lj+s*drlj+drc4)
def main():
 policy=load(BASE/'source-cutoff-preregistration.json');report={'schema':'orvia.c4-source-cutoff-supplement.v1','status':'in_progress','passed':False,'policySha256':sha(BASE/'source-cutoff-preregistration.json'),'scriptSha256':sha(Path(__file__)),'checks':[],'referenceCases':[],'failures':[],'scope':policy['scope'],'scientificAcceptance':False,'LJEndpointProtocolSelected':False,'fullHamiltonianEvaluated':False,'onChainImplemented':False,'engine':{'fullVersion':version.full_version,'gitRevision':version.git_revision}}
 def check(ok,name,**facts):
  report['checks'].append({'passed':bool(ok),'criterion':name,**facts})
  if not ok:raise AssertionError(name)
 try:
  metadata=load(BASE/'explicit-activity-metadata.json');groups=metadata['groups']
  for g in groups:g['pair']={k:mp.mpf(v)for k,v in g['pair'].items()}
  full=load(INPUT/'legs/complex33/c4.unresolved.json.gz')['nativeWrittenTables'];mapping=load(INPUT/'legs/complex33/global-map.json.gz');h=load(SCI/'ligand_endpoints_v0_1/hybrid_model.json');types=[int(v)-1 for v in full['ATOM_TYPE_INDEX']];nt=math.isqrt(len(full['NONBONDED_PARM_INDEX']));fac=4.184*.1**4
  coeff={(i,j):float(full['LENNARD_JONES_CCOEF'][int(full['NONBONDED_PARM_INDEX'][i*nt+j])-1])*fac for i in range(nt)for j in range(nt)}
  # H25's physical type is independently established by raw native A HC identity
  # and exact diagonal A/B coefficients, not a hardcoded C4 literal.
  atop=app.AmberPrmtopFile(str(SCI/'ligand_endpoints_v0_1/A/ligand.prmtop'))._prmtop._raw_data;na=math.isqrt(len(atop['NONBONDED_PARM_INDEX']));ta=int(atop['ATOM_TYPE_INDEX'][25])-1;ia=int(atop['NONBONDED_PARM_INDEX'][ta*na+ta])-1
  candidates=[]
  for t in set(types):
   names={full['AMBER_ATOM_TYPE'][i]for i,x in enumerate(types)if x==t}
   index=int(full['NONBONDED_PARM_INDEX'][t*nt+t])-1
   # Full C4 sidecar retains type/matrix labels; original A/B LJ tables come
   # from the base native prmtop through the published C4 type audit.
   if names=={atop['AMBER_ATOM_TYPE'][25]}:candidates.append(t)
  check(candidates==[21],'Native A H25 type maps uniquely to full HC22 by actual atom-type identity',candidates=candidates)
  source_full=SCI/'cardiac_adppi_ff03_m3l_33_782_solvated_v0_1/complex_1264.prmtop.gz'
  with tempfile.TemporaryDirectory(dir=BASE)as temporary:
   filename=Path(temporary)/'native.prmtop';filename.write_bytes(gzip.decompress(source_full.read_bytes()));fullraw=app.AmberPrmtopFile(str(filename))._prmtop._raw_data
   index=int(fullraw['NONBONDED_PARM_INDEX'][21*nt+21])-1
   check(all(float(fullraw[key][index])==float(atop[key][ia])for key in ['LENNARD_JONES_ACOEF','LENNARD_JONES_BCOEF']),'Native A HC diagonal LJ coefficients exactly match selected full HC22')
  report['sourceFiles']=[{'path':str(path.relative_to(ROOT)),'sha256':sha(path)}for path in [source_full,SCI/'ligand_endpoints_v0_1/A/ligand.prmtop',INPUT/'legs/complex33/c4.unresolved.json.gz',INPUT/'legs/complex33/global-map.json.gz',BASE/'explicit-activity-metadata.json']]
  audit=load(INPUT/'c4-audit/native-union-c4.json');report['nativeTypeAuditSha256']=sha(INPUT/'c4-audit/native-union-c4.json')
  countsB=Counter(types);countsA=countsB.copy()
  for g in groups:
   typ=21 if g['group']=='A'else types[g['globalAtom']]
   check(g['pair']['C']==M(coeff[32,typ]),'Unique coefficient exactly equals actual full native table',hybridAtom=g['hybridAtom'],nativeTypeIndex=typ+1)
   countsA[typ]+=1 if g['group']=='A'else -1
  spec=importlib.util.spec_from_file_location('independent_lrc',INPUT/'c4-endpoint/independent-lrc/analytic_c4.py');oracle=importlib.util.module_from_spec(spec);spec.loader.exec_module(oracle)
  report['independentLrcModuleSha256']=sha(INPUT/'c4-endpoint/independent-lrc/analytic_c4.py')
  box=load(SCI/'cardiac_adppi_ff03_m3l_33_782_solvated_v0_1/particle_cost_inputs.json.gz')['box_nm'];volume=mp.fprod(map(M,box));native_weight=mp.fsum(M(coeff[32,t])for i,t in enumerate(types)if i!=12132)+M(coeff[32,32]);common=native_weight-mp.fsum(g['pair']['C']for g in groups if g['group']=='B')
  for endpoint,lam,counts in [('A',0,countsA),('B',1,countsB)]:
   actual=tail(groups,common,132931,M(lam),volume)[0];expected=oracle.analytic_lrc_energy(counts,coeff,box,1.,decimal_digits=110)
   check(abs(actual-expected)<=mp.mpf('1e-85')+mp.mpf('1e-80')*abs(expected),'Independent whole-class native C4 tail endpoint golden',endpoint=endpoint,actual=actual,expected=expected,physicalAtoms=sum(counts.values()))
  # Separate implementation in OpenMM Reference. Diagnostic LJ switch applies
  # only to LJ; C4 remains exactly unswitched and hard-truncated by the engine.
  expression='a*(sw*(A/rho^2-B/rho)-C/rho^(2/3));rho=r^6+0.5*D*(1-a)^2;sw=1-10*x^3+15*x^4-6*x^5;x=min(1,max(0,(r-rs)/(rc-rs)))'
  expression_hash=hashlib.sha256(expression.encode()).hexdigest();radii=list(map(mp.mpf,policy['radiiNm']));activities=list(map(mp.mpf,policy['activities']));component_count=0
  for g in groups:
   p=g['pair'];system=mm.System();system.addParticle(24.3);system.addParticle(12.01);system.setDefaultPeriodicBoxVectors(mm.Vec3(4,0,0),mm.Vec3(0,4,0),mm.Vec3(0,0,4))
   f=mm.CustomNonbondedForce(expression)
   for name,value in [('a',0),('A',p['A']),('B',p['B']),('C',p['C']),('D',p['D']),('rs',mp.mpf('.9')),('rc',mp.mpf(1))]:f.addGlobalParameter(name,float(value))
   f.addParticle([]);f.addParticle([]);f.setNonbondedMethod(mm.CustomNonbondedForce.CutoffPeriodic);f.setCutoffDistance(1);f.setUseSwitchingFunction(False);f.setUseLongRangeCorrection(False);system.addForce(f);integrator=mm.VerletIntegrator(.001);context=mm.Context(system,integrator,mm.Platform.getPlatformByName('Reference'))
   try:
    for a in activities:
     context.setParameter('a',float(a))
     for radius in radii:
      # Oracle uses exact submitted binary64 geometry and coefficients, while
      # the mathematical native endpoint identity remains checked separately.
      r=M(float(radius));source_p={k:M(float(p[k]))for k in ['A','B','C','D']};source_a=M(float(a));E,F=caller(source_a,r,source_p)
      context.setPositions([[0,0,0],[float(radius),0,0]]);state=context.getState(getEnergy=True,getForces=True);actualE=float(state.getPotentialEnergy().value_in_unit(unit.kilojoule_per_mole));actualF=np.asarray(state.getForces(asNumpy=True).value_in_unit(unit.kilojoule_per_mole/unit.nanometer));expectedF=np.zeros((2,3));expectedF[0,0]=float(F);expectedF[1,0]=-float(F);e_error=abs(actualE-float(E));f_error=np.abs(actualF-expectedF);e_tol=policy['ReferenceEnergyAbsoluteTolerance']+policy['ReferenceEnergyRelativeTolerance']*abs(float(E));f_tol=policy['ReferenceForceAbsoluteTolerance']+policy['ReferenceForceRelativeTolerance']*np.abs(expectedF)
      passed=e_error<=e_tol and np.all(f_error<=f_tol);check(passed,'Independent Reference candidate caller energy/force',hybridAtom=g['hybridAtom'],activity=a,r=radius)
      report['referenceCases'].append({'hybridAtom':g['hybridAtom'],'activity':a,'rNm':radius,'actualEnergy':actualE,'expectedEnergy':E,'energyError':e_error,'energyTolerance':e_tol,'maxForceError':float(f_error.max()),'passed':bool(passed)});component_count+=6
    a=mp.mpf('.5');rho=1+mp.mpf('.5')*p['D']*(1-a)**2;left=-a*p['C']/rho**(mp.mpf(2)/3);at=caller(a,mp.mpf(1),p)[0]
    check(left<0 and at==0,'Native-style C4 cutoff jump retained, not falsely smoothed',hybridAtom=g['hybridAtom'],analyticLeftLimit=left,atCutoff=at)
   finally:del context,integrator,system
  report.update(status='passed_source_tail_and_caller_boundary_component_checks',passed=True,referenceContexts=len(groups),forceComponentsCompared=component_count,expression=expression,expressionSha256=expression_hash,cutoffConvention='Diagnostic1nm periodic; LJ-onlyswitch0.9nm; C4unswitched, tails tested separately. Full native LJ protocol remains unselected.',globalCutoffSmoothness=False)
 except Exception as error:report['status']='failed';report['failures'].append({'message':str(error),'traceback':traceback.format_exc()});raise
 finally:save(BASE/'source-cutoff-validation.json',report)
 print(json.dumps({'status':report['status'],'checks':len(report['checks']),'forceComponents':report.get('forceComponentsCompared'),'sha256':sha(BASE/'source-cutoff-validation.json')}))

if __name__=='__main__':main()
