#!/usr/bin/env python3
"""Evaluate a dedicated quantum-candidate geometry with native OpenMM Reference."""
from pathlib import Path
import argparse
import json
import hashlib
import numpy as np
import openmm as mm
from openmm import unit

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--system', type=Path, required=True)
parser.add_argument('--positions', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
source = args.system.read_bytes()
system = mm.XmlSerializer.deserialize(source.decode())
positions = json.loads(args.positions.read_text())
integrator = mm.VerletIntegrator(0.001 * unit.picoseconds)
context = mm.Context(system, integrator, mm.Platform.getPlatformByName('Reference'))
context.setPositions(np.asarray(positions) * unit.angstrom)
energy = context.getState(getEnergy=True).getPotentialEnergy().value_in_unit(unit.kilojoule_per_mole)
components = []
for i in range(system.getNumForces()):
    force = system.getForce(i)
    value = context.getState(getEnergy=True, groups=1 << force.getForceGroup()).getPotentialEnergy().value_in_unit(unit.kilojoule_per_mole)
    components.append({'group': force.getForceGroup(), 'class': force.__class__.__name__, 'energy_kJ_per_mol': value})
args.output.write_text(json.dumps(dict(platform='Reference', openmm_version=mm.version.full_version,
    system_sha256=hashlib.sha256(source).hexdigest(), energy_kJ_per_mol=energy, components=components), indent=2) + '\n')
