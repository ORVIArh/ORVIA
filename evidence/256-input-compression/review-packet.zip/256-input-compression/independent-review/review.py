from pathlib import Path
import gzip,hashlib,json
root=Path('/Users/abhijith/Documents/ChatGPT/AURA/output/256-input-compression')
r=json.loads((root/'overlay-audit.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
checks=[]
def ck(v,msg):
 if not v:raise ValueError(msg)
 checks.append(msg)
ck(sha((root/'audit_overlay.py').read_bytes())==r['scriptSha256'],'Audit source hash')
for f in r['sourceFiles']:ck(sha(Path(f['path']).read_bytes())==f['sha256'],'Source '+Path(f['path']).name)
base_words=base_slots=base_nz=base_tx=pack_tx=patches=patch_tx=tozero=logical=baseline_tx=0
for leg,info in r['legs'].items():
 raw={}
 for name,s in info['streams'].items():
  a=gzip.decompress(Path(s['sourcePath']).read_bytes());ck(sha(a)==s['rawSha256'],'Raw hash '+leg+'/'+name);ck(len(a)==s['logicalWords']*32,'Word count '+leg+'/'+name)
  n=len(a)//32;logical+=n;baseline_tx+=(n+127)//128
  words=[a[k:k+32] for k in range(0,len(a),32)];ck(all(w[:16]==bytes(16) for w in words),'Upper128zero '+leg+'/'+name)
  low=b''.join(w[16:] for w in words);packed=low+(bytes(16) if n%2 else b'');rebuilt=b''.join(bytes(16)+packed[k*16:k*16+16] for k in range(n));ck(a==rebuilt,'Independent128 decode '+leg+'/'+name)
  nz=sum(packed[k:k+32]!=bytes(32) for k in range(0,len(packed),32));ck(len(packed)//32==s['packed128PhysicalSlots'] and nz==s['packed128NonzeroPhysicalSlots'],'Packed counts '+leg+'/'+name)
  if not name.startswith('B.'):
   base_words+=n;base_slots+=len(packed)//32;base_nz+=nz;base_tx+=(n+127)//128;pack_tx+=((len(packed)//32)+127)//128
  raw[name]=a
 for role,p in info['overlay'].items():
  buf=Path(p['patchArtifact']['file']).read_bytes();ck(sha(buf)==p['patchArtifact']['sha256'],'Patch gzip '+leg+'/'+role);payload=gzip.decompress(buf);ck(sha(payload)==p['patchArtifact']['rawSha256'],'Patch raw '+leg+'/'+role)
  a,b=raw['A.'+role],raw['B.'+role];out=bytearray(a);last=-1;changed=0
  for k in range(0,len(payload),32):
   word=int.from_bytes(payload[k:k+32],'big');idx=word&((1<<64)-1);val=word>>64
   ck(last<idx<len(a)//32 and val<1<<128,'Patch sorted/bounded '+leg+'/'+role+'/'+str(idx));last=idx
   encoded=(1<<128)|val;ck(encoded!=0 and encoded>>128==1,'Presence marker '+leg+'/'+role+'/'+str(idx))
   v=(encoded&((1<<128)-1)).to_bytes(32,'big');ck(a[idx*32:idx*32+32]!=v,'Patch changes '+leg+'/'+role+'/'+str(idx));out[idx*32:idx*32+32]=v;changed+=1;tozero+=val==0
  ck(bytes(out)==b,'All target bytes recovered '+leg+'/'+role);ck(changed==p['changedWords'],'Patch count '+leg+'/'+role);patches+=changed;patch_tx+=(changed+127)//128
 expected=Path(r['inputRoot'])/'legs'/leg/'catalog-candidate.json';m=json.loads(expected.read_text());alias=m['streams']['B.particles'];ck(alias.get('aliasOf')=='A.particles' and gzip.decompress((Path(r['inputRoot'])/alias['path']).read_bytes())==raw['A.particles'],'Particle alias '+leg)
expected={'logicalWords':logical,'baselineAppendTransactions':baseline_tx,'baseLogicalWords':base_words,'basePacked128Slots':base_slots,'basePacked128NonzeroSlots':base_nz,'baseAppendTransactions':base_tx,'basePacked128AppendTransactions':pack_tx,'overlayChangedWords':patches,'overlayChangedToZeroWords':tozero,'overlayPatchAppendTransactions':patch_tx,'packedOverlayAppendTransactions':pack_tx+patch_tx,'packedOverlayUploadTransactions':pack_tx+patch_tx+48}
ck(logical==10903836 and baseline_tx==85195,'Baseline totals');ck(base_slots==3223734 and base_nz==2628236 and patches==466 and tozero==58,'Storage totals');ck(pack_tx+patch_tx==25201,'Physical128 append total');
result={'passed':True,'readOnlySourceReview':True,'scriptSha256':sha(Path(__file__).read_bytes()),'reviewedAuditSha256':sha((root/'overlay-audit.json').read_bytes()),'checks':len(checks),'independentTotals':expected,'caveats':['Format and transaction-count projection only; no current contract support or target gas quote.','New append API must permit128physical packed words=up to256logical words and bounded hash work.','Each patch is a32byte physical payload record encoding uint64 index+uint128value; on-chain storage must set explicitpresencebit128 even when value0.','On-chain admission must reject noncanonical reserved bits, nonascending or duplicate/out-of-rangeindices, malformedlengths, unsealed/mismatched/cyclicbases and invalidpackedpadding.','Commitment must bind encodingversion, logicalwordcount, role, chain/catalog, sealedbase commitment and ordered patchdata; newcommitment is not oldlogicalrollingdigest.','10overlaystream begin/sealcount assumes API can establishbase andencodingmetadata inthosecalls; additionalconfig transactions would increasecount.','Scientific acceptance and omitted C4/constraints/policy inputs remain unchanged.']}
Path(__file__).with_name('review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
