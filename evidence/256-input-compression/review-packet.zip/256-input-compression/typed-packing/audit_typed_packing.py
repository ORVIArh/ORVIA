#!/usr/bin/env python3
"""Offline, bit-exact role-typed packing audit. Does not change catalog or source inputs."""
import argparse, gzip, hashlib, json, math, sys, time
from pathlib import Path
import numpy as np

ROLES = {
 'positions': [('x','f'),('y','f'),('z','f')],
 'particles': [('mass','f'),('vx','f'),('vy','f'),('vz','f')],
 'nonbonded': [('sigma','f'),('epsilon','f'),('charge','f')],
 'bonds': [('a','a'),('b','a'),('k','f'),('r0','f')],
 'angles': [('a','a'),('b','a'),('c','a'),('k','f'),('theta0','f')],
 'torsions': [('a','a'),('b','a'),('c','a'),('d','a'),('periodicity','n'),('k','f'),('phase','f')],
 'exceptions': [('a','a'),('b','a'),('kind','n'),('sigma','f'),('epsilon','f'),('desiredChargeProduct','f')],
}
U=np.uint64
MASK48=U((1<<48)-1); MASK60=U((1<<60)-1)
def sha(b): return hashlib.sha256(b).hexdigest()
def readj(p): return json.loads(p.read_text())
def writej(p,d): p.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
def to64(hi,lo):
    """Invert binary64->binary128 exactly, using only integer bits."""
    sign=hi>>U(63); exp=(hi>>U(48))&U(32767); frac=hi&MASK48
    zero=((hi&U((1<<63)-1))==0)&(lo==0)
    normal=(exp>=15361)&(exp<=17406)&((lo&MASK60)==0)
    bits=(sign<<U(63))|((exp-U(15360))<<U(52))|(frac<<U(4))|(lo>>U(60))
    bits[zero]=sign[zero]<<U(63)
    rare=~(normal|zero)
    for i in np.flatnonzero(rare):
        e=int(exp[i]); sig=(1<<112)+(int(frac[i])<<64)+int(lo[i]); shift=16383-e-962
        if not(15309<=e<=15360 and 61<=shift<=112 and sig% (1<<shift)==0):
            raise AssertionError(f'non-IEEE64 binary128 at scalar {i}: {int(hi[i]):016x}{int(lo[i]):016x}')
        mant=sig>>shift
        assert 0<mant<(1<<52)
        bits[i]=U((int(sign[i])<<63)|mant)
    return bits,{'zero':int(zero.sum()),'negativeZero':int((zero&(sign!=0)).sum()),'normal':int(normal.sum()),'subnormal':int(rare.sum())}
def expand64(bits):
    sign=bits>>U(63); e=(bits>>U(52))&U(2047); m=bits&U((1<<52)-1)
    assert np.all(e<2047)
    hi=(sign<<U(63))|((e+U(15360))<<U(48))|(m>>U(4)); lo=(m&U(15))<<U(60)
    zero=(e==0)&(m==0); hi[zero]=sign[zero]<<U(63);lo[zero]=0
    for i in np.flatnonzero((e==0)&(m!=0)):
        v=int(m[i]); top=v.bit_length()-1; q=((int(sign[i])<<127)|((top-1074+16383)<<112)|((v-(1<<top))<<(112-top)))
        hi[i]=U(q>>64);lo[i]=U(q&((1<<64)-1))
    return hi,lo

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--aura-root',type=Path,default=Path(__file__).resolve().parents[3]); ap.add_argument('--output-dir',type=Path,default=Path(__file__).resolve().parent);args=ap.parse_args()
    root=args.aura_root.resolve(); out=args.output_dir.resolve(); out.mkdir(parents=True,exist_ok=True)
    inputs=root/'output/full-hybrid-inputs'; overlaypath=root/'output/256-input-compression/overlay-audit.json'; overlay=readj(overlaypath)
    assert overlay['passed'] and overlay['totals']['overlayChangedWords']==466
    sourcepaths=[inputs/'assemble_full_hybrid.py',root/'ORVIA/contracts/core/AlchemicalTopologyCatalog.sol',overlaypath]
    hashes={str(p.relative_to(root)):sha(p.read_bytes()) for p in sourcepaths}
    result={'schema':'orvia.lossless-role-typed-packing-audit.v1','status':'in_progress','passed':False,'onChainImplemented':False,'scientificAcceptance':False,'sourceInputsModified':False,'contractsModified':False,'sourceHashes':hashes,'scriptSha256':sha(Path(__file__).read_bytes()),'layouts':{},'streams':{},'aliases':[]}
    report=out/'typed-packing-audit.json';writej(report,result)
    names=['dense_f64_u32','record_f64_u32','dense_f64_u24_u8','record_f64_u24_u8']
    totals={name:{'allUniqueStreams':{'logicalWords':0,'payloadSlots':0,'nonzeroPayloadSlots':0,'appendTransactions128':0},'fourteenBases':{'logicalWords':0,'payloadSlots':0,'nonzeroPayloadSlots':0,'appendTransactions128':0}} for name in names}
    aggregate={'uniqueStreams':0,'aliasedDescriptors':0,'logicalWords':0,'floatWords':0,'integerWords':0,'zeroLogicalWords':0,'nonzeroLogicalWords':0,'floatZeroWords':0,'integerZeroWords':0,'negativeFloatZeroWords':0,'floatNormalWords':0,'floatSubnormalWords':0,'floatNonRecoverableWords':0,'upper128NonzeroWords':0,'maxAtomIndex':0,'maxPeriodicity':0,'maxKind':0,'baseLogicalWords':0,'baseNonzeroLogicalWords':0}
    for leg in ['complex33','solvent33']:
        mp=inputs/'legs'/leg/'catalog-candidate.json';hashes[str(mp.relative_to(root))]=sha(mp.read_bytes());manifest=readj(mp);seen={}
        for label,desc in sorted(manifest['streams'].items()):
            key=f'{leg}/{label}';p=inputs/desc['path'];compressed=p.read_bytes();assert sha(compressed)==desc['gzipSha256'];hashes[str(p.relative_to(root))]=desc['gzipSha256']
            if desc['path'] in seen:
                assert desc['rawSha256']==seen[desc['path']]['rawSha256'];result['aliases'].append({'stream':key,'samePathAs':seen[desc['path']]['stream'],'rawSha256':desc['rawSha256']});aggregate['aliasedDescriptors']+=1;continue
            seen[desc['path']]={'stream':key,'rawSha256':desc['rawSha256']}
            raw=gzip.decompress(compressed);assert len(raw)==desc['rawBytes']==desc['wordCount']*32 and sha(raw)==desc['rawSha256']
            role=label.split('.')[-1];fields=ROLES[role];w=len(fields);assert desc['wordCount']%w==0;n=desc['wordCount']//w
            q=np.frombuffer(raw,dtype='>u8').reshape(n,w,4);assert np.all(q[:,:,:2]==0)
            zeros=np.all(q==0,axis=2);base=label.startswith('A.') or label=='positions'
            info={'sourcePath':desc['path'],'gzipSha256':desc['gzipSha256'],'rawSha256':desc['rawSha256'],'records':n,'role':role,'logicalWords':desc['wordCount'],'zeroLogicalWords':int(zeros.sum()),'upper128AllZero':True,'isOverlayBase':base,'fields':{},'layouts':{}}
            fieldbytes=[];bitvalues=[]
            for j,(field,kind) in enumerate(fields):
                if kind=='f':
                    bits,stats=to64(q[:,j,2].astype('uint64'),q[:,j,3].astype('uint64'));h,l=expand64(bits)
                    assert np.array_equal(h,q[:,j,2]) and np.array_equal(l,q[:,j,3]);info['fields'][field]={'kind':'binary128_exact_binary64_embedding','words':n,'exactRecoverable':True,**stats}
                    aggregate['floatWords']+=n;aggregate['floatZeroWords']+=stats['zero'];aggregate['negativeFloatZeroWords']+=stats['negativeZero'];aggregate['floatNormalWords']+=stats['normal'];aggregate['floatSubnormalWords']+=stats['subnormal']
                else:
                    assert np.all(q[:,j,:3]==0);bits=q[:,j,3].astype('uint64');maxi=int(bits.max(initial=0));assert maxi<(1<<32)
                    assert maxi<(1<<24) if kind=='a' else maxi<256
                    if field=='periodicity': assert np.all((bits>=1)&(bits<=64));aggregate['maxPeriodicity']=max(aggregate['maxPeriodicity'],maxi)
                    elif field=='kind': assert np.all((bits==1)|(bits==2));aggregate['maxKind']=max(aggregate['maxKind'],maxi)
                    else: assert np.all(bits<manifest['counts']['hybrid']);aggregate['maxAtomIndex']=max(aggregate['maxAtomIndex'],maxi)
                    info['fields'][field]={'kind':'atom_index' if kind=='a' else field,'words':n,'max':maxi,'requiredUnsignedBits':maxi.bit_length(),'zeroWords':int((bits==0).sum())}
                    aggregate['integerWords']+=n;aggregate['integerZeroWords']+=int((bits==0).sum())
                bitvalues.append(bits)
            for name in names:
                compact='u24' in name;align=name.startswith('record');sizes=[8 if k=='f' else (3 if k=='a' else 1) if compact else 4 for _,k in fields];recordbytes=sum(sizes);stride=((recordbytes+31)//32)*32 if align else recordbytes
                packedrows=np.zeros((n,stride),dtype=np.uint8);off=0
                for bits,size in zip(bitvalues,sizes):
                    b=bits.astype('>u8').view('uint8').reshape(n,8);packedrows[:,off:off+size]=b[:,8-size:];off+=size
                packed=packedrows.tobytes();packed+=b'\0'*((-len(packed))%32)
                data=np.frombuffer(packed,dtype='uint8');rows=data[:n*stride].reshape(n,stride);reconstructed=np.zeros((n,w,4),dtype='>u8');off=0
                for j,((field,kind),size) in enumerate(zip(fields,sizes)):
                    b=np.zeros((n,8),dtype='uint8');b[:,8-size:]=rows[:,off:off+size];bits=b.tobytes();v=np.frombuffer(bits,dtype='>u8').astype('uint64');off+=size
                    if kind=='f': h,l=expand64(v);reconstructed[:,j,2]=h;reconstructed[:,j,3]=l
                    else: reconstructed[:,j,3]=v
                rebuilt=reconstructed.tobytes();assert rebuilt==raw and sha(rebuilt)==desc['rawSha256']
                slots=len(packed)//32;nz=int(np.any(data.reshape(slots,32)!=0,axis=1).sum());rec={'recordBytes':recordbytes,'recordStrideBytes':stride,'slotCount':slots,'nonzeroSlots':nz,'zeroSlots':slots-nz,'packedBytes':len(packed),'packedSha256':sha(packed),'expandedRawSha256':sha(rebuilt),'allBytesRoundtripVerified':True,'appendTransactions128':math.ceil(slots/128),'fields':[{'name':f,'bytes':s} for (f,_),s in zip(fields,sizes)]};info['layouts'][name]=rec
                for target in ['allUniqueStreams']+(['fourteenBases'] if base else []):
                    t=totals[name][target];t['logicalWords']+=desc['wordCount'];t['payloadSlots']+=slots;t['nonzeroPayloadSlots']+=nz;t['appendTransactions128']+=rec['appendTransactions128']
            result['streams'][key]=info
            aggregate['uniqueStreams']+=1;aggregate['logicalWords']+=desc['wordCount'];aggregate['zeroLogicalWords']+=info['zeroLogicalWords'];aggregate['nonzeroLogicalWords']+=desc['wordCount']-info['zeroLogicalWords']
            if base: aggregate['baseLogicalWords']+=desc['wordCount'];aggregate['baseNonzeroLogicalWords']+=desc['wordCount']-info['zeroLogicalWords']
            print(f'{key}: {desc["wordCount"]} words exact float/integer + four packing roundtrips PASS',flush=True)
    assert aggregate['uniqueStreams']==24 and aggregate['aliasedDescriptors']==2 and aggregate['logicalWords']==10903836 and aggregate['baseLogicalWords']==6447465
    assert aggregate['floatWords']+aggregate['integerWords']==aggregate['logicalWords'];assert aggregate['zeroLogicalWords']==3131996 and aggregate['baseNonzeroLogicalWords']==4454765
    for name,t in totals.items():
        base=t['fourteenBases'];t['fourteenBasesPlusParentTaggedOverlays']={**base,'overlayPatchSlots':466,'overlayZeroOverrideSlots':58,'payloadSlots':base['payloadSlots']+466,'nonzeroPayloadSlots':base['nonzeroPayloadSlots']+466,'appendTransactions128':base['appendTransactions128']+overlay['totals']['overlayPatchAppendTransactions'],'beginSealTransactionsAssumedUnchanged':48,'totalUploadTransactionsAssuming128PayloadsPerAppend':base['appendTransactions128']+overlay['totals']['overlayPatchAppendTransactions']+48}
    for rel,h in hashes.items():assert sha((root/rel).read_bytes())==h,f'source changed {rel}'
    result.update(status='passed_lossless_offline_format_audit_not_implemented',passed=True,aggregate=aggregate,layouts=totals,sourceHashesVerifiedAfterAudit=True,claims={'binary64OnlyTransportEncoding':True,'allComputationStillBinary128':True,'allUniqueSourceWordsExactRoundtripPerLayout':aggregate['logicalWords'],'allUniqueRoundtripLayoutComparisons':aggregate['logicalWords']*len(names),'packedPayloadsPersisted':False,'workingStateNotIncluded':True,'unresolvedC4AndConstraintStreamsNotIncluded':True},limitations=['No Solidity typed decoder, integration, gas measurement, deployment, or scientific acceptance.','Counts cover the exact 24 current catalog streams only; C4, constraints, metadata, mappings, bank initialization and commitments are excluded.','Zero words already have no allocated raw data mapping slot; logical payload slots and nonzero allocated data slots are reported separately.','Append counts assume a future unchanged 128-payload limit and 48 begin/seal calls; typed serialization needs an explicit bound decoder and commitment design.','Each logical typed field is at most eight bytes and intersects at most two packed slots; full 36-byte u32 records also need at most two slots.','Formats explicitly bind role, field widths, record count and zero padding; malformed/nonrepresentable values must be rejected.'])
    writej(report,result);print(json.dumps({'aggregate':aggregate,'layouts':totals},indent=2),flush=True)
if __name__=='__main__':main()
