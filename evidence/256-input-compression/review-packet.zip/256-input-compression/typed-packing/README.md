# Exact role-typed input packing: offline audit

This is an offline candidate encoding, not an implemented contract, measured gas saving, deployment, or scientific acceptance. No source input or canonical contract was changed. It covers the 24 unique current position/parameter streams; two B particle descriptors alias A. The unresolved C4 and constraint side streams, working state, metadata, commitments and initialization are outside these counts.

The audit verified compressed and raw source hashes, checked every role field against the assembler/catalog layout, then packed and reconstructed every original 32-byte word under each of four formats. All 10,903,836 unique source words were exactly reconstructed in every format: 43,615,344 layout-word comparisons. Source hashes were checked again afterward.

All original words have zero upper 128 bits. The binary128 float occupies the **low 128 bits** of each bytes32. All 7,138,962 float words are exact embeddings of IEEE binary64: 4,007,112 normal values and 3,131,850 positive zeros; no negative zero, subnormal, nonfinite or nonrecoverable value occurred. This permits an exact transport encoding as eight-byte binary64 bits, expanded to the original binary128 bits before use. It does not permit performing the simulation in binary64 or packing future calculated state this way.

There are 3,764,874 integer words, all within uint32. The largest explicit atom index is 151,223 (18 bits), maximum torsion periodicity is 4, and exception kind is at most 2. There are 146 zero integer words. The uint24/u8 option must declare and enforce its narrower domain; it is not a generic replacement for uint32 atom indices.

## Exact formats

Fields follow the existing role order. Big-endian bits are concatenated in each record; padding is zero. Dense formats concatenate records without row padding and pad only the stream end to 32 bytes. Record formats pad each record to a multiple of 32 bytes.

| Role | Fields | f64/u32 record bytes | f64/u24/u8 record bytes |
|---|---|---:|---:|
| positions | x,y,z floats | 24 | 24 |
| particles | mass,vx,vy,vz floats | 32 | 32 |
| nonbonded | sigma,epsilon,q floats | 24 | 24 |
| bonds | a,b indices; k,r0 floats | 24 | 22 |
| angles | a,b,c indices; k,theta0 floats | 28 | 25 |
| torsions | a,b,c,d indices; periodicity; k,phase floats | 36 | 29 |
| exceptions | a,b indices; kind; sigma,epsilon,desiredQprod floats | 36 | 31 |

The uint32 formats use four bytes for every integer; the optional compact formats use three for atom indices and one for periodicity/kind. All floats use eight-byte exact binary64 transport bits.

## Storage accounting with the parent's verified overlays

Totals below combine **only 14 A/positions bases** with the parent's 466 tagged B patches, including 58 zero overrides. Each tagged patch is nonzero because it contains a presence bit. They do not sum the 24 independent streams again. The parent overlay report is source-hash-bound in the audit.

| Format | Physical payload slots | Nonzero data slots | Append calls at 128 payloads | Total calls with assumed 48 begin/seal calls |
|---|---:|---:|---:|---:|
| Dense f64/u32 | 1,377,032 | 1,377,030 | 10,770 | 10,818 |
| Record f64/u32 | 1,929,777 | 1,594,205 | 15,089 | 15,137 |
| Dense f64/u24/u8 | 1,294,155 | 1,294,152 | 10,123 | 10,171 |
| Record f64/u24/u8 | 1,544,932 | 1,544,932 | 12,083 | 12,131 |

These are candidate payload/data counts, not gas estimates. Per-stream ceiling divisions are used for append calls. They assume a future 128-payload typed appender and the parent's 10 patch append calls and 48 begin/seal calls. A real typed appender, authorization and original logical-stream commitment validation are not implemented.

The full uncompressed 24-stream baseline has 10,903,836 logical words but only 7,771,840 nonzero data mapping slots; its 3,131,996 zero words already allocate no data slot. The 14 uncompressed bases have 6,447,465 logical words and 4,454,765 nonzero slots. Thus logical-word reduction must not be equated to the same reduction in allocated storage or gas. For example, particle velocity words are already zero, so four-fold logical particle packing does not save four-fold allocated particle data storage.

## Bounded access and required implementation

For logical word index i, compute record floor(i/roleWidth), field i modulo roleWidth, and its byte offset from the bound role schema. A field is at most eight bytes and spans at most two adjacent packed slots, so direct logical-word decoding requires at most two data SLOADs, without a scan. Each dense full record also intersects at most two slots: the only 36-byte records have four-byte alignment, and their largest starting offset is 28. Record-aligned uint32 torsion/exception records use two slots; other records use one. Every compact record fits one aligned slot. Metadata/dependency authentication reads are additional.

An implementation must bind codec ID, role, field widths/order, record and logical-word counts, padding and expanded logical commitment; reject malformed/nonrepresentable values; retain random access and bank bounds; and test exact byte/identity compatibility and measured gas. A packed byte hash is not interchangeable with the existing logical stream hash.

## Reproduce

Requires Python and NumPy. From an AURA checkout with the unchanged full-hybrid input archive restored at `output/full-hybrid-inputs` and the parent's `output/256-input-compression/overlay-audit.json`:

```sh
python audit_typed_packing.py --aura-root /absolute/path/to/AURA --output-dir /absolute/path/to/new-audit-output
```

The runner writes an incomplete report first, verifies all source hashes and all four pack/unpack layouts, then writes a passing report only at completion. Packed payloads are serialized and fully checked in memory; they are not persisted. Per-stream record layouts, raw and packed hashes, zero/nonzero counts and provenance are in `typed-packing-audit.json`. `audit.log` retains the actual completed run. `CHECKSUMS.sha256` freezes this packet.
