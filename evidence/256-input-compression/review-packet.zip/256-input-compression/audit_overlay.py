#!/usr/bin/env python3
"""Lossless storage-format research; never alters source inputs or contracts."""
from pathlib import Path
import argparse,gzip,hashlib,json,math,traceback
import numpy as np

def sha(b):return hashlib.sha256(b).hexdigest()
def write_json(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def gzwrite(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(b,mtime=0));return {'file':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'rawSha256':sha(b),'rawBytes':len(b)}
def batch(n):return (n+127)//128
def stats(raw):
 x=np.frombuffer(raw,dtype='>u8').reshape(-1,4);n=x.shape[0];zeros=np.all(x==0,axis=1);upperzero=np.all(x[:,:2]==0)
 if not upperzero:raise ValueError('Cannot use128-bit lossless encoding')
 values=np.ascontiguousarray(x[:,2:]).tobytes();assert len(values)==16*n
 # Every original32byteword is reconstructed from its low128bits.
 restore=np.zeros_like(x);restore[:,2:]=np.frombuffer(values,dtype='>u8').reshape(-1,2);assert restore.tobytes()==raw
 pad=(-len(values))%32;packed=values+b'\0'*pad;ps=np.frombuffer(packed,dtype='>u8').reshape(-1,4)
 return {'logicalWords':n,'zeroLogicalWords':int(zeros.sum()),'nonzeroLogicalWords':int(n-zeros.sum()),'allWordsUpper128Zero':bool(upperzero),'packed128PhysicalSlots':len(packed)//32,'packed128NonzeroPhysicalSlots':int(np.any(ps!=0,axis=1).sum()),'packed128ZeroPhysicalSlots':int(np.all(ps==0,axis=1).sum()),'packed128ByteRoundtripVerified':True,'rawSha256':sha(raw)}

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--input-root',type=Path,default=Path(__file__).resolve().parents[1]/'full-hybrid-inputs');parser.add_argument('--output-root',type=Path,default=Path(__file__).resolve().parent);args=parser.parse_args();src=args.input_root.resolve();out=args.output_root.resolve()
 report={'schema':'orvia.lossless-256-input-overlay-audit.v1','status':'in_progress','passed':False,'scriptSha256':sha(Path(__file__).read_bytes()),'inputRoot':str(src),'scientificAcceptance':False,'contractsModified':False,'sourceInputsModified':False,'onChainImplemented':False,'productionAddressesAdded':0,'publicTransactionsSent':0,'legs':{},'sourceFiles':[],'claims':['Logical bytes32 words must roundtrip byte-for-byte, including zero and IEEE sign bits.','96inputbanks+128workingstatebanks and32coreaddresses can be retained by a versioned catalog/bank implementation; no extra deployed dependency is required.','Upload transaction counts below are format projections at128payload records per append, not measured gas or current-contract support.'],'limitations':['Current BankedInputCatalog does not implement overlays or packed physical decoding.','Current original rolling logical digest differs from a versioned overlay commitment; a new commitment must bind role,length,sealed base commitment,sorted unique patches,and encoding policy.','Zero logical values currently occupy no nonzero EVM storage slot even though the existing code executes a zero SSTORE and includes them in upload/hash batches.','C4, constraints and experimental activity/policy streams are not in these24corestreams and remain additional mandatory inputs.']}
 target=out/'overlay-audit.json';write_json(target,report)
 try:
  totals={k:0 for k in ['baselineLogicalWords','baselineZeroLogicalWords','baselineNonzeroLogicalSlots','baselineAppendTransactions','baseLogicalWords','baseNonzeroLogicalSlots','baseZeroLogicalWords','baseAppendTransactions','overlayChangedWords','overlayChangedToZeroWords','overlayPatchAppendTransactions','basePacked128Slots','basePacked128NonzeroSlots','basePacked128AppendTransactions','logicalWordsVerified']}
  for leg in ['complex33','solvent33']:
   manifest_path=src/'legs'/leg/'catalog-candidate.json';manifest=json.loads(manifest_path.read_text());report['sourceFiles'].append({'path':str(manifest_path),'sha256':sha(manifest_path.read_bytes())});rows={};cache={};aliases={}
   for name,entry in manifest['streams'].items():
    if 'aliasOf'in entry:aliases[name]=entry['aliasOf'];continue
    file=src/entry['path'];compressed=file.read_bytes();assert sha(compressed)==entry['gzipSha256'];raw=gzip.decompress(compressed);assert sha(raw)==entry['rawSha256'];assert len(raw)==entry['wordCount']*32
    cache[name]=raw;s=stats(raw);s['sourcePath']=str(file);s['sourceGzipSha256']=sha(compressed);s['baselineAppendTransactions']=batch(s['logicalWords']);rows[name]=s;report['sourceFiles'].append({'path':str(file),'sha256':sha(compressed),'rawSha256':sha(raw)})
    totals['baselineLogicalWords']+=s['logicalWords'];totals['baselineZeroLogicalWords']+=s['zeroLogicalWords'];totals['baselineNonzeroLogicalSlots']+=s['nonzeroLogicalWords'];totals['baselineAppendTransactions']+=batch(s['logicalWords']);totals['logicalWordsVerified']+=s['logicalWords']
    if not name.startswith('B.'):
     totals['baseLogicalWords']+=s['logicalWords'];totals['baseZeroLogicalWords']+=s['zeroLogicalWords'];totals['baseNonzeroLogicalSlots']+=s['nonzeroLogicalWords'];totals['baseAppendTransactions']+=batch(s['logicalWords']);totals['basePacked128Slots']+=s['packed128PhysicalSlots'];totals['basePacked128NonzeroSlots']+=s['packed128NonzeroPhysicalSlots'];totals['basePacked128AppendTransactions']+=batch(s['packed128PhysicalSlots'])
   overlay={}
   for role in ['nonbonded','bonds','angles','torsions','exceptions']:
    a=cache['A.'+role];b=cache['B.'+role];assert len(a)==len(b);aa=np.frombuffer(a,dtype='>u8').reshape(-1,4);bb=np.frombuffer(b,dtype='>u8').reshape(-1,4);indices=np.flatnonzero(np.any(aa!=bb,axis=1));rebuilt=bytearray(a);patches=bytearray();tozero=0;changedRecords=set();width={'nonbonded':3,'bonds':4,'angles':5,'torsions':7,'exceptions':6}[role]
    # Store a tagged128-bit value at mapping[overlayID][logicalIndex]. One spare
    # high bit supplies presence, so a changed-to-zero patch cannot alias absence.
    for j in indices:
     index=int(j);word=b[index*32:(index+1)*32];value=int.from_bytes(word,'big');assert value<1<<128;assert index<1<<64
     encoded=(value<<64)|index;payload=encoded.to_bytes(32,'big');patches.extend(payload)
     decoded=int.from_bytes(payload,'big');readindex=decoded&((1<<64)-1);readvalue=decoded>>64;assert readindex==index
     stored=(1<<128)|readvalue;assert stored!=0;assert stored>>128==1
     restored=(stored&((1<<128)-1)).to_bytes(32,'big');assert restored==word
     rebuilt[readindex*32:(readindex+1)*32]=restored;tozero+=int(value==0);changedRecords.add(index//width)
    assert bytes(rebuilt)==b
    patchfile=out/'overlay-patches'/leg/(role+'.patches.bin.gz');p=gzwrite(patchfile,bytes(patches));assert gzip.decompress(patchfile.read_bytes())==bytes(patches)
    s={'base':'A.'+role,'logicalTarget':'B.'+role,'logicalWords':len(a)//32,'identicalWords':len(a)//32-len(indices),'changedWords':len(indices),'changedRecords':len(changedRecords),'changedToZeroWords':tozero,'patchMappingNonzeroSlots':len(indices),'minimumChangedIndex':int(indices[0])if len(indices)else None,'maximumChangedIndex':int(indices[-1])if len(indices)else None,'changedIndexSpan':int(indices[-1]-indices[0]+1)if len(indices)else 0,'patchPayloadWords':len(indices),'patchAppendTransactions':batch(len(indices)),'reconstructedTargetSha256':sha(rebuilt),'targetSha256':sha(b),'allWordsByteRoundtripVerified':True,'patchArtifact':p}
    overlay[role]=s;totals['overlayChangedWords']+=len(indices);totals['overlayChangedToZeroWords']+=tozero;totals['overlayPatchAppendTransactions']+=batch(len(indices))
   assert cache['A.particles']==gzip.decompress((src/manifest['streams']['B.particles']['path']).read_bytes())
   report['legs'][leg]={'counts':manifest['counts'],'streams':rows,'alreadyAliasedStreams':aliases,'overlay':overlay};write_json(target,report)
   print(json.dumps({'leg':leg,'changedWords':sum(v['changedWords']for v in overlay.values()),'verifiedUniqueWords':sum(v['logicalWords']for v in rows.values())}),flush=True)
  assert totals['baselineLogicalWords']==10903836
  totals['overlayRawPhysicalSlots']=totals['baseLogicalWords']+totals['overlayChangedWords'];totals['overlayRawNonzeroPhysicalSlots']=totals['baseNonzeroLogicalSlots']+totals['overlayChangedWords'];totals['overlayRawAppendTransactions']=totals['baseAppendTransactions']+totals['overlayPatchAppendTransactions']
  totals['overlayPacked128PhysicalSlots']=totals['basePacked128Slots']+totals['overlayChangedWords'];totals['overlayPacked128NonzeroPhysicalSlots']=totals['basePacked128NonzeroSlots']+totals['overlayChangedWords'];totals['overlayPacked128AppendTransactions']=totals['basePacked128AppendTransactions']+totals['overlayPatchAppendTransactions']
  totals['baselineBeginSealTransactions']=24*2;totals['overlayBeginSealTransactions']=24*2;totals['baseStreams']=14;totals['overlayStreams']=10
  scenarios={}
  for label,slotkey,nzkey,txkey in [('safe_overlay_raw_base','overlayRawPhysicalSlots','overlayRawNonzeroPhysicalSlots','overlayRawAppendTransactions'),('safe_overlay_packed128_base','overlayPacked128PhysicalSlots','overlayPacked128NonzeroPhysicalSlots','overlayPacked128AppendTransactions')]:
   slots=totals[slotkey];nonzero=totals[nzkey];tx=totals[txkey];scenarios[label]={'logicalWordsPreserved':totals['baselineLogicalWords'],'physicalPayloadSlots':slots,'nonzeroDataSlots':nonzero,'zeroPhysicalSlotsCanSkipSstore':slots-nonzero,'appendTransactionsAt128PayloadWords':tx,'totalUploadTransactionsIncluding24BeginAndSeal':tx+48,'physicalPayloadSlotsSaved':totals['baselineLogicalWords']-slots,'physicalPayloadReductionPercent':100*(1-slots/totals['baselineLogicalWords']),'nonzeroDataSlotsSaved':totals['baselineNonzeroLogicalSlots']-nonzero,'appendTransactionsSaved':totals['baselineAppendTransactions']-tx,'streamMetadataSlotsExcluded':True,'currentContractImplementationExists':False}
  for row in report['sourceFiles']:assert sha(Path(row['path']).read_bytes())==row['sha256']
  report.update(status='passed_lossless_offline_format_audit_not_implemented',passed=True,totals=totals,scenarios=scenarios,sourceHashesVerifiedAfterAudit=True)
 except Exception as e:report['status']='failed';report['error']={'message':str(e),'traceback':traceback.format_exc()};raise
 finally:write_json(target,report)
 print(json.dumps({'passed':report['passed'],'totals':report.get('totals'),'scenarios':report.get('scenarios'),'reportSha256':sha(target.read_bytes())}))
if __name__=='__main__':main()
