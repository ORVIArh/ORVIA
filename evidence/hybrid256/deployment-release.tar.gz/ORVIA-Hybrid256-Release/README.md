# ORVIA: frozen 256-contract infrastructure release

Prepared and reviewed; no public transaction was sent during preparation.

## Exact deployment

One coordinator plus 255 report shards: **256 contracts in 33 transactions**, Robinhood mainnet **4663**.

- Sender, initial owner and report signer: `0x2541a9e93B5C853E9208b0C5C7386dD458424c77`
- First nonce: `0`
- Predicted coordinator: `0x3B188B4c5B76b009d80455D3bbB7597983E390f0`
- Reviewed plan hash: `814e9c0aced4f8c6ef24bf4ca7fe5d423ef8bb4e4d54216a3dea02484958b50c`
- Compiler: `0.8.26+commit.8a97fa7a.Emscripten.clang`, Shanghai, optimizer 200 runs.

`plan.json` contains every address, transaction, constructor-bound runtime, and 32 prerequisite states.

## Full infrastructure price

Quote observed **2026-11-02T16:22:48.904Z**, block `0x6384f30`:

- Total for all 256 contracts: **231618594 gas**, **0.00470417364414 ETH** at `20310000` wei/gas.
- Funding reservation including the 25% per-transaction gas-limit margin: **0.00588021708564 ETH** at the quoted gas price. Unused gas is not an additional charge.
- Public wallet balance: **0.038676614738669727 ETH**.
- Pending nonce remained zero; all 256 target addresses had empty code and zero nonce. The RPC accepted all prerequisite-state overrides.

This covers deployment and shard provisioning. Experiment registration, report transactions and GPU simulation are excluded. The **full scientific campaign cost remains unknown**, not zero. Every transaction is re-estimated against actual pending state before signing.

## Run locally to deploy

Double-click **Deploy256.command** to open Terminal. It verifies the package and current repository source hashes, then requests the existing encrypted-wallet password through hidden local input. Running it signs and broadcasts the reviewed mainnet transactions. Never send a password or private key in chat.

The launcher references the secured CLI in the existing repository. It reads RPC configuration and the encrypted wallet from the private `.orvia` directory. No credential, RPC URL, wallet file or password is packaged here.

Journal: `~/.orvia/deployments/814e9c0aced4f8c6ef24bf4ca7fe5d423ef8bb4e4d54216a3dea02484958b50c.json`.

Rerun the same launcher after an interruption to reconcile saved transactions. An unsent transaction can only be retransmitted as identical signed bytes after fresh chain, nonce, contract inventory, balance and gas checks. Known pending transactions are awaited. No replacement is signed automatically. A sender-and-chain lock prevents two releases racing. After a process crash, confirm the previous process stopped before removing any stale lock.

The tool requires funding for all transaction limits including the 25% gas margin. It stops if the gas price or an individual gas limit exceeds twice its initial quote, a nonce changes, code differs, or a transaction fails. The journal is preserved. Changed source requires a new reviewed package.

## Evidence and limits

Ten planner tests and nine operator tests passed. Two independent local rehearsals created exactly 256 contracts and matched constructor bindings and prerequisite states. Tests cover rehashed plan/source/config/state changes, collisions, wrong network, fee inconsistencies, crash recovery, journal file safety and reorgs during verification. The mainnet quote was read-only and did not open a wallet file.

After deployment, all runtime bytes and shard registrations are checked. Transaction confirmation requires two subsequent blocks; this is not an irreversible-finality claim.

These contracts store **trusted operator attestations of external GPU calculations**. Signatures do not prove correct computation. Infrastructure deployment does not certify the full molecular model, simulation protocol, convergence or scientific results. Scientific campaign readiness remains false.

## Reproduction

`source/` contains reviewed contracts, tools, wallet helper and package manifests. `source-hashes.json` binds the working repository and Node executable. The quote, read-only RPC evidence, security review, independent rehearsal and test logs are included.

From the unchanged working repository:

```text
node --test scripts/deployment/test_hybrid256.mjs
node --test scripts/deployment/test_hybrid_operator.mjs
node scripts/deployment/hybrid256.mjs rehearse ../output/hybrid256-release/spec.json /tmp/orvia-reproduced-plan.json
```

Rehearsal timestamps and plan hash may differ; transaction intent, contract inventory and prerequisite states must match. The read-only quote CLI takes an independent specification and a private ORVIA_RPC_URL environment setting. Deployment takes no secret argument.
