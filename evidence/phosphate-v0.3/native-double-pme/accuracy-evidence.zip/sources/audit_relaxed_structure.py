#!/usr/bin/env python3
"""Read-only geometry audit of returned coordinates against the frozen v0.3 input."""
import argparse
import hashlib
import json
from pathlib import Path
import time
import traceback
import numpy as np
from scipy.spatial import cKDTree
import parmed
from rdkit import Chem
from structure_validation import audit_leg, read_positions

EXPECTED={'complex33':'55366f20dab76493f67fd465f1cf88d2aa740c932cb080b1ef1730b96436d1c7','solvent33':'f9425cc8ce73ff0d2dde297e467b71f64f8cd27ef1d8103e16297c8eca497e89'}

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def contacts(top, xyz, box):
    if box.shape!=(3,3) or not np.array_equal(box,np.diag(np.diag(box))) or np.any(np.diag(box)<=0):raise ValueError('Expected positive orthorhombic box')
    n=len(xyz);data=top.parm_data;types=np.asarray(data['ATOM_TYPE_INDEX'],dtype=int)-1;ntypes=int(data['POINTERS'][1]);indices=np.asarray(data['NONBONDED_PARM_INDEX'],dtype=int).reshape(ntypes,ntypes)-1
    av=np.asarray(data['LENNARD_JONES_ACOEF']);bv=np.asarray(data['LENNARD_JONES_BCOEF']);amat=np.where(indices>=0,av[np.maximum(indices,0)],0);bmat=np.where(indices>=0,bv[np.maximum(indices,0)],0)
    minimum=np.zeros_like(amat);positive=(amat>0)&(bmat>0);minimum[positive]=(2*amat[positive]/bmat[positive])**(1/6)*.1
    active=np.flatnonzero(np.diag(amat)[types]>0);lengths=np.diag(box)
    pairs=cKDTree(np.mod(xyz[active],lengths),boxsize=lengths).query_pairs(.6*float(minimum.max()),output_type='ndarray');a=active[pairs[:,0]];b=active[pairs[:,1]]
    num=np.asarray(data['NUMBER_EXCLUDED_ATOMS'],dtype=np.int64);listed=np.asarray(data['EXCLUDED_ATOMS_LIST'],dtype=np.int64)
    if num.sum()!=len(listed):raise ValueError('Malformed native exclusions')
    ea=np.repeat(np.arange(n,dtype=np.int64),num);keep=listed>0;eb=listed[keep]-1;ea=ea[keep];excluded=np.unique(np.minimum(ea,eb)*n+np.maximum(ea,eb))
    keys=np.minimum(a,b)*n+np.maximum(a,b);loc=np.searchsorted(excluded,keys);is_excluded=np.zeros(len(keys),dtype=bool);valid=loc<len(excluded);is_excluded[valid]=excluded[loc[valid]]==keys[valid]
    delta=xyz[b]-xyz[a];delta-=lengths*np.rint(delta/lengths);distance=np.linalg.norm(delta,axis=1);rmin=minimum[types[a],types[b]];bad=(rmin>0)&(distance<.6*rmin)&~is_excluded
    rows=[dict(atoms=[int(i),int(j)],distance_nm=float(r),native_minimum_nm=float(m),ratio=float(r/m))for i,j,r,m in zip(a[bad],b[bad],distance[bad],rmin[bad])]
    rows.sort(key=lambda x:x['ratio'])
    return dict(trigger_ratio_to_native_LJ_minimum=.6,violations=len(rows),worst_pairs=rows[:30],native_exclusions_honored=True)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--aura-root',type=Path,required=True);p.add_argument('--complex-positions',type=Path,required=True);p.add_argument('--solvent-positions',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();root=a.aura_root.resolve()
    if a.output.exists():raise FileExistsError(a.output)
    a.output.parent.mkdir(parents=True,exist_ok=True);start=time.monotonic();r=dict(schema='orvia.relaxed-v03-independent-geometry.v1',status='in_progress',passed=False,scientific_acceptance=False,production_ready=False,source_sha256=sha(__file__),stereochemistry_validator_sha256=sha(Path(__file__).with_name('structure_validation.py')),legs={})
    def save():a.output.write_text(json.dumps(r,indent=2,allow_nan=False)+'\n')
    save()
    try:
        ligand=root/'work/scientific-preparation/data/prepared_candidate/ligand_endpoints_v0_1/B';template=Chem.SDMolSupplier(str(ligand/'input.sdf'),removeHs=False)[0];identity=json.loads((ligand/'parameters.json').read_text())['atom_identity']
        for leg,directory,topname,afterfile in [('complex33','cardiac_adppi_ff03_m3l_33_782_solvated_v0_1','complex_1264.prmtop.gz',a.complex_positions),('solvent33','ligand_adppi_ff03_m3l_33_782_solvated_v0_1','solvent.prmtop.gz',a.solvent_positions)]:
            beforefile=root/'output/full-model-repair/adppi-v0.3-clash-relief-r3'/leg/'positions.json';topfile=root/'work/scientific-preparation/data/prepared_candidate'/directory/topname
            if sha(beforefile)!=EXPECTED[leg]:raise ValueError('Frozen v0.3 coordinates changed')
            bound={str(q):sha(q)for q in [beforefile,afterfile,topfile,ligand/'input.sdf',ligand/'parameters.json']};top=parmed.load_file(str(topfile));before,box=read_positions(beforefile,len(top.atoms));after,afterbox=read_positions(afterfile,len(top.atoms))
            if not np.array_equal(box,afterbox):raise ValueError('Returned periodic box changed')
            row=audit_leg(top,before,after,box,template,identity);row['positive_LJ_contacts']=contacts(top,after,box)
            errors=[abs(float(np.linalg.norm(after[b.atom1.idx]-after[b.atom2.idx]))-b.type.req*.1)for b in top.bonds if b.type is not None]
            row['stricter_bond_check']={'threshold_nm':.025,'maximum_error_nm':max(errors,default=0.),'outliers':sum(x>.025 for x in errors)}
            row['passed']=row['geometry_checks_passed'] and row['positive_LJ_contacts']['violations']==0 and row['stricter_bond_check']['outliers']==0
            row['input_sha256']=bound;row['atoms']=len(top.atoms);row['box_unchanged']=True;r['legs'][leg]=row
            for q,h in bound.items():
                if sha(q)!=h:raise ValueError('Audit input changed during read')
            save()
        r['passed']=all(x['passed']for x in r['legs'].values());r['status']='passed_geometry_only'if r['passed']else'geometry_gate_failed'
    except Exception as e:r.update(status='audit_failed',error={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()})
    r['elapsed_seconds']=time.monotonic()-start;save();print(json.dumps({'status':r['status'],'passed':r['passed'],'output':str(a.output)}));return 0 if r['passed'] else 2

if __name__=='__main__':raise SystemExit(main())
