#!/usr/bin/env python3
"""Four bounded H200 replicas using immutable v4 inputs; never scientific acceptance."""
from __future__ import annotations
import argparse
import csv
import hashlib
import importlib.util
import io
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import tarfile
import threading
import time

V4_MANIFEST = '90c95d2ca4653384bce9ca11d8848ab80378740dbb2e00c50f5feb0667ff7b32'
V4_RUNNER = '5b973f8a44ae61a3e825f91c02bed93fbaa1764fa346c55d442f7759839b1464'
JOB_ID = 'orvia-stress-20261102-02'
TOTAL_STEPS = 400000
BASELINE_STEPS = 80000
CHECKPOINT_STEP = 60000
REPLAY_STEPS = 20000
FRAME_INTERVAL = 800
FORCE_INTERVAL = 100
WORKER_SECONDS = 590
CLEANUP_SECONDS = 10
REPLICAS = (('complex33', 1), ('complex33', 2), ('solvent33', 1), ('solvent33', 2))


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 ** 2), b''):
            h.update(chunk)
    return h.hexdigest()


def configuration():
    return {'experiment': 'ORVIA-ADP-PHOSPHATE-v0.3', 'replicasPerModel': 2,
            'baselineStepsPerReplica': BASELINE_STEPS, 'restartAtStep': CHECKPOINT_STEP,
            'replayStepsPerReplica': REPLAY_STEPS, 'totalIntegrationSteps': TOTAL_STEPS,
            'timeStepPs': 0.0001, 'baselineTimePs': 8.0, 'initialVelocities': 'zero',
            'integrator': 'Verlet', 'precision': 'double', 'deterministicForces': True,
            'constraintTolerance': 1e-8, 'forceMarginKJMolNm': 2 ** 26,
            'forceObservationIntervalSteps': FORCE_INTERVAL, 'trajectoryIntervalSteps': FRAME_INTERVAL,
            'comparisonTolerances': {'energy_absolute_kJ_mol': 0.01, 'force_max_absolute_kJ_mol_nm': 0.05, 'force_relative_L2': 5e-5},
            'restartContinuationTolerances': {'positions_max_abs_nm': 1e-9, 'velocities_max_abs_nm_ps': 1e-8},
            'concurrency': 4, 'workerCutoffSeconds': WORKER_SECONDS, 'cleanupReserveSeconds': CLEANUP_SECONDS,
            'replicaMeaning': 'Identical deterministic replicas test concurrent load and within-replica checkpoint restart; no between-replica agreement or independent statistical sampling is claimed',
            'purpose': 'Bounded parallel GPU stress and strict restart diagnostic; not production sampling'}


def load_v4(bundle):
    if sha(bundle / 'manifest.json') != V4_MANIFEST or sha(bundle / 'live_workflow.py') != V4_RUNNER:
        raise RuntimeError('Immutable v4 input/source identity mismatch')
    spec = importlib.util.spec_from_file_location('orvia_frozen_v4', bundle / 'live_workflow.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    manifest = module.verify_bundle(bundle)
    return module, manifest


def verify_packet(w, packet):
    w.require(packet.is_dir() and not packet.is_symlink(), 'Unsafe stress packet directory')
    manifest = json.loads((packet / 'manifest.json').read_text())
    w.require(manifest.get('schema') == 'orvia.parallel-stress-packet.v1', 'Wrong stress packet schema')
    w.require(manifest.get('configuration') == configuration(), 'Changed stress configuration')
    w.require(manifest.get('v4InputManifestSha256') == V4_MANIFEST, 'Wrong stress input identity')
    w.require(manifest.get('diagnosticOnly') is True and manifest.get('scientificAcceptance') is False, 'Diagnostic packet required')
    expected = {'manifest.json', 'stress_parallel.py'}
    w.require({p.name for p in packet.iterdir()} == expected, 'Unexpected stress packet files')
    w.require(all(p.is_file() and not p.is_symlink() for p in packet.iterdir()), 'Unsafe stress packet member')
    record = manifest['files']['stress_parallel.py']
    member = packet / 'stress_parallel.py'
    w.require(sha(__file__) == record['sha256'] and Path(__file__).stat().st_size == record['bytes']
              and sha(member) == record['sha256'] and member.stat().st_size == record['bytes'], 'Stress source differs')
    return manifest


def worker(args, w, manifest):
    import numpy as np
    import openmm as mm
    from openmm import unit
    import sysconfig
    engine, _ = w.engine_environment(args.engine_build_report)
    binding = json.loads(args.environment_binding.read_text())
    w.require(binding.get('historicalBuildReportSha256') == w.ENGINE_SHA and binding.get('bootstrapSourceSha256') == manifest['files']['bootstrap_live_engine.py']['sha256'], 'Wrong restored runtime binding')
    w.require(binding.get('exportManifestSha256') == sha(args.bundle / 'engine-export-manifest.json'), 'Wrong runtime export binding')
    site = Path(sysconfig.get_paths()['purelib'])
    for name, record in json.loads((args.bundle / 'engine-export-manifest.json').read_text())['files'].items():
        if name.startswith('python-site/'):
            path = site / name[len('python-site/'):]
            w.require(path.is_file() and path.stat().st_size == record['bytes'] and sha(path) == record['sha256'], 'Runtime wrapper changed')
    w.require(Path(sys.prefix).resolve() == Path(engine['python']).parent.parent.resolve(), 'Wrong runtime Python')
    w.require(Path(mm.__file__).resolve().is_relative_to(Path(sys.prefix).resolve()), 'Wrong OpenMM module')
    w.require(os.environ.get('OPENMM_PLUGIN_DIR') == engine['pluginDirectory'], 'Wrong plugin directory')
    w.require(os.environ.get('LD_LIBRARY_PATH', '').split(':')[0] == engine['libraryPrefix'] + '/lib', 'Wrong native library prefix')
    w.require(mm.version.full_version == '8.6.1.dev-b399af4' and np.__version__ == '2.5.4', 'Wrong engine dependency version')
    out = args.output
    out.mkdir(parents=True, exist_ok=False)
    contexts = []
    report = {'schema': 'orvia.parallel-stress-phase.v1', 'jobId': JOB_ID, 'model': args.model, 'replica': args.replica,
              'phase': args.phase, 'startedAt': w.utc(), 'passed': False, 'diagnosticOnly': True, 'scientificAcceptance': False,
              'configuration': configuration(), 'sourceSha256': sha(__file__), 'inputManifestSha256': V4_MANIFEST,
              'stressManifestSha256': sha(args.packet / 'manifest.json'), 'engineBuildReportSha256': w.ENGINE_SHA,
              'environmentBindingSha256': sha(args.environment_binding), 'integrationStepsExecuted': 0}
    def progress(stage, steps):
        w.write_json(out / 'progress.json', {'stage': stage, 'steps': steps, 'updatedAt': w.utc()})
    def finite(value):
        w.require(bool(np.isfinite(value).all()), 'Nonfinite numerical array')
        return value
    def observe(context):
        state = context.getState(getPositions=True, getVelocities=True, getEnergy=True, getForces=True)
        energy = float(state.getPotentialEnergy().value_in_unit(unit.kilojoule_per_mole))
        kinetic = float(state.getKineticEnergy().value_in_unit(unit.kilojoule_per_mole))
        w.require(math.isfinite(energy) and math.isfinite(kinetic), 'Nonfinite energy')
        forces = finite(np.asarray(state.getForces(asNumpy=True).value_in_unit(unit.kilojoule_per_mole / unit.nanometer)))
        stamp = float(state.getTime().value_in_unit(unit.picosecond))
        w.record_force_margin(report, float(np.max(np.abs(forces))), context.getPlatform().getName(), stamp)
        return {'positions': finite(np.asarray(state.getPositions(asNumpy=True).value_in_unit(unit.nanometer))),
                'velocities': finite(np.asarray(state.getVelocities(asNumpy=True).value_in_unit(unit.nanometer / unit.picosecond))),
                'forces': forces, 'box': finite(np.asarray(state.getPeriodicBoxVectors(asNumpy=True).value_in_unit(unit.nanometer))),
                'time': stamp, 'energy': energy, 'kineticEnergy': kinetic}
    def save(name, observation):
        np.savez_compressed(out / name, **observation)
    def comparison(reference, current):
        delta = current['forces'] - reference['forces']
        metrics = {'energy_absolute_kJ_mol': abs(float(current['energy']) - float(reference['energy'])),
                   'force_max_absolute_kJ_mol_nm': float(np.max(np.abs(delta))),
                   'force_relative_L2': float(np.linalg.norm(delta)) / max(float(np.linalg.norm(reference['forces'])), 1e-12)}
        w.require(all(math.isfinite(x) for x in metrics.values()), 'Invalid comparison')
        return {**metrics, 'passed': all(metrics[k] <= v for k, v in w.TOLERANCES.items())}
    try:
        progress('loading', 0)
        system = mm.XmlSerializer.deserialize((args.bundle / 'inputs' / args.model / 'system.xml').read_text())
        payload = json.loads((args.bundle / 'inputs' / args.model / 'positions.json').read_text())
        positions = finite(np.asarray(payload['positions_nm'], dtype=np.float64))
        n = {'complex33': 132935, 'solvent33': 151505}[args.model]
        w.require(system.getNumParticles() == n and positions.shape == (n, 3), 'Wrong full model size')
        box = np.asarray([v.value_in_unit(unit.nanometer) for v in system.getDefaultPeriodicBoxVectors()])
        w.require(np.array_equal(box, np.asarray(payload['box_vectors_nm'])), 'Input box differs')
        nb = [system.getForce(i) for i in range(system.getNumForces()) if isinstance(system.getForce(i), mm.NonbondedForce)]
        w.require(len(nb) == 1 and nb[0].getNonbondedMethod() == mm.NonbondedForce.PME, 'Native PME required')
        def context(name):
            integrator = mm.VerletIntegrator(w.DT_PS * unit.picoseconds)
            integrator.setConstraintTolerance(1e-8)
            props = {'Precision': 'double', 'DeviceIndex': '0', 'UseCpuPme': 'false', 'DeterministicForces': 'true'} if name == 'CUDA' else {}
            ctx = mm.Context(system, integrator, mm.Platform.getPlatformByName(name), props)
            contexts.append((ctx, integrator))
            actual = ctx.getPlatform()
            got = {key: actual.getPropertyValue(ctx, key) for key in actual.getPropertyNames()}
            w.require(actual.getName() == name, 'Wrong platform')
            if name == 'CUDA':
                w.require(got.get('Precision') == 'double' and got.get('UseCpuPme') == 'false' and got.get('DeterministicForces') == 'true', 'Wrong CUDA properties')
            pme = nb[0].getPMEParametersInContext(ctx)
            alpha = pme[0].value_in_unit(1 / unit.nanometer) if hasattr(pme[0], 'value_in_unit') else float(pme[0])
            settings = [float(alpha), *map(int, pme[1:])]
            w.require(settings == manifest['models'][args.model]['pme'], 'PME grid changed')
            report.setdefault('contexts', {})[name] = {'actualPlatform': name, 'properties': got, 'actualPme': settings}
            return ctx, integrator
        gpu, integrator = context('CUDA')
        report.update(particles=n, openmmVersion=mm.version.full_version, numpyVersion=np.__version__)
        trajectory = None
        if args.phase == 'baseline':
            gpu.setPositions(positions * unit.nanometer)
            gpu.applyConstraints(1e-8)
            gpu.setVelocities(np.zeros_like(positions) * unit.nanometer / unit.picosecond)
            current = observe(gpu)
            initial = current
            if args.replica == 1:
                trajectory = w.Trajectory(np, args.bundle, args.model, JOB_ID, box, n)
                trajectory.payload['source']['runnerSha256'] = sha(__file__)
                trajectory.capture(0, current['positions'])
                trajectory.save(out / 'trajectory-partial.json')
            progress('validating', 0)
            reference, _ = context('Reference')
            reference.setPositions(current['positions'] * unit.nanometer)
            reference.setVelocities(current['velocities'] * unit.nanometer / unit.picosecond)
            initial_ref = observe(reference)
            save('initial-reference.npz', initial_ref)
            save('initial-cuda.npz', current)
            report['initialComparison'] = comparison(initial_ref, current)
            w.require(report['initialComparison']['passed'], 'Initial strict Reference/CUDA comparison failed')
            limit = BASELINE_STEPS
        else:
            base = args.baseline
            prior = json.loads((base / 'result.json').read_text())
            lineage = {'schema': 'orvia.parallel-stress-phase.v1', 'jobId': JOB_ID, 'model': args.model, 'replica': args.replica,
                       'phase': 'baseline', 'configuration': configuration(), 'inputManifestSha256': V4_MANIFEST,
                       'environmentBindingSha256': sha(args.environment_binding), 'integrationStepsExecuted': BASELINE_STEPS,
                       'sourceSha256': sha(__file__), 'stressManifestSha256': sha(args.packet / 'manifest.json')}
            w.require(prior.get('passed') is True and all(prior.get(key) == value for key, value in lineage.items()), 'Unapproved baseline lineage')
            w.require(sha(base / 'midpoint.chk') == prior['checkpointSha256'], 'Baseline checkpoint differs')
            report['baselineResultSha256'] = sha(base / 'result.json')
            gpu.loadCheckpoint((base / 'midpoint.chk').read_bytes())
            current = observe(gpu)
            save('restored.npz', current)
            with np.load(base / 'midpoint.npz', allow_pickle=False) as stored:
                restore = {key: float(np.max(np.abs(current[key] - stored[key]))) for key in ('positions', 'velocities', 'box', 'time')}
                report['restoreMaxAbsoluteDifferences'] = restore
                report['restoreForceComparison'] = comparison(stored, current)
            w.require(all(v == 0 for v in restore.values()) and report['restoreForceComparison']['passed'], 'Checkpoint restoration differs')
            limit = REPLAY_STEPS
        report['energyTrace'] = []
        for step in range(FORCE_INTERVAL, limit + 1, FORCE_INTERVAL):
            progress('simulating', step - FORCE_INTERVAL)
            integrator.step(FORCE_INTERVAL)
            report['integrationStepsExecuted'] = step
            current = observe(gpu)
            progress('simulating', step)
            if trajectory is not None and step % FRAME_INTERVAL == 0:
                trajectory.capture(step, current['positions'])
                if step % 4000 == 0:
                    trajectory.save(out / 'trajectory-partial.json')
            if step % 1000 == 0:
                report['energyTrace'].append({'step': step, 'timePs': current['time'], 'potential_kJ_mol': current['energy'], 'kinetic_kJ_mol': current['kineticEnergy']})
                w.write_json(out / 'partial-result.json', report)
            if args.phase == 'baseline' and step == CHECKPOINT_STEP:
                progress('checkpointing', step)
                (out / 'midpoint.chk').write_bytes(gpu.createCheckpoint())
                save('midpoint.npz', current)
                report['checkpointSha256'] = sha(out / 'midpoint.chk')
                if trajectory is not None:
                    trajectory.save(out / 'trajectory-partial.json')
        save('final.npz', current)
        (out / 'final.chk').write_bytes(gpu.createCheckpoint())
        progress('validating', limit)
        if args.phase == 'baseline':
            reference.setPositions(current['positions'] * unit.nanometer)
            reference.setVelocities(current['velocities'] * unit.nanometer / unit.picosecond)
            final_ref = observe(reference)
            save('final-reference.npz', final_ref)
            report['finalComparison'] = comparison(final_ref, current)
            w.require(report['finalComparison']['passed'], 'Final strict Reference/CUDA comparison failed')
            report['energyConservationAccepted'] = False
            report['observedEnergyRange_kJ_mol'] = max([initial['energy'] + initial['kineticEnergy']] + [r['potential_kJ_mol'] + r['kinetic_kJ_mol'] for r in report['energyTrace']]) - min([initial['energy'] + initial['kineticEnergy']] + [r['potential_kJ_mol'] + r['kinetic_kJ_mol'] for r in report['energyTrace']])
            if trajectory is not None:
                trajectory.save(out / 'trajectory.json')
                report['trajectorySha256'] = sha(out / 'trajectory.json')
        else:
            with np.load(args.baseline / 'final.npz', allow_pickle=False) as saved:
                continuation = {'positions_max_abs_nm': float(np.max(np.abs(current['positions'] - saved['positions']))),
                                'velocities_max_abs_nm_ps': float(np.max(np.abs(current['velocities'] - saved['velocities'])))}
                report['continuationComparison'] = {**continuation, 'passed': all(continuation[k] <= v for k, v in w.RESTART_TOLERANCES.items())}
                report['continuationForceComparison'] = comparison(saved, current)
            with np.load(args.baseline / 'final-reference.npz', allow_pickle=False) as saved_ref:
                report['finalReferenceComparison'] = comparison(saved_ref, current)
            w.require(report['continuationComparison']['passed'] and report['continuationForceComparison']['passed'] and report['finalReferenceComparison']['passed'], 'Replay strict continuation failed')
            report['checkpointSha256'] = sha(out / 'final.chk')
        report['passed'] = True
        progress('finished', limit)
    except Exception as error:
        report['error'] = {'type': type(error).__name__, 'message': str(error)[:1000]}
        progress('failed', report['integrationStepsExecuted'])
    finally:
        report['completedAt'] = w.utc()
        w.write_json(out / 'result.json', report)
    return 0 if report['passed'] else 1


def supervisor(args, w):
    root = args.output
    root.mkdir(parents=True, exist_ok=False)
    engine, environment = w.engine_environment(args.engine_build_report)
    pub = w.Telemetry(root, JOB_ID, os.environ.get('ORVIA_WORKER_TOKEN', ''))
    started = time.monotonic()
    deadline = started + WORKER_SECONDS
    active = {}
    tasks = {}
    lock = threading.RLock()
    timed_out = threading.Event()
    finished = threading.Event()
    sampler = None
    metrics_sender = None
    latest_sample = {}
    metrics_sequence = 0
    report = {'schema': 'orvia.parallel-stress-run.v1', 'jobId': JOB_ID, 'startedAt': w.utc(),
              'configuration': configuration(), 'diagnosticOnly': True, 'scientificAcceptance': False, 'passed': False,
              'sourceSha256': sha(__file__), 'inputManifestSha256': V4_MANIFEST,
              'stressManifestSha256': sha(args.packet / 'manifest.json'), 'engineBuildReportSha256': w.ENGINE_SHA,
              'automaticPodShutdown': False, 'onChainReportSubmitted': False, 'phases': [],
              'timingScope': {'workerCutoffSeconds': WORKER_SECONDS, 'cleanupReserveSeconds': CLEANUP_SECONDS,
                              'hashingArchivalAndFinalNetworkExcluded': True, 'watchdog': 'independent thread kills active process groups at cutoff'},
              'integrationStepsExecuted': 0}
    def emit(state, stage, steps, result_hash=None, checkpoint_hash=None, final=False):
        w.require(not pub.terminal and pub.last_steps <= steps <= TOTAL_STEPS, 'Invalid stress progress')
        pub.sequence += 1
        payload = {'schemaVersion': 1, 'jobId': JOB_ID, 'sequence': pub.sequence, 'state': state, 'stage': stage,
                   'stepsCompleted': steps, 'stepsTotal': TOTAL_STEPS, 'updatedAt': w.utc(), 'device': 'NVIDIA H200',
                   'diagnosticOnly': True, 'scientificAcceptance': False, 'resultSha256': result_hash, 'checkpointSha256': checkpoint_hash}
        w.write_json(root / 'telemetry' / f'{pub.sequence:06d}.json', payload)
        pub.pending.append(payload)
        pub.last_steps = steps
        pub.terminal = state in ('completed', 'failed')
        return pub.flush(deadline=None if final else deadline)
    def kill_active():
        with lock:
            for task in active.values():
                if task['process'].poll() is None:
                    try:
                        os.killpg(task['process'].pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
    def watch():
        if not finished.wait(max(0, deadline - time.monotonic())):
            timed_out.set()
            kill_active()
    watchdog = threading.Thread(target=watch, name='orvia-stress-cutoff', daemon=True)
    watchdog.start()
    def interrupted(signum, frame):
        kill_active()
        raise InterruptedError('Stress job interrupted')
    signal.signal(signal.SIGINT, interrupted)
    signal.signal(signal.SIGTERM, interrupted)
    def spawn(model, replica, phase):
        key = f'{model}-r{replica}/{phase}'
        out = root / key
        command = [engine['python'], str(Path(__file__).resolve()), '--worker', '--packet', str(args.packet), '--bundle', str(args.bundle),
                   '--output', str(out), '--model', model, '--replica', str(replica), '--phase', phase,
                   '--engine-build-report', str(args.engine_build_report), '--environment-binding', str(args.environment_binding)]
        if phase == 'resume':
            command += ['--baseline', str(root / f'{model}-r{replica}' / 'baseline')]
        log = root / 'logs' / (key.replace('/', '-') + '.log')
        log.parent.mkdir(exist_ok=True)
        with lock:
            w.require(not timed_out.is_set() and time.monotonic() < deadline, 'Worker deadline reached')
            with log.open('xb') as stream:
                process = subprocess.Popen(command, stdout=stream, stderr=subprocess.STDOUT, env=environment, start_new_session=True)
            task = {'process': process, 'model': model, 'replica': replica, 'phase': phase, 'out': out, 'steps': 0, 'started': time.monotonic()}
            active[key] = task
            tasks[key] = task
    def observed_steps():
        for task in tasks.values():
            path = task['out'] / 'progress.json'
            if path.exists():
                value = json.loads(path.read_text())
                limit = BASELINE_STEPS if task['phase'] == 'baseline' else REPLAY_STEPS
                w.require(type(value['steps']) is int and task['steps'] <= value['steps'] <= limit, 'Invalid worker step report')
                task['steps'] = value['steps']
        return sum(task['steps'] for task in tasks.values())
    def sample_gpu():
        stamp = w.utc()
        try:
            raw = subprocess.check_output(['nvidia-smi', '--query-gpu=utilization.gpu,utilization.memory,memory.used,memory.total,power.draw,temperature.gpu', '--format=csv,noheader,nounits'], timeout=3, text=True).strip()
            rows = list(csv.reader(io.StringIO(raw)))
            w.require(len(rows) == 1 and len(rows[0]) == 6, 'Unexpected GPU sample')
            names = ('gpuUtilizationPercent', 'memoryUtilizationPercent', 'memoryUsedMiB', 'memoryTotalMiB', 'powerWatts', 'temperatureC')
            sample = {'at': stamp, 'elapsedSeconds': time.monotonic() - started,
                      **{name: float(value.strip()) if value.strip() not in ('N/A', '[N/A]') else None for name, value in zip(names, rows[0])}}
        except Exception as error:
            sample = {'at': stamp, 'elapsedSeconds': time.monotonic() - started, 'error': type(error).__name__}
        with (root / 'gpu-samples.jsonl').open('a') as stream:
            with lock:
                sample['activeWorkerProcesses'] = sum(task['process'].poll() is None for task in active.values())
                latest_sample.clear()
                latest_sample.update(sample)
            stream.write(json.dumps(sample, allow_nan=False) + '\n')
    def sample_loop():
        next_at = time.monotonic()
        while not finished.is_set():
            sample_gpu()
            next_at += 5
            if finished.wait(max(0, next_at - time.monotonic())):
                break
    def publish_metrics():
        nonlocal metrics_sequence
        with lock:
            sample = dict(latest_sample)
        if not sample or 'error' in sample:
            return
        metrics_sequence += 1
        body = {'schemaVersion': 1, 'jobId': JOB_ID, 'sequence': metrics_sequence,
                'updatedAt': sample['at'], 'device': 'NVIDIA H200',
                **{key: sample[key] for key in ('gpuUtilizationPercent', 'memoryUtilizationPercent', 'memoryUsedMiB',
                   'memoryTotalMiB', 'powerWatts', 'temperatureC', 'activeWorkerProcesses')}}
        code = pub._post('https://orvia.fyi/api/orvia/gpu', json.dumps(body, allow_nan=False, separators=(',', ':')).encode(), 2)
        with (root / 'gpu-metrics-delivery.jsonl').open('a') as stream:
            stream.write(json.dumps({'sequence': metrics_sequence, 'sampleAt': sample['at'], 'httpStatus': code}) + '\n')
    def metrics_loop():
        while not finished.wait(15):
            publish_metrics()
    try:
        gpu = subprocess.check_output(['nvidia-smi', '--query-gpu=name,driver_version,memory.total', '--format=csv,noheader'], timeout=15, text=True).strip()
        w.require(len(gpu.splitlines()) == 1 and 'H200' in gpu.split(',', 1)[0], 'Exactly one H200 required')
        report['hardware'] = gpu
        w.require(emit('running', 'starting', 0), 'Website rejected stress workflow start')
        sampler = threading.Thread(target=sample_loop, name='orvia-gpu-sampler', daemon=True)
        sampler.start()
        metrics_sender = threading.Thread(target=metrics_loop, name='orvia-gpu-metrics', daemon=True)
        metrics_sender.start()
        for model, replica in REPLICAS:
            spawn(model, replica, 'baseline')
        next_telemetry = 0.0
        while active:
            now = time.monotonic()
            if timed_out.is_set() or now >= deadline:
                timed_out.set()
                kill_active()
                raise TimeoutError('Parallel GPU workers reached their bounded cutoff')
            for key, task in list(active.items()):
                code = task['process'].poll()
                if code is None:
                    continue
                with lock:
                    del active[key]
                path = task['out'] / 'result.json'
                result = json.loads(path.read_text()) if path.exists() else {'passed': False, 'integrationStepsExecuted': task['steps']}
                task['steps'] = max(task['steps'], result['integrationStepsExecuted'])
                passed = code == 0 and result.get('passed') is True
                report['phases'].append({'model': task['model'], 'replica': task['replica'], 'phase': task['phase'],
                    'passed': passed, 'exitCode': code, 'elapsedSeconds': time.monotonic() - task['started'],
                    'resultSha256': sha(path) if path.exists() else None})
                if passed and task['phase'] == 'baseline':
                    spawn(task['model'], task['replica'], 'resume')
            count = observed_steps()
            report['integrationStepsExecuted'] = count
            w.write_json(root / 'run-status.json', report)
            if now >= next_telemetry:
                emit('running', 'simulating', count)
                next_telemetry = time.monotonic() + 15
            time.sleep(0.2)
        report['passed'] = len(report['phases']) == 8 and all(p['passed'] for p in report['phases']) and report['integrationStepsExecuted'] == TOTAL_STEPS
        w.require(report['passed'], 'One or more strict replica/restart checks failed')
    except Exception as error:
        report['error'] = {'type': type(error).__name__, 'message': str(error)[:1000]}
    finally:
        kill_active()
        cleanup_deadline = time.monotonic() + CLEANUP_SECONDS
        for task in active.values():
            try:
                task['process'].wait(timeout=max(0.001, cleanup_deadline - time.monotonic()))
            except subprocess.TimeoutExpired:
                pass
        stopped_after = time.monotonic() - started
        finished.set()
        watchdog.join(timeout=0.1)
        if sampler is not None:
            sampler.join(timeout=3.1)
        if metrics_sender is not None:
            metrics_sender.join(timeout=2.1)
        report['workersStillRunning'] = [task['process'].pid for task in active.values() if task['process'].poll() is None]
        report['gpuWorkersStoppedAfterSeconds'] = stopped_after
        report['timedOut'] = timed_out.is_set()
        report['integrationStepsExecuted'] = max(report['integrationStepsExecuted'], observed_steps(), pub.last_steps)
        report['passed'] = report['passed'] and not report['workersStillRunning'] and not report['timedOut']
        sample_gpu()
        publish_metrics()
        samples = [json.loads(line) for line in (root / 'gpu-samples.jsonl').read_text().splitlines()]
        valid = [sample for sample in samples if 'error' not in sample and sample['gpuUtilizationPercent'] is not None]
        report['gpuMeasurementSummary'] = {'sampleCount': len(samples), 'validUtilizationSamples': len(valid),
            'scope': 'Whole-device samples across setup, calculation and post-stop observation; not isolated kernel timing',
            'peakGpuUtilizationPercent': max((row['gpuUtilizationPercent'] for row in valid), default=None),
            'arithmeticMeanSampledGpuUtilizationPercent': sum(row['gpuUtilizationPercent'] for row in valid) / len(valid) if valid else None,
            'peakMemoryUsedMiB': max((row['memoryUsedMiB'] for row in valid if row['memoryUsedMiB'] is not None), default=None)}
        # Upload only completed representative baselines; this happens after GPU workers stop.
        for model, replica in REPLICAS:
            if replica != 1:
                continue
            path = root / f'{model}-r1/baseline/trajectory.json'
            if path.exists():
                report.setdefault('trajectories', {})[model] = pub.upload_trajectory(path)
        report['completedAt'] = w.utc()
        w.write_json(root / 'result.json', report)
        w.write_json(root / 'run-status.json', report)
        checkpoints = {str(p.relative_to(root)): {'sha256': sha(p), 'bytes': p.stat().st_size} for p in root.rglob('*.chk')}
        w.write_json(root / 'checkpoints.json', checkpoints)
        emit('completed' if report['passed'] else 'failed', 'finished' if report['passed'] else 'failed', report['integrationStepsExecuted'],
             sha(root / 'result.json') if report['passed'] else None, sha(root / 'checkpoints.json') if report['passed'] else None, final=True)
        (root / 'source.py').write_bytes(Path(__file__).read_bytes())
        (root / 'stress-manifest.json').write_bytes((args.packet / 'manifest.json').read_bytes())
        (root / 'input-manifest.json').write_bytes((args.bundle / 'manifest.json').read_bytes())
        (root / 'environment-binding.json').write_bytes(args.environment_binding.read_bytes())
        (root / 'engine-build-report.json').write_bytes(args.engine_build_report.read_bytes())
        archive = root.with_suffix('.tar.gz')
        with tarfile.open(archive, 'w:gz', compresslevel=2) as tar:
            for path in sorted(root.rglob('*')):
                if path.is_file():
                    tar.add(path, arcname=str(path.relative_to(root)))
        print(json.dumps({'passed': report['passed'], 'steps': report['integrationStepsExecuted'], 'archive': str(archive),
                          'archiveSha256': sha(archive), 'scientificAcceptance': False, 'automaticPodShutdown': False}))
    return 0 if report['passed'] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle', type=Path, default=Path('/workspace/orvia-live-workflow-v4'))
    parser.add_argument('--packet', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--engine-build-report', type=Path, default=Path('/workspace/orvia-native-double-build-r2/build-report.json'))
    parser.add_argument('--environment-binding', type=Path, default=Path('/workspace/orvia-live-engine-restore/environment-binding.json'))
    parser.add_argument('--worker', action='store_true')
    parser.add_argument('--model', choices=('complex33', 'solvent33'))
    parser.add_argument('--replica', type=int, choices=(1, 2))
    parser.add_argument('--phase', choices=('baseline', 'resume'))
    parser.add_argument('--baseline', type=Path)
    args = parser.parse_args()
    if not __debug__ or sys.flags.optimize:
        raise RuntimeError('Optimized Python forbidden')
    w, manifest = load_v4(args.bundle)
    verify_packet(w, args.packet)
    if args.worker:
        w.require(args.model and args.replica and args.phase and (args.phase != 'resume' or args.baseline), 'Incomplete worker arguments')
        return worker(args, w, manifest)
    return supervisor(args, w)


if __name__ == '__main__':
    raise SystemExit(main())
