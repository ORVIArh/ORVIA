// Independent array audit of the failed recovery; no simulation or network use.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {readObservationNpz,assertComparison,maximumDifference,maximumAbsolute} from '../../../ORVIA/scripts/hybrid/live_workflow_arrays.mjs';
const here=path.dirname(fileURLToPath(import.meta.url)),original=path.join(here,'../returned-20261102-02'),recovery=path.join(here,'returned-20261102-03');
const sha=b=>createHash('sha256').update(b).digest('hex'),files={};
function read(root,name){const p=path.join(root,name);assert.equal(fs.lstatSync(p).isSymbolicLink(),false);const before=fs.statSync(p),bytes=fs.readFileSync(p),after=fs.statSync(p);assert.equal(before.size,after.size);assert.equal(before.mtimeMs,after.mtimeMs);files[(root===original?'original/':'recovery/')+name]={bytes:bytes.length,sha256:sha(bytes)};return bytes;}
const json=(r,n)=>JSON.parse(read(r,n)),result=json(recovery,'result.json'),plan=json(recovery,'recovery-inputs.json');
assert.equal(result.passed,false);assert.equal(result.timedOut,false);assert.deepEqual(result.workersStillRunning,[]);
assert.equal(result.newIntegrationStepsExecuted,80000);assert.equal(result.originalReportedIntegrationSteps,338800);assert.equal(result.aggregateReportedExecutedSteps,418800);assert.equal(result.completedPlannedCohortSteps,null);
assert.equal(result.originalAttemptRemainsFailed,true);assert.equal(result.scientificAcceptance,false);assert.equal(result.diagnosticOnly,true);
assert.equal(result.sourceSha256,'7a02a794e05ea6078bdbd26dd9646c0de335446be754bf85f33b74c841e45264');
assert.equal(result.recoveryPlanSha256,sha(read(recovery,'recovery-inputs.json')));
assert.equal(result.originalResultSha256,sha(read(original,'result.json')));
assert.equal(sha(read(recovery,'source.py')),result.sourceSha256);
assert.equal(sha(read(recovery,'recovery-manifest.json')),result.recoveryManifestSha256);
assert.equal(sha(read(recovery,'environment-binding.json')),plan.environmentBindingSha256);
assert.equal(Object.keys(plan.files).length,117);
for(const [name,record] of Object.entries(plan.files)){const b=read(original,name);assert.equal(b.length,record.bytes);assert.equal(sha(b),record.sha256);}
const checkpointInventory=json(recovery,'checkpoints.json');assert.equal(Object.keys(checkpointInventory).length,4);
for(const [name,record] of Object.entries(checkpointInventory)){const b=read(recovery,name);assert.equal(b.length,record.bytes);assert.equal(sha(b),record.sha256);}
const rows=[],cross={};
function difference(a,b){let square=0,count=0;for(let i=0;i<a.length;i++){const d=b[i]-a[i];square+=d*d;if(d!==0)count++;}return {maximumAbsolute:maximumDifference(a,b),rmsPerComponent:Math.sqrt(square/a.length),changedComponents:count};}
function arrayHashes(o){return Object.fromEntries(['positions','velocities','forces','box','time'].map(k=>[k,sha(o[k].raw)]));}
for(const [model,n] of Object.entries({complex33:132935,solvent33:151505})){
  cross[model]=[];
  for(const replica of [1,2]){
    const key=`${model}-r${replica}`,base=key+'/baseline/',report=json(recovery,key+'/result.json'),binding=json(recovery,key+'/recovery-context.json');
    assert.equal(report.passed,false);assert.equal(report.error.message,'Replay strict continuation failed');assert.equal(report.integrationStepsExecuted,20000);
    assert.equal(binding.recoveryJobId,result.jobId);assert.equal(binding.computationProtocolJobId,result.parentJobId);assert.equal(binding.recoverySourceSha256,result.sourceSha256);assert.equal(binding.recoveryPlanSha256,result.recoveryPlanSha256);assert.equal(binding.childResultSha256,sha(read(recovery,key+'/result.json')));assert.equal(binding.originalEvidenceUnchanged,true);
    const phase=result.phases.find(p=>p.replica===key);assert.equal(phase.passed,false);assert.equal(phase.exitCode,1);assert.equal(phase.resultSha256,binding.childResultSha256);assert.equal(phase.contextSha256,sha(read(recovery,key+'/recovery-context.json')));
    const mid=readObservationNpz(read(original,base+'midpoint.npz'),n),target=readObservationNpz(read(original,base+'final.npz'),n),reference=readObservationNpz(read(original,base+'final-reference.npz'),n);
    const restored=readObservationNpz(read(recovery,key+'/restored.npz'),n),final=readObservationNpz(read(recovery,key+'/final.npz'),n);
    const exactRestore={};
    for(const k of ['positions','velocities','box','time']){exactRestore[k]=mid[k].raw.equals(restored[k].raw);assert.equal(exactRestore[k],true);assert.equal(report.restoreMaxAbsoluteDifferences[k],0);}
    assert.ok(Math.abs(mid.time.values[0]-6)<1e-9);assert.ok(Math.abs(final.time.values[0]-8)<1e-9);
    const restoredForce=assertComparison(mid,restored,report.restoreForceComparison),continuedForce=assertComparison(target,final,report.continuationForceComparison),storedReferenceForce=assertComparison(reference,final,report.finalReferenceComparison);
    const positions=difference(target.positions.values,final.positions.values),velocities=difference(target.velocities.values,final.velocities.values);
    assert.equal(positions.maximumAbsolute,report.continuationComparison.positions_max_abs_nm);assert.equal(velocities.maximumAbsolute,report.continuationComparison.velocities_max_abs_nm_ps);assert.equal(report.continuationComparison.passed,false);
    assert.ok(positions.maximumAbsolute>1e-9);assert.ok(velocities.maximumAbsolute>1e-8);
    assert.equal(report.forceMarginObservations.length,201);
    for(const r of report.forceMarginObservations){assert.equal(r.passed,true);assert.equal(r.limitKJMolNm,2**26);assert.ok(Number.isFinite(r.maxAbsoluteForceKJMolNm)&&r.maxAbsoluteForceKJMolNm>=0&&r.maxAbsoluteForceKJMolNm<2**26);}
    for(const [i,o] of [[0,restored],[200,final]]){assert.equal(report.forceMarginObservations[i].maxAbsoluteForceKJMolNm,maximumAbsolute(o.forces.values));assert.equal(report.forceMarginObservations[i].timePs,o.time.values[0]);}
    const hashes={baselineMidpoint:arrayHashes(mid),baselineFinal:arrayHashes(target),restored:arrayHashes(restored),replayFinal:arrayHashes(final)};cross[model].push(hashes);
    rows.push({model,replica,exactRestore,restoredForce,continuedForce,storedReferenceForce,positions:{...positions,toleranceNm:1e-9,limitMultiple:positions.maximumAbsolute/1e-9,passed:false},velocities:{...velocities,toleranceNmPerPs:1e-8,limitMultiple:velocities.maximumAbsolute/1e-8,passed:false},allRetainedArraysFinite:true,forceMarginObservationCount:201,allForceMarginObservationsPass:true,baselineFinalPotential:target.energy.values[0],replayFinalPotential:final.energy.values[0],baselineFinalKinetic:target.kineticEnergy.values[0],replayFinalKinetic:final.kineticEnergy.values[0],hashes});
  }
}
const crossReplica=Object.fromEntries(Object.entries(cross).map(([model,pair])=>[model,Object.fromEntries(Object.keys(pair[0]).map(phase=>[phase,Object.fromEntries(Object.keys(pair[0][phase]).map(k=>[k,pair[0][phase][k]===pair[1][phase][k]]))]))]));
const audit={schema:'orvia.failed-recovery-independent-array-review.v1',reviewedAt:new Date().toISOString(),auditCompleted:true,runPassed:false,timedOut:false,scientificAcceptance:false,diagnosticOnly:true,originalFilesUnchanged:117,originalReportedSteps:338800,newExecutedSteps:80000,aggregateReportedExecutedSteps:418800,failedGate:'Final replay coordinate and velocity equality thresholds',allFourRestoresBitwiseExact:true,allTwelveEnergyForceComparisonsPass:true,allObservedForceMarginsPass:true,rows,crossReplica,files,interpretation:'Saved checkpoint coordinates, velocities, box and time restored bitwise exactly. Full replay positions/velocities exceed the unchanged strict continuation limits while energy/force and range checks pass. Tiny force differences already exist immediately after restore. This localizes the failure to strict cross-process trajectory reproducibility; these artifacts alone do not identify the native-kernel root cause. Stored-reference comparisons use the original baseline final coordinates, not a fresh Reference evaluation of the replay final coordinates.',molecularEvaluations:0,gpuEvaluations:0,networkRequests:0};
fs.writeFileSync(path.join(here,'actual-recovery-array-review.json'),JSON.stringify(audit,null,2)+'\n');
console.log(JSON.stringify({auditCompleted:true,runPassed:false,failedGate:audit.failedGate,allFourRestoresBitwiseExact:true,allTwelveEnergyForceComparisonsPass:true,crossReplica,rows:rows.map(({model,replica,positions,velocities,restoredForce})=>({model,replica,positions,velocities,restoredForce}))},null,2));
