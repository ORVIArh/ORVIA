// Offline evidence audit only: no molecular engine, wallet, RPC or network use.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {readObservationNpz,assertComparison,maximumDifference,maximumAbsolute} from '../../../ORVIA/scripts/hybrid/live_workflow_arrays.mjs';

const here=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(here,'../returned-20261102-02');
const input=path.resolve(here,'../../live-gpu-workflow/orvia-live-workflow-v4');
const sha=b=>createHash('sha256').update(b).digest('hex');
const files={};
function read(name){const p=path.join(root,name);assert.equal(fs.lstatSync(p).isSymbolicLink(),false);const before=fs.statSync(p),b=fs.readFileSync(p),after=fs.statSync(p);assert.equal(before.size,after.size);assert.equal(before.mtimeMs,after.mtimeMs);files[name]={bytes:b.length,sha256:sha(b)};return b;}
const json=name=>JSON.parse(read(name));
const result=json('result.json');assert.equal(result.passed,false);assert.equal(result.timedOut,true);assert.deepEqual(result.workersStillRunning,[]);assert.equal(result.integrationStepsExecuted,338800);
const manifest=JSON.parse(fs.readFileSync(path.join(input,'manifest.json')));
const metrics=[],replicas=[];let sum=0;
for(const [model,n] of Object.entries({complex33:132935,solvent33:151505}))for(const replica of [1,2]){
  const prefix=`${model}-r${replica}/baseline/`,report=json(prefix+'result.json');
  assert.equal(report.passed,true);assert.equal(report.integrationStepsExecuted,80000);assert.equal(report.energyConservationAccepted,false);
  assert.equal(report.openmmVersion,'8.6.1.dev-b399af4');assert.equal(report.numpyVersion,'2.5.4');
  const load=name=>readObservationNpz(read(prefix+name+'.npz'),n);
  const initial=load('initial-cuda'),initialRef=load('initial-reference'),mid=load('midpoint'),final=load('final'),finalRef=load('final-reference');
  for(const [o,time] of [[initial,0],[initialRef,0],[mid,6],[final,8],[finalRef,0]]){
    assert.ok(Math.abs(o.time.values[0]-time)<1e-9);assert.ok(maximumAbsolute(o.forces.values)<2**26);
    assert.deepEqual([...o.box.values],[...initial.box.values]);
  }
  assert.equal(maximumAbsolute(initial.velocities.values),0);
  for(const [a,b] of [[initialRef,initial],[finalRef,final]])for(const key of ['positions','velocities','box'])assert.equal(maximumDifference(a[key].values,b[key].values),0);
  metrics.push({model,replica,comparison:'initial Reference/CUDA',...assertComparison(initialRef,initial,report.initialComparison)},
    {model,replica,comparison:'final Reference/CUDA',...assertComparison(finalRef,final,report.finalComparison)});
  assert.equal(report.forceMarginObservations.length,803);
  for(const r of report.forceMarginObservations){assert.equal(r.passed,true);assert.equal(r.limitKJMolNm,2**26);assert.ok(Number.isFinite(r.maxAbsoluteForceKJMolNm)&&r.maxAbsoluteForceKJMolNm>=0&&r.maxAbsoluteForceKJMolNm<2**26);}
  for(const [i,o,platform] of [[0,initial,'CUDA'],[1,initialRef,'Reference'],[601,mid,'CUDA'],[801,final,'CUDA'],[802,finalRef,'Reference']]){
    const r=report.forceMarginObservations[i];assert.equal(r.platform,platform);assert.equal(r.timePs,o.time.values[0]);assert.equal(r.maxAbsoluteForceKJMolNm,maximumAbsolute(o.forces.values));
  }
  assert.equal(report.energyTrace.length,80);
  const energy=[initial.energy.values[0]+initial.kineticEnergy.values[0]];
  for(let i=0;i<80;i++){const e=report.energyTrace[i];assert.equal(e.step,(i+1)*1000);assert.ok(Number.isFinite(e.potential_kJ_mol)&&Number.isFinite(e.kinetic_kJ_mol));energy.push(e.potential_kJ_mol+e.kinetic_kJ_mol);}
  for(const [i,o] of [[59,mid],[79,final]]){assert.equal(report.energyTrace[i].potential_kJ_mol,o.energy.values[0]);assert.equal(report.energyTrace[i].kinetic_kJ_mol,o.kineticEnergy.values[0]);}
  assert.equal(report.observedEnergyRange_kJ_mol,Math.max(...energy)-Math.min(...energy));
  assert.equal(report.checkpointSha256,sha(read(prefix+'midpoint.chk')));
  const steps={};for(const phase of ['baseline','resume']){const progress=json(`${model}-r${replica}/${phase}/progress.json`);assert.ok(Number.isSafeInteger(progress.steps)&&progress.steps>=0&&progress.steps<=(phase==='baseline'?80000:20000));steps[phase]=progress.steps;sum+=progress.steps;}
  if(replica===1){
    const t=json(prefix+'trajectory.json'),selection=JSON.parse(fs.readFileSync(path.join(input,`inputs/${model}/selection.json`)));
    assert.equal(report.trajectorySha256,files[prefix+'trajectory.json'].sha256);assert.equal(t.jobId,result.jobId);assert.equal(t.source.runnerSha256,result.sourceSha256);assert.equal(t.source.inputManifestSha256,result.inputManifestSha256);assert.equal(t.source.selectionSha256,manifest.files[`inputs/${model}/selection.json`].sha256);
    assert.deepEqual(t.atoms,selection.atoms);assert.deepEqual(t.bonds,selection.bonds);assert.deepEqual(t.backboneLinks,selection.backboneLinks);assert.equal(t.frames.length,101);
    for(let i=0;i<101;i++){const frame=t.frames[i];assert.equal(frame.step,i*800);assert.equal(frame.timeFs,i*80);assert.equal(frame.positions.length,selection.atoms.length);for(const xyz of frame.positions)assert.ok(xyz.length===3&&xyz.every(Number.isFinite));}
    for(const [i,o] of [[0,initial],[75,mid],[100,final]]){
      assert.equal(t.frames[i].fullPositionsSha256,sha(o.positions.raw));
      for(let atom=0;atom<selection.atoms.length;atom++)for(let axis=0;axis<3;axis++){
        const length=o.box.values[axis*3+axis],delta=t.frames[i].positions[atom][axis]-o.positions.values[selection.atoms[atom].index*3+axis];assert.ok(Math.abs(delta-Math.round(delta/length)*length)<=5.1e-7);
      }
    }
  }
  replicas.push({model,replica,baselineSteps:steps.baseline,partialReplayReportedSteps:steps.resume,allRetainedArraysFinite:true,exactReferenceStateMatch:true,forceObservationCount:803});
}
assert.equal(sum,result.integrationStepsExecuted);
const audit={schema:'orvia.stress-original-baselines-array-review.v1',reviewedAt:new Date().toISOString(),passed:true,originalRunPassed:false,originalTimedOut:true,sourceBoundReportedSteps:sum,newReplayTargetSteps:80000,aggregateReportedStepsIfNewTargetCompletes:sum+80000,plannedCohortSteps:400000,diagnosticOnly:true,scientificAcceptance:false,metrics,replicas,files,molecularEvaluations:0,gpuEvaluations:0,networkRequests:0};
fs.writeFileSync(path.join(here,'actual-parent-baseline-array-review.json'),JSON.stringify(audit,null,2)+'\n');
console.log(JSON.stringify({passed:true,baselineComparisons:metrics.length,baselineReplicas:replicas,originalReportedSteps:sum,aggregateIfRecoveryCompletes:sum+80000,maximumEnergyDifference:Math.max(...metrics.map(m=>m.energy_absolute_kJ_mol)),maximumForceDifference:Math.max(...metrics.map(m=>m.force_max_absolute_kJ_mol_nm)),maximumForceRelativeL2:Math.max(...metrics.map(m=>m.force_relative_L2))},null,2));
