#!/usr/bin/env python3
"""Restore the licensed, hash-pinned Linux runtime onto a fresh H200 pod.

This installs only the official NumPy binary dependency; it does not rebuild or
change the numerical engine, run molecular work, sign reports, or stop the pod.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import platform
import shutil
import subprocess
import sys
import tarfile
import zipfile

LICENSED_ZIP_SHA = '88aa8f1997ea520027f6403822c5a2973363d15447b8f75e8d01b50bce641e50'
ENGINE_REPORT_SHA = '82f3560f4ff7e0b780b65608f50d188e85d12a08b7bd5c14fba82d8236833f4f'
BUILD_ROOT = Path('/workspace/orvia-native-double-build-r2')


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 ** 2), b''):
            h.update(block)
    return h.hexdigest()


def safe_relative(name):
    rel = PurePosixPath(name)
    require(name and not rel.is_absolute() and '..' not in rel.parts and '\\' not in name, 'Unsafe archive path')
    return Path(*rel.parts)


def copy_exact(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    require(not target.is_symlink(), 'Refusing symlink destination')
    if target.exists():
        require(target.is_file() and sha(target) == sha(source), 'Existing runtime file differs: ' + target.name)
    else:
        shutil.copyfile(source, target)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--archive', type=Path, required=True)
    ap.add_argument('--restore-root', type=Path, default=Path('/workspace/orvia-live-engine-restore'))
    ap.add_argument('--python', default='python3.12')
    args = ap.parse_args()
    require(platform.system() == 'Linux' and platform.machine() == 'x86_64', 'Linux x86_64 runtime required')
    require(sha(args.archive) == LICENSED_ZIP_SHA, 'Licensed runtime archive identity mismatch')
    root = args.restore_root.resolve()
    root.mkdir(parents=True, exist_ok=True)
    outer = root / 'licensed-runtime'
    outer.mkdir(exist_ok=True)
    with zipfile.ZipFile(args.archive) as packed:
        require(len(packed.infolist()) == 6 and sum(x.file_size for x in packed.infolist()) < 30 * 1024 ** 2, 'Unexpected licensed archive layout')
        for entry in packed.infolist():
            target = outer / safe_relative(entry.filename)
            require(not entry.is_dir() and ((entry.external_attr >> 16) & 0o170000) != 0o120000, 'Unsupported ZIP member')
            data = packed.read(entry)
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.exists():
                require(target.read_bytes() == data, 'Changed restored license artifact')
            else:
                target.write_bytes(data)
    checksums = json.loads((outer / 'CHECKSUMS.json').read_text())
    for name, record in checksums.items():
        p = outer / safe_relative(name)
        require(p.stat().st_size == record['bytes'] and sha(p) == record['sha256'], 'Licensed archive payload mismatch')
    unpack = root / 'unpacked'
    unpack.mkdir(exist_ok=True)
    with tarfile.open(outer / 'historical-runtime/orvia-native-double-pme-engine.tar.gz', 'r:gz') as packed:
        entries = packed.getmembers()
        require(len(entries) < 500 and sum(x.size for x in entries) < 200 * 1024 ** 2, 'Runtime expansion exceeds bound')
        for entry in entries:
            rel = safe_relative(entry.name)
            require(rel.parts[0] == 'orvia-native-double-pme-engine' and (entry.isfile() or entry.isdir()), 'Unsafe runtime member')
            target = unpack / rel
            if entry.isdir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            data = packed.extractfile(entry).read()
            if target.exists():
                require(target.read_bytes() == data, 'Changed extracted runtime artifact')
            else:
                target.write_bytes(data)
    runtime = unpack / 'orvia-native-double-pme-engine'
    manifest = json.loads((runtime / 'manifest.json').read_text())
    require(manifest['sourceBuildReportSha256'] == ENGINE_REPORT_SHA, 'Wrong source build report')
    for name, record in manifest['files'].items():
        p = runtime / safe_relative(name)
        require(p.is_file() and not p.is_symlink() and p.stat().st_size == record['bytes'] and sha(p) == record['sha256'], 'Runtime file mismatch')
    original_report = runtime / 'evidence/build-report.json'
    require(sha(original_report) == ENGINE_REPORT_SHA, 'Historical engine report mismatch')
    probe = json.loads(subprocess.check_output([args.python, '-c', 'import sys,json,platform;print(json.dumps({"version":list(sys.version_info[:3]),"machine":platform.machine()}))'], timeout=15))
    require(probe['version'][:2] == [3, 12] and probe['machine'] == 'x86_64', 'CPython3.12 x86_64 required')
    BUILD_ROOT.mkdir(parents=True, exist_ok=True)
    python = BUILD_ROOT / 'venv/bin/python'
    if not python.exists():
        subprocess.run([args.python, '-m', 'venv', str(BUILD_ROOT / 'venv')], timeout=60, check=True)
    subprocess.run([str(python), '-m', 'pip', 'install', '--disable-pip-version-check', '--only-binary=:all:', '--no-deps', '--index-url', 'https://pypi.org/simple', 'numpy==2.5.4'], timeout=180, check=True)
    site = Path(subprocess.check_output([str(python), '-c', 'import sysconfig; print(sysconfig.get_paths()["purelib"])'], timeout=10, text=True).strip())
    require(site.is_relative_to(BUILD_ROOT / 'venv'), 'Unexpected virtual environment site directory')
    for source in (runtime / 'python-site').rglob('*'):
        if source.is_file():
            copy_exact(source, site / source.relative_to(runtime / 'python-site'))
    for source in (runtime / 'runtime/prefix').rglob('*'):
        if source.is_file():
            copy_exact(source, BUILD_ROOT / 'prefix' / source.relative_to(runtime / 'runtime/prefix'))
    copy_exact(original_report, BUILD_ROOT / 'build-report.json')
    env = {**os.environ, 'LD_LIBRARY_PATH': str(BUILD_ROOT / 'prefix/lib'), 'OPENMM_PLUGIN_DIR': str(BUILD_ROOT / 'prefix/lib/plugins')}
    preflight = json.loads(subprocess.check_output([str(python), '-c',
        'import openmm,numpy,json,sys; print(json.dumps({"openmm":openmm.version.full_version,"numpy":numpy.__version__,"module":openmm.__file__,"python":sys.version,"platforms":[openmm.Platform.getPlatform(i).getName() for i in range(openmm.Platform.getNumPlatforms())]}))'], env=env, timeout=30, text=True))
    require(preflight['numpy'] == '2.5.4' and preflight['openmm'] == '8.6.1.dev-b399af4' and 'CUDA' in preflight['platforms'] and 'Reference' in preflight['platforms'], 'Restored engine preflight failed')
    binding = {'schema': 'orvia.restored-engine-environment-binding.v1', 'createdAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'licensedArchiveSha256': LICENSED_ZIP_SHA, 'historicalBuildReportSha256': ENGINE_REPORT_SHA,
        'exportManifestSha256': sha(runtime / 'manifest.json'), 'bootstrapSourceSha256': sha(__file__),
        'historicalEngineRecompiled': False, 'numericalValidationPassed': False, 'scientificAcceptance': False,
        'restoredBuildRoot': str(BUILD_ROOT), 'host': {'system': platform.system(), 'machine': platform.machine(), 'libc': platform.libc_ver()},
        'preflight': preflight, 'originalRuntimeFilesVerified': len(manifest['files']),
        'licenseDirectory': str(outer), 'note': 'A new environment binding; original library and wrapper bytes were restored at historical prefixes. Fresh GPU validation remains required.'}
    path = root / 'environment-binding.json'
    path.write_text(json.dumps(binding, indent=2) + '\n')
    print(json.dumps({'restored': True, 'binding': str(path), 'bindingSha256': sha(path), 'engineBuildReport': str(BUILD_ROOT / 'build-report.json'), 'python': str(python)}))


if __name__ == '__main__':
    main()
