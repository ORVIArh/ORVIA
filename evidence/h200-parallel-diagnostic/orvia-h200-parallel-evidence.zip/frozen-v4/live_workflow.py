#!/usr/bin/env python3
"""Bounded, diagnostic-only H200 dynamics and process-restart validation.

The supervisor holds a telemetry-only token; GPU children receive no token.
No wallet signing, Runpod control, scientific acceptance, or production campaign.
"""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import signal
import subprocess
import sys
import tarfile
import time
import urllib.error
import urllib.request

ENGINE_SHA = '82f3560f4ff7e0b780b65608f50d188e85d12a08b7bd5c14fba82d8236833f4f'
ENDPOINT = 'https://orvia.fyi/api/orvia/worker'
MODELS = ('complex33', 'solvent33')
TOTAL_STEPS = 3000  # 2 x (1000 baseline + 500 replay integration steps)
DT_PS = 0.0001
STEPS = 1000
MIDPOINT = 500
FORCE_MARGIN = 2 ** 26
TOLERANCES = {'energy_absolute_kJ_mol': 0.01, 'force_max_absolute_kJ_mol_nm': 0.05, 'force_relative_L2': 5e-5}
TRAJECTORY_ENDPOINT = 'https://orvia.fyi/api/orvia/trajectory'
IMAGING_METHOD = 'minimum-image initial chain and ligand unwrapping; per-atom temporal unwrapping; no alignment or interpolation'
RESTART_TOLERANCES = {'positions_max_abs_nm': 1e-9, 'velocities_max_abs_nm_ps': 1e-8}
JOB_RE = re.compile(r'^[a-zA-Z0-9_-]{8,80}$')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.tmp')
    with temporary.open('w') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def verify_bundle(bundle):
    bundle = Path(bundle).resolve()
    manifest = json.loads((bundle / 'manifest.json').read_text())
    require(manifest.get('schema') == 'orvia.live-checkpoint-diagnostic-inputs.v1', 'Wrong bundle schema')
    require(manifest.get('diagnosticOnly') is True and manifest.get('scientificAcceptance') is False, 'Diagnostic-only bundle required')
    require(manifest.get('engineBuildReportSha256') == ENGINE_SHA, 'Wrong pinned engine')
    require(manifest.get('configuration') == configuration(), 'Changed declared diagnostic configuration')
    declared = {'manifest.json'}
    for name, item in manifest['files'].items():
        rel = PurePosixPath(name)
        require(not rel.is_absolute() and '..' not in rel.parts and '\\' not in name and name == str(rel), 'Unsafe bundle path')
        path = bundle / name
        require(path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(bundle), 'Missing/unsafe bundle file')
        require(path.stat().st_size == item['bytes'] and sha(path) == item['sha256'], 'Bundle identity mismatch: ' + name)
        declared.add(name)
    actual = {str(p.relative_to(bundle)) for p in bundle.rglob('*') if p.is_file()}
    require(actual == declared, 'Missing or undeclared input files')
    require(sha(__file__) == manifest['files']['live_workflow.py']['sha256'], 'Running source differs from frozen source')
    return manifest


def record_force_margin(report, maximum, platform, time_ps):
    require(isinstance(maximum, (int, float)) and math.isfinite(maximum) and maximum >= 0, 'Invalid force maximum')
    row = {'platform': platform, 'timePs': time_ps, 'maxAbsoluteForceKJMolNm': maximum,
           'limitKJMolNm': FORCE_MARGIN, 'passed': maximum < FORCE_MARGIN}
    report.setdefault('forceMarginObservations', []).append(row)
    require(row['passed'], 'Observed force exceeds preserved 2^26 margin: ' + str(maximum))


def configuration():
    return {'experiment': 'ORVIA-ADP-PHOSPHATE-v0.3', 'models': list(MODELS),
            'baselineStepsPerModel': STEPS, 'restartAtStep': MIDPOINT,
            'replayStepsPerModel': STEPS - MIDPOINT, 'timeStepPs': DT_PS,
            'trajectoryTimePsPerModel': STEPS * DT_PS,
            'initialVelocities': 'zero', 'integrator': 'Verlet',
            'precision': 'double', 'deterministicForces': True,
            'constraintTolerance': 1e-8, 'forceMarginKJMolNm': FORCE_MARGIN,
            'forceObservationIntervalSteps': 100, 'comparisonTolerances': TOLERANCES,
            'restartContinuationTolerances': RESTART_TOLERANCES,
            'purpose': 'Fresh bounded dynamics, strict force agreement and cross-process checkpoint restart; not equilibrium or production sampling'}


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, msg, headers, newurl):
        return None


class Telemetry:
    def __init__(self, root, job_id, token, sender=None):
        require(JOB_RE.fullmatch(job_id) is not None, 'Invalid workflow ID')
        require(isinstance(token, str) and 32 <= len(token) <= 256 and '\n' not in token and '\r' not in token, 'Telemetry credential unavailable')
        self.root, self.job_id, self.token = Path(root), job_id, token
        self.sender = sender or self._send
        self.sequence, self.acknowledged, self.pending = 0, 0, []
        self.last_steps, self.terminal = 0, False

    def _post(self, url, data, timeout):
        # A separate bounded helper also bounds slow headers/bodies and TLS stalls.
        # The credential travels through a private pipe, never argv or an artifact.
        code = """import json,sys,urllib.request,urllib.error,hashlib
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs): return None
try:
 x=json.load(sys.stdin); body=x['body'].encode('utf-8')
 h={'Content-Type':'application/json','Authorization':'Bearer '+x['token']}
 if x['url'].endswith('/trajectory'): h['X-ORVIA-SHA256']=hashlib.sha256(body).hexdigest()
 r=urllib.request.Request(x['url'],data=body,headers=h,method='POST')
 with urllib.request.build_opener(NoRedirect()).open(r,timeout=x['timeout']) as response: status=response.status
except urllib.error.HTTPError as error: status=error.code
except Exception: status=503
print(status)
"""
        clean_env = {k: v for k, v in os.environ.items() if k not in ('ORVIA_WORKER_TOKEN', 'RUNPOD_API_KEY', 'NETLIFY_AUTH_TOKEN') and not k.startswith('ORVIA_WALLET')}
        try:
            result = subprocess.run([sys.executable, '-c', code],
                input=json.dumps({'url': url, 'body': data.decode('utf-8'), 'token': self.token, 'timeout': timeout}),
                text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=clean_env, timeout=timeout, check=False)
            return int(result.stdout.strip()) if result.returncode == 0 else 503
        except (subprocess.TimeoutExpired, ValueError, OSError):
            return 503

    def _send(self, payload):
        return self._post(ENDPOINT, json.dumps(payload, separators=(',', ':')).encode(), self.request_timeout)

    def flush(self, max_seconds=8, deadline=None):
        stop_at = time.monotonic() + max_seconds
        if deadline is not None:
            stop_at = min(stop_at, deadline)
        code = 503
        while self.pending and time.monotonic() < stop_at:
            payload = self.pending[0]
            self.request_timeout = max(0.001, stop_at - time.monotonic())
            code = self.sender(payload)
            if code != 200:
                break
            self.acknowledged = payload['sequence']
            self.pending.pop(0)
        write_json(self.root / 'telemetry-delivery.json', {'acknowledgedSequence': self.acknowledged,
            'pendingEvents': len(self.pending), 'lastHttpStatus': 200 if not self.pending else code, 'updatedAt': utc()})
        return not self.pending

    def emit(self, state, stage, steps, result_hash=None, checkpoint_hash=None, deadline=None):
        require(not self.terminal and self.last_steps <= steps <= TOTAL_STEPS, 'Invalid telemetry progression')
        require(self.sequence < 10000, 'Telemetry sequence budget exhausted')
        self.sequence += 1
        payload = {'schemaVersion': 1, 'jobId': self.job_id, 'sequence': self.sequence,
            'state': state, 'stage': stage, 'stepsCompleted': steps, 'stepsTotal': TOTAL_STEPS,
            'updatedAt': utc(), 'device': 'NVIDIA H200', 'diagnosticOnly': True, 'scientificAcceptance': False,
            'resultSha256': result_hash, 'checkpointSha256': checkpoint_hash}
        write_json(self.root / 'telemetry' / f'{self.sequence:06d}.json', payload)
        self.pending.append(payload)
        self.last_steps = steps
        self.terminal = state in ('completed', 'failed')
        return self.flush(deadline=deadline)


    def upload_trajectory(self, path, deadline=None):
        data = Path(path).read_bytes()
        require(0 < len(data) <= 4 * 1024 * 1024, 'Trajectory exceeds public upload bound')
        code = 503
        for attempt in range(3):
            remaining = 15 if deadline is None else min(15, deadline - time.monotonic())
            if remaining <= 0:
                break
            code = self._post(TRAJECTORY_ENDPOINT, data, remaining)
            if code in (200, 201):
                break
        record = {'sha256': sha(path), 'bytes': len(data), 'uploaded': code in (200, 201), 'lastHttpStatus': code}
        write_json(Path(path).with_suffix('.upload.json'), record)
        return record


class Trajectory:
    """Select genuine simulation coordinates; apply only declared lattice translations."""
    def __init__(self, np, bundle, model, job_id, box, atom_count):
        self.np = np
        self.box = np.asarray(box, dtype=float)
        self.lengths = np.diag(self.box)
        require(np.array_equal(self.box, np.diag(self.lengths)) and bool((self.lengths > 0).all()), 'Declared visualization requires the pinned orthorhombic box')
        self.previous_raw = self.previous_display = None
        selection_path = bundle / 'inputs' / model / 'selection.json'
        selection = json.loads(selection_path.read_text())
        atoms = selection['atoms']
        self.indices = np.asarray([a['index'] for a in atoms], dtype=int)
        self.payload = {'schemaVersion': 1, 'jobId': job_id, 'modelId': model,
            'label': 'Myosin-ligand complex' if model == 'complex33' else 'Ligand in solvent',
            'fullAtomCount': atom_count, 'selectedAtomCount': len(atoms),
            'selection': 'protein C-alpha and all ligand atoms' if model == 'complex33' else 'all ligand atoms',
            'timeUnit': 'fs', 'lengthUnit': 'nm', 'atoms': atoms, 'bonds': selection['bonds'],
            'backboneLinks': selection['backboneLinks'], 'frames': [], 'diagnosticOnly': True, 'scientificAcceptance': False,
            'source': {'systemSha256': sha(bundle / 'inputs' / model / 'system.xml'),
                'positionsSha256': sha(bundle / 'inputs' / model / 'positions.json'),
                'selectionSha256': sha(selection_path), 'topologySha256': selection['topologySha256'],
                'runnerSha256': sha(__file__), 'inputManifestSha256': sha(bundle / 'manifest.json')},
            'imaging': {'method': IMAGING_METHOD, 'boxVectorsNm': self.box.tolist(), 'coordinateDecimals': 6}}
        self.protein = [i for i, a in enumerate(atoms) if a['group'] == 'protein']
        self.ligand = [i for i, a in enumerate(atoms) if a['group'] == 'ligand']
        self.bonds = selection['bonds']
    def minimum(self, delta):
        fractional = delta / self.lengths
        return (fractional - self.np.round(fractional)) * self.lengths
    def capture(self, step, full_positions):
        np = self.np
        full_positions = np.asarray(full_positions, dtype=np.float64)
        require(bool(np.isfinite(full_positions).all()), 'Nonfinite trajectory coordinates')
        raw = full_positions[self.indices].copy()
        if self.previous_raw is None:
            display = raw.copy()
            for a, b in self.payload['backboneLinks']:
                display[b] = display[a] + self.minimum(raw[b] - raw[a])
            adjacency = {i: [] for i in self.ligand}
            for a, b in self.bonds:
                if a in adjacency and b in adjacency:
                    adjacency[a].append(b)
                    adjacency[b].append(a)
            seen = set()
            for first in self.ligand:
                if first in seen:
                    continue
                seen.add(first)
                queue = [first]
                while queue:
                    a = queue.pop(0)
                    for b in adjacency[a]:
                        if b not in seen:
                            display[b] = display[a] + self.minimum(raw[b] - raw[a])
                            seen.add(b)
                            queue.append(b)
            if self.protein and self.ligand:
                anchor = self.ligand[0]
                deltas = self.minimum(raw[anchor] - raw[self.protein])
                nearest = int(np.argmin(np.sum(deltas * deltas, axis=1)))
                desired = display[self.protein[nearest]] + deltas[nearest]
                display[self.ligand] += desired - display[anchor]
        else:
            display = self.previous_display + self.minimum(raw - self.previous_raw)
        self.previous_raw, self.previous_display = raw, display
        self.payload['frames'].append({'step': step, 'timeFs': round(step * DT_PS * 1000, 6),
            'positions': np.round(display, 6).tolist(),
            'fullPositionsSha256': hashlib.sha256(np.ascontiguousarray(full_positions, dtype='<f8').tobytes()).hexdigest()})
    def save(self, path):
        raw = json.dumps(self.payload, separators=(',', ':'), allow_nan=False).encode()
        require(len(raw) <= 4 * 1024 * 1024, 'Trajectory exceeds artifact bound')
        path = Path(path)
        temporary = path.with_suffix('.tmp')
        temporary.write_bytes(raw)
        temporary.replace(path)


def engine_environment(path):
    path = Path(path).resolve()
    require(sha(path) == ENGINE_SHA, 'Validated engine build report changed')
    engine = json.loads(path.read_text())
    require(engine.get('buildPassed') is True and engine.get('artifacts'), 'Validated engine unavailable')
    for name, record in engine['artifacts'].items():
        artifact = (path.parent / name).resolve()
        require(artifact.is_relative_to(path.parent) and artifact.is_file() and artifact.stat().st_size == record['bytes'] and sha(artifact) == record['sha256'], 'Engine library identity mismatch')
    env = {k: v for k, v in os.environ.items() if k not in ('ORVIA_WORKER_TOKEN', 'RUNPOD_API_KEY', 'NETLIFY_AUTH_TOKEN', 'PYTHONPATH', 'PYTHONOPTIMIZE') and not k.startswith('ORVIA_WALLET')}
    env.update(OPENMM_PLUGIN_DIR=engine['pluginDirectory'], LD_LIBRARY_PATH=engine['libraryPrefix'] + '/lib',
               PYTHONUNBUFFERED='1', OMP_NUM_THREADS='4', OPENBLAS_NUM_THREADS='4')
    return engine, env


def worker(args):
    """One fresh process per baseline or checkpoint continuation."""
    import numpy as np
    import openmm as mm
    from openmm import unit
    manifest = verify_bundle(args.bundle)
    engine, _ = engine_environment(args.engine_build_report)
    binding = json.loads(args.environment_binding.read_text())
    require(binding.get('historicalBuildReportSha256') == ENGINE_SHA and binding.get('bootstrapSourceSha256') == manifest['files']['bootstrap_live_engine.py']['sha256'], 'Restored runtime environment binding mismatch')
    require(binding.get('exportManifestSha256') == sha(args.bundle / 'engine-export-manifest.json'), 'Wrong engine export binding')
    import sysconfig
    installed_site = Path(sysconfig.get_paths()['purelib'])
    exported = json.loads((args.bundle / 'engine-export-manifest.json').read_text())
    for relative, record in exported['files'].items():
        if relative.startswith('python-site/'):
            wrapper = installed_site / relative[len('python-site/'):]
            require(wrapper.is_file() and wrapper.stat().st_size == record['bytes'] and sha(wrapper) == record['sha256'], 'Restored Python wrapper changed')
    require(Path(sys.prefix).resolve() == Path(engine['python']).parent.parent.resolve(), 'Wrong engine Python environment')
    require(Path(mm.__file__).resolve().is_relative_to(Path(sys.prefix).resolve()), 'Wrong OpenMM module')
    require(os.environ.get('OPENMM_PLUGIN_DIR') == engine['pluginDirectory'], 'Wrong engine plugin directory')
    require(os.environ.get('LD_LIBRARY_PATH', '').split(':')[0] == engine['libraryPrefix'] + '/lib', 'Wrong engine library prefix')
    out = args.output
    out.mkdir(parents=True, exist_ok=False)
    report = {'schema': 'orvia.live-checkpoint-diagnostic-phase.v1', 'phase': args.phase, 'model': args.model,
        'startedAt': utc(), 'passed': False, 'diagnosticOnly': True, 'scientificAcceptance': False,
        'configuration': configuration(), 'engineBuildReportSha256': ENGINE_SHA, 'sourceSha256': sha(__file__),
        'bundleManifestSha256': sha(args.bundle / 'manifest.json'), 'environmentBindingSha256': sha(args.environment_binding), 'integrationStepsExecuted': 0}
    contexts = []
    def progress(stage, count):
        write_json(out / 'progress.json', {'stage': stage, 'steps': count, 'updatedAt': utc()})
    def finish():
        report['completedAt'] = utc()
        write_json(out / 'result.json', report)
    def finite(a):
        require(bool(np.isfinite(a).all()), 'Nonfinite numerical data')
        return a
    def observe(context):
        state = context.getState(getPositions=True, getVelocities=True, getEnergy=True, getForces=True)
        e = float(state.getPotentialEnergy().value_in_unit(unit.kilojoule_per_mole))
        ke = float(state.getKineticEnergy().value_in_unit(unit.kilojoule_per_mole))
        require(math.isfinite(e) and math.isfinite(ke), 'Nonfinite energy')
        forces = finite(np.asarray(state.getForces(asNumpy=True).value_in_unit(unit.kilojoule_per_mole / unit.nanometer)))
        force_max = float(np.max(np.abs(forces)))
        record_force_margin(report, force_max, context.getPlatform().getName(), float(state.getTime().value_in_unit(unit.picosecond)))
        return {'positions': finite(np.asarray(state.getPositions(asNumpy=True).value_in_unit(unit.nanometer))),
                'velocities': finite(np.asarray(state.getVelocities(asNumpy=True).value_in_unit(unit.nanometer / unit.picosecond))),
                'forces': forces,
                'box': finite(np.asarray(state.getPeriodicBoxVectors(asNumpy=True).value_in_unit(unit.nanometer))),
                'time': float(state.getTime().value_in_unit(unit.picosecond)), 'energy': e, 'kineticEnergy': ke}
    def save_observation(path, obs):
        np.savez_compressed(path, **obs)
    def compare(a, b):
        delta = b['forces'] - a['forces']
        norm = float(np.linalg.norm(a['forces']))
        metrics = {'energy_absolute_kJ_mol': abs(a['energy'] - b['energy']),
            'force_max_absolute_kJ_mol_nm': float(np.max(np.abs(delta))),
            'force_relative_L2': float(np.linalg.norm(delta)) / max(norm, 1e-12)}
        require(all(math.isfinite(v) for v in metrics.values()), 'Invalid comparison arithmetic')
        return {**metrics, 'passed': all(metrics[k] <= limit for k, limit in TOLERANCES.items())}
    try:
        progress('loading', 0)
        system = mm.XmlSerializer.deserialize((args.bundle / 'inputs' / args.model / 'system.xml').read_text())
        positions_payload = json.loads((args.bundle / 'inputs' / args.model / 'positions.json').read_text())
        positions = finite(np.asarray(positions_payload['positions_nm'], dtype=np.float64))
        require(positions.shape == (system.getNumParticles(), 3), 'Position size mismatch')
        require(system.getNumParticles() == {'complex33': 132935, 'solvent33': 151505}[args.model], 'Unexpected full-model size')
        box = np.asarray([v.value_in_unit(unit.nanometer) for v in system.getDefaultPeriodicBoxVectors()])
        require(np.array_equal(box, np.asarray(positions_payload['box_vectors_nm'])), 'Input box mismatch')
        nb = [system.getForce(i) for i in range(system.getNumForces()) if isinstance(system.getForce(i), mm.NonbondedForce)]
        require(len(nb) == 1 and nb[0].getNonbondedMethod() == mm.NonbondedForce.PME, 'Expected one native PME force')
        def make_context(platform):
            integrator = mm.VerletIntegrator(DT_PS * unit.picoseconds)
            integrator.setConstraintTolerance(1e-8)
            props = {'Precision': 'double', 'DeviceIndex': '0', 'UseCpuPme': 'false', 'DeterministicForces': 'true'} if platform == 'CUDA' else {}
            c = mm.Context(system, integrator, mm.Platform.getPlatformByName(platform), props)
            contexts.append((c, integrator))
            actual = c.getPlatform()
            actual_props = {n: actual.getPropertyValue(c, n) for n in actual.getPropertyNames()}
            require(actual.getName() == platform, 'Wrong actual platform')
            if platform == 'CUDA':
                require(actual_props.get('Precision') == 'double' and actual_props.get('UseCpuPme') == 'false' and actual_props.get('DeterministicForces') == 'true', 'Wrong CUDA settings')
            pme = nb[0].getPMEParametersInContext(c)
            alpha = pme[0].value_in_unit(1 / unit.nanometer) if hasattr(pme[0], 'value_in_unit') else float(pme[0])
            settings = [float(alpha), *map(int, pme[1:])]
            expected = manifest['models'][args.model]['pme']
            require(settings == expected, 'Actual PME differs from pinned grid')
            report.setdefault('contexts', {})[platform] = {'actualPlatform': actual.getName(), 'properties': actual_props, 'actualPme': settings}
            return c, integrator
        gpu, integrator = make_context('CUDA')
        report['particles'] = system.getNumParticles()
        report['openmmVersion'] = mm.version.full_version
        report['numpyVersion'] = np.__version__
        if args.phase == 'baseline':
            gpu.setPositions(positions * unit.nanometer)
            gpu.applyConstraints(1e-8)
            gpu.setVelocities(np.zeros_like(positions) * unit.nanometer / unit.picosecond)
            initial = observe(gpu)
            trajectory = Trajectory(np, args.bundle, args.model, args.job_id, box, system.getNumParticles())
            trajectory.capture(0, initial['positions'])
            progress('validating', 0)
            reference, _ = make_context('Reference')
            reference.setPositions(initial['positions'] * unit.nanometer)
            reference.setVelocities(initial['velocities'] * unit.nanometer / unit.picosecond)
            initial_ref = observe(reference)
            report['initialComparison'] = compare(initial_ref, initial)
            save_observation(out / 'initial-reference.npz', initial_ref)
            save_observation(out / 'initial-cuda.npz', initial)
            require(report['initialComparison']['passed'], 'Initial strict Reference/CUDA comparison failed')
            report['energyTrace'] = []
            for step in range(10, STEPS + 1, 10):
                progress('simulating', step - 10)
                integrator.step(10)
                report['integrationStepsExecuted'] = step
                frame_positions = finite(np.asarray(gpu.getState(getPositions=True).getPositions(asNumpy=True).value_in_unit(unit.nanometer)))
                trajectory.capture(step, frame_positions)
                if step % 100:
                    continue
                current = observe(gpu)
                report['energyTrace'].append({'step': step, 'potential_kJ_mol': current['energy'], 'kinetic_kJ_mol': current['kineticEnergy'], 'total_kJ_mol': current['energy'] + current['kineticEnergy']})
                progress('checkpointing' if step == MIDPOINT else 'simulating', step)
                if step == MIDPOINT:
                    (out / 'midpoint.chk').write_bytes(gpu.createCheckpoint())
                    save_observation(out / 'midpoint.npz', current)
                    trajectory.save(out / 'trajectory-partial.json')
                write_json(out / 'partial-result.json', report)
            final = observe(gpu)
            save_observation(out / 'final.npz', final)
            (out / 'final.chk').write_bytes(gpu.createCheckpoint())
            progress('validating', STEPS)
            reference.setPositions(final['positions'] * unit.nanometer)
            reference.setVelocities(final['velocities'] * unit.nanometer / unit.picosecond)
            final_ref = observe(reference)
            save_observation(out / 'final-reference.npz', final_ref)
            report['finalComparison'] = compare(final_ref, final)
            require(report['finalComparison']['passed'], 'Final strict Reference/CUDA comparison failed')
            energies = [initial['energy'] + initial['kineticEnergy']] + [r['total_kJ_mol'] for r in report['energyTrace']]
            report['observedEnergyRange_kJ_mol'] = max(energies) - min(energies)
            report['energyConservationAccepted'] = False  # No campaign drift threshold is preregistered.
            report['checkpointSha256'] = sha(out / 'midpoint.chk')
            trajectory.save(out / 'trajectory.json')
            report['trajectorySha256'] = sha(out / 'trajectory.json')
        else:
            baseline = args.baseline
            require(baseline and json.loads((baseline / 'result.json').read_text()).get('passed') is True, 'Successful bound baseline required')
            checkpoint = baseline / 'midpoint.chk'
            base = json.loads((baseline / 'result.json').read_text())
            require(base['model'] == args.model and base['bundleManifestSha256'] == report['bundleManifestSha256'] and sha(checkpoint) == base['checkpointSha256'], 'Baseline/checkpoint identity mismatch')
            report['baselineResultSha256'] = sha(baseline / 'result.json')
            gpu.loadCheckpoint(checkpoint.read_bytes())
            restored = observe(gpu)
            save_observation(out / 'restored.npz', restored)
            with np.load(baseline / 'midpoint.npz', allow_pickle=False) as expected:
                restore_metrics = {k: float(np.max(np.abs(restored[k] - expected[k]))) for k in ('positions', 'velocities', 'box')}
                restore_metrics['time'] = abs(restored['time'] - float(expected['time']))
            report['restoreMaxAbsoluteDifferences'] = restore_metrics
            require(all(v == 0 for v in restore_metrics.values()), 'Checkpoint did not exactly restore saved state')
            for step in range(100, STEPS - MIDPOINT + 1, 100):
                progress('simulating', step - 100)
                integrator.step(100)
                report['integrationStepsExecuted'] = step
                current = observe(gpu)
                progress('simulating', step)
                write_json(out / 'partial-result.json', report)
            final = observe(gpu)
            save_observation(out / 'final.npz', final)
            (out / 'final.chk').write_bytes(gpu.createCheckpoint())
            with np.load(baseline / 'final.npz', allow_pickle=False) as expected:
                metrics = {'positions_max_abs_nm': float(np.max(np.abs(final['positions'] - expected['positions']))),
                    'velocities_max_abs_nm_ps': float(np.max(np.abs(final['velocities'] - expected['velocities'])))}
                report['continuationForceComparison'] = compare({k: expected[k] for k in expected.files}, final)
            report['continuationComparison'] = {**metrics, 'passed': all(metrics[k] <= v for k, v in RESTART_TOLERANCES.items())}
            require(report['continuationComparison']['passed'] and report['continuationForceComparison']['passed'], 'Resumed trajectory differs beyond declared tolerances')
            report['checkpointSha256'] = sha(out / 'final.chk')
        report['passed'] = True
        progress('finished', report['integrationStepsExecuted'])
    except Exception as error:
        report['error'] = {'type': type(error).__name__, 'message': str(error)[:1000]}
        progress('failed', report['integrationStepsExecuted'])
    finally:
        finish()
        contexts.clear()
    return 0 if report['passed'] else 1


def supervise(args):
    require(JOB_RE.fullmatch(args.job_id) is not None, 'Invalid workflow ID')
    require(0 < args.max_seconds <= 1200, 'Maximum wall time is 1200 seconds')
    manifest = verify_bundle(args.bundle)
    engine, environment = engine_environment(args.engine_build_report)
    root = args.output.resolve()
    root.mkdir(parents=True, exist_ok=False)
    token = os.environ.get('ORVIA_WORKER_TOKEN', '')
    telemetry = Telemetry(root, args.job_id, token)
    started = time.monotonic()
    deadline = started + args.max_seconds
    active = None
    steps = 0
    report = {'schema': 'orvia.live-checkpoint-diagnostic-run.v1', 'jobId': args.job_id,
        'startedAt': utc(), 'passed': False, 'diagnosticOnly': True, 'scientificAcceptance': False,
        'configuration': configuration(), 'calculationBudgetSeconds': args.max_seconds,
        'timingScope': {'hardTotalWallGuarantee': False, 'phaseBudgetsSeconds': {'baseline': 450, 'resume': 120},
            'telemetryFlushBudgetSeconds': 8, 'watchdogPollSeconds': 0.5, 'childStopGraceSeconds': 10,
            'trajectoryUploadAttemptSeconds': 15, 'trajectoryUploadAttempts': 3,
            'networkDuringCalculationSharesDeadline': True, 'finalTelemetryBudgetSeconds': 8,
            'archivalExcludedFromCalculationBudget': True},
        'sourceSha256': sha(__file__), 'inputManifestSha256': sha(args.bundle / 'manifest.json'),
        'engineBuildReportSha256': ENGINE_SHA, 'phases': [], 'automaticPodShutdown': False,
        'onChainReportSubmitted': False, 'integrationStepsExecuted': 0}
    def stop():
        nonlocal active
        if active and active.poll() is None:
            try:
                os.killpg(active.pid, signal.SIGTERM)
                active.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(active.pid, signal.SIGKILL)
                active.wait(timeout=5)
    def interrupted(signum, frame):
        stop()
        raise InterruptedError('Workflow interrupted')
    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    try:
        # Do not start paid compute until the website has accepted this workflow.
        require(telemetry.emit('running', 'starting', 0, deadline=deadline), 'Site did not accept the authenticated workflow start')
        gpu = subprocess.check_output(['nvidia-smi', '--query-gpu=name,driver_version,memory.total', '--format=csv,noheader'], timeout=15, text=True).strip()
        require('H200' in gpu and len(gpu.splitlines()) == 1, 'Expected exactly one H200 GPU')
        report['hardware'] = gpu
        write_json(root / 'run-status.json', report)
        telemetry.emit('running', 'environment', 0, deadline=deadline)
        for model in MODELS:
            for phase, phase_steps, phase_budget in (('baseline', STEPS, 450), ('resume', STEPS - MIDPOINT, 120)):
                phase_out = root / model / phase
                command = [engine['python'], str(args.bundle / 'live_workflow.py'), '--worker', '--bundle', str(args.bundle.resolve()),
                    '--engine-build-report', str(args.engine_build_report.resolve()), '--environment-binding', str(args.environment_binding.resolve()), '--model', model, '--phase', phase,
                    '--output', str(phase_out), '--job-id', args.job_id]
                if phase == 'resume':
                    command += ['--baseline', str(root / model / 'baseline')]
                telemetry.emit('running', 'loading', steps, deadline=deadline)
                phase_started = time.monotonic()
                remaining = min(phase_budget, deadline - phase_started)
                require(remaining > 0, 'Overall watchdog exhausted')
                logs = root / 'logs'
                logs.mkdir(exist_ok=True)
                with (logs / (model + '-' + phase + '.log')).open('wb') as stream:
                    active = subprocess.Popen(command, stdout=stream, stderr=subprocess.STDOUT, env=environment, start_new_session=True)
                    next_update = 0.0
                    while active.poll() is None:
                        now = time.monotonic()
                        if now - phase_started > remaining:
                            stop()
                            raise TimeoutError('GPU diagnostic phase reached its hard deadline')
                        if now >= next_update:
                            progress_file = phase_out / 'progress.json'
                            p = json.loads(progress_file.read_text()) if progress_file.exists() else {'stage': 'loading', 'steps': 0}
                            telemetry.emit('running', p['stage'] if p['stage'] not in ('finished', 'failed') else 'validating', steps + p['steps'], deadline=min(deadline, phase_started + remaining))
                            next_update = time.monotonic() + 15
                        time.sleep(0.5)
                    code = active.returncode
                active = None
                phase_result = json.loads((phase_out / 'result.json').read_text())
                steps += phase_result['integrationStepsExecuted']
                report['integrationStepsExecuted'] = steps
                report['phases'].append({'model': model, 'phase': phase, 'passed': phase_result['passed'], 'exitCode': code,
                    'elapsedSeconds': time.monotonic() - phase_started, 'resultSha256': sha(phase_out / 'result.json')})
                write_json(root / 'run-status.json', report)
                require(code == 0 and phase_result['passed'], 'Diagnostic failed; see retained phase result')
                if phase == 'baseline':
                    report.setdefault('trajectories', {})[model] = telemetry.upload_trajectory(phase_out / 'trajectory.json', deadline=deadline)
                telemetry.emit('running', 'checkpointing', steps, deadline=deadline)
        verify_bundle(args.bundle)
        require(steps == TOTAL_STEPS, 'Unexpected completed integration count')
        report['passed'] = True
    except Exception as error:
        report['error'] = {'type': type(error).__name__, 'message': str(error)[:1000]}
    finally:
        stop()
        report['completedAt'] = utc()
        report['elapsedSeconds'] = time.monotonic() - started
        # If a native call timed out after a heartbeat, retain its largest executed count.
        report['integrationStepsExecuted'] = max(report['integrationStepsExecuted'], telemetry.last_steps)
        write_json(root / 'result.json', report)
        write_json(root / 'run-status.json', report)
        checkpoint_files = {str(p.relative_to(root)): {'sha256': sha(p), 'bytes': p.stat().st_size} for p in root.rglob('*.chk')}
        write_json(root / 'checkpoints.json', checkpoint_files)
        telemetry.emit('completed' if report['passed'] else 'failed', 'finished' if report['passed'] else 'failed',
            report['integrationStepsExecuted'], sha(root / 'result.json') if report['passed'] else None,
            sha(root / 'checkpoints.json') if report['passed'] else None)
        (root / 'source.py').write_bytes(Path(__file__).read_bytes())
        (root / 'input-manifest.json').write_bytes((args.bundle / 'manifest.json').read_bytes())
        (root / 'engine-build-report.json').write_bytes(args.engine_build_report.read_bytes())
        (root / 'environment-binding.json').write_bytes(args.environment_binding.read_bytes())
        archive = root.with_suffix('.tar.gz')
        with tarfile.open(archive, 'w:gz', compresslevel=2) as packed:
            for path in sorted(root.rglob('*')):
                if path.is_file():
                    packed.add(path, arcname=str(path.relative_to(root)))
        print(json.dumps({'passed': report['passed'], 'output': str(root), 'archive': str(archive), 'archiveSha256': sha(archive),
            'diagnosticOnly': True, 'scientificAcceptance': False, 'onChainReportSubmitted': False, 'telemetryAcknowledgedSequence': telemetry.acknowledged,
            'telemetryPendingEvents': len(telemetry.pending)}))
    return 0 if report['passed'] else 1


def main():
    require(__debug__, 'Optimized Python is forbidden')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle', type=Path, required=True)
    parser.add_argument('--engine-build-report', type=Path, default=Path('/workspace/orvia-native-double-build-r2/build-report.json'))
    parser.add_argument('--environment-binding', type=Path, default=Path('/workspace/orvia-live-engine-restore/environment-binding.json'))
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--job-id')
    parser.add_argument('--max-seconds', type=int, default=1200)
    parser.add_argument('--worker', action='store_true')
    parser.add_argument('--model', choices=MODELS)
    parser.add_argument('--phase', choices=('baseline', 'resume'))
    parser.add_argument('--baseline', type=Path)
    args = parser.parse_args()
    if args.worker:
        require(args.model and args.phase, 'Worker phase and model required')
        return worker(args)
    require(args.job_id, 'Workflow ID required')
    return supervise(args)


if __name__ == '__main__':
    raise SystemExit(main())
