#!/usr/bin/env python3
"""Recover only the four checkpoint replays; preserve the original timed-out run."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time
import tarfile
from types import SimpleNamespace

JOB_ID = 'orvia-stress-replay-20261102-03'
PARENT_JOB = 'orvia-stress-20261102-02'
STRESS_SHA = '5b781a291219256f8450c6d016011b85a430f8bdc184a54256dba6b28276325b'
STRESS_MANIFEST = '9ab2588d31b1395155ef54c4b667c59e75551a1f9f8dfe07a2ad2a0cba177441'
TOTAL_STEPS = 80000
WORKER_SECONDS = 290
REPLICAS = (('complex33', 1), ('complex33', 2), ('solvent33', 1), ('solvent33', 2))


def configuration():
    return {'jobId': JOB_ID, 'parentJobId': PARENT_JOB, 'newIntegrationSteps': TOTAL_STEPS,
            'replays': 4, 'stepsPerReplay': 20000, 'reusedBaselineSteps': 320000,
            'timeStepPs': 0.0001, 'workerCutoffSeconds': WORKER_SECONDS, 'cleanupReserveSeconds': 10,
            'protocol': 'Invoke unchanged frozen stress worker for four new separate-process checkpoint replays',
            'priorAttemptRemainsFailed': True, 'scientificAcceptance': False}


def load_sources(args):
    path = args.original_packet / 'stress_parallel.py'
    import hashlib
    if hashlib.sha256(path.read_bytes()).hexdigest() != STRESS_SHA:
        raise RuntimeError('Original frozen stress source differs')
    spec = importlib.util.spec_from_file_location('frozen_stress', path)
    original = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(original)
    w, inputs = original.load_v4(args.bundle)
    original.verify_packet(w, args.original_packet)
    w.require(w.sha(args.original_packet / 'manifest.json') == STRESS_MANIFEST, 'Original stress manifest differs')
    manifest = json.loads((args.packet / 'manifest.json').read_text())
    w.require(manifest.get('configuration') == configuration() and manifest.get('schema') == 'orvia.stress-replay-recovery-packet.v1', 'Recovery manifest differs')
    w.require(not args.packet.is_symlink() and {p.name for p in args.packet.iterdir()} == {'manifest.json', 'stress_replay_recovery.py'}, 'Unsafe recovery packet')
    w.require(all(p.is_file() and not p.is_symlink() for p in args.packet.iterdir()), 'Unsafe recovery member')
    record = manifest['files']['stress_replay_recovery.py']
    w.require(w.sha(__file__) == record['sha256'] and w.sha(args.packet / 'stress_replay_recovery.py') == record['sha256'], 'Recovery source differs')
    return original, w, inputs


def file_record(w, path):
    w.require(path.is_file() and not path.is_symlink(), 'Missing/unsafe lineage file: ' + str(path))
    return {'sha256': w.sha(path), 'bytes': path.stat().st_size}


def inventory_files(w, root):
    entries = list(root.rglob('*'))
    w.require(not root.is_symlink() and all(not p.is_symlink() for p in entries), 'Symlink in original evidence')
    return {str(p.relative_to(root)): file_record(w, p) for p in sorted(entries) if p.is_file()}


def comparison_ok(w, value):
    import math
    return value.get('passed') is True and all(type(value.get(k)) in (int, float) and math.isfinite(value[k]) and 0 <= value[k] <= limit for k, limit in w.TOLERANCES.items())


def preflight(args, original, w):
    old = args.original_output
    w.require(not old.is_symlink(), 'Unsafe original output')
    report = json.loads((old / 'result.json').read_text())
    w.require(report.get('schema') == 'orvia.parallel-stress-run.v1' and report.get('diagnosticOnly') is True
              and report.get('scientificAcceptance') is False, 'Wrong original report schema or acceptance flags')
    w.require(report.get('jobId') == PARENT_JOB and report.get('passed') is False and report.get('timedOut') is True
              and report.get('workersStillRunning') == [], 'Original attempt must be terminal timed-out with all workers stopped')
    w.require(report.get('sourceSha256') == STRESS_SHA and report.get('stressManifestSha256') == STRESS_MANIFEST
              and report.get('configuration') == original.configuration(), 'Wrong original attempt identity')
    w.require(report.get('inputManifestSha256') == original.V4_MANIFEST and report.get('engineBuildReportSha256') == w.ENGINE_SHA, 'Wrong original inputs/engine')
    inventory = json.loads((old / 'checkpoints.json').read_text())
    plan = {'schema': 'orvia.stress-replay-recovery-inputs.v1', 'jobId': JOB_ID, 'parentJobId': PARENT_JOB,
            'originalReportedIntegrationSteps': report['integrationStepsExecuted'], 'originalPassed': False,
            'files': inventory_files(w, old), 'replicas': [], 'environmentBindingSha256': w.sha(args.environment_binding)}
    for name in ('result.json', 'checkpoints.json', 'source.py', 'stress-manifest.json', 'input-manifest.json', 'environment-binding.json', 'engine-build-report.json'):
        plan['files'][name] = file_record(w, old / name)
    w.require(plan['files']['source.py']['sha256'] == STRESS_SHA and plan['files']['stress-manifest.json']['sha256'] == STRESS_MANIFEST, 'Original archived sources differ')
    w.require(plan['files']['environment-binding.json']['sha256'] == w.sha(args.environment_binding), 'Changed recovery environment')
    w.require(plan['files']['engine-build-report.json']['sha256'] == w.ENGINE_SHA, 'Changed engine')
    for model, replica in REPLICAS:
        key = f'{model}-r{replica}/baseline'
        base = old / key
        value = json.loads((base / 'result.json').read_text())
        expected = {'schema': 'orvia.parallel-stress-phase.v1', 'jobId': PARENT_JOB, 'model': model, 'replica': replica,
                    'phase': 'baseline', 'configuration': original.configuration(), 'inputManifestSha256': original.V4_MANIFEST,
                    'environmentBindingSha256': w.sha(args.environment_binding), 'integrationStepsExecuted': 80000,
                    'sourceSha256': STRESS_SHA, 'stressManifestSha256': STRESS_MANIFEST, 'engineBuildReportSha256': w.ENGINE_SHA,
                    'diagnosticOnly': True, 'scientificAcceptance': False, 'energyConservationAccepted': False,
                    'particles': {'complex33': 132935, 'solvent33': 151505}[model]}
        w.require(value.get('passed') is True and all(value.get(k) == v for k, v in expected.items()), 'Baseline not eligible: ' + key)
        contexts = value.get('contexts', {})
        expected_pme = json.loads((args.bundle / 'manifest.json').read_text())['models'][model]['pme']
        for platform_name in ('CUDA', 'Reference'):
            context = contexts.get(platform_name, {})
            w.require(context.get('actualPlatform') == platform_name and context.get('actualPme') == expected_pme, 'Baseline platform/PME differs')
        properties = contexts['CUDA'].get('properties', {})
        w.require(properties.get('Precision') == 'double' and properties.get('UseCpuPme') == 'false'
                  and properties.get('DeterministicForces') == 'true', 'Baseline CUDA configuration differs')
        w.require(comparison_ok(w, value['initialComparison']) and comparison_ok(w, value['finalComparison']), 'Baseline strict comparisons fail: ' + key)
        rows = value.get('forceMarginObservations', [])
        w.require(rows and all(r.get('passed') is True and r.get('limitKJMolNm') == 2 ** 26 and 0 <= r.get('maxAbsoluteForceKJMolNm', -1) < 2 ** 26 for r in rows), 'Baseline force margin fails')
        binding = [p for p in report['phases'] if p['model'] == model and p['replica'] == replica and p['phase'] == 'baseline']
        w.require(len(binding) == 1 and binding[0]['passed'] is True and binding[0]['resultSha256'] == w.sha(base / 'result.json'), 'Baseline not bound by original result')
        for name in ('result.json', 'initial-cuda.npz', 'initial-reference.npz', 'midpoint.npz', 'midpoint.chk', 'final.npz', 'final-reference.npz', 'final.chk'):
            plan['files'][key + '/' + name] = file_record(w, base / name)
        mid = key + '/midpoint.chk'
        w.require(plan['files'][mid]['sha256'] == value['checkpointSha256'] and plan['files'][mid] == inventory[mid], 'Midpoint checkpoint identity differs')
        plan['replicas'].append({'model': model, 'replica': replica, 'baseline': key, 'newReplaySteps': 20000})
    w.require(type(plan['originalReportedIntegrationSteps']) is int and 320000 <= plan['originalReportedIntegrationSteps'] <= 400000, 'Invalid original step count')
    return plan


def verify_plan_files(args, w, plan):
    w.require(inventory_files(w, args.original_output) == plan['files'], 'Original evidence inventory or bytes changed')
    w.require(w.sha(args.environment_binding) == plan['environmentBindingSha256'], 'Recovery environment changed')


def worker(args, original, w, inputs):
    plan = json.loads(args.plan.read_text())
    w.require(w.sha(args.plan) == args.plan_sha256, 'Recovery plan changed')
    verify_plan_files(args, w, plan)
    baseline = args.original_output / f'{args.model}-r{args.replica}/baseline'
    worker_args = SimpleNamespace(bundle=args.bundle, packet=args.original_packet, output=args.output,
        engine_build_report=args.engine_build_report, environment_binding=args.environment_binding,
        model=args.model, replica=args.replica, phase='resume', baseline=baseline)
    # Original worker remains byte-identical, with its original protocol job ID.
    # The separate context file binds that computation to this new recovery attempt.
    code = original.worker(worker_args, w, inputs)
    verify_plan_files(args, w, plan)
    w.write_json(args.output / 'recovery-context.json', {'schema': 'orvia.stress-recovery-child-binding.v1',
        'recoveryJobId': JOB_ID, 'computationProtocolJobId': PARENT_JOB, 'recoverySourceSha256': w.sha(__file__),
        'recoveryPlanSha256': args.plan_sha256, 'originalWorkerSourceSha256': STRESS_SHA,
        'childResultSha256': w.sha(args.output / 'result.json'), 'originalEvidenceUnchanged': True,
        'scientificAcceptance': False})
    return code


def supervisor(args, original, w):
    plan = preflight(args, original, w)  # Refuse before any GPU work or output creation.
    engine, environment = w.engine_environment(args.engine_build_report)
    args.output.mkdir(parents=True, exist_ok=False)
    plan_path = args.output / 'recovery-inputs.json'
    w.write_json(plan_path, plan)
    plan_hash = w.sha(plan_path)
    publisher = w.Telemetry(args.output, JOB_ID, os.environ.get('ORVIA_WORKER_TOKEN', ''))
    started = time.monotonic()
    deadline = started + WORKER_SECONDS
    active, tasks = {}, {}
    lock = threading.RLock()
    finished, timed_out = threading.Event(), threading.Event()
    worker_completion_seconds = None
    report = {'schema': 'orvia.stress-replay-recovery-run.v1', 'jobId': JOB_ID, 'parentJobId': PARENT_JOB,
        'startedAt': w.utc(), 'configuration': configuration(), 'sourceSha256': w.sha(__file__),
        'recoveryPlanSha256': plan_hash, 'recoveryManifestSha256': w.sha(args.packet / 'manifest.json'),
        'originalResultSha256': plan['files']['result.json']['sha256'], 'originalAttemptRemainsFailed': True,
        'originalReportedIntegrationSteps': plan['originalReportedIntegrationSteps'], 'newIntegrationStepsExecuted': 0,
        'reusedPassedBaselineSteps': 320000, 'passed': False, 'diagnosticOnly': True, 'scientificAcceptance': False,
        'automaticPodShutdown': False, 'onChainReportSubmitted': False, 'phases': [],
        'timingScope': {'workerCutoffSeconds': 290, 'cleanupReserveSeconds': 10,
                        'workerInputAndPostrunHashChecksIncluded': True,
                        'finalParentHashingArchivalAndNetworkExcluded': True}}
    def emit(state, stage, count, final=False):
        w.require(not publisher.terminal and publisher.last_steps <= count <= TOTAL_STEPS, 'Invalid new-step progress')
        publisher.sequence += 1
        payload = {'schemaVersion': 1, 'jobId': JOB_ID, 'sequence': publisher.sequence, 'state': state, 'stage': stage,
            'stepsCompleted': count, 'stepsTotal': TOTAL_STEPS, 'updatedAt': w.utc(), 'device': 'NVIDIA H200',
            'diagnosticOnly': True, 'scientificAcceptance': False,
            'resultSha256': w.sha(args.output / 'result.json') if state == 'completed' else None,
            'checkpointSha256': w.sha(args.output / 'checkpoints.json') if state == 'completed' else None}
        w.write_json(args.output / 'telemetry' / f'{publisher.sequence:06d}.json', payload)
        publisher.pending.append(payload)
        publisher.last_steps = count
        publisher.terminal = state in ('completed', 'failed')
        return publisher.flush(deadline=None if final else deadline)
    def kill():
        with lock:
            for task in active.values():
                if task['process'].poll() is None:
                    try:
                        os.killpg(task['process'].pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
    def cutoff():
        if not finished.wait(max(0, deadline - time.monotonic())):
            timed_out.set()
            kill()
    def interrupted(signum, frame):
        kill()
        raise InterruptedError('Recovery interrupted')
    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    watcher = threading.Thread(target=cutoff, daemon=True)
    watcher.start()
    metric_sequence = 0
    monitor = None
    def gpu_sample(send=False):
        nonlocal metric_sequence
        try:
            values = subprocess.check_output(['nvidia-smi', '--query-gpu=utilization.gpu,utilization.memory,memory.used,memory.total,power.draw,temperature.gpu', '--format=csv,noheader,nounits'], timeout=3, text=True).strip().split(',')
            w.require(len(values) == 6, 'Unexpected GPU metric sample')
            names = ('gpuUtilizationPercent', 'memoryUtilizationPercent', 'memoryUsedMiB', 'memoryTotalMiB', 'powerWatts', 'temperatureC')
            metric_sequence += 1
            with lock:
                running = sum(t['process'].poll() is None for t in active.values())
            body = {'schemaVersion': 1, 'jobId': JOB_ID, 'sequence': metric_sequence, 'updatedAt': w.utc(),
                    'device': 'NVIDIA H200', 'activeWorkerProcesses': running,
                    **{name: None if value.strip() in ('N/A', '[N/A]') else float(value) for name, value in zip(names, values)}}
            raw = json.dumps(body, allow_nan=False, separators=(',', ':'))
            with (args.output / 'gpu-samples.jsonl').open('a') as stream:
                stream.write(raw + '\n')
            if send:
                status = publisher._post('https://orvia.fyi/api/orvia/gpu', raw.encode(), 2)
                with (args.output / 'gpu-metrics-delivery.jsonl').open('a') as stream:
                    stream.write(json.dumps({'sequence': metric_sequence, 'httpStatus': status}) + '\n')
        except Exception as error:
            with (args.output / 'gpu-sampling-errors.jsonl').open('a') as stream:
                stream.write(json.dumps({'at': w.utc(), 'errorType': type(error).__name__}) + '\n')
    def monitor_loop():
        tick = 0
        next_at = time.monotonic()
        while not finished.is_set():
            gpu_sample(send=tick % 3 == 0)
            tick += 1
            next_at += 5
            finished.wait(max(0, next_at - time.monotonic()))
    def count_steps():
        for task in tasks.values():
            path = task['out'] / 'progress.json'
            if path.exists():
                n = json.loads(path.read_text())['steps']
                w.require(type(n) is int and task['steps'] <= n <= 20000, 'Invalid worker step count')
                task['steps'] = n
        return sum(t['steps'] for t in tasks.values())
    try:
        gpu = subprocess.check_output(['nvidia-smi', '--query-gpu=name,driver_version,memory.total', '--format=csv,noheader'], timeout=15, text=True).strip()
        w.require(len(gpu.splitlines()) == 1 and 'H200' in gpu.split(',', 1)[0], 'Expected single H200')
        report['hardware'] = gpu
        w.require(emit('running', 'starting', 0), 'Site rejected new recovery job')
        monitor = threading.Thread(target=monitor_loop, name='recovery-gpu-monitor', daemon=True)
        monitor.start()
        for model, replica in REPLICAS:
            key = f'{model}-r{replica}'
            out = args.output / key
            command = [engine['python'], str(Path(__file__).resolve()), '--worker', '--packet', str(args.packet),
                '--bundle', str(args.bundle), '--original-packet', str(args.original_packet), '--original-output', str(args.original_output),
                '--output', str(out), '--plan', str(plan_path), '--plan-sha256', plan_hash,
                '--model', model, '--replica', str(replica), '--engine-build-report', str(args.engine_build_report),
                '--environment-binding', str(args.environment_binding)]
            with lock:
                w.require(time.monotonic() < deadline and not timed_out.is_set(), 'Recovery deadline reached')
                with (args.output / (key + '.log')).open('xb') as stream:
                    proc = subprocess.Popen(command, stdout=stream, stderr=subprocess.STDOUT, env=environment, start_new_session=True)
                tasks[key] = active[key] = {'process': proc, 'out': out, 'steps': 0}
        next_update = 0.0
        while active:
            if timed_out.is_set() or time.monotonic() >= deadline:
                timed_out.set()
                kill()
                raise TimeoutError('Recovery worker cutoff reached')
            for key, task in list(active.items()):
                if task['process'].poll() is None:
                    continue
                with lock:
                    del active[key]
                    if not active:
                        worker_completion_seconds = time.monotonic() - started
                        finished.set()
                result_path = task['out'] / 'result.json'
                binding_path = task['out'] / 'recovery-context.json'
                value = json.loads(result_path.read_text()) if result_path.exists() else {}
                bound = json.loads(binding_path.read_text()) if binding_path.exists() else {}
                passed = task['process'].returncode == 0 and value.get('passed') is True and bound.get('recoveryPlanSha256') == plan_hash and bound.get('childResultSha256') == w.sha(result_path)
                report['phases'].append({'replica': key, 'passed': passed, 'exitCode': task['process'].returncode,
                    'resultSha256': w.sha(result_path) if result_path.exists() else None,
                    'contextSha256': w.sha(binding_path) if binding_path.exists() else None})
            report['newIntegrationStepsExecuted'] = count_steps()
            w.write_json(args.output / 'run-status.json', report)
            if not active:
                break
            if time.monotonic() >= next_update:
                emit('running', 'simulating', report['newIntegrationStepsExecuted'])
                next_update = time.monotonic() + 15
            time.sleep(.2)
        if worker_completion_seconds is None:
            worker_completion_seconds = time.monotonic() - started
        finished.set()
        watcher.join(timeout=.1)
        if worker_completion_seconds > WORKER_SECONDS:
            timed_out.set()
        verify_plan_files(args, w, plan)
        report['passed'] = len(report['phases']) == 4 and all(p['passed'] for p in report['phases']) and report['newIntegrationStepsExecuted'] == TOTAL_STEPS
        w.require(report['passed'], 'Recovery strict checkpoint replay did not pass')
    except Exception as error:
        report['error'] = {'type': type(error).__name__, 'message': str(error)[:1000]}
    finally:
        kill()
        until = time.monotonic() + 10
        for task in active.values():
            try:
                task['process'].wait(timeout=max(.001, until - time.monotonic()))
            except subprocess.TimeoutExpired:
                pass
        finished.set()
        watcher.join(timeout=.1)
        report['workersStillRunning'] = [t['process'].pid for t in active.values() if t['process'].poll() is None]
        report['gpuWorkersStoppedAfterSeconds'] = worker_completion_seconds if worker_completion_seconds is not None else time.monotonic() - started
        if monitor is not None:
            monitor.join(timeout=5.1)
        gpu_sample(send=True)
        report['timedOut'] = timed_out.is_set()
        report['newIntegrationStepsExecuted'] = max(report['newIntegrationStepsExecuted'], count_steps(), publisher.last_steps)
        report['aggregateReportedExecutedSteps'] = plan['originalReportedIntegrationSteps'] + report['newIntegrationStepsExecuted']
        report['passed'] = report['passed'] and not report['workersStillRunning'] and not report['timedOut']
        report['completedPlannedCohortSteps'] = 400000 if report['passed'] else None
        report['completedAt'] = w.utc()
        w.write_json(args.output / 'result.json', report)
        w.write_json(args.output / 'run-status.json', report)
        w.write_json(args.output / 'checkpoints.json', {str(p.relative_to(args.output)): file_record(w, p) for p in args.output.rglob('*.chk')})
        emit('completed' if report['passed'] else 'failed', 'finished' if report['passed'] else 'failed', report['newIntegrationStepsExecuted'], final=True)
        for source, name in ((Path(__file__), 'source.py'), (args.packet / 'manifest.json', 'recovery-manifest.json'),
                             (args.environment_binding, 'environment-binding.json'), (args.engine_build_report, 'engine-build-report.json')):
            (args.output / name).write_bytes(source.read_bytes())
        archive = args.output.with_suffix('.tar.gz')
        with tarfile.open(archive, 'w:gz', compresslevel=2) as tar:
            for path in sorted(args.output.rglob('*')):
                if path.is_file():
                    tar.add(path, arcname=str(path.relative_to(args.output)))
        print(json.dumps({'passed': report['passed'], 'newSteps': report['newIntegrationStepsExecuted'], 'archive': str(archive), 'archiveSha256': w.sha(archive), 'originalAttemptRemainsFailed': True}))
    return 0 if report['passed'] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name, default in (('bundle', '/workspace/orvia-live-workflow-v4'), ('original-packet', '/workspace/orvia-h200-stress-v1'),
                          ('original-output', '/workspace/orvia-stress-20261102-02'), ('engine-build-report', '/workspace/orvia-native-double-build-r2/build-report.json'),
                          ('environment-binding', '/workspace/orvia-live-engine-restore/environment-binding.json')):
        parser.add_argument('--' + name, type=Path, default=Path(default))
    parser.add_argument('--packet', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--worker', action='store_true')
    parser.add_argument('--model', choices=('complex33', 'solvent33'))
    parser.add_argument('--replica', type=int, choices=(1, 2))
    parser.add_argument('--plan', type=Path)
    parser.add_argument('--plan-sha256')
    args = parser.parse_args()
    if not __debug__ or sys.flags.optimize:
        raise RuntimeError('Optimized Python forbidden')
    original, w, inputs = load_sources(args)
    if args.worker:
        w.require(args.model and args.replica and args.plan and args.plan_sha256, 'Missing worker arguments')
        return worker(args, original, w, inputs)
    return supervisor(args, original, w)


if __name__ == '__main__':
    raise SystemExit(main())
