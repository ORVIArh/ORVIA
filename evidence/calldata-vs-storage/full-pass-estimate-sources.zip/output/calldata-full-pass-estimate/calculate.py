"""Project one full packed-input pass from existing measured batch rates.

No signing, wallet access, RPC or simulation is performed by this calculator.
Run with --aura-root PATH; pricing.json must already exist beside this script.
"""
import argparse
import gzip
import hashlib
import json
from decimal import Decimal, getcontext
from pathlib import Path

getcontext().prec = 45
parser = argparse.ArgumentParser()
parser.add_argument('--aura-root', type=Path, required=True)
args = parser.parse_args()
base = args.aura_root
out = Path(__file__).resolve().parent

def read(path):
    return json.loads(path.read_text())

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

manifest_path = base / 'output/calldata-vs-storage-data/packed-manifest.json'
comparison_path = base / 'ORVIA/evidence/calldata-vs-storage/comparison.json'
infrastructure_path = base / 'ORVIA/evidence/256-costs/cost-summary.json'
manifest = read(manifest_path)
comparison = read(comparison_path)
infrastructure = read(infrastructure_path)
pricing = read(out / 'pricing.json')
assert manifest['passed'] and pricing['chainId'] == 4663

streams = [dict(key=s['key'], kind='base', bytes=s['totalBytes'],
                sourceSha256=s['packedSha256']) for s in manifest['streams']]
patches = sorted((base / 'output/256-input-compression/overlay-patches').glob('*/*.bin.gz'))
assert len(patches) == 10
for path in patches:
    data = gzip.decompress(path.read_bytes())
    assert len(data) % 32 == 0
    streams.append(dict(key=path.parent.name + '/' + path.name.removesuffix('.bin.gz'),
                        kind='patch', bytes=len(data),
                        sourceSha256=hashlib.sha256(data).hexdigest()))
assert len(streams) == 24
assert sum(s['bytes'] for s in streams) == manifest['totalBaseAndPatchPayloadBytes'] == 44065024

price = Decimal(pricing['gasPriceWei']) / Decimal(10**18)
usd = Decimal(pricing['ethUsd'])
def amount(gas):
    return dict(gas=str(gas), eth=str(Decimal(gas)*price), usd=str(Decimal(gas)*price*usd))

infrastructure_gas = int(infrastructure['costs']['infrastructure']['gasLow'])
assert infrastructure_gas == int(infrastructure['costs']['infrastructure']['gasHigh'])
root_rate = comparison['commonRootRegistrationGas']
root_count = len(streams)
setup_gas = infrastructure_gas + root_count*root_rate
rows = []
for size, case in [(1024, 'bulk1'), (16384, 'bulk16')]:
    rate = next(c['calldataGas'] for c in comparison['cases'] if c['scenario'] == case)
    per_stream = [dict(**s, calls=(s['bytes']+size-1)//size,
                       partialLastBatchBytes=s['bytes'] % size) for s in streams]
    calls = sum(s['calls'] for s in per_stream)
    pass_gas = calls*rate
    rows.append(dict(payloadBytesPerBatch=size, batchImplementation='One 1 KiB leaf' if size == 1024 else 'Sixteen 1 KiB leaves, individual proofs, one transaction',
                     measuredReferenceGasPerFullBatch=rate, passTransactions=calls,
                     passCost=amount(pass_gas), setupAndPassTransactions=91+root_count+calls,
                     setupAndPassCost=amount(setup_gas+pass_gas),
                     chargedPayloadCapacityBytes=calls*size,
                     aggregateCeilIgnoringStreamBoundaries=(44065024+size-1)//size,
                     perStream=per_stream))

result = dict(status='full_packed_input_one_pass_rate_projection_not_campaign_quote',
              sourceManifestSha256=digest(manifest_path), measuredComparisonSha256=digest(comparison_path),
              infrastructureSummarySha256=digest(infrastructure_path), calculatorSha256=digest(Path(__file__)),
              inputPayloadBytes=44065024, baseStreams=14, patchStreams=10,
              pureFloatBasePayloadBytes=sum(s['totalBytes'] for s in manifest['streams'] if s['codec'] == 'ORVIA.DenseF64.v1'),
              mixedAndPatchPayloadBytes=44065024-sum(s['totalBytes'] for s in manifest['streams'] if s['codec'] == 'ORVIA.DenseF64.v1'),
              pricing=pricing,
              setup=dict(infrastructureTransactions=91, infrastructure=amount(infrastructure_gas),
                         assumedRootRegistrations=root_count, referenceGasPerRoot=root_rate,
                         rootRegistrationAllowance=amount(root_count*root_rate), total=amount(setup_gas)),
              scenarios=rows,
              transactionReductionPercent=str((Decimal(rows[0]['passTransactions'])-rows[1]['passTransactions'])/rows[0]['passTransactions']*100),
              passGasReductionPercent=str((Decimal(rows[0]['passCost']['gas'])-Decimal(rows[1]['passCost']['gas']))/Decimal(rows[0]['passCost']['gas'])*100),
              assumptions=[
                  'One complete sequential pass over current packed bases and endpoint patches; no cross-stream batching.',
                  'Every batch, including a short last batch, is charged at the measured full reference-batch rate.',
                  'Reference gas uses actual first complex33 nonbonded chunks and 12-level proofs. Other bytes, proof depths and codecs are not individually quoted.',
                  'The 16 KiB scenario bundles sixteen 1 KiB leaves with independent proofs, not one new 16 KiB leaf.',
                  '24 separate root registrations are an illustrative allowance, not an implemented production API.',
                  'The existing 256-address deployment quote is reused as a baseline; a new integrated reader changes bytecode and must be requoted.',
                  'No extra L1-data fee is added to the existing target-provider gas estimates.',
              ],
              excluded=[
                  'Production bank routing, code-hash checks and mixed/patch decoder integration',
                  'Separate prior data publication and the off-chain data supplier',
                  'Unresolved C4, constraints, activity and other future inputs',
                  'Model initialization, evolving positions/forces/progress, molecular forces, dynamics and analysis',
                  'Repeated data access needed by a real scientific campaign',
              ],
              fullCampaignQuoted=False, productionReaderImplemented=False, hardUpperBound=False,
              scientificAcceptance=False, mainnetReady=False, publicTransactionsSent=0)
(out / 'full-pass-estimate.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({k: result[k] for k in ['status','inputPayloadBytes','setup','transactionReductionPercent','passGasReductionPercent']},indent=2))
print(json.dumps([{k:s[k] for k in ['payloadBytesPerBatch','passTransactions','passCost','setupAndPassTransactions','setupAndPassCost']} for s in rows],indent=2))
