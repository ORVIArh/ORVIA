# Verified calldata versus permanent packed input storage

This is an **executed data-access microbenchmark**, not a full molecular-engine benchmark, production implementation or campaign quote. No public transaction was signed or sent; no wallet or private key was used. All public-network requests were read-only estimates of hypothetical states.

The two paths consume the **same actual packed input bytes**, expand their IEEE binary64 transport fields into exact binary128 bits, and produce the same ordered digest over all selected values. Arithmetic is not changed to binary64. Stored reads fetch only the necessary packed slots; sparse reads do not copy the full stored chunk.

## Mainnet estimate results

These 12 conditional estimates used chain 4663 at block `0x6370174` (`0x1f32d404e3207f562f4d1f93ce8356717d01a6d33e17d466f1267d3dd8520329`). The runtime and exact preceding storage were supplied as state overrides. These are target-provider gas estimates, not receipts from mainnet execution. The local execution uses pinned solc 0.8.26, optimizer 200, Shanghai, and ordinary contract-size limits.

For the first actual 1,024-byte `complex33/A.nonbonded` chunk (12-level indexed Merkle proof):

| Operation | Permanent storage path | Verified calldata path |
|---|---:|---:|
| Common root registration | 94,588 | 94,588 |
| Additional one-chunk permanent upload | 796,240 | — |
| Read/expand/digest entire 1,024-byte chunk | 281,956 | 195,136 |
| Read/expand/digest one 8-byte field | 33,657 | 65,970 |
| Read/expand/digest one 24-byte record crossing a storage-slot boundary | 38,698 | 67,987 |
| Entire chunks, four in one call | 1,047,524 | 686,544 |
| Entire chunks, sixteen in one call | 4,202,582 | 2,774,398 |

The one-chunk verified calldata transaction contains 1,892 calldata bytes (chunk, proof and ABI included), versus 228 bytes for the stored-read transaction. Exact zero/nonzero calldata-byte counts and all local gas receipts are in `report.json` and `comparison.json`.

**Interpretation:** bulk access favors verified calldata in these measured cases, even before charging the permanent-storage upload. Repeated sparse access favors permanent storage after amortizing its upload: **25 separate 8-byte-read transactions**, or **28 separate 24-byte-record-read transactions**, using the measured one-chunk target setup cost. Common registration is excluded because both paths need it. These are case-specific break-even counts, not MD timesteps or universal bounds. Batch-upload amortization, proof size, data entropy, access grouping, caching and future fees can change them.

Additional local-only cases use actual nonbonded 256-byte chunks, particle 1,024-byte chunks and position 256-byte chunks, with one/four/sixteen chunks, sparse reads and repeated use within one call. Both modes prefetch the selected fields once before repeated digest work. Positions are an input-entropy example; evolved positions are mutable working state and are not covered by this immutable-input design.

## Authentication and availability

Leaves are `keccak256(abi.encode(DOMAIN, streamId, codec, uint64(totalBytes), uint32(chunkSize), uint64(chunkIndex), bytes(chunk)))`. The domain is `ORVIA.CalldataVsStorage.Chunk.v1`; codec is `ORVIA.DenseF64.v1`. Parents hash ordered left/right children. The full tree is padded using indexed empty leaves, and the contract rejects padded-leaf access, wrong index, wrong expected final length or proof depth. Root registration has the same trusted-owner assumption for both paths.

Permanent upload validates the same proofs, stores the actual packed words and allows bounded random reads. Its append batches are limited to 128 physical slots. The calldata path verifies the whole chunk once, then uses the requested fields directly. The comparison uses independent proofs per chunk, not a multiproof optimization.

**A root does not publish the model.** A calldata-only design still needs the actual bytes to be available and resupplied for future transactions. Old transaction calldata is not directly readable by contracts. A separate first-publication cost, resupply infrastructure and a production protocol's validation/provenance interfaces are not included. No full 44 MB data-pass or campaign cost is inferred from this float-only checksum workload.

GPU work was limited to preparing and checking packed input bytes; EVM execution and gas measurement were not GPU-accelerated. The producer's CPU/GPU byte comparisons and independent full-tree proof audit live in the sibling data evidence.

## Checks and evidence

- `report.json`: 78 local transaction receipts, 52 checks, 12 target estimates, source/runtime bindings, exact calldata sizes and request/response hashes.
- `edge-checks.json`: actual EVM tests against 12 independent literal IEEE bit vectors, including positive/negative zero, subnormal extremes and maximum finite values, plus unauthorized-root rejection.
- `comparison.json`: measured per-case setup/read costs and break-even arithmetic.
- `PackedReadBenchmark.sol`, `compiler-input.json`, `artifact.json`: exact compiled microbenchmark.
- `overrides/*.json.gz`: exact hypothetical prestates for the target quotes.
- `benchmark.mjs`, `edge-checks.mjs`, `analyze.mjs`: executed scripts. Local `eth_sendTransaction` uses an impersonated public address with zero private keys; the remote helper only allows read methods.

Negative cases include altered chunk, wrong index, bad proof, incorrect chunk length and incorrect final partial-chunk length. Valid final partial chunks also pass. All stored/calldata outputs match independently reconstructed binary128 digests.

The runner uses the original AURA sibling-directory layout (`calldata-vs-storage-data`, `256-deployment-gas`, ORVIA pinned dependencies); the full packed input files are source-bound external evidence, not duplicated here. Run `node output/calldata-vs-storage-evm/benchmark.mjs --local-only` for a local replay. Omitting that flag invokes the authorized private endpoint configuration and must not be mistaken for a request to broadcast—it still has no remote send method.

Scientific acceptance, production readiness and a full-engine performance conclusion remain false.
