import fs from 'node:fs';
import {privateMainnetRpc,sha} from '../256-deployment-gas/rpc.mjs';
const p=privateMainnetRpc();
const [chain,block,gas,spot]=await Promise.all([
 p.rpc('eth_chainId',[]),p.rpc('eth_getBlockByNumber',['latest',false]),p.rpc('eth_gasPrice',[]),
 fetch('https://api.coinbase.com/v2/prices/ETH-USD/spot',{signal:AbortSignal.timeout(15000)}).then(async r=>{if(!r.ok)throw Error('Coinbase HTTP '+r.status);return r.json();})
]);
if(Number(BigInt(chain.result))!==4663||spot.data?.base!=='ETH'||spot.data?.currency!=='USD'||!Number.isFinite(Number(spot.data?.amount)))throw Error('Unexpected public price response');
const report={checkedAtUtc:new Date().toISOString(),chainId:4663,providerHostname:p.hostname,blockNumber:block.result.number,blockHash:block.result.hash,gasPriceWei:BigInt(gas.result).toString(),ethUsd:spot.data.amount,ethUsdSource:'https://api.coinbase.com/v2/prices/ETH-USD/spot',coinbaseResponseSha256:sha(JSON.stringify(spot)),rpcCalls:p.calls,transactionsSent:0};
fs.writeFileSync(new URL('pricing.json',import.meta.url),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
