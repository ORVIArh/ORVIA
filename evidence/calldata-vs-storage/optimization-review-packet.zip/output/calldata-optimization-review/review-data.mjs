import fs from 'node:fs';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';
const require=createRequire(new URL('../../ORVIA/package.json',import.meta.url));
const {AbiCoder,keccak256,concat}=require('ethers'),abi=AbiCoder.defaultAbiCoder();
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const bytes=fs.readFileSync(new URL('../calldata-range-data/ranges.json',import.meta.url));
const d=JSON.parse(bytes);
const m=JSON.parse(fs.readFileSync(new URL('../calldata-vs-storage-data/packed-manifest.json',import.meta.url)));
const source=m.streams.find(s=>s.key==='complex33/A.nonbonded');
const all=fs.readFileSync(source.packedFile);
if(!d.passed||sha(all)!==d.sourcePackedSha256||d.sourcePackedSha256!==source.packedSha256)throw Error('Source binding');
const old=JSON.parse(fs.readFileSync(new URL('../calldata-vs-storage-data/samples.json',import.meta.url))).datasets.find(s=>s.key===d.key);
for(const k of ['root','streamId','codec','totalBytes','chunkSize'])if(d[k]!==old[k])throw Error('Changed original root metadata '+k);
const leaf=(index,b)=>keccak256(abi.encode(['bytes32','bytes32','bytes32','uint64','uint32','uint64','bytes'],[d.DOMAIN,d.streamId,d.codec,d.totalBytes,d.chunkSize,index,b]));
function finish(node,index,proof){for(const x of proof){node=keccak256(index%2?concat([x,node]):concat([node,x]));index=Math.floor(index/2);}return node;}
for(const c of d.individualSamples){
 const b=all.subarray(c.index*d.chunkSize,Math.min(all.length,(c.index+1)*d.chunkSize));
 if(c.chunk!=='0x'+b.toString('hex')||sha(b)!==c.chunkSha256||c.proof.length!==d.depth||finish(leaf(c.index,c.chunk),c.index,c.proof)!==d.root)throw Error('Individual proof mismatch');
}
const checked=[];
const extra=[{start:16,count:16},{start:32,count:32}].map(x=>({...x,dataHex:'0x'+all.subarray(x.start*d.chunkSize,(x.start+x.count)*d.chunkSize).toString('hex'),proof:d.individualSamples.find(c=>c.index===x.start).proof.slice(Math.log2(x.count))}));
for(const r of [...d.ranges,...extra]){
 if(!r.count||(r.count&(r.count-1))||r.start%r.count||r.start+r.count>d.actualChunkCount)throw Error('Invalid range');
 const expected=all.subarray(r.start*d.chunkSize,Math.min(all.length,(r.start+r.count)*d.chunkSize));
 if(r.dataHex!=='0x'+expected.toString('hex')||r.proof.length!==d.depth-Math.log2(r.count))throw Error('Range payload/length');
 let nodes=[];
 for(let j=0;j<r.count;j++)nodes.push(leaf(r.start+j,'0x'+expected.subarray(j*d.chunkSize,(j+1)*d.chunkSize).toString('hex')));
 while(nodes.length>1){const next=[];for(let j=0;j<nodes.length;j+=2)next.push(keccak256(concat([nodes[j],nodes[j+1]])));nodes=next;}
 if(finish(nodes[0],r.start/r.count,r.proof)!==d.root)throw Error('Range root mismatch');
 checked.push({start:r.start,count:r.count,bytes:expected.length,proofHashes:r.proof.length});
}
const baseline=fs.readFileSync(new URL('../calldata-vs-storage-evm/PackedReadBenchmark.sol',import.meta.url),'utf8');
const copied=fs.readFileSync(new URL('../calldata-optimized-benchmark/PackedReadBenchmark.sol',import.meta.url),'utf8');
const candidate=fs.readFileSync(new URL('../calldata-optimized-benchmark/AlignedRangeReadBenchmark.sol',import.meta.url),'utf8');
if(copied!==baseline)throw Error('Changed baseline source');
function body(s,name){let p=s.indexOf('function '+name+'(');if(p<0)throw Error('Missing function');p=s.indexOf('{',p);let depth=1,end=p+1;while(depth){const c=s[end++];if(c==='{')depth++;if(c==='}')depth--;}return s.slice(p,end).replace(/\s+/g,'');}
if(body(candidate,'_foldRange')!==body(baseline,'_fold').replaceAll('_expand64','_expandRange'))throw Error('Digest work changed');
if(body(candidate,'_expandRange')!==body(baseline,'_expand64'))throw Error('Expansion changed');
const report={passed:true,sourceSha256:sha(candidate),baselineSourceSha256:sha(baseline),rangeDataSha256:sha(bytes),scriptSha256:sha(fs.readFileSync(import.meta.filename)),originalRootPreserved:true,originalBaselineSourceUnchanged:true,originalFoldBodyPreserved:true,originalExpansionBodyPreserved:true,individualProofsChecked:d.individualSamples.length,rangesChecked:checked,publicTransactionsSent:0};
fs.writeFileSync(new URL('data-and-source-review.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
