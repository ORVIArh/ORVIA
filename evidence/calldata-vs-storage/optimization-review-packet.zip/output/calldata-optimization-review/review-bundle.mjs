import fs from 'node:fs';import zlib from 'node:zlib';import crypto from 'node:crypto';import {createRequire} from 'node:module';
const require=createRequire(new URL('../../ORVIA/package.json',import.meta.url));
const {Interface,AbiCoder,keccak256,toBeHex,toQuantity}=require('ethers'),abi=AbiCoder.defaultAbiCoder();
const get=n=>fs.readFileSync(new URL('../calldata-bundled-benchmark/'+n,import.meta.url)),sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const report=JSON.parse(get('report.json')),artifact=JSON.parse(get('artifact.json')),api=new Interface(artifact.abi);
const d=JSON.parse(fs.readFileSync(new URL('../calldata-range-data/ranges.json',import.meta.url)));
const manifest=JSON.parse(fs.readFileSync(new URL('../calldata-vs-storage-data/packed-manifest.json',import.meta.url)));
const original=zlib.gunzipSync(fs.readFileSync(manifest.streams.find(x=>x.key==='complex33/A.nonbonded').sourcePath));
if(!report.passed||sha(original)!==d.sourceRawSha256||sha(get('BundledRangeReadBenchmark.sol'))!==report.sourceSha256||sha(get('benchmark.mjs'))!==report.scriptSha256)throw Error('Source binding');
const input=JSON.parse(get('compiler-input.json'));input.settings.outputSelection={'*':{'*':['evm.deployedBytecode']}};
const compiled=JSON.parse(require('solc').compile(JSON.stringify(input)));if(compiled.errors?.some(x=>x.severity==='error'))throw Error('Compile');
const code=Object.values(compiled.contracts).map(x=>x.BundledRangeReadBenchmark).find(Boolean).evm.deployedBytecode;
if(code.object!==artifact.evm.deployedBytecode.object)throw Error('Runtime template');
const sender='0x2541a9e93B5C853E9208b0C5C7386dD458424c77',deployed=Buffer.from(code.object,'hex');
for(const refs of Object.values(code.immutableReferences))for(const ref of refs){if(ref.length!==32)throw Error('Immutable');Buffer.from(sender.slice(2).padStart(64,'0'),'hex').copy(deployed,ref.start);}
function parts(q){const [stream,start,count,offset,length,repeats]=q,indices=Array.from({length:count},(_,i)=>start+i),selected=indices.map(i=>d.individualSamples.find(x=>x.index===i));
 if(stream!==d.streamId||selected.some(x=>!x))throw Error('Query source');
 let h=keccak256(abi.encode(['bytes32','uint64[]','uint32','uint32','uint8'],[stream,indices,offset,length,repeats]));
 for(const i of indices)for(let r=0;r<repeats;r++)for(let p=offset;p<offset+length;p+=8){const at=(i*d.chunkSize+p)/8*32;h=keccak256(abi.encode(['bytes32','uint128'],[h,BigInt('0x'+original.subarray(at+16,at+32).toString('hex'))]));}
 return{bundle:'0x'+selected.map(x=>x.chunk.slice(2)).join(''),proof:selected[0].proof.slice(Math.log2(count)),digest:h};}
const checked=[];
for(const r of report.rows.filter(x=>x.targetGas)){
 const ps=r.queries.map(parts);if(JSON.stringify(ps.map(x=>x.digest))!==JSON.stringify(r.expectedDigests))throw Error('Original-source digest');
 const args=r.function==='consumeRanges'?[r.queries,ps.map(x=>x.bundle),ps.map(x=>x.proof)]:[r.queries[0],ps[0].bundle,ps[0].proof];
 const data=api.encodeFunctionData(r.function,args);if(keccak256(data)!==r.calldataKeccak256)throw Error('Calldata');
 const bytes=zlib.gunzipSync(get(r.overrideFile)),state=JSON.parse(bytes);if(sha(bytes)!==r.overrideSha256||state[r.address].code.toLowerCase()!=='0x'+deployed.toString('hex')||BigInt(state[sender].nonce)!==BigInt(r.nonce))throw Error('Witness');
 const base=BigInt(keccak256(abi.encode(['bytes32','uint256'],[d.streamId,0]))),slots=state[r.address].state;
 const vals=[BigInt(d.root),BigInt(d.codec),BigInt(d.totalBytes)|(BigInt(d.chunkSize)<<128n)|(BigInt(d.depth)<<160n)|(1n<<168n)];
 if(vals.some((x,i)=>x!==BigInt(slots[toBeHex(base+BigInt(i),32)]??0)))throw Error('Root metadata');
 const request={jsonrpc:'2.0',id:r.rpcId,method:'eth_estimateGas',params:[{from:sender,to:r.address,nonce:r.nonce,value:'0x0',data,gas:'0x1c9c380'},report.block.number,state]};
 if(sha(JSON.stringify(request))!==r.rpcRequestSha256)throw Error('Request hash');
 const response={jsonrpc:'2.0',id:r.rpcId,result:toQuantity(BigInt(r.targetGas))},orders=[['jsonrpc','id','result'],['jsonrpc','result','id'],['id','jsonrpc','result'],['id','result','jsonrpc'],['result','id','jsonrpc'],['result','jsonrpc','id']];
 if(!orders.some(order=>sha(JSON.stringify(Object.fromEntries(order.map(k=>[k,response[k]]))))===r.rpcResponseSha256))throw Error('Response hash');
 const b=Buffer.from(data.slice(2),'hex'),nz=b.filter(x=>x!==0).length;if(b.length!==r.calldataBytes||nz!==r.nonzeroCalldataBytes||21000+16*nz+4*(b.length-nz)!==r.intrinsicGas)throw Error('Byte accounting');
 checked.push({label:r.label,targetGas:r.targetGas,originalSourceDigestsVerified:ps.length,compiledRuntimeAndWitnessVerified:true});
}
if(checked.length!==6)throw Error('Quote count');
const result={passed:true,reportSha256:sha(get('report.json')),scriptSha256:sha(fs.readFileSync(import.meta.filename)),targetQuotesVerified:checked.length,checked,publicTransactionsSent:0};
fs.writeFileSync(new URL('bundle-evm-review.json',import.meta.url),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
