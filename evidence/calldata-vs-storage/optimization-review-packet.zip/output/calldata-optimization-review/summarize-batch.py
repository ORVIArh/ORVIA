import hashlib
import json
from decimal import Decimal, getcontext
from pathlib import Path

getcontext().prec = 40
here = Path(__file__).resolve().parent
out = here.parent
report_path = out / 'calldata-bundled-benchmark/report.json'
report = json.loads(report_path.read_text())
range_summary = json.loads((here / 'optimization-summary.json').read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert report['passed']
c = {k: int(v) for k, v in report['comparison'].items()}
reduction = lambda old, new: str(Decimal(old-new) * 100 / old)
layout = next(s for s in range_summary['scenarios']
              if s['kind'] == 'aligned_range' and s['maxPayloadKiB'] == 16)
calls = layout['inputCalls']
result = {
    'scope': 'Measured bounded 4x16KiB data-access bundle; full-input counts are layout projections only',
    'reportSha256': sha(report_path),
    'calculatorSha256': sha(Path(__file__)),
    'rangeSummarySha256': sha(here / 'optimization-summary.json'),
    'fourthChildRollbackSha256': sha(out / 'calldata-bundled-benchmark/fourth-child-rollback.json'),
    'sourceSha256': report['sourceSha256'],
    'block': report['block'],
    'sameActualPayloadBytes': 65536,
    'comparison': report['comparison'],
    'targetGasSavedVsSeparate': c['separate4x16TargetGas']-c['bundled4x16TargetGas'],
    'targetPercentSavedVsSeparate': reduction(c['separate4x16TargetGas'], c['bundled4x16TargetGas']),
    'targetPercentSavedVsSingle64': reduction(c['single64TargetGas'], c['bundled4x16TargetGas']),
    'localGasSavedVsSeparate': c['separate4x16LocalGas']-c['bundled4x16LocalGas'],
    'localPercentSavedVsSeparate': reduction(c['separate4x16LocalGas'], c['bundled4x16LocalGas']),
    'fullInputLayoutProjection': {
        'payloadBytes': 44065024, 'streamCount': 24,
        'countsByLeaves': layout['countsByLeaves'], 'rangeOperations': calls,
        'maxOperationsPerTransaction': 4,
        'dataTransactions': (calls+3)//4,
        'previousSetupTransactionsAllowance': 115,
        'setupAndDataTransactions': (calls+3)//4+115,
        'assumptions': ['Cross-stream grouping permitted', 'All required codecs integrated',
                        'Existing setup allowance retained, not requoted',
                        'One input pass, not a force evaluation or simulation'],
        'fullInputBundleGasQuoted': False
    },
    'productionIntegrated': False, 'mainnetReady': False, 'publicTransactionsSent': 0
}
(here / 'batch-optimization-summary.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({k: result[k] for k in ['targetPercentSavedVsSeparate', 'targetPercentSavedVsSingle64',
                                      'localPercentSavedVsSeparate', 'fullInputLayoutProjection']}, indent=2))
