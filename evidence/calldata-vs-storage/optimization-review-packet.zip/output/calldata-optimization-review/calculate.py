import json
import hashlib
from decimal import Decimal, getcontext
from pathlib import Path

getcontext().prec = 40
here = Path(__file__).resolve().parent
out = here.parent
def read(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
report_path = out/'calldata-optimized-benchmark/report.json'
report = read(report_path)
price = read(here/'pricing.json')
old_path = out/'calldata-full-pass-estimate/full-pass-estimate.json'
old = read(old_path)
streams = old['scenarios'][0]['perStream']
assert report['passed'] and sum(s['bytes'] for s in streams) == 44065024
unit = Decimal(price['gasPriceWei'])/Decimal(10**18)
def amounts(gas): return {'gas':str(gas),'eth':str(Decimal(gas)*unit),'usd':str(Decimal(gas)*unit*Decimal(price['ethUsd']))}
rates = {r['count']:int(r['targetGas']) for r in report['rows'] if r['label'].startswith('range:bulk')}
baseline = {r['count']:int(r['targetGas']) for r in report['rows'] if r['label'].startswith('baseline:bulk')}
setup = int(old['setup']['total']['gas'])
scenarios = []
for cap in [1,2,4,8,16,32,64]:
    hist = {2**i:0 for i in range(cap.bit_length())}
    for s in streams:
        n = (s['bytes']+1023)//1024
        hist[cap] += n//cap
        for k in hist:
            if k < cap and n%cap & k: hist[k] += 1
    gas = sum(hist[k]*rates[k] for k in hist)
    scenarios.append({'kind':'aligned_range','maxPayloadKiB':cap,'countsByLeaves':hist,
                      'inputCalls':sum(hist.values()),'callsWithSetup':sum(hist.values())+115,
                      'inputPass':amounts(gas),'setupAndPass':amounts(gas+setup)})
for cap in [1,16]:
    n = sum((s['bytes']+cap*1024-1)//(cap*1024) for s in streams)
    scenarios.append({'kind':'separate_proofs','maxPayloadKiB':cap,'inputCalls':n,
                      'callsWithSetup':n+115,'inputPass':amounts(n*baseline[cap]),
                      'setupAndPass':amounts(n*baseline[cap]+setup)})
best = min((s for s in scenarios if s['kind']=='aligned_range'),key=lambda s:int(s['inputPass']['gas']))
result = {'status':'measured_range_optimization_with_rough_full_input_rate_projection',
          'reportSha256':sha(report_path),'calculatorSha256':sha(Path(__file__)),
          'countSourceSha256':sha(old_path),'pricing':price,
          'sameBlock16KiBGas':{'baseline':baseline[16],'range':rates[16],
                              'reductionPercent':str((Decimal(baseline[16])-rates[16])/baseline[16]*100)},
          'measuredRangeGasByKiB':rates,'setupBaseline':amounts(setup),
          'scenarios':scenarios,'lowestProjectedGasRangeCapKiB':best['maxPayloadKiB'],
          'limitations':['Reference gas rates are from one float-only source stream, not all production codecs and proof depths.',
                         'Short final leaves use full-leaf reference rates; aligned tails are decomposed into powers of two.',
                         'About half the packed model still requires mixed-field or patch decoder integration.',
                         'Reuses the existing infrastructure/root setup allowance; redesigned deployment bytecode is unquoted.',
                         'No bank routing, actual forces, dynamics, working state or full campaign is priced.'],
          'productionIntegrated':False,'mainnetReady':False,'publicTransactionsSent':0}
(here/'optimization-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'sameBlock16KiBGas':result['sameBlock16KiBGas'],'lowestCapKiB':best['maxPayloadKiB'],
                  'scenarios':[{k:s[k] for k in ['kind','maxPayloadKiB','inputCalls','setupAndPass']} for s in scenarios]},indent=2))
