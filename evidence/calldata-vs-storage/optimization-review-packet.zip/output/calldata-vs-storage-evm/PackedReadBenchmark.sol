// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

/// @notice Isolated data-access microbenchmark, not a molecular simulation.
contract PackedReadBenchmark {
    error Invalid(); error Unauthorized(); error BadProof();
    bytes32 public constant DOMAIN = keccak256("ORVIA.CalldataVsStorage.Chunk.v1");
    bytes32 public constant CODEC = keccak256("ORVIA.DenseF64.v1");
    address public immutable owner;
    struct Meta { bytes32 root; bytes32 codec; uint64 totalBytes; uint64 storedChunks; uint32 chunkSize; uint8 depth; bool exists; }
    mapping(bytes32 => Meta) public metadata;
    mapping(bytes32 => mapping(uint64 => bytes32)) private payload;
    event Result(bytes32 digest);
    constructor(address who) { if(who==address(0))revert Invalid();owner=who; }
    function registerRoot(bytes32 stream,bytes32 root,uint64 totalBytes,uint32 chunkSize) external {
        if(msg.sender!=owner)revert Unauthorized();
        if(stream==0||root==0||metadata[stream].exists||totalBytes==0||totalBytes%8!=0||(chunkSize!=256&&chunkSize!=1024))revert Invalid();
        uint256 count=(uint256(totalBytes)+chunkSize-1)/chunkSize;uint256 width=1;uint8 depth;
        while(width<count){width*=2;++depth;if(depth>32)revert Invalid();}
        metadata[stream]=Meta(root,CODEC,totalBytes,0,chunkSize,depth,true);
    }
    function storeChunks(bytes32 stream,bytes[] calldata chunks,bytes32[][] calldata proofs) external {
        if(msg.sender!=owner)revert Unauthorized();Meta storage m=metadata[stream];
        if(!m.exists||chunks.length==0||chunks.length!=proofs.length)revert Invalid();
        uint256 slots;
        for(uint256 i;i<chunks.length;++i){uint64 index=m.storedChunks;_verify(stream,m,index,chunks[i],proofs[i]);
            slots+=(chunks[i].length+31)/32;if(slots>128)revert Invalid();
            _store(stream,index,m.chunkSize,chunks[i]);
            ++m.storedChunks;
        }
    }
    function _store(bytes32 stream,uint64 index,uint32 chunkSize,bytes calldata chunk)private{
        uint256 first=uint256(index)*(chunkSize/32);
        for(uint256 k;k<chunk.length;k+=32){bytes32 word;assembly{word:=calldataload(add(chunk.offset,k))}
            if(k+32>chunk.length)word=bytes32(uint256(word)&(type(uint256).max<<(8*(k+32-chunk.length))));
            payload[stream][uint64(first+k/32)]=word;}
    }
    function consumeStored(bytes32 stream,uint64[] calldata indices,uint32 offset,uint32 length,uint8 repeats) external returns(bytes32 digest){
        Meta storage m=metadata[stream];_query(m,indices.length,offset,length,repeats);
        digest=keccak256(abi.encode(stream,indices,offset,length,repeats));
        for(uint256 j;j<indices.length;++j){uint64 index=indices[j];if(index>=m.storedChunks||uint256(index)*m.chunkSize+offset+length>m.totalBytes)revert Invalid();
            uint64[] memory values=_storedValues(stream,index,m.chunkSize,offset,length);
            digest=_fold(digest,values,repeats);
        }emit Result(digest);
    }
    function consumeCalldata(bytes32 stream,uint64[] calldata indices,bytes[] calldata chunks,bytes32[][] calldata proofs,uint32 offset,uint32 length,uint8 repeats)external returns(bytes32 digest){
        Meta storage m=metadata[stream];_query(m,indices.length,offset,length,repeats);if(chunks.length!=indices.length||proofs.length!=indices.length)revert Invalid();
        digest=keccak256(abi.encode(stream,indices,offset,length,repeats));
        for(uint256 j;j<indices.length;++j){_verify(stream,m,indices[j],chunks[j],proofs[j]);if(offset+length>chunks[j].length)revert Invalid();
            uint64[] memory values=_calldataValues(chunks[j],offset,length);
            digest=_fold(digest,values,repeats);
        }emit Result(digest);
    }
    function _storedValues(bytes32 stream,uint64 index,uint32 chunkSize,uint32 offset,uint32 length)private view returns(uint64[] memory values){
        values=new uint64[](length/8);uint256 first=uint256(index)*(chunkSize/32);uint256 previous=type(uint256).max;bytes32 word;
        for(uint256 i;i<values.length;++i){uint256 pos=offset+i*8;uint256 slot=first+pos/32;
            if(slot!=previous){word=payload[stream][uint64(slot)];previous=slot;}values[i]=uint64(uint256(word)>>(8*(24-pos%32)));}
    }
    function _calldataValues(bytes calldata chunk,uint32 offset,uint32 length)private pure returns(uint64[] memory values){
        values=new uint64[](length/8);for(uint256 i;i<values.length;++i){uint256 pos=offset+i*8;uint64 value;
            assembly{value:=shr(192,calldataload(add(chunk.offset,pos)))}values[i]=value;}
    }
    function _query(Meta storage m,uint256 n,uint32 offset,uint32 length,uint8 repeats)private view{
        if(!m.exists||n==0||n>16||length==0||offset%8!=0||length%8!=0||uint256(offset)+length>m.chunkSize||repeats==0||repeats>16)revert Invalid();
    }
    function _verify(bytes32 stream,Meta storage m,uint64 index,bytes calldata chunk,bytes32[] calldata proof)private view{
        uint256 start=uint256(index)*m.chunkSize;if(start>=m.totalBytes)revert Invalid();uint256 expected=m.totalBytes-start;if(expected>m.chunkSize)expected=m.chunkSize;
        if(chunk.length!=expected||proof.length!=m.depth)revert Invalid();
        bytes32 node=keccak256(abi.encode(DOMAIN,stream,m.codec,m.totalBytes,m.chunkSize,index,chunk));uint256 position=index;
        for(uint256 i;i<proof.length;++i){node=position&1==0?keccak256(abi.encodePacked(node,proof[i])):keccak256(abi.encodePacked(proof[i],node));position>>=1;}
        if(node!=m.root)revert BadProof();
    }
    function _fold(bytes32 digest,uint64[] memory values,uint8 repeats)private pure returns(bytes32){
        for(uint256 r;r<repeats;++r)for(uint256 i;i<values.length;++i)digest=keccak256(abi.encode(digest,_expand64(values[i])));
        return digest;
    }
    function _expand64(uint64 value)private pure returns(uint128){
        uint128 sign=uint128(value>>63)<<127;uint64 exp=(value>>52)&2047;uint64 frac=value&0x000fffffffffffff;if(exp==2047)revert Invalid();
        if(exp==0){if(frac==0)return sign;uint256 top;uint64 v=frac;while(v>1){v>>=1;++top;}return sign|uint128((top+15309)<<112)|uint128(uint256(frac-(uint64(1)<<top))<<(112-top));}
        return sign|(uint128(exp+15360)<<112)|(uint128(frac)<<60);
    }
}
