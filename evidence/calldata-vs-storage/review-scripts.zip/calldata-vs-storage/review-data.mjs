import fs from 'node:fs';
import crypto from 'node:crypto';
import {AbiCoder,keccak256,concat,getBytes} from '../../ORVIA/node_modules/ethers/lib.esm/index.js';

const folder=new URL('../calldata-vs-storage-data/',import.meta.url);
const bytes=fs.readFileSync(new URL('samples.json',folder));
const samples=JSON.parse(bytes);
if(!samples.passed)throw Error('Sample preparation is incomplete');
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const coder=AbiCoder.defaultAbiCoder();
const types=['bytes32','bytes32','bytes32','uint64','uint32','uint64','bytes'];
let checked=0;
const details=[];
for(const d of samples.datasets){
  const packed=fs.readFileSync(d.packedFile);
  if(sha(packed)!==d.packedSha256||packed.length!==d.totalBytes)throw Error('Packed source mismatch');
  const count=Math.ceil(d.totalBytes/d.chunkSize);
  if(count!==d.actualChunkCount||Math.ceil(Math.log2(count))!==d.proofDepth)throw Error('Tree shape mismatch');
  for(const c of d.selectedChunks){
    const chunk=Buffer.from(getBytes(c.chunk));
    if(c.index>=count||c.proof.length!==d.proofDepth)throw Error('Proof shape mismatch');
    if(chunk.length!==Math.min(d.chunkSize,d.totalBytes-c.index*d.chunkSize))throw Error('Chunk length mismatch');
    if(!chunk.equals(packed.subarray(c.index*d.chunkSize,(c.index+1)*d.chunkSize)))throw Error('Source slice mismatch');
    if(!chunk.equals(fs.readFileSync(c.chunkFile))||sha(chunk)!==c.chunkSha256)throw Error('Sample bytes mismatch');
    let hash=keccak256(coder.encode(types,[samples.DOMAIN,d.streamId,d.codec,d.totalBytes,d.chunkSize,c.index,chunk]));
    let index=c.index;
    for(const sibling of c.proof){hash=keccak256(concat(index%2?[sibling,hash]:[hash,sibling]));index=Math.floor(index/2);}
    if(hash!==d.root||index!==0)throw Error('Proof root mismatch');
    ++checked;
  }
  details.push({dataset:d.key,selectedChunks:d.selectedChunks.length,proofDepth:d.proofDepth,sourceBytes:packed.length});
}
const report={passed:true,scope:'Independent sample-to-source, hash, tree-shape and selected indexed-proof checks; no repeat of all tree construction',samplesSha256:sha(bytes),scriptSha256:sha(fs.readFileSync(new URL(import.meta.url))),checkedSamples:checked,datasets:details,publicTransactionsSent:0};
fs.writeFileSync(new URL('data-review.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
