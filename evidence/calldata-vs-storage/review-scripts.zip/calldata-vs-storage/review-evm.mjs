import fs from 'node:fs';
import zlib from 'node:zlib';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';
const require=createRequire(new URL('../../ORVIA/package.json',import.meta.url));
const solc=require('solc');
const {Interface,AbiCoder,keccak256,toBeHex}=require('ethers');
const folder=new URL('../calldata-vs-storage-evm/',import.meta.url);
const get=n=>fs.readFileSync(new URL(n,folder));
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const report=JSON.parse(get('report.json'));
if(!report.passed)throw Error('EVM run incomplete');
const input=JSON.parse(get('compiler-input.json'));
const artifact=JSON.parse(get('artifact.json'));
const compiled=JSON.parse(solc.compile(JSON.stringify(input)));
if(compiled.errors?.some(x=>x.severity==='error'))throw Error('Independent compile failed');
const actual=Object.values(compiled.contracts).flatMap(x=>Object.values(x)).find(x=>x.evm?.bytecode?.object===artifact.evm.bytecode.object);
if(!actual||actual.evm.deployedBytecode.object!==artifact.evm.deployedBytecode.object)throw Error('Artifact recompile mismatch');
if(sha(get('PackedReadBenchmark.sol'))!==report.sourceSha256||sha(get('compiler-input.json'))!==report.compilerInputSha256||sha(get('benchmark.mjs'))!==report.scriptSha256)throw Error('Source binding mismatch');
const samples=JSON.parse(fs.readFileSync(new URL('../calldata-vs-storage-data/samples.json',import.meta.url)));
const abi=new Interface(artifact.abi),coder=AbiCoder.defaultAbiCoder();
const sender='0x2541a9e93B5C853E9208b0C5C7386dD458424c77';
let quotes=0,slots=0;
const records=[];
for(const r of report.rows.filter(x=>x.targetGas)){
  const d=samples.datasets.find(x=>x.key===r.dataset),deployment=report.datasets.find(x=>x.key===r.dataset);
  let data,n=r.chunks??0;
  const chosen=d.selectedChunks.filter(x=>x.index<n).slice(0,n);
  if(r.kind==='register')data=abi.encodeFunctionData('registerRoot',[d.streamId,d.root,d.totalBytes,d.chunkSize]);
  else if(r.kind==='store')data=abi.encodeFunctionData('storeChunks',[d.streamId,chosen.map(x=>x.chunk),chosen.map(x=>x.proof)]);
  else if(r.kind==='stored')data=abi.encodeFunctionData('consumeStored',[d.streamId,chosen.map(x=>x.index),r.offset,r.length,r.repeats]);
  else if(r.kind==='calldata')data=abi.encodeFunctionData('consumeCalldata',[d.streamId,chosen.map(x=>x.index),chosen.map(x=>x.chunk),chosen.map(x=>x.proof),r.offset,r.length,r.repeats]);
  else throw Error('Unexpected quoted operation');
  if(keccak256(data)!==r.calldataKeccak256)throw Error('Calldata mismatch');
  const raw=zlib.gunzipSync(get(r.overrideFile)),overrides=JSON.parse(raw);
  if(sha(raw)!==r.overrideSha256)throw Error('Override hash mismatch');
  const state=overrides[deployment.address].state;
  if(keccak256(overrides[deployment.address].code)!==r.runtimeKeccak256)throw Error('Runtime mismatch');
  const metaBase=BigInt(keccak256(coder.encode(['bytes32','uint256'],[d.streamId,0])));
  const read=k=>BigInt(state[toBeHex(k,32)]??'0x0');
  if(r.kind==='register'){
    for(let i=0n;i<3n;i++){if(read(metaBase+i)!==0n)throw Error('Root registration prestate not empty');slots++;}
  }else{
    const stored=(r.kind==='store'?0:n);
    const packed=BigInt(d.totalBytes)|(BigInt(stored)<<64n)|(BigInt(d.chunkSize)<<128n)|(BigInt(d.proofDepth)<<160n)|(1n<<168n);
    if(read(metaBase)!==BigInt(d.root)||read(metaBase+1n)!==BigInt(d.codec)||read(metaBase+2n)!==packed)throw Error('Metadata prestate mismatch');slots+=3;
    const inner=keccak256(coder.encode(['bytes32','uint256'],[d.streamId,1]));
    for(let j=0;j<(r.kind==='store'?1:n);j++){
      const b=Buffer.from(d.selectedChunks.find(x=>x.index===j).chunk.slice(2),'hex');
      for(let off=0;off<b.length;off+=32){
        const key=BigInt(keccak256(coder.encode(['uint64','bytes32'],[j*(d.chunkSize/32)+off/32,inner])));
        const expected=r.kind==='store'?0n:BigInt('0x'+b.subarray(off,off+32).toString('hex').padEnd(64,'0'));
        if(read(key)!==expected)throw Error('Stored payload mismatch');slots++;
      }
    }
  }
  if(BigInt(overrides[sender].nonce)!==BigInt(r.nonce))throw Error('Sender nonce mismatch');
  const request={jsonrpc:'2.0',id:r.rpcId,method:'eth_estimateGas',params:[{from:sender,to:deployment.address,nonce:r.nonce,value:'0x0',data,gas:'0x1c9c380'},report.targetBlock.number,overrides]};
  if(sha(JSON.stringify(request))!==r.rpcRequestSha256)throw Error('Target request hash mismatch');
  const values={jsonrpc:'2.0',id:r.rpcId,result:toBeHex(BigInt(r.targetGas)).replace(/^0x0([0-9a-f])/, '0x$1')};
  const orders=[['jsonrpc','id','result'],['id','jsonrpc','result'],['id','result','jsonrpc'],['result','id','jsonrpc'],['result','jsonrpc','id'],['jsonrpc','result','id']];
  if(!orders.some(keys=>sha(JSON.stringify(Object.fromEntries(keys.map(k=>[k,values[k]]))))===r.rpcResponseSha256))throw Error('Gas response hash mismatch');
  const call=report.remoteCalls.find(x=>x.id===r.rpcId);
  if(call.requestSha256!==r.rpcRequestSha256||call.responseSha256!==r.rpcResponseSha256)throw Error('Transcript mismatch');
  const b=Buffer.from(data.slice(2),'hex'),zero=b.filter(x=>x===0).length;
  if(b.length!==r.calldataBytes||zero!==r.zeroCalldataBytes||21000+4*zero+16*(b.length-zero)!==r.intrinsicGas)throw Error('Calldata gas count mismatch');
  records.push({label:r.label,targetGas:r.targetGas,requestHashVerified:true,responseHashVerified:true,prestateVerified:true});quotes++;
}
if(quotes!==12)throw Error('Expected twelve target quotes');
const result={passed:true,reportSha256:sha(get('report.json')),scriptSha256:sha(fs.readFileSync(new URL(import.meta.url))),compilerReproduced:true,targetQuotesVerified:quotes,prestateValuesVerified:slots,records,publicTransactionsSent:0,scope:'Offline reconstruction of exact target requests, responses and relevant prior storage. No additional RPC requests; no full molecular campaign.'};
fs.writeFileSync(new URL('evm-review.json',import.meta.url),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
