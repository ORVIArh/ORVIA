from pathlib import Path
from decimal import Decimal, getcontext
import json,hashlib
getcontext().prec=40
here=Path(__file__).resolve().parent
report_file=here.parent/'calldata-vs-storage-evm/report.json'
r=json.loads(report_file.read_text());assert r['passed']
p=json.loads((here/'pricing.json').read_text())
unit=Decimal(p['gasPriceWei'])/Decimal(10)**18
usd=unit*Decimal(p['ethUsd'])
rows={x['label']:x for x in r['rows']if x.get('targetGas')}
prefix='complex33/A.nonbonded.chunk1024:'
setup=int(rows[prefix+'store1:0']['targetGas'])
items=[]
for name in ['sparse8','cross24','bulk1','bulk4','bulk16']:
 s=int(rows[prefix+name+':stored']['targetGas']);c=int(rows[prefix+name+':calldata']['targetGas']);difference=c-s
 items.append({'scenario':name,'storedGas':s,'calldataGas':c,'storedUsdPerCall':str(Decimal(s)*usd),'calldataUsdPerCall':str(Decimal(c)*usd),'storedUsdPer1000Calls':str(Decimal(s)*usd*1000),'calldataUsdPer1000Calls':str(Decimal(c)*usd*1000),'calldataPerCallGasReductionPercent':str(Decimal(s-c)/s*100),'storageBecomesStrictlyCheaperAfterUses':setup//difference+1 if name in ['sparse8','cross24'] and difference>0 else None,'sameInputOutputVerified':True})
summary={'status':'priced_conditional_target_data_access_comparison','reportSha256':hashlib.sha256(report_file.read_bytes()).hexdigest(),'pricing':p,'commonRootRegistrationGas':int(rows[prefix+'register']['targetGas']),'additionalStore1024BytesGas':setup,'additionalStore1024BytesUsd':str(Decimal(setup)*usd),'cases':items,'formula':'For a fixed 1KB chunk: storage = one initial store + uses * stored-read; calldata = uses * verified-calldata-read. Shared root registration omitted from both.','completeModelOrCampaignQuote':False,'productionReaderImplemented':False,'publicTransactionsSent':0,'limitations':['Actual target estimates with temporary hypothetical state, not mainnet transactions.','Measures data extraction, binary64-to-binary128 expansion and a common digest, not molecular forces.','Break-even assumes the same 1KB chunk is permanently stored in full and its sparse field is reused in separate transactions.','Byte/record-sized Merkle leaves and multiproofs could shift the crossover.','The current mainnet production architecture is unchanged.']}
(here/'comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
