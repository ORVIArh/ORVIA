# Same-root aligned range-proof data

Actual source: complex33 A.nonbonded, exact dense binary64 transport of the unchanged binary128 input words. This packet changes proof representation only. It does not change codec, tree, leaf domain, input bytes, scientific model or production contracts.

`ranges.json` reconstructs the original full 4,096-leaf tree from the real 3,190,464-byte packed file and verifies the existing root:

`0x1acb6f7ebce5a205808fb4d1a647572da0a701a134324e377eec99d8f761efdd`

There are 3,116 actual 1,024-byte chunks, with indexed empty leaves padding the tree. First 64 individual chunks/proofs are included, plus the final 704-byte chunk at index 3,115. Aligned flat bundles at start 0 contain 1/2/4/8/16/32/64 unchanged chunks. Each compact proof starts at that aligned subtree's root and walks to the original root in left/right index order. The last partial one-leaf range is also included.

| Chunks | Input bytes | Separate-proof bytes | Compact-proof bytes |
|---:|---:|---:|---:|
| 1 | 1,024 | 384 | 384 |
| 2 | 2,048 | 768 | 352 |
| 4 | 4,096 | 1,536 | 320 |
| 8 | 8,192 | 3,072 | 288 |
| 16 | 16,384 | 6,144 | 256 |
| 32 | 32,768 | 12,288 | 224 |
| 64 | 65,536 | 24,576 | 192 |

Counts exclude ABI headers and metadata. This is proof-byte accounting, not gas or fee savings. Leaf hashing remains necessary. For 64 chunks, 63 internal subtree hashes plus 6 ancestor hashes replace 768 independently repeated parent hashes. Gas and target transaction limits must be measured by the separate executable benchmark.

The preferred first candidate is this aligned subtree proof, rather than an arbitrary multiproof with caller-supplied queue flags. Both sides must retain the exact original index-bound leaf domain and ordered parent hash; a sorted/commutative Merkle library is incompatible with this root.

Required admission/negative cases: count 0/non-power-of-two/>64; unaligned start; start/count beyond actual leaves; wrong exact bundle length including final partial; truncated/extra/reordered ancestor nodes; mutated or permuted leaf bytes; wrong start/index; root/codec/length/chunk-size replay; and malformed consumption offsets. Compute range lengths in checked uint256 arithmetic. Require proof length exactly depth−log2(count). Do not accept padded empty leaves as actual source chunks. After verification, preserve the old seed, field order, binary64-to-binary128 expansion and fold order when comparing consumer outputs.

This source has zero transport padding; a general typed reader must additionally bind original logical length so padding cannot become a scientific field. Tagged endpoint patch records and mixed uint32 records need their own bound codecs and are not decoded by this float-only range fixture.

Reproduce with the original packed source and prior samples manifest available:

```sh
ORVIA_NODE_ROOT=/path/to/ORVIA \
ORVIA_SOURCE_SAMPLES=/path/to/original/samples.json \
node prepare_range.mjs
```

The original sample manifest identifies the whole packed file and source hashes. This producer writes only beside its own script; run a copy in a fresh directory to retain the frozen evidence. No GPU run, public call or transaction is used. `ranges.json` contains the complete selected bytes, source bindings and self-verification results; the 3.19 MB whole packed file is deliberately not copied into this packet.
