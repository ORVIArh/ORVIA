# Aligned range proof microbenchmark

This isolated candidate improves the previous verified-calldata transport by accepting an aligned range of contiguous 1 KiB leaves as one flat bytes bundle. It preserves the exact existing leaf domain, stream/codec/length/index binding, ordered Merkle root, binary64-to-binary128 bit conversion and per-value `keccak256(abi.encode(digest,uint128))` calculation. It does not apply the proposed scratch-memory digest optimization. No canonical contracts were edited.

## Measured result

All target estimates below were captured at the same pinned Robinhood mainnet block `0x63769ad` (`0xe454bce15614c974b891257b55ff6076f487a38fd51de571e81b66d246443cc5`) with the exact local runtime and hypothetical preceding state supplied as overrides. No mainnet transaction was signed or sent. Local execution used pinned solc 0.8.26, optimizer 200, Shanghai, standard contract limits and no signing key.

| Actual input / operation | Original calldata path, gas | Shared range path, gas |
|---|---:|---:|
| 1 KiB, all fields | 228,790 | 234,495 |
| 16 KiB, all fields | 2,909,375 | 2,701,791 |
| One 8-byte field from a 1 KiB chunk | 99,521 | 105,962 |

The 16 KiB target estimate decreases **7.13%**. A single chunk and a sparse single-chunk lookup become slightly more expensive. This is a transport/microbenchmark result, not a full molecular-force or campaign speedup. These prices must not be compared directly with a prior block's estimates: posting fees changed between runs.

The exact power-of-two range measurements, using the first actual nonbonded data of each size:

| Range size | Original leaf count | Ancestor proof nodes | Local receipt gas | Target estimate gas |
|---|---:|---:|---:|---:|
| 1 KiB | 1 | 12 | 198,752 | 234,495 |
| 2 KiB | 2 | 11 | 349,817 | 390,782 |
| 4 KiB | 4 | 10 | 656,186 | 708,288 |
| 8 KiB | 8 | 9 | 1,283,832 | 1,358,235 |
| 16 KiB | 16 | 8 | 2,597,821 | 2,701,791 |
| 32 KiB | 32 | 7 | 5,462,677 | 5,608,939 |
| 64 KiB | 64 | 6 | 12,131,353 | 12,346,042 |

A focused follow-up estimated four contiguous 16 KiB ranges covering **the same first 64 KiB**: 2,701,791 + 2,715,313 + 2,713,654 + 2,700,942 = **10,831,700 gas**. One 64 KiB call costs **12,346,042 gas**, 13.98% more. The same scalar values are decoded and folded; four calls have four independently seeded result digests, versus one digest for the single call. The original allocation-heavy digest work is intentionally retained. Larger batches therefore cannot be assumed cheaper; further memory optimization would be a separate experiment.

## Proof and boundary policy

`consumeRange(Query, bytes bundle, bytes32[] ancestors)` accepts nonzero power-of-two counts up to 64. Start must be aligned to count, and the entire range must be inside the actual leaf count. Every leaf uses the original encoding and its actual index. The contract computes the range's internal subtree once, then verifies exactly `treeDepth-log2(count)` ordered ancestor nodes. The flat bundle must have precisely the expected byte length; the last physical leaf may be shorter than 1 KiB.

The initial digest includes the same stream, explicit index array, offset, length and repeat count as the baseline. Every requested field follows the same conversion and fold. Both paths prefetch their selected fields once; no arithmetic or digest work was removed from the primary comparison.

The source model's final range is not automatically a full 16-leaf block. Full-pass projections must decompose tails into aligned powers of two and account for short final leaves and stream-specific proof depths. The 44 MB model also contains mixed integer/float and patch formats that this float-only microbenchmark does not implement. No full-model cost is asserted here.

## Validation and replay

- `report.json`: 18 local receipts, 29 checks and 12 initial conditional target estimates. It includes exact calldata sizes, decoded-result oracle hashes, runtime/source hashes and request/response hashes.
- `followup.json`: two additional conditional target estimates at the same block and exact saved state, plus local receipts and decoded-result checks for offsets 32 and 48.
- Negative tests reject zero/non-power-of-two/oversized counts, unaligned/wrong/out-of-range starts, short proofs, altered chunks, wrong proof nodes, extra/short bundle bytes, short final leaf and reads beyond the final leaf.
- Valid nonzero start 16/count 16 and the final short leaf pass.
- `PackedReadBenchmark.sol` is an exact copy of the previous baseline; the candidate inherits it. Root's independent compile/source review confirms the fold and expansion bodies are unchanged.
- Source/proof preparation reuses the existing full tree and actual packed data; no additional GPU or full-tree work is needed by the benchmark runner.

The run made **14 read-only target estimates total**: 12 initial plus two focused follow-up estimates. Every target call used the same pinned block. The preceding-state files are under `overrides/`. A root is not data publication; a production calldata system still needs availability, resupply and integrated authenticated consumer interfaces.

Extract the packet with its sibling `calldata-range-data/ranges.json` and read-only `256-deployment-gas/rpc.mjs` helper under AURA/output; use the pinned dependencies in AURA/ORVIA. `node output/calldata-optimized-benchmark/benchmark.mjs --local-only` replays the primary benchmark locally. The default runner performs read-only target estimates through the user's external provider configuration. `followup.mjs` requires the primary report and also has no remote send operation.

Scientific acceptance, full-engine validation and production readiness remain false.
