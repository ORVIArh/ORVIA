// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;
import {PackedReadBenchmark} from "./PackedReadBenchmark.sol";

/// @notice Experimental aligned-range proof and flat calldata transport.
/// @dev Retains the original leaf/root and exact per-value binary128-bit digest.
contract AlignedRangeReadBenchmark is PackedReadBenchmark {
    constructor(address who) PackedReadBenchmark(who) {}
    struct Query { bytes32 stream; uint64 start; uint32 count; uint32 offset; uint32 length; uint8 repeats; }
    function consumeRange(Query calldata q,bytes calldata bundle,bytes32[] calldata proof)external returns(bytes32 digest){
        Meta storage m=metadata[q.stream];
        if(!m.exists||q.count==0||q.count>64||(q.count&(q.count-1))!=0||q.start%q.count!=0
            ||q.length==0||q.offset%8!=0||q.length%8!=0||uint256(q.offset)+q.length>m.chunkSize||q.repeats==0||q.repeats>16)revert Invalid();
        _verifyRange(q,m,bundle,proof);
        uint64[] memory indices=new uint64[](q.count);for(uint256 i;i<q.count;++i)indices[i]=uint64(uint256(q.start)+i);
        digest=keccak256(abi.encode(q.stream,indices,q.offset,q.length,q.repeats));
        for(uint256 i;i<q.count;++i){uint256 first=i*m.chunkSize;
            if((uint256(q.start)+i)*m.chunkSize+q.offset+q.length>m.totalBytes)revert Invalid();
            uint64[] memory values=_rangeValues(bundle,first+q.offset,q.length);
            digest=_foldRange(digest,values,q.repeats);
        }emit Result(digest);
    }
    function _verifyRange(Query calldata q,Meta storage m,bytes calldata bundle,bytes32[] calldata proof)private view{
        {uint256 leaves=(uint256(m.totalBytes)+m.chunkSize-1)/m.chunkSize;
        if(uint256(q.start)+q.count>leaves)revert Invalid();
        uint256 expected=uint256(q.count)*m.chunkSize;uint256 remaining=uint256(m.totalBytes)-uint256(q.start)*m.chunkSize;if(expected>remaining)expected=remaining;
        if(bundle.length!=expected)revert Invalid();}
        uint256 height;for(uint256 n=q.count;n>1;n>>=1)++height;
        if(height>m.depth||proof.length!=m.depth-height)revert Invalid();
        bytes32[] memory nodes=new bytes32[](q.count);
        for(uint256 i;i<q.count;++i){uint256 first=i*m.chunkSize;uint256 last=first+m.chunkSize;if(last>bundle.length)last=bundle.length;
            nodes[i]=_leaf(q.stream,m,uint64(uint256(q.start)+i),bundle[first:last]);}
        for(uint256 width=q.count;width>1;width>>=1)for(uint256 i;i<width/2;++i)nodes[i]=keccak256(abi.encodePacked(nodes[i*2],nodes[i*2+1]));
        bytes32 node=nodes[0];uint256 position=uint256(q.start)>>height;
        for(uint256 i;i<proof.length;++i){node=position&1==0?keccak256(abi.encodePacked(node,proof[i])):keccak256(abi.encodePacked(proof[i],node));position>>=1;}
        if(node!=m.root)revert BadProof();
    }
    function _leaf(bytes32 stream,Meta storage m,uint64 index,bytes calldata chunk)private view returns(bytes32){
        return keccak256(abi.encode(DOMAIN,stream,m.codec,m.totalBytes,m.chunkSize,index,chunk));
    }
    function _rangeValues(bytes calldata bundle,uint256 first,uint32 length)private pure returns(uint64[] memory values){
        values=new uint64[](length/8);for(uint256 i;i<values.length;++i){uint256 pos=first+i*8;uint64 value;
            assembly{value:=shr(192,calldataload(add(bundle.offset,pos)))}values[i]=value;}
    }
    // The same arithmetic and allocation work as PackedReadBenchmark._fold.
    function _foldRange(bytes32 digest,uint64[] memory values,uint8 repeats)private pure returns(bytes32){
        for(uint256 r;r<repeats;++r)for(uint256 i;i<values.length;++i)digest=keccak256(abi.encode(digest,_expandRange(values[i])));
        return digest;
    }
    function _expandRange(uint64 value)private pure returns(uint128){
        uint128 sign=uint128(value>>63)<<127;uint64 exp=(value>>52)&2047;uint64 frac=value&0x000fffffffffffff;if(exp==2047)revert Invalid();
        if(exp==0){if(frac==0)return sign;uint256 top;uint64 v=frac;while(v>1){v>>=1;++top;}return sign|uint128((top+15309)<<112)|uint128(uint256(frac-(uint64(1)<<top))<<(112-top));}
        return sign|(uint128(exp+15360)<<112)|(uint128(frac)<<60);
    }
}
