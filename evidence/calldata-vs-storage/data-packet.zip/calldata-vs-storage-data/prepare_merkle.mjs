import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
import {performance} from 'node:perf_hooks';
const base=fileURLToPath(new URL('.',import.meta.url));
const require=createRequire(path.resolve(process.env.ORVIA_NODE_ROOT||fileURLToPath(new URL('../../ORVIA/',import.meta.url)),'package.json'));
const {AbiCoder,keccak256,toUtf8Bytes,concat}=require('ethers');
const abi=AbiCoder.defaultAbiCoder(),DOMAIN=keccak256(toUtf8Bytes('ORVIA.CalldataVsStorage.Chunk.v1'));
const sha=b=>createHash('sha256').update(b).digest('hex');
const leaf=(stream,codec,totalBytes,size,index,chunk)=>keccak256(abi.encode(['bytes32','bytes32','bytes32','uint64','uint32','uint64','bytes'],[DOMAIN,stream,codec,totalBytes,size,index,chunk]));
const report={schema:'orvia.actual-packed-stream-indexed-merkle-samples.v1',status:'in_progress',passed:false,hashingDevice:'CPU:ethers keccak256',gpuHashing:false,gpuEvmGasMeasurement:false,publicTransactionsSent:0,scientificAcceptance:false,workingStateIncluded:false,scriptSha256:sha(fs.readFileSync(import.meta.filename)),leafAbi:['bytes32 DOMAIN','bytes32 streamId','bytes32 codec','uint64 totalBytes','uint32 chunkSize','uint64 chunkIndex','bytes chunk'],DOMAIN,parentPolicy:'keccak256(left||right), ordered by index; pad to power2 with leaf(index,emptybytes)',invalidRequestRules:['index>=actualChunkCount rejects','chunk.length!=min(chunkSize,totalBytes-index*chunkSize) rejects','proof.length!=ceilLog2(actualChunkCount) rejects'],datasets:[]};
const save=()=>fs.writeFileSync(base+'samples.json',JSON.stringify(report,null,2)+'\n');save();
try{
 const source=JSON.parse(fs.readFileSync(base+'packed-manifest.json'));assert(source.passed,'Source preparation incomplete');report.packedManifestSha256=sha(fs.readFileSync(base+'packed-manifest.json'));
 const order=['complex33/A.nonbonded','complex33/A.particles','complex33/positions','solvent33/A.nonbonded','solvent33/A.particles','solvent33/positions','complex33/A.bonds','complex33/A.exceptions','solvent33/A.bonds','solvent33/A.exceptions'];
 const start=performance.now();
 for(const key of order){const row=source.streams.find(x=>x.key===key);assert(row,'Missing stream');const all=fs.readFileSync(row.packedFile);assert(sha(all)===row.packedSha256,'Packed hash');
  for(const size of [1024,256]){const started=performance.now(),codec=keccak256(toUtf8Bytes(row.codec)),count=Math.ceil(all.length/size),depth=Math.ceil(Math.log2(count)),paddedCount=2**depth;const levels=[[]];
   for(let i=0;i<paddedCount;i++){const chunk=i<count?'0x'+all.subarray(i*size,Math.min(all.length,(i+1)*size)).toString('hex'):'0x';levels[0].push(leaf(row.sourceStreamId,codec,all.length,size,i,chunk));}
   for(let n=paddedCount;n>1;n/=2){const last=levels.at(-1),next=[];for(let i=0;i<n;i+=2)next.push(keccak256(concat([last[i],last[i+1]])));levels.push(next);}
   const root=levels.at(-1)[0];const indices=[...new Set([...Array.from({length:Math.min(16,count)},(_,i)=>i),count-1])];const chunks=[];
   for(const index of indices){const bytes=all.subarray(index*size,Math.min(all.length,(index+1)*size)),chunk='0x'+bytes.toString('hex');let p=index;const proof=[];for(let l=0;l<depth;l++){proof.push(levels[l][p^1]);p=Math.floor(p/2);}let digest=leaf(row.sourceStreamId,codec,all.length,size,index,chunk);p=index;for(const sibling of proof){digest=keccak256(p&1?concat([sibling,digest]):concat([digest,sibling]));p=Math.floor(p/2);}assert(digest===root,'Proof self verification');
    const target=path.join(base,'samples',key+'.chunk'+size+'.index'+index+'.bin');fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,bytes);chunks.push({index,chunkBytes:bytes.length,chunkFile:target,chunkSha256:sha(bytes),chunk,zeroBytes:bytes.length-Buffer.from(bytes).filter(x=>x!==0).length,proof,proofBytes:proof.length*32,proofSelfVerified:true});}
   const record={key:key+'.chunk'+size,streamKey:key,role:row.role,codecName:row.codec,codec,streamId:row.sourceStreamId,totalBytes:all.length,chunkSize:size,actualChunkCount:count,paddedLeafCount:paddedCount,proofDepth:depth,root,packedFile:row.packedFile,packedSha256:row.packedSha256,sourceRawSha256:row.sourceRawSha256,sourceLogicalWords:row.sourceLogicalWords,fullTreeConstructed:true,cpuTreeConstructionSeconds:(performance.now()-started)/1000,selectedChunks:chunks};report.datasets.push(record);save();console.log(JSON.stringify({key:record.key,bytes:record.totalBytes,leaves:count,depth,root,seconds:record.cpuTreeConstructionSeconds}));
  }
 }
 report.totalCpuTreeConstructionSeconds=(performance.now()-start)/1000;report.passed=true;report.status='passed_actual_whole_stream_roots_and_selected_proofs';report.completedAtUtc=new Date().toISOString();
}catch(e){report.status='failed';report.error={message:e.message,stack:e.stack};throw e;}
finally{save();}
function assert(v,m){if(!v)throw Error(m);}
