#!/usr/bin/env python3
"""Prepare exact real typed payloads; no contract/input modification."""
from pathlib import Path
import argparse,gzip,hashlib,json,time,traceback
import numpy as np

def sha(b):return hashlib.sha256(b).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--input-root',type=Path,default=Path(__file__).resolve().parents[1]/'full-hybrid-inputs');ap.add_argument('--output-root',type=Path,default=Path(__file__).resolve().parent);a=ap.parse_args();src=a.input_root.resolve();out=a.output_root.resolve();out.mkdir(exist_ok=True,parents=True)
 report={'schema':'orvia.calldata-storage-actual-dense-inputs.v1','status':'in_progress','passed':False,'scientificAcceptance':False,'workingStateIncluded':False,'sourceInputsModified':False,'publicTransactionsSent':0,'scriptSha256':sha(Path(__file__).read_bytes()),'streams':[]};(out/'packed-manifest.json').write_text(json.dumps(report,indent=2)+'\n');started=time.perf_counter();widths={'positions':(3,0),'particles':(4,0),'nonbonded':(3,0),'bonds':(4,2),'angles':(5,3),'torsions':(7,5),'exceptions':(6,3)}
 try:
  for leg in ['complex33','solvent33']:
   m=json.loads((src/'legs'/leg/'catalog-candidate.json').read_text())
   for name,entry in sorted(m['streams'].items()):
    if name.startswith('B.'):continue
    start=time.perf_counter();p=src/entry['path'];compressed=p.read_bytes();assert sha(compressed)==entry['gzipSha256'];raw=gzip.decompress(compressed);assert sha(raw)==entry['rawSha256'];role=name.split('.')[-1];w,k=widths[role];q=np.frombuffer(raw,dtype='>u8').reshape(-1,w,4);assert np.all(q[:,:,:2]==0);n=len(q);recordbytes=4*k+8*(w-k);packed=np.zeros((n,recordbytes),dtype=np.uint8);reconstructed=np.zeros_like(q);offset=0
    for j in range(w):
     if j<k:
      assert np.all(q[:,j,:3]==0);bits=q[:,j,3].astype('uint64');assert np.all(bits<1<<32);size=4
      b=bits.astype('>u8').view('uint8').reshape(n,8);packed[:,offset:offset+size]=b[:,8-size:];v=np.zeros((n,8),dtype='uint8');v[:,4:]=packed[:,offset:offset+size];reconstructed[:,j,3]=np.frombuffer(v.tobytes(),dtype='>u8');offset+=size
     else:
      hi=q[:,j,2].astype('uint64');lo=q[:,j,3].astype('uint64');e=(hi>>np.uint64(48))&np.uint64(32767);zero=((hi&np.uint64((1<<63)-1))==0)&(lo==0);assert np.all(zero|((e>=15361)&(e<=17406)&((lo&np.uint64((1<<60)-1))==0)))
      bits=((hi>>np.uint64(63))<<np.uint64(63))|((e-np.uint64(15360))<<np.uint64(52))|((hi&np.uint64((1<<48)-1))<<np.uint64(4))|(lo>>np.uint64(60));bits[zero]=hi[zero]&np.uint64(1<<63);b=bits.astype('>u8').view('uint8').reshape(n,8);packed[:,offset:offset+8]=b;v=np.frombuffer(packed[:,offset:offset+8].copy().tobytes(),dtype='>u8').astype('uint64');sign=v&np.uint64(1<<63);e64=(v>>np.uint64(52))&np.uint64(2047);frac=v&np.uint64((1<<52)-1);rh=sign|((e64+np.uint64(15360))<<np.uint64(48))|(frac>>np.uint64(4));rl=(frac&np.uint64(15))<<np.uint64(60);rh[zero]=sign[zero];rl[zero]=0;reconstructed[:,j,2]=rh;reconstructed[:,j,3]=rl;offset+=8
    assert reconstructed.tobytes()==raw
    data=packed.tobytes();recordDataBytes=len(data);data+=bytes((-len(data))%32);target=out/'packed'/leg/(name+'.bin');target.parent.mkdir(exist_ok=True,parents=True);target.write_bytes(data)
    row={'key':leg+'/'+name,'leg':leg,'name':name,'role':role,'sourcePath':str(p),'sourceGzipSha256':sha(compressed),'sourceRawSha256':sha(raw),'sourceLogicalWords':entry['wordCount'],'sourceStreamId':entry['proposedStreamId'],'codec':'ORVIA.DenseF64.v1'if k==0 else'ORVIA.DenseF64U32.v1','records':n,'roleWidth':w,'leadingIntegerFields':k,'recordBytes':recordbytes,'unPaddedDataBytes':recordDataBytes,'totalBytes':len(data),'paddingBytes':len(data)-recordDataBytes,'packedSha256':sha(data),'packedFile':str(target),'zeroBytes':data.count(0),'nonzeroBytes':len(data)-data.count(0),'allLogicalWordsByteRoundtripVerified':True,'cpuPreparationSeconds':time.perf_counter()-start};report['streams'].append(row)
  assert len(report['streams'])==14
  report['basePayloadBytes']=sum(s['totalBytes']for s in report['streams']);report['overlayPatchPayloadBytes']=466*32;report['totalBaseAndPatchPayloadBytes']=report['basePayloadBytes']+report['overlayPatchPayloadBytes'];assert report['totalBaseAndPatchPayloadBytes']==44065024
  report['totalCpuPreparationSeconds']=time.perf_counter()-started;report['passed']=True;report['status']='passed_exact_source_preparation'
 except Exception as e:report['status']='failed';report['error']={'message':str(e),'traceback':traceback.format_exc()};raise
 finally:(out/'packed-manifest.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'passed':report['passed'],'streams':len(report['streams']),'baseBytes':report.get('basePayloadBytes'),'baseAndPatchBytes':report.get('totalBaseAndPatchPayloadBytes'),'seconds':report.get('totalCpuPreparationSeconds')}))
if __name__=='__main__':main()
