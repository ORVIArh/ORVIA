# Actual Apple M5 GPU input bitpacking

The public Apple OpenCL framework executed the included integer-only kernel on an `Apple M5` device returned by `clGetDeviceIDs(CL_DEVICE_TYPE_GPU)`. No package, driver or operating-system changes were made. This was local input encoding only: no molecular computation, GPU hashing, EVM execution, gas result, wallet action, transaction or scientific acceptance.

Eight real input streams were processed: positions, A.particles, A.bonds and A.exceptions for complex33 and solvent33. The four required all-float streams passed, along with the four mixed integer/float streams. The complete run verified **5,157,130 original bytes32 words**, generating **34,924,968 packed bytes**. For every stream:

1. The compressed and expanded source hashes matched its frozen catalog manifest.
2. Every GPU error flag was zero.
3. The complete GPU output matched an independently calculated CPU bit encoding.
4. Expanding the **actual GPU output** reproduced every byte of the original binary128/integer source words.
5. With stream-end zero padding, the GPU output hash matched the earlier independent typed packing audit.

The kernel reads the low 128 bits of each big-endian bytes32 and requires its high 128 bits to be zero. Float fields accept exact normal binary64 embeddings and signed zero; other representations are rejected. Integers must fit uint32. These are source-input transport bits; computation remains binary128. The source streams contain no unsupported float values. Bond records use two uint32 fields then two float64 transport fields; exceptions use three uint32 fields then three float fields. No values are rounded.

The final recorded complete run took approximately **0.547 seconds**, including compilation, gzip, CPU comparisons, hashing, source rechecks and output writes. The sum of host launch-plus-`clFinish` waits was approximately **0.00765 seconds** for eight launches. Driver event profiling timestamps are preserved in the report, but their much shorter durations are treated as driver observations only; they are not used to claim bandwidth or a CPU speedup. The report separately records upload/download wall times and per-stream wall times. Timings are a single local observation, not a benchmark distribution or network/EVM latency estimate.

`gpu-packing-validation.json` binds source paths/hashes, framework inventory, runner/kernel hashes, actual timestamps, complete comparison results and output hashes. The `.bin` files are the actual GPU-produced dense f64/u32 bytes without stream-end padding; `paddedPackedSha256` covers padding to 32-byte slots. `run.log` is the completed run's log. `CHECKSUMS.sha256` freezes this directory's deliverables.

Reproduce with Python and NumPy, with the full-hybrid archive and the frozen typed audit restored under the chosen AURA root:

```sh
python pack_gpu.py --aura-root /absolute/path/to/AURA --output-dir /absolute/path/to/new-gpu-output
```

The public framework path is `/System/Library/Frameworks/OpenCL.framework/OpenCL`. If no compatible GPU is available, or the build/kernel/comparison fails, the runner records a failing report and exits unsuccessfully. It does not silently substitute CPU execution. CPU code is used explicitly for complete verification and hashing.
