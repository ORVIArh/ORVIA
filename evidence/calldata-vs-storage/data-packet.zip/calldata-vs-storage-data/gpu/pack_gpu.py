#!/usr/bin/env python3
"""Public Apple OpenCL bitpacking, with complete independent CPU comparison."""
import argparse, ctypes as C, gzip, hashlib, json, platform, sys, time
from pathlib import Path
import numpy as np
H=lambda b:hashlib.sha256(b).hexdigest()
V=C.c_void_p;U=C.c_uint;L=C.c_ulonglong;I=C.c_int;S=C.c_size_t

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--aura-root',type=Path,default=Path(__file__).resolve().parents[3]);ap.add_argument('--output-dir',type=Path,default=Path(__file__).resolve().parent);a=ap.parse_args()
 root=a.aura_root.resolve();out=a.output_dir.resolve();out.mkdir(parents=True,exist_ok=True);report=out/'gpu-packing-validation.json'
 script=Path(__file__);kernel=script.with_name('pack.cl');source=kernel.read_bytes();started=time.monotonic()
 result={'schema':'orvia.apple-opencl-exact-input-packing.v1','status':'in_progress','passed':False,'scientificAcceptance':False,'evmCompute':False,'gpuHashing':False,'sourceInputsModified':False,'contractsModified':False,'sourceHashes':{str(script.relative_to(root)):H(script.read_bytes()),str(kernel.relative_to(root)):H(source)},'streams':[],'host':{'machine':platform.machine(),'system':platform.platform(),'python':sys.version,'numpy':np.__version__},'scope':'GPU integer bit transport of source input words only; no molecular energy/forces, trajectory, EVM execution, gas, deployment or scientific acceptance.'}
 def save():report.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
 save()
 try:
  cl=C.CDLL('/System/Library/Frameworks/OpenCL.framework/OpenCL')
  def bind(name,ret,args):
   f=getattr(cl,name);f.restype=ret;f.argtypes=args;return f
  getplatform=bind('clGetPlatformIDs',I,[U,C.POINTER(V),C.POINTER(U)]);getpinfo=bind('clGetPlatformInfo',I,[V,U,S,V,C.POINTER(S)])
  getdevices=bind('clGetDeviceIDs',I,[V,L,U,C.POINTER(V),C.POINTER(U)]);getdinfo=bind('clGetDeviceInfo',I,[V,U,S,V,C.POINTER(S)])
  createcontext=bind('clCreateContext',V,[V,U,C.POINTER(V),V,V,C.POINTER(I)]);createqueue=bind('clCreateCommandQueue',V,[V,V,L,C.POINTER(I)])
  createprogram=bind('clCreateProgramWithSource',V,[V,U,C.POINTER(C.c_char_p),C.POINTER(S),C.POINTER(I)]);buildprogram=bind('clBuildProgram',I,[V,U,C.POINTER(V),C.c_char_p,V,V]);getbuild=bind('clGetProgramBuildInfo',I,[V,V,U,S,V,C.POINTER(S)]);createkernel=bind('clCreateKernel',V,[V,C.c_char_p,C.POINTER(I)])
  createbuffer=bind('clCreateBuffer',V,[V,L,S,V,C.POINTER(I)]);writebuffer=bind('clEnqueueWriteBuffer',I,[V,V,U,S,S,V,U,V,V]);readbuffer=bind('clEnqueueReadBuffer',I,[V,V,U,S,S,V,U,V,V])
  setarg=bind('clSetKernelArg',I,[V,U,S,V]);enqueue=bind('clEnqueueNDRangeKernel',I,[V,V,U,V,C.POINTER(S),V,U,V,C.POINTER(V)]);finish=bind('clFinish',I,[V]);profile=bind('clGetEventProfilingInfo',I,[V,U,S,V,C.POINTER(S)])
  releasebuffer=bind('clReleaseMemObject',I,[V]);releaseevent=bind('clReleaseEvent',I,[V])
  def check(code,where):
   if code!=0:raise RuntimeError(f'{where}: OpenCL error {code}')
  def info(fun,obj,key):
   n=S();check(fun(obj,key,0,None,C.byref(n)),'info size');b=C.create_string_buffer(n.value);check(fun(obj,key,n,b,None),'info');return bytes(b.raw).rstrip(b'\0').decode(errors='replace')
  npf=U();check(getplatform(0,None,C.byref(npf)),'platform count');pfs=(V*npf.value)();check(getplatform(npf,pfs,None),'platforms');selection=None
  inventory=[]
  for p in pfs:
   nd=U();code=getdevices(p,4,0,None,C.byref(nd));entry={'name':info(getpinfo,p,0x902),'vendor':info(getpinfo,p,0x903),'version':info(getpinfo,p,0x901),'gpuDeviceQueryCode':code,'gpuDevices':[]}
   if code==0:
    ds=(V*nd.value)();check(getdevices(p,4,nd,ds,None),'GPU devices')
    for d in ds:
     entry['gpuDevices'].append({'name':info(getdinfo,d,0x102B),'vendor':info(getdinfo,d,0x102C),'version':info(getdinfo,d,0x102F),'driver':info(getdinfo,d,0x102D)})
     if selection is None:selection=(p,d)
   inventory.append(entry)
  result['timingInterpretation']='Driver event timestamps are retained as observations only. Host launch-plus-clFinish wall times and complete-run wall time are separately reported. No throughput, CPU speedup, EVM acceleration, or transaction latency inference is made.';result['openclInventory']=inventory;assert selection is not None,'no public OpenCL GPU device';p,d=selection
  err=I();device=V(d);context=V(createcontext(None,1,C.byref(device),None,None,C.byref(err)));check(err.value,'create context');queue=V(createqueue(context,device,2,C.byref(err)));check(err.value,'create profiling queue')
  src=C.c_char_p(source);length=S(len(source));program=V(createprogram(context,1,C.byref(src),C.byref(length),C.byref(err)));check(err.value,'create program');t=time.monotonic();code=buildprogram(program,1,C.byref(device),b'-cl-std=CL1.2',None,None)
  logs=S();getbuild(program,device,0x1183,0,None,C.byref(logs));log=C.create_string_buffer(logs.value);getbuild(program,device,0x1183,logs,log,None);result['buildLog']=log.value.decode(errors='replace');result['programBuildSeconds']=time.monotonic()-t;check(code,'build program');k=V(createkernel(program,b'pack_quad',C.byref(err)));check(err.value,'create kernel')
  totalwords=0;gputime=0.;typedpath=root/'output/256-input-compression/typed-packing/typed-packing-audit.json';typed=json.loads(typedpath.read_text());assert typed['passed'];result['sourceHashes'][str(typedpath.relative_to(root))]=H(typedpath.read_bytes())
  for leg in ['complex33','solvent33']:
   mp=root/'output/full-hybrid-inputs/legs'/leg/'catalog-candidate.json';m=json.loads(mp.read_text());result['sourceHashes'][str(mp.relative_to(root))]=H(mp.read_bytes())
   for label,width,ints in [('positions',3,0),('A.particles',4,0),('A.bonds',4,2),('A.exceptions',6,3)]:
    t=time.monotonic();desc=m['streams'][label];path=root/'output/full-hybrid-inputs'/desc['path'];comp=path.read_bytes();assert H(comp)==desc['gzipSha256'];raw=gzip.decompress(comp);assert H(raw)==desc['rawSha256'];result['sourceHashes'][str(path.relative_to(root))]=H(comp);words=len(raw)//32;assert words==desc['wordCount'];rows=words//width;rb=4*ints+8*(width-ints);outsize=rows*rb
    # Independent CPU expected encoding by integer bit inversion, followed by exact quad expansion.
    q=np.frombuffer(raw,dtype='>u8').reshape(rows,width,4);assert np.all(q[:,:,:2]==0);expected=np.zeros((rows,rb),dtype='uint8');offset=0
    for j in range(width):
     hi=q[:,j,2].astype('uint64');lo=q[:,j,3].astype('uint64')
     if j<ints:
      assert np.all(hi==0) and np.all(lo<(1<<32));bits=lo;size=4
     else:
      sign=hi>>np.uint64(63);exp=(hi>>np.uint64(48))&np.uint64(32767);zero=((hi&np.uint64((1<<63)-1))==0)&(lo==0);normal=(exp>=15361)&(exp<=17406)&((lo&np.uint64((1<<60)-1))==0);assert np.all(zero|normal)
      bits=(sign<<np.uint64(63))|((exp-np.uint64(15360))<<np.uint64(52))|((hi&np.uint64((1<<48)-1))<<np.uint64(4))|(lo>>np.uint64(60));bits[zero]=sign[zero]<<np.uint64(63);size=8
     expected[:,offset:offset+size]=bits.astype('>u8').view('uint8').reshape(rows,8)[:,8-size:];offset+=size
    expected=expected.tobytes();inputbuf=C.create_string_buffer(raw);gpuout=C.create_string_buffer(outsize);errors=C.create_string_buffer(words);bufs=[]
    for sz,flag in [(len(raw),4),(outsize,2),(words,2)]:
     b=V(createbuffer(context,flag,sz,None,C.byref(err)));check(err.value,'create buffer');bufs.append(b)
    uploadstart=time.monotonic();check(writebuffer(queue,bufs[0],1,0,len(raw),inputbuf,0,None,None),'upload');uploadseconds=time.monotonic()-uploadstart
    for idx,b in enumerate(bufs):check(setarg(k,idx,C.sizeof(V),C.byref(b)),'buffer argument')
    for idx,value in [(3,L(words)),(4,U(width)),(5,U(ints))]:check(setarg(k,idx,C.sizeof(value),C.byref(value)),'scalar argument')
    globalwork=S(words);event=V();kernelstart=time.monotonic();check(enqueue(queue,k,1,None,C.byref(globalwork),None,0,None,C.byref(event)),'enqueue kernel');check(finish(queue),'finish kernel');kernelseconds=time.monotonic()-kernelstart
    startns=L();endns=L();check(profile(event,0x1282,C.sizeof(L),C.byref(startns),None),'profile start');check(profile(event,0x1283,C.sizeof(L),C.byref(endns),None),'profile end');gpu_seconds=(endns.value-startns.value)*1e-9
    downloadstart=time.monotonic();check(readbuffer(queue,bufs[1],1,0,outsize,gpuout,0,None,None),'download packed');check(readbuffer(queue,bufs[2],1,0,words,errors,0,None,None),'download errors');downloadseconds=time.monotonic()-downloadstart
    e=np.frombuffer(errors.raw,dtype='uint8');assert not np.any(e),f'{leg}/{label} GPU rejected {np.unique(e,return_counts=True)}';packed=gpuout.raw;assert packed==expected,'GPU vs CPU bytes mismatch'
    # Expand actual GPU-produced bytes to every full original 32-byte word.
    gpurows=np.frombuffer(packed,dtype='uint8').reshape(rows,rb);rebuilt=np.zeros((rows,width,4),dtype='>u8');offset=0
    for j in range(width):
     size=4 if j<ints else 8;b=np.zeros((rows,8),dtype='uint8');b[:,8-size:]=gpurows[:,offset:offset+size];offset+=size;bits=np.frombuffer(b.tobytes(),dtype='>u8').astype('uint64')
     if j<ints:rebuilt[:,j,3]=bits
     else:
      sign=bits>>np.uint64(63);exp=(bits>>np.uint64(52))&np.uint64(2047);mant=bits&np.uint64((1<<52)-1);assert np.all((exp>0)|(mant==0));hi=(sign<<np.uint64(63))|((exp+np.uint64(15360))<<np.uint64(48))|(mant>>np.uint64(4));lo=(mant&np.uint64(15))<<np.uint64(60);zero=(exp==0);hi[zero]=sign[zero]<<np.uint64(63);lo[zero]=0;rebuilt[:,j,2]=hi;rebuilt[:,j,3]=lo
    reconstructed=rebuilt.tobytes();assert reconstructed==raw;pad=packed+b'\0'*((-len(packed))%32);prior=typed['streams'][f'{leg}/{label}']['layouts']['dense_f64_u32'];assert H(pad)==prior['packedSha256']
    target=out/f'{leg}.{label}.dense-f64-u32.bin';target.write_bytes(packed)
    row={'leg':leg,'stream':label,'sourcePath':str(path.relative_to(root)),'sourceGzipSha256':H(comp),'sourceRawSha256':H(raw),'logicalWords':words,'roleWidth':width,'integerFields':ints,'sourceBytes':len(raw),'packedBytes':outsize,'packedSha256':H(packed),'paddedPackedSha256':H(pad),'cpuExpectedBytesEqual':True,'cpuExpandedFullSourceBytesEqual':True,'cpuExpandedSourceSha256':H(reconstructed),'previousTypedAuditPackedHashEqual':True,'gpuErrorWords':int(np.count_nonzero(e)),'gpuEventStartRaw':startns.value,'gpuEventEndRaw':endns.value,'gpuEventSeconds':gpu_seconds,'kernelWaitWallSeconds':kernelseconds,'uploadWallSeconds':uploadseconds,'downloadWallSeconds':downloadseconds,'streamWholeWallSeconds':time.monotonic()-t,'packedOutput':target.name}
    result['streams'].append(row);totalwords+=words;gputime+=gpu_seconds;save();print(f'{leg}/{label} PASS {words} words GPU {gpu_seconds:.6f}s',flush=True)
    for b in bufs:check(releasebuffer(b),'release buffer')
    check(releaseevent(event),'release event')
  for rel,h in result['sourceHashes'].items():assert H((root/rel).read_bytes())==h,'source changed '+rel
  result.update(status='passed_actual_apple_gpu_exact_bitpacking_not_evm_or_scientific_validation',passed=True,totalLogicalWordsVerified=totalwords,totalGpuEventSeconds=gputime,totalWallSeconds=time.monotonic()-started,sourceHashesVerifiedAfterRun=True)
 except BaseException as exc:
  result.update(status='failed_preserved_actual_attempt',errorType=type(exc).__name__,error=str(exc),totalWallSeconds=time.monotonic()-started);save();raise
 save();print(json.dumps({'passed':result['passed'],'words':result['totalLogicalWordsVerified'],'gpuSeconds':gputime,'wallSeconds':result['totalWallSeconds']},indent=2))
if __name__=='__main__':main()
