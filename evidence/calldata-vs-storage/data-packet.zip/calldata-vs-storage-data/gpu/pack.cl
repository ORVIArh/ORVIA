// Exact integer bit transport only; no floating-point arithmetic or molecular computation.
ulong be64(__global const uchar *p) {
    ulong x=0; for (uint k=0;k<8;k++) x=(x<<8)|(ulong)p[k]; return x;
}
__kernel void pack_quad(__global const uchar *src, __global uchar *dst,
                        __global uchar *errors, ulong words,
                        uint width, uint int_fields) {
    ulong i=get_global_id(0); if(i>=words) return;
    __global const uchar *p=src+32*i;
    uint field=(uint)(i%width); ulong row=i/width;
    uint record_bytes=4*int_fields+8*(width-int_fields);
    uint bytes=field<int_fields?4:8;
    ulong offset=row*record_bytes+(field<int_fields?4*field:4*int_fields+8*(field-int_fields));
    ulong hi=be64(p+16), lo=be64(p+24), result=0;
    uchar error=0;
    if(be64(p)!=0 || be64(p+8)!=0) error=1;
    if(field<int_fields) {
        if(hi!=0 || lo>0xffffffffUL) error=2;
        result=lo;
    } else {
        ulong sign=hi>>63, exponent=(hi>>48)&32767UL;
        if((hi&0x7fffffffffffffffUL)==0 && lo==0) result=sign<<63;
        else if(exponent>=15361UL && exponent<=17406UL && (lo&0x0fffffffffffffffUL)==0) {
            result=(sign<<63)|((exponent-15360UL)<<52)|((hi&0xffffffffffffUL)<<4)|(lo>>60);
        } else error=3;
    }
    for(uint k=0;k<bytes;k++) dst[offset+k]=(uchar)(result>>(8*(bytes-1-k)));
    errors[i]=error;
}
