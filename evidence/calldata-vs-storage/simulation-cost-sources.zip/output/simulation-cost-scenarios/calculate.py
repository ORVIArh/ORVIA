"""Full-schedule accounting with explicitly partial, locally calibrated costs.

This is not a complete simulation quote. Keep unmeasured components null.
"""
from decimal import Decimal, getcontext
from fractions import Fraction
from pathlib import Path
import hashlib
import json

getcontext().prec = 40
here = Path(__file__).resolve().parent
aura = here.parent.parent
repo = aura / 'ORVIA'
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
decimal = lambda f: str(Decimal(f.numerator) / Decimal(f.denominator))
price = read(here / 'pricing.json')
review = read(here / 'work-count-review.json')
catalogs = {leg: read(aura / f'output/full-hybrid-inputs/legs/{leg}/catalog-candidate.json')
            for leg in ['complex33', 'solvent33']}
qsum = sum(c['counts']['constraints'] for c in catalogs.values())
nsum = sum(c['counts']['hybrid'] for c in catalogs.values())
assert qsum == 271698 and nsum == 284442
gp = Fraction(review['solverMeasuredUnitAverages']['position']['gasPerRecordFraction'])
gv = Fraction(review['solverMeasuredUnitAverages']['velocity']['gasPerRecordFraction'])
wei_per_gas = int(price['gasPriceWei'])
eth_per_gas = Fraction(wei_per_gas, 10**18)
k, r, samples = 16, 3, 100
scenarios = []
for name, steps in [('short', 1000), ('medium', 100000), ('long', 1000000)]:
    sensitivity = []
    for label, pos_sweeps, vel_sweeps in [
        ('one_sweep_assumption', 1, 1),
        ('repeat_observed_small_fixture_sweep_counts', 26, 29),
        ('thirty_two_sweep_assumption', 32, 32),
    ]:
        pos_records = k*r*2*qsum*(2*steps)*pos_sweeps
        vel_records = k*r*2*qsum*(1+5*steps)*vel_sweeps
        gas = pos_records*gp + vel_records*gv
        sensitivity.append({
            'label': label, 'positionSweepsPerProjection': pos_sweeps,
            'velocitySweepsPerProjection': vel_sweeps,
            'positionRecords': pos_records, 'velocityRecords': vel_records,
            'constraintOnlyGasFraction': str(gas),
            'constraintOnlyGas': decimal(gas), 'constraintOnlyEth': decimal(gas*eth_per_gas),
            'isLowerOrUpperBound': False,
        })
    scenarios.append({
        'name': name, 'stepsPerWindowIncludingEquilibration': steps,
        'equilibrationStepsPerWindow': steps//2,
        'productionSampleStride': steps//(2*samples),
        'statesPerLeg': k, 'repeatPairs': r, 'legs': 2, 'windows': k*r*2,
        'rawSamplesPerWindow': samples,
        'rawSamplesPerCampaign': k*samples, 'campaigns': r*2,
        'illustrativeTimestepFs': 2,
        'timePerWindowNs': decimal(Fraction(steps*2, 10**6)),
        'aggregateWindowTimeNs': decimal(Fraction(steps*2*k*r*2, 10**6)),
        'hamiltonianEvaluations': k*r*2*(steps+1+samples*(k-1)),
        'integrationStepsAcrossAllWindows': k*r*2*steps,
        'constraintProjectionCalls': k*r*2*(1+7*steps),
        'nonHamiltonianPipelineWorkExcludingSolver':
            k*r*(3*nsum+steps*(12*nsum+2)+2*samples*(k+2)),
        'constraintCostSensitivity': sensitivity,
        'completeSimulationGas': None, 'completeSimulationEth': None,
    })

source_paths = [Path(__file__), here/'work-count-review.json', here/'pricing.json',
                repo/'reports/full_model_constraints_validation.json',
                repo/'contracts/core/FullModelConstraintSolver.sol',
                repo/'contracts/core/MolecularSimulationPipeline.sol'] + [
                aura/f'output/full-hybrid-inputs/legs/{leg}/catalog-candidate.json' for leg in catalogs]
result = {
    'status': 'FULL_CAMPAIGN_UNQUOTED_CONSTRAINT_COST_SENSITIVITY_ONLY',
    'scope': 'Three full-schedule scenarios; only the constraint solver has a monetary extrapolation here.',
    'pricing': price,
    'models': {leg: c['counts'] for leg, c in catalogs.items()},
    'modelAcceptance': 'Available ADP/phosphate candidate, not accepted original vanadate protocol; no model substitution approved.',
    'measuredCalibration': review['solverMeasuredUnitAverages'],
    'formula': 'K*R*2*(Q_complex+Q_solvent)*(2*T*Ipos*Gp+(1+5*T)*Ivel*Gv)',
    'scenarios': scenarios,
    'unpriced': [
        'Complete full-scale force and energy evaluations, including reciprocal electrostatics and C4',
        'Pipeline initialization, atom updates, state imports, snapshots and continuation',
        'Full model/topology/constraint registration and validation',
        'Chronology, sample collection/selection, MBAR iterations, diagnostics and repeat uncertainty',
        'Production decoder integration, repeated input delivery, and target L1 data-posting fees',
        'Any additional minimization, equilibration, repeats or extensions required for scientific acceptance',
    ],
    'limitations': [
        'These are scaling sensitivities, not live target-chain estimates, funding requirements, confidence intervals, or bounds.',
        'Constraint gas uses current-source three-atom local fixtures; gas per record and sweeps can differ greatly at full scale.',
        'Position fixture used work=1, velocity used work=8; no unmeasured batching or calldata savings are applied.',
        'One sweep is an optimistic scenario, not evidence of convergence. Repeating 26/29 fixture sweeps does not validate large-model convergence.',
        'The 2fs timestep, 16 states, lengths and 100 samples are engineering illustrations, not an approved or sufficient scientific schedule.',
        'One constant current gas price is applied across the entire hypothetical campaign; no duration or future fee forecast is implied.',
        'The earlier approximately 0.15ETH infrastructure plus input-pass subtotal is not a simulation price and is not relabelled as one.',
    ],
    'sourceHashes': {str(p.relative_to(aura)): sha(p) for p in source_paths},
    'completeCampaignPriceKnown': False, 'scientificAcceptance': False,
    'mainnetReady': False, 'publicTransactionsSent': 0,
}
(here/'scenarios.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps([{
    'name': s['name'], 'H_evaluations': s['hamiltonianEvaluations'],
    'constraint_only_ETH': {c['label']: c['constraintOnlyEth'] for c in s['constraintCostSensitivity']},
    'full_campaign_ETH': None,
} for s in scenarios], indent=2))
