# Bounded transaction bundling benchmark

This isolated experiment embeds a fixed-target batch method in the preceding range-proof microbenchmark. It permits one to four child ranges of at most 16 leaves each, calls only `this.consumeRange`, and forwards no value. It has no arbitrary target, delegatecall or owner-operation dispatch. This is not a production integration or proposal to add another deployed address.

The four actual ranges cover chunks 0–15, 16–31, 32–47 and 48–63 of the same frozen packed nonbonded stream. Every child preserves the exact original leaf/root, binary128-bit decoding and per-value digest operation. External self-calls give each child its own memory frame. Returned digests and emitted events match the four separately evaluated ranges exactly.

## Results

All six read-only target estimates used the same runtime, registered root, actual input bytes and pinned Robinhood mainnet block `0x63769ad` (`0xe454bce15614c974b891257b55ff6076f487a38fd51de571e81b66d246443cc5`). The runtime and exact hypothetical preceding state were supplied as overrides. No transaction was signed or sent to a public network; no wallet or private key was used.

| Process the same first 64 KiB | Transactions | Local receipt gas | Target estimate gas |
|---|---:|---:|---:|
| Four separate 16 KiB ranges | 4 | 10,393,288 | 10,834,995 |
| One 64 KiB range | 1 | 12,134,703 | 12,349,477 |
| **One bundle of four 16 KiB self-calls** | **1** | **10,331,640** | **10,549,574** |

Bundling reduces the target estimate by **285,421 gas (2.63%)** versus four transactions and by **1,799,903 gas (14.57%)** versus one large range. The local execution saving versus four transactions is smaller: **61,648 gas (0.59%)**. Target estimates include the chain's fee accounting; this experiment did not separately attribute the remaining difference. These are measured data-access/digest cases, not full molecular-engine or campaign savings.

Four separate child digests and the bundled four returned digests are identical. The single 64 KiB call has one differently seeded digest because its range is different; it still reads and decodes the same scalar values in order. The larger call retains the earlier allocation-heavy digest loop and consequently does not demonstrate that larger frames are always cheaper.

## Bounds and atomicity

The batch rejects zero children, more than four children, mismatched array lengths and any child over 16 leaves. The inherited range verifier checks alignment, actual-leaf bounds, exact length, proof height, root and field range. A child's revert propagates through the whole transaction.

The main run passes 13 checks and records six target estimates. The focused `fourth-child-rollback.json` verifies that the first three valid child ranges return their expected digests, then executes a local transaction with a corrupted **fourth** proof. The receipt has status 0, no surviving logs and unchanged application storage. The earlier main-run corrupted-second-child test is also retained.

The implementation compiles with solc 0.8.26, optimizer 200, Shanghai, without relaxed contract-size limits; runtime is 10,798 bytes. The imported baseline and aligned-range sources are exact frozen copies. Root's independent review checked all six quote request/response hashes, hypothetical state and binary128 digests.

## Files and replay

- `report.json`: exact rows, calldata byte counts, source/runtime hashes, prestates, six quote hashes and comparison totals.
- `fourth-child-rollback.json`: local atomic rollback regression.
- `BundledRangeReadBenchmark.sol`, imported sources, `compiler-input.json`, `artifact.json`: exact compiled code.
- `overrides/*.json.gz`: quoted hypothetical states.
- `benchmark.mjs`: executed local/target comparison; remote access is read-only through the allowlisted helper.
- `fourth-child-rollback.mjs`: offline local regression using the saved state and input data.

The archive preserves the AURA/output sibling layout and includes the needed frozen range-data JSON, earlier range report and read-only provider helper. It uses pinned dependencies under AURA/ORVIA. The main benchmark reads the authorized private endpoint configuration outside the archive; no credential is included. The rollback regression can run locally with no network.

Actual production batching still needs integration with authenticated simulator work limits and state transitions. Whole-model codecs, input availability/resupply, accepted physics and full campaign runtime remain unresolved. Scientific acceptance and production readiness remain false.
