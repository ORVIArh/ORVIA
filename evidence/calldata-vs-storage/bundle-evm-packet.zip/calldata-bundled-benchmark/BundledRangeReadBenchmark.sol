// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;
import {AlignedRangeReadBenchmark} from "./AlignedRangeReadBenchmark.sol";

/// @notice Isolated fixed-target batching experiment; no production deployment proposal.
contract BundledRangeReadBenchmark is AlignedRangeReadBenchmark {
    constructor(address who) AlignedRangeReadBenchmark(who) {}
    function consumeRanges(Query[] calldata queries,bytes[] calldata bundles,bytes32[][] calldata proofs)
        external returns(bytes32[] memory digests)
    {
        uint256 count=queries.length;
        if(count==0||count>4||bundles.length!=count||proofs.length!=count)revert Invalid();
        digests=new bytes32[](count);
        for(uint256 i;i<count;++i){
            if(queries[i].count>16)revert Invalid();
            // A new memory frame per bounded child; failure rolls back every Result event.
            digests[i]=this.consumeRange(queries[i],bundles[i],proofs[i]);
        }
    }
}
