from pathlib import Path
import gzip,json,hashlib,copy
BASE=Path(__file__).resolve().parent
report=json.loads((BASE/'deployment-gas.json').read_text())
previous={};steps=[]
def digest(s):return hashlib.sha256(s.encode()).hexdigest()
for row in report['rows']:
    text=gzip.decompress((BASE/row['overrideFile']).read_bytes()).decode();current=json.loads(text)
    assert digest(text)==row['overrideSha256']
    patches={};orders={}
    for address,value in current.items():
        old=previous.get(address)
        if old is None:patches[address]={'replace':value};continue
        patch={key:new for key,new in value.items()if key!='state' and old.get(key)!=new}
        if 'state' in value:
            before=old.get('state',{});after=value['state'];updates={k:v for k,v in after.items()if before.get(k)!=v};removed=[k for k in before if k not in after]
            if updates:patch['stateUpdates']=updates
            if removed:patch['stateRemoved']=removed
            if list(before)!=list(after):orders[address]=list(after)
        if patch:patches[address]=patch
    steps.append({'index':row['index'],'overrideSha256':row['overrideSha256'],'accountOrder':list(current),'patches':patches,'storageOrders':orders})
    previous=current
payload={'schemaVersion':1,'encoding':'ordered-account-storage-deltas-v1','steps':steps}
encoded=json.dumps(payload,separators=(',',':')).encode();(BASE/'ordered-state-deltas.json.gz').write_bytes(gzip.compress(encoded))
# Independently replay every patch and reproduce the original request bytes.
state={}
for step in steps:
    for address,patch in step['patches'].items():
        if 'replace' in patch:state[address]=copy.deepcopy(patch['replace']);continue
        for k,v in patch.items():
            if k not in ('stateUpdates','stateRemoved'):state[address][k]=v
        for k in patch.get('stateRemoved',[]):state[address]['state'].pop(k)
        if 'stateUpdates' in patch:state[address].setdefault('state',{}).update(patch['stateUpdates'])
    for address,order in step['storageOrders'].items():state[address]['state']={k:state[address]['state'][k]for k in order}
    ordered={a:state[a]for a in step['accountOrder']};text=json.dumps(ordered,separators=(',',':'));assert digest(text)==step['overrideSha256'],step['index']
print(json.dumps({'passed':True,'exactlyReconstructedOverrides':len(steps),'compressedBytes':(BASE/'ordered-state-deltas.json.gz').stat().st_size,'payloadSha256':hashlib.sha256(encoded).hexdigest()}))
