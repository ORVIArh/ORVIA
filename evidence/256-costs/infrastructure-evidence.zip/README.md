# Complete 256-contract infrastructure estimate

All **91 unsigned infrastructure transactions** were estimated through Robinhood mainnet chain 4663:32 core creations,56 four-bank provisioning calls creating 224 banks, and 3 pipeline/constraint/spatial bindings. No public transaction was signed or submitted.

| Stage | Transactions | Target estimated gas | Local receipt gas |
| --- | ---: | ---: | ---: |
| Core creation | 32 | 73,919,093 | 73,299,992 |
| Bank provisioning | 56 | 111,642,065 | 110,698,124 |
| Bindings | 3 | 616,281 | 609,022 |
| **Total** | **91** | **186,177,439** | **184,607,138** |

At the recorded **20,038,000 wei/gas**, the target gas estimate totals **0.003730623522682 ETH**. A later 20,016,000 wei/gas observation prices the same estimate at 0.003726527619024 ETH. These are dated estimates, not fixed future fees. Conversion to another currency is not part of this packet.

[Robinhood's fee documentation](https://docs.robinhood.com/chain/gas-and-fees/) states that standard `eth_estimateGas` includes L2 execution and L1 data posting. Every target value here is an actual provider `eth_estimateGas` response for the exact transaction. The full total is not extrapolated from one deployment or from local receipts.

## Conditional state and scope

The 91 transactions have not been executed on mainnet. For each transaction, an isolated local chain 4663 first executes the exact public-sender plan. Its state *before that transaction* is exported: runtime code, complete storage and account nonce for all previously created contracts. Every exported storage value is cross-checked with the corresponding prior-block storage read. That precise state is supplied through temporary mainnet RPC state overrides, at block `0x636795a`, hash`0x8d037a2f2dcfeceb4cfe2bbba6baf3a98133a6052d3497dee752976d14cd04e5`.

The provider capability check verifies code, storage and sender-nonce overrides and a negative storage-dependent failure. Every created runtime matches the plan; all 256 addresses were empty in the pinned actual mainnet state. Sender overrides change only the nonce. Each independent estimate sees the observed mainnet sender balance; hypothetical prior fees are not deducted. The aggregate estimate is separately checked against that balance. The final pinned block and actual pending nonce are rechecked.

These are **target execution estimates under conditional future states**, not already-deployed production state or an accepted scientific campaign. Protocol registration is unresolved and excluded. Molecular uploads, topology and constraint registration, minimization, equilibration, production dynamics, cross-state calculations and analysis are also excluded.

## Reading and reproducing the evidence

`deployment-gas.json` records all 91 target estimates, local receipt gas, exact calldata and override hashes, the source-bound plan and RPC request/response hashes. `gas-validation.json` verifies the total and reconstructs every target request, all prior contract nonces/runtimes and 17,765 stored state entries. The separate engineering review found no material prestate or primary-total error.

`ordered-state-deltas.json.gz` is a compact, lossless representation of the 91 full override objects. `reconstruct-overrides.py` replays every delta to the original SHA256 without any network requests. Run `python reconstruct-overrides.py /tmp/new-overrides` from this folder; the output folder must not exist. The original compression/checking source is also retained under `sources/`. Account and storage-key order are retained because RPC request hashes bind serialized JSON. `state-after-91.json.gz` supplies the complete final infrastructure state for subsequent conditional input-upload estimates. `final-state-files.json` distinguishes its decompressed payload hash from the plain JSON-file hash, which additionally includes a newline.

Exact executed sources are retained under `sources/`. They were run from an external `AURA/output/256-deployment-gas/`folder beside the canonical`AURA/ORVIA/`checkout. The RPC helper reads the user-authorized URL only from a protected 0600 local file and records only the provider hostname. No credential, wallet password or private key is included in this packet.

**NodeInterface values are not used as a fee decomposition.** Only 62 of 91 calls returned component words, and several resemble intrinsic-only gas rather than the staged execution. They appear not to honor the nested override context. Those raw diagnostic values remain visible for traceability, but no complete L1/execution split is claimed. The authoritative total uses only the 91 standard RPC estimates.

The original failed poststate-export attempt encountered unavailable storage-key preimages after importing a state. The final export instead combines the fully enumerated pre-last-binding key set with all four actual SSTORE keys from the final binding trace, then verifies the final getters and factory nonces. No estimated transaction or network quote was substituted because of that local export issue.

Scientific acceptance, full current-source validation, full-model cost and production readiness remain separate gates.
