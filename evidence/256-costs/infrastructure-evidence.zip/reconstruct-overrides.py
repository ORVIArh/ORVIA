"""Offline restoration of the exact91quoted prestate override JSON objects."""
from pathlib import Path
import argparse,copy,gzip,hashlib,json
parser=argparse.ArgumentParser();parser.add_argument('output',type=Path);args=parser.parse_args()
base=Path(__file__).resolve().parent;data=json.loads(gzip.decompress((base/'ordered-state-deltas.json.gz').read_bytes()))
assert data['schemaVersion']==1 and data['encoding']=='ordered-account-storage-deltas-v1'
assert len(data['steps'])==91
args.output.mkdir(parents=True,exist_ok=False);state={}
for index,step in enumerate(data['steps']):
    assert step['index']==index
    for address,patch in step['patches'].items():
        if 'replace' in patch:state[address]=copy.deepcopy(patch['replace']);continue
        for key,value in patch.items():
            if key not in ('stateUpdates','stateRemoved'):state[address][key]=value
        for key in patch.get('stateRemoved',[]):state[address]['state'].pop(key)
        if 'stateUpdates' in patch:state[address].setdefault('state',{}).update(patch['stateUpdates'])
    for address,order in step['storageOrders'].items():state[address]['state']={key:state[address]['state'][key]for key in order}
    ordered={address:state[address]for address in step['accountOrder']};raw=json.dumps(ordered,separators=(',',':')).encode()
    assert hashlib.sha256(raw).hexdigest()==step['overrideSha256'],index
    (args.output/f'{index:03}.json').write_bytes(raw)
print(json.dumps({'passed':True,'exactlyReconstructedOverrides':91,'networkRequests':0}))
