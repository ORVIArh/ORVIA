# Bounded input-upload gas calibration

This is a **conditional mainnet estimate and local cost model**, not an executed upload, accepted scientific dataset, full campaign quote or spending authorization. No public transaction was sent and no wallet was opened.

The 30 `eth_estimateGas` measurements used Robinhood mainnet (4663), Alchemy, pinned block `0x6368f77` / `0x38184970cd898673b24780de321e157a98f9a80e39f706716b1661fa6265eefe`, and the exact hypothetical state after the separately measured 91 infrastructure transactions. Each upload was replayed locally, with its exact prestate supplied to the target estimator. The target estimates include the chain's fee-gas calculation; they are not amounts spent. A hypothetical future state is not a deployment.

The source inventory contains 24 distinct existing candidate streams, 10,903,836 ABI words (7,771,840 nonzero, 3,131,996 zero), 85,195 append transactions and 48 begin/seal transactions. Unresolved C4/activity/stage/constraint additions, protocol/topology/campaign registration and simulation are excluded.

## Measured examples

| Append contents | Words/nonzero | Local receipt gas | Target estimate gas |
|---|---:|---:|---:|
| All zero | 128/0 | 454,947 | 459,769 |
| Integer one | 128/128 | 3,003,683 | 3,028,734 |
| Actual particle excerpt | 128/32 | 1,095,107 | 1,105,024 |
| Actual position excerpt | 128/128 | 3,015,731 | 3,041,064 |
| Actual partial excerpt | 31/10 | 344,047 | 347,994 |
| Actual partial excerpt | 71/59 | 1,449,583 | 1,462,343 |
| Actual partial excerpt | 79/20 | 698,425 | 705,191 |
| Actual partial excerpt | 112/112 | 2,644,509 | 2,666,868 |

Each first/later pair had identical local and target cost. The measured zero batch at the end of bank 0 and at the beginning of bank 1 had equal local cost (454,947), with target estimates of 459,771 each. No boundary surcharge appeared. The bank routing restarts within the same fixed 96 banks; no new contracts are created by upload.

The EVM trace measured exactly 22,100 gas per new nonzero word and 2,200 per new zero word: a cold storage access plus zero-to-nonzero or zero-to-zero SSTORE. Appended indices are never reused. These numbers assume the current code, no access list and the measured Shanghai gas schedule. The catalog's metadata fields are packed; the first append does not newly initialize a separate counter slot.

## Model

| Component | Gas |
|---|---:|
| Word storage alone | 178,648,055,200 |
| Source payload calldata | 1,911,165,492 |
| Transaction base gas | 1,790,103,000 |
| Append loop, memory and authentication residual | 11,509,464,004 |
| Exact append ABI headers | 72,684,952 |
| Begin/seal execution residual | 2,643,912 |
| Begin/seal calldata (role-byte range) | 34,800–43,728 |
| **Local Shanghai model** | **193,934,151,360–193,934,160,288** |

Every actual final partial-batch length was measured locally. The 128-word residual is 135,107 gas after word SSTORE and calldata/base intrinsic gas; its value is independent of the tested word values. Shorter lengths have separately measured memory/loop costs, not a fitted straight line. Stream roles are absent from the input-count manifest, so begin-call role bytes are honestly ranged from one to 32 nonzero bytes. Rolling digest updates are assumed to remain distinct/nonzero as in the observations; the entire source digest chain was not executed here.

Applying the observed append-specific target/local ratio and conservative observed setup ratios produces a **195,551,588,254–196,159,036,309 gas empirical target-budget scenario**. This is not an upper/lower guarantee and not 85,195 individually quoted uploads. The broader all-stage-ratio envelope is retained in the JSON. Prices change; ETH/USD conversion and the separately measured 91-infrastructure gas should be added externally with a dated fee observation.

The dedicated NodeInterface `gasEstimateL1Component` readings estimate calldata posting only. They do not validate nested execution or decompose the difference between Ganache receipts and target estimates. The unreliable earlier full NodeInterface decomposition is not used here.

## Integrity and replay

`calibration.json` retains all measurements and target request hashes. `overrides/*.json.gz` are exact pre-call state overrides. `validate-and-model.mjs` reconstructs all 30 target request hashes, links the reused first quote to the **retained first-attempt transcript** (not the new transcript's coincident ID), checks each target gas response hash, the source/input/override hashes and word costs, and generates `validation-and-model.json` (188 checks).

The first failed local tracing attempts are retained. One quote from the first attempt was reused at the identical block, calldata and override, so the total is **30 target estimates: one first-attempt quote plus 29 new quotes**. Failures concerned comparing intermediate storage writes and Ganache's abbreviated zero-storage return; no failed attempt is counted as a completed calibration. `local-residuals.mjs` makes no network request.

Replay these scripts from their current AURA workspace layout with the sibling `256-deployment-gas` and `256-full-gas` evidence directories and the pinned ORVIA dependencies. The provider helper reads its authorized private endpoint outside the repository; neither URL credentials nor private keys are included in this packet. Verification of the saved model itself is offline:

```
node output/256-upload-calibration/validate-and-model.mjs
```

Scientific acceptance, full production validation, and readiness to broadcast remain false.
