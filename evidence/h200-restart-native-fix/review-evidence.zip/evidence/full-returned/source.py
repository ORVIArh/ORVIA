#!/usr/bin/env python3
"""Explicit candidate-engine validation; frozen inputs and numerical gates unchanged."""
import argparse
import datetime as dt
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import sysconfig
import threading
import time

sys.dont_write_bytecode=True
ORIGINAL_SOURCE='5b781a291219256f8450c6d016011b85a430f8bdc184a54256dba6b28276325b'
UPSTREAM='b399af4725573963b46d6c1083fdcf7a37615857'

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def require(ok,msg):
    if not ok:raise ValueError(msg)

def write(p,value):
    p=Path(p);tmp=p.with_suffix(p.suffix+'.tmp')
    tmp.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');tmp.replace(p)

def utc():return dt.datetime.now(dt.timezone.utc).isoformat()

def config(mode):
    full=mode=='full'
    return {'mode':mode,'experiment':'ORVIA-ADP-PHOSPHATE-v0.3','replicasPerModel':2 if full else 1,
            'baselineSteps':80000 if full else 21000,'checkpointStep':60000 if full else 1000,
            'replaySteps':20000,'totalIntegrationSteps':400000 if full else 82000,
            'timeStepPs':0.0001,'integrator':'Verlet','initialVelocities':'zero','precision':'double',
            'deterministicForces':True,'constraintTolerance':1e-8,'forceMarginKJMolNm':2**26,
            'forceObservationIntervalSteps':100,
            'forceTolerances':{'energy_absolute_kJ_mol':0.01,'force_max_absolute_kJ_mol_nm':0.05,'force_relative_L2':5e-5},
            'restartTolerances':{'positions_max_abs_nm':1e-9,'velocities_max_abs_nm_ps':1e-8},
            'maximumWallSeconds':1200,'diagnosticOnly':True,'scientificAcceptance':False}

def inputs(a):
    path=a.original_packet/'stress_parallel.py'
    require(sha(path)==ORIGINAL_SOURCE,'Frozen original source changed')
    spec=importlib.util.spec_from_file_location('frozen_inputs',path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    w,manifest=m.load_v4(a.bundle);m.verify_packet(w,a.original_packet)
    require(w.TOLERANCES==config(a.mode)['forceTolerances'] and w.RESTART_TOLERANCES==config(a.mode)['restartTolerances'],'Numerical gates changed')
    return w,manifest

def engine(a):
    report=json.loads(a.candidate_report.read_text());root=a.candidate_report.parent.resolve()
    require(report.get('schema')=='orvia.isolated-restart-candidate-build.v1' and report.get('buildPassed') is True,'Candidate build incomplete')
    require(report.get('sourceCommit')==UPSTREAM and report.get('originalNativeFilesUnchanged') is True,'Candidate source/runtime binding changed')
    require(report.get('scientificAcceptance') is False,'Invalid candidate acceptance claim')
    prefix=Path(report['libraryPrefix']).resolve();require(prefix==root/'prefix','Unexpected candidate prefix')
    require(Path(report['pluginDirectory']).resolve()==prefix/'lib/plugins','Unexpected plugin path')
    for rel,rec in report['artifacts'].items():
        p=root/rel;require(p.resolve().is_relative_to(prefix) and p.is_file() and p.stat().st_size==rec['bytes'] and sha(p)==rec['sha256'],'Candidate native library changed')
    for name,key in [('precision-patch.json','precisionPatchSha256'),('restart-patch.json','restartPatchSha256')]:
        require(sha(root/name)==report[key],'Candidate patch record changed')
    precision=json.loads((root/'precision-patch.json').read_text())
    restart=json.loads((root/'restart-patch.json').read_text())
    require(subprocess.check_output(['git','-C',str(root/'source'),'rev-parse','HEAD'],text=True).strip()==UPSTREAM,'Candidate checkout commit changed')
    expected=set()
    for rel,record in precision['files'].items():
        require(sha(root/'source'/rel)==record['patchedSha256'],'Precision source changed');expected.add(rel)
    for rel,record in restart['files'].items():
        require(sha(root/'source'/rel)==record['afterSha256'],'Restart source changed');expected.add(rel)
    changed=set(subprocess.check_output(['git','-C',str(root/'source'),'diff','--name-only'],text=True).splitlines())
    require(changed==expected,'Unexpected candidate source edits')
    env={k:v for k,v in os.environ.items() if k not in ('ORVIA_WORKER_TOKEN','RUNPOD_API_KEY','NETLIFY_AUTH_TOKEN','PYTHONPATH','PYTHONOPTIMIZE') and not k.startswith('ORVIA_WALLET')}
    env.update(LD_LIBRARY_PATH=str(prefix/'lib'),OPENMM_PLUGIN_DIR=str(prefix/'lib/plugins'),PYTHONDONTWRITEBYTECODE='1',PYTHONUNBUFFERED='1',OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4')
    return report,env

def worker(a):
    require(sha(a.plan)==a.plan_sha,'Validation plan changed')
    plan=json.loads(a.plan.read_text());require(plan['validatorSha256']==sha(__file__),'Validator source changed')
    require(plan['candidateBuildSha256']==sha(a.candidate_report) and plan['configuration']==config(a.mode),'Candidate/plan binding changed')
    w,manifest=inputs(a);eng,env=engine(a)
    import numpy as np
    import openmm as mm
    from openmm import unit
    require(Path(sys.prefix).resolve()==Path(eng['python']).parent.parent.resolve(),'Wrong Python environment')
    require(mm.version.full_version=='8.6.1.dev-b399af4' and np.__version__=='2.5.4','Wrong dependency versions')
    for rel,record in json.loads((a.bundle/'engine-export-manifest.json').read_text())['files'].items():
        if rel.startswith('python-site/'):
            p=Path(sysconfig.get_paths()['purelib'])/rel[len('python-site/'):]
            require(p.is_file() and p.stat().st_size==record['bytes'] and sha(p)==record['sha256'],'Frozen Python wrapper changed')
    prefix=Path(eng['libraryPrefix']).resolve()
    loaded=sorted({line.split()[-1] for line in Path('/proc/self/maps').read_text().splitlines() if 'libOpenMM' in line})
    require(loaded and all(Path(p).resolve().is_relative_to(prefix) for p in loaded),'Native libraries loaded outside candidate prefix')
    a.output.mkdir(parents=True,exist_ok=False)
    cfg=config(a.mode)
    report={'schema':'orvia.candidate-validation-phase.v1','model':a.model,'replica':a.replica,'phase':a.phase,
            'mode':a.mode,'startedAt':utc(),'passed':False,'scientificAcceptance':False,'diagnosticOnly':True,
            'configuration':cfg,'validatorSha256':sha(__file__),'planSha256':a.plan_sha,
            'candidateBuildSha256':sha(a.candidate_report),'inputManifestSha256':sha(a.bundle/'manifest.json'),
            'loadedNativeLibraries':loaded,'integrationStepsExecuted':0,'forceMarginObservations':[],'contexts':{}}
    contexts=[]
    def progress(stage):write(a.output/'progress.json',{'stage':stage,'steps':report['integrationStepsExecuted'],'updatedAt':utc()})
    def observe(ctx):
        state=ctx.getState(getPositions=True,getVelocities=True,getForces=True,getEnergy=True)
        obs={'positions':np.asarray(state.getPositions(asNumpy=True).value_in_unit(unit.nanometer)),
             'velocities':np.asarray(state.getVelocities(asNumpy=True).value_in_unit(unit.nanometer/unit.picosecond)),
             'forces':np.asarray(state.getForces(asNumpy=True).value_in_unit(unit.kilojoule_per_mole/unit.nanometer)),
             'energy':float(state.getPotentialEnergy().value_in_unit(unit.kilojoule_per_mole)),
             'kineticEnergy':float(state.getKineticEnergy().value_in_unit(unit.kilojoule_per_mole)),
             'box':np.asarray(state.getPeriodicBoxVectors(asNumpy=True).value_in_unit(unit.nanometer)),
             'time':float(state.getTime().value_in_unit(unit.picosecond))}
        require(all(np.isfinite(v).all() for v in obs.values()),'Nonfinite numerical state')
        maximum=float(np.max(np.abs(obs['forces'])));require(maximum<2**26,'Force accumulation margin failed')
        report['forceMarginObservations'].append({'platform':ctx.getPlatform().getName(),'timePs':obs['time'],'maxAbsoluteForceKJMolNm':maximum,'passed':True})
        return obs
    def compare(ref,cur):
        delta=cur['forces']-ref['forces']
        row={'energy_absolute_kJ_mol':abs(float(cur['energy'])-float(ref['energy'])),
             'force_max_absolute_kJ_mol_nm':float(np.max(np.abs(delta))),
             'force_relative_L2':float(np.linalg.norm(delta))/max(float(np.linalg.norm(ref['forces'])),1e-12)}
        require(all(math.isfinite(v) for v in row.values()),'Invalid comparison')
        row['passed']=all(row[k]<=v for k,v in cfg['forceTolerances'].items());return row
    def save(name,obs):
        np.savez_compressed(a.output/name,**obs)
        report.setdefault('artifacts',{})[name]={'sha256':sha(a.output/name),'bytes':(a.output/name).stat().st_size}
    try:
        progress('loading')
        system=mm.XmlSerializer.deserialize((a.bundle/'inputs'/a.model/'system.xml').read_text())
        n={'complex33':132935,'solvent33':151505}[a.model];require(system.getNumParticles()==n,'Wrong full model size')
        payload=json.loads((a.bundle/'inputs'/a.model/'positions.json').read_text());pos=np.asarray(payload['positions_nm'],dtype=np.float64)
        require(pos.shape==(n,3) and np.isfinite(pos).all(),'Wrong initial coordinates')
        box=np.asarray([v.value_in_unit(unit.nanometer) for v in system.getDefaultPeriodicBoxVectors()])
        require(np.array_equal(box,np.asarray(payload['box_vectors_nm'])),'Initial box changed')
        nb=[f for f in system.getForces() if isinstance(f,mm.NonbondedForce)]
        require(len(nb)==1 and nb[0].getNonbondedMethod()==mm.NonbondedForce.PME,'Native PME required')
        def context(name):
            integrator=mm.VerletIntegrator(cfg['timeStepPs']*unit.picoseconds);integrator.setConstraintTolerance(cfg['constraintTolerance'])
            props={'Precision':'double','DeviceIndex':'0','UseCpuPme':'false','DeterministicForces':'true'} if name=='CUDA' else {}
            ctx=mm.Context(system,integrator,mm.Platform.getPlatformByName(name),props);contexts.append((ctx,integrator))
            actual={k:ctx.getPlatform().getPropertyValue(ctx,k) for k in ctx.getPlatform().getPropertyNames()}
            require(all(actual[k]==v for k,v in props.items()),'CUDA properties differ')
            pme=nb[0].getPMEParametersInContext(ctx);alpha=pme[0].value_in_unit(1/unit.nanometer) if hasattr(pme[0],'value_in_unit') else float(pme[0])
            actual_pme=[float(alpha),*map(int,pme[1:])];require(actual_pme==manifest['models'][a.model]['pme'],'PME parameters changed')
            report['contexts'][name]={'properties':actual,'pme':actual_pme};return ctx,integrator
        gpu,integrator=context('CUDA');reference,_=context('Reference')
        def reference_at(obs):
            reference.setPeriodicBoxVectors(*[mm.Vec3(*row)*unit.nanometer for row in obs['box']])
            reference.setPositions(obs['positions']*unit.nanometer);reference.setVelocities(obs['velocities']*unit.nanometer/unit.picosecond)
            return observe(reference)
        if a.phase=='baseline':
            gpu.setPositions(pos*unit.nanometer);gpu.applyConstraints(1e-8);gpu.setVelocities(np.zeros_like(pos)*unit.nanometer/unit.picosecond)
            current=observe(gpu);initial_ref=reference_at(current);save('initial-cuda.npz',current);save('initial-reference.npz',initial_ref)
            report['initialComparison']=compare(initial_ref,current);require(report['initialComparison']['passed'],'Initial Reference/CUDA agreement failed')
            limit=cfg['baselineSteps']
        else:
            prior=json.loads((a.baseline/'result.json').read_text())
            for key,value in {'passed':True,'phase':'baseline','model':a.model,'replica':a.replica,'planSha256':a.plan_sha,
                              'candidateBuildSha256':sha(a.candidate_report),'validatorSha256':sha(__file__),
                              'integrationStepsExecuted':cfg['baselineSteps'],'configuration':cfg}.items():
                require(prior.get(key)==value,'Baseline lineage mismatch '+key)
            require(sha(a.baseline/'midpoint.chk')==prior['checkpointSha256'],'Baseline checkpoint changed')
            for name in ('midpoint.npz','final.npz','final-reference.npz'):
                rec=prior['artifacts'][name]
                require((a.baseline/name).stat().st_size==rec['bytes'] and sha(a.baseline/name)==rec['sha256'],'Baseline state artifact changed')
            report['baselineResultSha256']=sha(a.baseline/'result.json')
            gpu.loadCheckpoint((a.baseline/'midpoint.chk').read_bytes());current=observe(gpu);save('restored.npz',current)
            with np.load(a.baseline/'midpoint.npz',allow_pickle=False) as saved:
                exact={k:bool(np.array_equal(current[k],saved[k])) for k in ('positions','velocities','box','time')}
                report['restoreBitwiseExact']=exact;report['restoreForceComparison']=compare(saved,current)
            require(all(exact.values()) and report['restoreForceComparison']['passed'],'Checkpoint restoration failed')
            limit=cfg['replaySteps']
        report['energyTrace']=[]
        for step in range(100,limit+1,100):
            integrator.step(100);report['integrationStepsExecuted']=step;current=observe(gpu)
            progress('simulating')
            if step%1000==0:
                report['energyTrace'].append({'step':step,'timePs':current['time'],'potential_kJ_mol':current['energy'],'kinetic_kJ_mol':current['kineticEnergy']})
                write(a.output/'partial-result.json',report)
            if a.phase=='baseline' and step==cfg['checkpointStep']:
                (a.output/'midpoint.chk').write_bytes(gpu.createCheckpoint());save('midpoint.npz',current)
                report['checkpointSha256']=sha(a.output/'midpoint.chk')
        progress('validating');save('final.npz',current);(a.output/'final.chk').write_bytes(gpu.createCheckpoint())
        report['finalCheckpointSha256']=sha(a.output/'final.chk')
        final_ref=reference_at(current);save('final-reference.npz',final_ref)
        report['finalReferenceComparison']=compare(final_ref,current)
        require(report['finalReferenceComparison']['passed'],'Final fresh Reference/CUDA agreement failed')
        if a.phase=='resume':
            with np.load(a.baseline/'final.npz',allow_pickle=False) as saved:
                row={'positions_max_abs_nm':float(np.max(np.abs(current['positions']-saved['positions']))),
                     'velocities_max_abs_nm_ps':float(np.max(np.abs(current['velocities']-saved['velocities'])))}
                row['passed']=all(row[k]<=v for k,v in cfg['restartTolerances'].items());report['continuationComparison']=row
                report['continuationForceComparison']=compare(saved,current)
            with np.load(a.baseline/'final-reference.npz',allow_pickle=False) as saved_reference:
                report['storedReferenceComparison']=compare(saved_reference,current)
            require(row['passed'] and report['continuationForceComparison']['passed'] and report['storedReferenceComparison']['passed'],
                    'Full 20000-step strict continuation failed')
        report['passed']=True;progress('finished')
    except Exception as error:
        report['error']={'type':type(error).__name__,'message':str(error)[:1000]};progress('failed')
    finally:
        report['completedAt']=utc();write(a.output/'result.json',report)
    return 0 if report['passed'] else 1

def supervise(a):
    require(not a.output.resolve().is_relative_to(a.candidate_report.parent.resolve()),'Validation output must be outside candidate build')
    require(not a.output.resolve().is_relative_to(a.bundle.resolve()) and not a.output.resolve().is_relative_to(a.original_packet.resolve()),'Output overlaps frozen inputs')
    a.output.mkdir(parents=True,exist_ok=False);started=time.monotonic();active={};all_processes=[]
    report={'schema':'orvia.candidate-validation-run.v1','mode':a.mode,'configuration':config(a.mode),'startedAt':utc(),
            'passed':False,'scientificAcceptance':False,'diagnosticOnly':True,'onChainReportSubmitted':False,
            'automaticPodShutdown':False,'historicalFailureResolved':False,'phases':[]}
    def terminate(signum,frame):raise TimeoutError('Validation 1200-second cutoff reached')
    signal.signal(signal.SIGTERM,terminate);signal.signal(signal.SIGINT,terminate)
    watchdog=threading.Timer(1190,lambda:os.kill(os.getpid(),signal.SIGTERM));watchdog.daemon=True;watchdog.start()
    try:
        w,manifest=inputs(a);eng,env=engine(a)
        plan={'schema':'orvia.candidate-validation-plan.v1','configuration':config(a.mode),'validatorSha256':sha(__file__),
              'candidateBuildSha256':sha(a.candidate_report),'inputManifestSha256':sha(a.bundle/'manifest.json'),
              'precisionPatchSha256':eng['precisionPatchSha256'],'restartPatchSha256':eng['restartPatchSha256']}
        plan_path=a.output/'plan.json';write(plan_path,plan);plan_sha=sha(plan_path)
        report.update(planSha256=plan_sha,validatorSha256=sha(__file__),candidateBuildSha256=sha(a.candidate_report))
        (a.output/'source.py').write_bytes(Path(__file__).read_bytes());(a.output/'candidate-build-report.json').write_bytes(a.candidate_report.read_bytes())
        def spawn(model,replica,phase):
            dest=a.output/f'{model}-r{replica}'/phase;dest.parent.mkdir(exist_ok=True)
            argv=[eng['python'],str(Path(__file__).resolve()),'--worker','--mode',a.mode,'--model',model,'--replica',str(replica),
                  '--phase',phase,'--output',str(dest),'--plan',str(plan_path),'--plan-sha',plan_sha]
            for key in ('candidate_report','bundle','original_packet'):argv+=['--'+key.replace('_','-'),str(getattr(a,key))]
            if phase=='resume':argv+=['--baseline',str(dest.parent/'baseline')]
            log=(dest.parent/f'{phase}.log').open('w')
            proc=subprocess.Popen(argv,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            active[proc.pid]=(proc,model,replica,phase,dest,log);all_processes.append(proc)
        for model in ('complex33','solvent33'):
            for replica in range(1,config(a.mode)['replicasPerModel']+1):spawn(model,replica,'baseline')
        while active:
            time.sleep(1)
            for pid,(proc,model,replica,phase,dest,log) in list(active.items()):
                if proc.poll() is None:continue
                log.close();del active[pid]
                result=json.loads((dest/'result.json').read_text()) if (dest/'result.json').is_file() else {'passed':False,'error':{'message':'Worker ended without result'}}
                report['phases'].append({'model':model,'replica':replica,'phase':phase,'exitCode':proc.returncode,
                                         'passed':result['passed'],'resultSha256':sha(dest/'result.json') if (dest/'result.json').exists() else None})
                if phase=='baseline' and proc.returncode==0 and result['passed']:spawn(model,replica,'resume')
            total=0
            for path in a.output.glob('*-r*/*/progress.json'):
                try:total+=json.loads(path.read_text())['steps']
                except (ValueError,KeyError):pass
            report['integrationStepsExecuted']=total
            write(a.output/'progress.json',{'stage':'validating' if total==config(a.mode)['totalIntegrationSteps'] else 'running',
                                          'steps':total,'totalSteps':config(a.mode)['totalIntegrationSteps'],'activeWorkers':len(active),'updatedAt':utc()})
            write(a.output/'run-status.json',report)
        engine(a) # Recheck candidate binaries and source after all computations.
        report['candidateFilesUnchanged']=True
        report['passed']=len(report['phases'])==4*config(a.mode)['replicasPerModel'] and all(r['passed'] and r['exitCode']==0 for r in report['phases']) and report['integrationStepsExecuted']==config(a.mode)['totalIntegrationSteps']
        report['historicalFailureResolved']=False
        report['candidateLongReplayPassed']=report['passed']
    except Exception as error:
        report['error']={'type':type(error).__name__,'message':str(error)[:1000]}
    finally:
        watchdog.cancel()
        for proc in all_processes:
            if proc.poll() is None:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
        for item in active.values():item[-1].close()
        report.update(completedAt=utc(),elapsedSeconds=time.monotonic()-started,workersStillRunning=[])
        write(a.output/'result.json',report);write(a.output/'run-status.json',report)
        print(json.dumps({k:report.get(k) for k in ('passed','integrationStepsExecuted','elapsedSeconds','error')}))
    return 0 if report['passed'] else 1

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--candidate-report',type=Path,default=Path('/workspace/orvia-restart-candidate-v1/build-report.json'))
    p.add_argument('--bundle',type=Path,default=Path('/workspace/orvia-live-workflow-v4'))
    p.add_argument('--original-packet',type=Path,default=Path('/workspace/orvia-h200-stress-v1'))
    p.add_argument('--output',type=Path,required=True);p.add_argument('--mode',choices=('screen','full'),required=True)
    p.add_argument('--worker',action='store_true');p.add_argument('--model',choices=('complex33','solvent33'))
    p.add_argument('--replica',type=int);p.add_argument('--phase',choices=('baseline','resume'));p.add_argument('--baseline',type=Path)
    p.add_argument('--plan',type=Path);p.add_argument('--plan-sha')
    a=p.parse_args();return worker(a) if a.worker else supervise(a)

if __name__=='__main__':sys.exit(main())
