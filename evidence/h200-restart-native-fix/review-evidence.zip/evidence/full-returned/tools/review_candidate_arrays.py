#!/usr/bin/env python3
"""Independently recompute candidate numerical comparisons from saved NPZ arrays."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import numpy as np

LIMITS={'energy_absolute_kJ_mol':.01,'force_max_absolute_kJ_mol_nm':.05,'force_relative_L2':5e-5}
RESTART={'positions_max_abs_nm':1e-9,'velocities_max_abs_nm_ps':1e-8}
def require(value,message):
    if not value:raise ValueError(message)
def load(folder,name,report):
    path=folder/name;rec=report['artifacts'][name]
    require(path.stat().st_size==rec['bytes'] and hashlib.sha256(path.read_bytes()).hexdigest()==rec['sha256'],'NPZ identity mismatch: '+str(path))
    with np.load(path,allow_pickle=False) as data:out={k:data[k].copy() for k in data.files}
    require(all(np.isfinite(v).all() for v in out.values()),'Nonfinite NPZ array')
    return out
def compare(ref,cur):
    d=cur['forces']-ref['forces'];r={'energy_absolute_kJ_mol':float(abs(cur['energy']-ref['energy'])),
        'force_max_absolute_kJ_mol_nm':float(np.max(np.abs(d))),
        'force_relative_L2':float(np.linalg.norm(d))/max(float(np.linalg.norm(ref['forces'])),1e-12)}
    r['passed']=all(r[k]<=v for k,v in LIMITS.items());return r
def matches(actual,record):
    require(actual['passed'] is record['passed'],'Reported pass differs from arrays')
    for k in actual:
        if k!='passed':require(math.isclose(actual[k],record[k],rel_tol=1e-11,abs_tol=1e-15),'Reported metric differs from arrays: '+k)
def main():
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    parent=json.loads((a.root/'result.json').read_text());rows=[];all_passed=True
    cfg=parent['configuration']
    expected={(m,r,phase) for m in ('complex33','solvent33') for r in range(1,cfg['replicasPerModel']+1) for phase in ('baseline','resume')}
    require(len(parent['phases'])==len(expected) and {(x['model'],x['replica'],x['phase']) for x in parent['phases']}==expected,'Wrong phase identity set')
    for item in parent['phases']:
        require(item['passed'],'Array review requires completed candidate phase')
        folder=a.root/f'{item["model"]}-r{item["replica"]}'/item['phase'];r=json.loads((folder/'result.json').read_text())
        require(hashlib.sha256((folder/'result.json').read_bytes()).hexdigest()==item['resultSha256'],'Parent-result binding changed')
        final=load(folder,'final.npz',r);reference=load(folder,'final-reference.npz',r)
        fresh=compare(reference,final);matches(fresh,r['finalReferenceComparison'])
        row={'model':item['model'],'replica':item['replica'],'phase':item['phase'],'freshReference':fresh}
        if item['phase']=='baseline':
            initial=compare(load(folder,'initial-reference.npz',r),load(folder,'initial-cuda.npz',r));matches(initial,r['initialComparison']);row['initialReference']=initial
            all_passed=all_passed and initial['passed']
        else:
            base=folder.parent/'baseline';b=json.loads((base/'result.json').read_text())
            require(hashlib.sha256((base/'result.json').read_bytes()).hexdigest()==r['baselineResultSha256'],'Baseline binding changed')
            restored=load(folder,'restored.npz',r);mid=load(base,'midpoint.npz',b)
            exact={k:bool(np.array_equal(mid[k],restored[k])) for k in ('positions','velocities','box','time')}
            require(exact==r['restoreBitwiseExact'],'Restore metadata disagrees with arrays')
            restore_force=compare(mid,restored);matches(restore_force,r['restoreForceComparison'])
            baseline_final=load(base,'final.npz',b);continuation_force=compare(baseline_final,final);matches(continuation_force,r['continuationForceComparison'])
            continuation={'positions_max_abs_nm':float(np.max(np.abs(final['positions']-baseline_final['positions']))),
                          'velocities_max_abs_nm_ps':float(np.max(np.abs(final['velocities']-baseline_final['velocities'])))}
            continuation['passed']=all(continuation[k]<=v for k,v in RESTART.items());matches(continuation,r['continuationComparison'])
            stored=compare(load(base,'final-reference.npz',b),final);matches(stored,r['storedReferenceComparison'])
            row.update(exactRestore=exact,restoreForces=restore_force,continuationForces=continuation_force,continuation=continuation,storedReference=stored)
            all_passed=all_passed and all(exact.values()) and restore_force['passed'] and continuation_force['passed'] and continuation['passed'] and stored['passed']
        all_passed=all_passed and fresh['passed'];rows.append(row)
    out={'schema':'orvia.candidate-independent-array-review.v1','allRetainedArraysFinite':True,'numericalComparisonsPassed':all_passed,
         'scientificAcceptance':False,'numpyReviewerVersion':np.__version__,'molecularEvaluations':0,
         'reviewerSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'parentResultSha256':hashlib.sha256((a.root/'result.json').read_bytes()).hexdigest(),
         'planSha256':parent['planSha256'],'validatorSha256':parent['validatorSha256'],
         'candidateBuildSha256':parent['candidateBuildSha256'],'mode':parent['mode'],
         'integrationStepsExecuted':parent['integrationStepsExecuted'],'rows':rows}
    a.output.write_text(json.dumps(out,indent=2,allow_nan=False)+'\n');print(json.dumps({k:out[k] for k in ('numericalComparisonsPassed','allRetainedArraysFinite')}))
if __name__=='__main__':main()
