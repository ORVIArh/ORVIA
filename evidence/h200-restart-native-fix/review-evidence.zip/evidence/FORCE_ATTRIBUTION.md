# Checkpoint force attribution

The original-engine diagnostic completed all four cases in 40.658 seconds: `complex33` and `solvent33`, each after independent 100- and 1,000-step warmups (2,200 integration steps total). The executed source matches the prepared source, every child JSON matches its parent SHA-256 and embedded result, and all recorded state restores are exact.

| Model | Warm steps | Direct-force maximum difference (kJ/mol/nm) | Reciprocal forces | Other forces |
| --- | ---: | ---: | --- | --- |
| complex33 | 100 | 2.561137080192566 × 10⁻⁹ | Bitwise exact | Bitwise exact |
| complex33 | 1,000 | 2.7939677238464355 × 10⁻⁹ | Bitwise exact | Bitwise exact |
| solvent33 | 100 | 2.7939677238464355 × 10⁻⁹ | Bitwise exact | Bitwise exact |
| solvent33 | 1,000 | 1.862645149230957 × 10⁻⁹ | Bitwise exact | Bitwise exact |

Every repeated fresh-context force read was exact. The all-force maximum differences equal the corresponding direct-force maxima. These maxima are 11, 12, 12 and 8 units of 2⁻³², consistent with fixed-point force accumulation. Small energy differences are separate from force exactness.

The XML input hash refers to the original model. The diagnostic clone assigns other forces to group 0, direct nonbonded forces to group 1 and reciprocal forces to group 2; all groups remain enabled for integration.

## Native-source interpretation

For pinned OpenMM commit `b399af4725573963b46d6c1083fdcf7a37615857`:

- `CudaKernels.cpp:55–57` already selects fixed-point PME charge spreading in double precision or deterministic mode.
- `nonbonded.cu:384–390,436–470` sums forces within each tile in floating point, then converts each tile sum for integer atomic accumulation. Different tile/pair groupings can therefore change rounding before the integer sum.
- `findInteractingBlocks.cu:173–185,188–237,494–533` caches neighbor lists and partitions neighbors into tiles or individual pairs. The pair threshold is fixed by compute capability, not runtime timing autotuning.
- `CudaNonbondedUtilities.cpp:441–447` stores an adaptive tile-count reference and can trigger an early atom reorder. `CommonKernels.cpp:354–427` checkpoints atom ordering and its normal step counter, but not that tile-count reference or cached neighbor-list state.

The measurements localize the observed mismatch to the direct nonbonded force group and support the neighbor-history hypothesis. They do **not** yet establish the exact subkernel cause or prove the proposed fix. The candidate rebuilds neighbor lists at every force evaluation and disables adaptive early atom reorder only when deterministic forces are requested. Equations, cutoffs, PME and acceptance thresholds remain unchanged.

This review verifies returned source/result bindings and reported metrics; raw force arrays were not returned or independently recomputed. The historical 20,000-step failure remains failed, and scientific acceptance remains false. Candidate reference-force and full continuation tests are still required.

Machine-readable hashes and checks: `force-probe-independent-review.json`. Returned evidence: `force-probe-returned/`.
