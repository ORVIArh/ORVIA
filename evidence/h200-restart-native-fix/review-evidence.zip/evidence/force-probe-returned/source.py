#!/usr/bin/env python3
"""Bounded, read-only-input attribution probe using the original ORVIA engine."""
import argparse
import datetime as dt
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

sys.dont_write_bytecode = True
STRESS_SHA = '5b781a291219256f8450c6d016011b85a430f8bdc184a54256dba6b28276325b'
CHECKPOINTS = {'complex33': 'e9e27d89602d37d5148cb39596233d28892027b972599877fb17a0e796660bf9',
               'solvent33': 'c3febb92c8dc7cbee0a2f875308d206c5f92993e99b808022d08e6db9524ec4b'}

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def require(ok, message):
    if not ok:
        raise ValueError(message)

def write(p, obj):
    Path(p).write_text(json.dumps(obj, indent=2, allow_nan=False)+'\n')

def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat()

def load(a):
    path = a.original_packet/'stress_parallel.py'
    require(sha(path) == STRESS_SHA, 'Frozen original stress source differs')
    spec = importlib.util.spec_from_file_location('original_stress', path)
    original = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(original)
    worker, manifest = original.load_v4(a.bundle)
    original.verify_packet(worker, a.original_packet)
    engine, env = worker.engine_environment(a.engine_build_report)
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    return worker, manifest, engine, env

def probe(a):
    worker, manifest, engine, env = load(a)
    import numpy as np
    import openmm as mm
    from openmm import unit
    require(Path(sys.prefix).resolve() == Path(engine['python']).parent.parent.resolve(), 'Wrong Python environment')
    require(mm.version.full_version == '8.6.1.dev-b399af4', 'Wrong OpenMM version')
    system_path = a.bundle/'inputs'/a.model/'system.xml'
    system = mm.XmlSerializer.deserialize(system_path.read_text())
    require(system.getNumParticles() == {'complex33':132935, 'solvent33':151505}[a.model], 'Wrong full model')
    nbs = [f for f in system.getForces() if isinstance(f, mm.NonbondedForce)]
    require(len(nbs) == 1 and nbs[0].getNonbondedMethod() == mm.NonbondedForce.PME, 'Wrong nonbonded force')
    for force in system.getForces():
        force.setForceGroup(0)
    nbs[0].setForceGroup(1)
    nbs[0].setReciprocalSpaceForceGroup(2)
    checkpoint = a.original_output/(a.model+'-r1')/'baseline'/'midpoint.chk'
    require(sha(checkpoint) == CHECKPOINTS[a.model], 'Original checkpoint differs')
    contexts = []
    def context():
        integrator = mm.VerletIntegrator(worker.DT_PS*unit.picoseconds)
        integrator.setConstraintTolerance(1e-8)
        props = {'Precision':'double','DeviceIndex':'0','UseCpuPme':'false','DeterministicForces':'true'}
        ctx = mm.Context(system, integrator, mm.Platform.getPlatformByName('CUDA'), props)
        actual = {k:ctx.getPlatform().getPropertyValue(ctx,k) for k in ctx.getPlatform().getPropertyNames()}
        require(all(actual[k] == v for k,v in props.items()), 'Wrong CUDA settings')
        pme = nbs[0].getPMEParametersInContext(ctx)
        alpha = pme[0].value_in_unit(1/unit.nanometer) if hasattr(pme[0], 'value_in_unit') else float(pme[0])
        require([float(alpha),*map(int,pme[1:])] == manifest['models'][a.model]['pme'], 'Wrong PME grid')
        contexts.append((ctx,integrator))
        return ctx,integrator,actual
    def state(ctx):
        value = ctx.getState(getPositions=True,getVelocities=True)
        return {'positions':np.asarray(value.getPositions(asNumpy=True).value_in_unit(unit.nanometer)),
                'velocities':np.asarray(value.getVelocities(asNumpy=True).value_in_unit(unit.nanometer/unit.picosecond)),
                'box':np.asarray(value.getPeriodicBoxVectors(asNumpy=True).value_in_unit(unit.nanometer)),
                'time':np.asarray(value.getTime().value_in_unit(unit.picosecond))}
    def forces(ctx, mask):
        value = ctx.getState(getForces=True,getEnergy=True,groups=mask)
        f = np.asarray(value.getForces(asNumpy=True).value_in_unit(unit.kilojoule_per_mole/unit.nanometer))
        e = float(value.getPotentialEnergy().value_in_unit(unit.kilojoule_per_mole))
        require(np.isfinite(f).all() and np.isfinite(e), 'Nonfinite force or energy')
        return f,e
    def compare(first, second):
        f,e = first; g,h = second
        return {'forcesBitwiseExact':bool(np.array_equal(f,g)),
                'forceMaxAbsolute_kJ_mol_nm':float(np.max(np.abs(f-g))),
                'forceRelativeL2':float(np.linalg.norm(f-g)/max(np.linalg.norm(f),1e-12)),
                'energyAbsolute_kJ_mol':abs(e-h)}
    warm, integrator, actual = context()
    warm.loadCheckpoint(checkpoint.read_bytes())
    integrator.step(a.steps)
    # Capture warm forces BEFORE any checkpoint restore or neighbor-list rebuild.
    labels = [('direct',2),('reciprocal',4),('other',1),('all',-1)]
    baseline = {label:forces(warm, mask) for label,mask in labels}
    saved_state = state(warm)
    blob = warm.createCheckpoint()
    fresh, _, _ = context()
    fresh.loadCheckpoint(blob)
    restored = state(fresh)
    exact = {k:bool(np.array_equal(saved_state[k],restored[k])) for k in saved_state}
    require(all(exact.values()), 'Probe restore is not exact')
    rows = []
    for label,mask in labels:
        first = forces(fresh,mask)
        repeat = forces(fresh,mask)
        rows.append({'component':label,'groupsMask':mask,
                     'warmVersusFresh':compare(baseline[label],first),
                     'freshRepeat':compare(first,repeat)})
    write(a.output, {'schema':'orvia.force-group-checkpoint-probe.v1',
          'diagnosticOnly':True,'scientificAcceptance':False,'historicalFailureResolved':False,
          'originalEngine':True,'model':a.model,'warmSteps':a.steps,
          'sourceSha256':sha(__file__),'systemInputSha256':sha(system_path),
          'originalCheckpointSha256':sha(checkpoint),
          'probeCheckpointSha256':hashlib.sha256(blob).hexdigest(),
          'cudaProperties':actual,'stateRestoreBitwiseExact':exact,'comparisons':rows,
          'completedAt':utc()})

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name,default in (('bundle','/workspace/orvia-live-workflow-v4'),
                         ('original-packet','/workspace/orvia-h200-stress-v1'),
                         ('original-output','/workspace/orvia-stress-20261102-02'),
                         ('engine-build-report','/workspace/orvia-native-double-build-r2/build-report.json')):
        parser.add_argument('--'+name,type=Path,default=Path(default))
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--model',choices=('complex33','solvent33'))
    parser.add_argument('--steps',type=int,choices=(100,1000))
    a = parser.parse_args()
    for p in (a.bundle,a.original_packet,a.original_output,a.engine_build_report.parent):
        require(not a.output.resolve().is_relative_to(p.resolve()), 'Output overlaps immutable input')
    if a.model:
        require(a.steps is not None, 'Steps required')
        require(not a.output.exists(), 'Output already exists')
        probe(a)
        return 0
    start = time.monotonic()
    _,_,engine,env = load(a)
    a.output.mkdir(parents=True,exist_ok=False)
    (a.output/'source.py').write_bytes(Path(__file__).read_bytes())
    report = {'schema':'orvia.force-group-checkpoint-probe-batch.v1',
              'diagnosticOnly':True,'scientificAcceptance':False,'historicalFailureResolved':False,
              'onChainReportSubmitted':False,'automaticPodShutdown':False,
              'sourceSha256':sha(__file__),'startedAt':utc(),'results':[]}
    proc = None
    try:
        for model in ('complex33','solvent33'):
            for steps in (100,1000):
                output = a.output/(model+'-'+str(steps)+'.json')
                argv = [engine['python'],str(Path(__file__).resolve()),'--model',model,'--steps',str(steps),'--output',str(output)]
                for key in ('bundle','original_packet','original_output','engine_build_report'):
                    argv += ['--'+key.replace('_','-'),str(getattr(a,key))]
                with (a.output/(model+'-'+str(steps)+'.log')).open('w') as log:
                    proc = subprocess.Popen(argv,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
                    proc.wait(timeout=max(1,360-(time.monotonic()-start)))
                require(proc.returncode == 0, 'Probe subprocess failed: '+output.name)
                report['results'].append({'path':output.name,'sha256':sha(output),'result':json.loads(output.read_text())})
        report['completed'] = True
    except Exception as error:
        report['completed'] = False
        report['error'] = {'type':type(error).__name__,'message':str(error)[:1000]}
    finally:
        if proc is not None and proc.poll() is None:
            os.killpg(proc.pid,9)
            proc.wait()
        report.update(completedAt=utc(),elapsedSeconds=time.monotonic()-start)
        write(a.output/'result.json',report)
    print(json.dumps({'completed':report['completed'],'seconds':report['elapsedSeconds']}))
    return 0 if report['completed'] else 1

if __name__ == '__main__':
    sys.exit(main())
