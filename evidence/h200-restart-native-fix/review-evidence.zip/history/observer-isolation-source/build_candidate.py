"""Prepare a worker-only observation-isolation experiment from pinned source."""
from pathlib import Path
import hashlib
import json
import difflib

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / 'orvia-h200-stress-v1/stress_parallel.py'
EXPECTED = '5b781a291219256f8450c6d016011b85a430f8bdc184a54256dba6b28276325b'
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == EXPECTED
original = SOURCE.read_text()
source = original

def replace(old, new):
    global source
    assert source.count(old) == 1, old
    source = source.replace(old, new)

replace('"""Four bounded H200 replicas using immutable v4 inputs; never scientific acceptance."""',
        '"""Worker-only observation-isolation experiment; unvalidated until replay tests pass."""')
replace("'phase': args.phase, 'startedAt': w.utc(), 'passed': False, 'diagnosticOnly': True, 'scientificAcceptance': False,",
        "'phase': args.phase, 'startedAt': w.utc(), 'passed': False, 'diagnosticOnly': True, 'scientificAcceptance': False,\n"
        "              'candidateProtocol': 'isolated-restoration-observation-v1', 'candidateJobId': 'orvia-replay-observer-isolation-20261103',\n"
        "              'parentWorkerSourceSha256': '" + EXPECTED + "',\n"
        "              'protocolChange': 'Restored force validation uses a separate CUDA context; the advancing context has no extra force/energy observation before step one.',")
replace("'sourceSha256': sha(__file__), 'stressManifestSha256': sha(args.packet / 'manifest.json')}",
        "'sourceSha256': '" + EXPECTED + "', 'stressManifestSha256': '9ab2588d31b1395155ef54c4b667c59e75551a1f9f8dfe07a2ad2a0cba177441'}")
replace("            gpu.loadCheckpoint((base / 'midpoint.chk').read_bytes())\n"
        "            current = observe(gpu)\n"
        "            save('restored.npz', current)",
        "            # Preserve the strict restored-force check without perturbing the advancing context.\n"
        "            validator, validator_integrator = context('CUDA')\n"
        "            validator.loadCheckpoint((base / 'midpoint.chk').read_bytes())\n"
        "            current = observe(validator)\n"
        "            save('restored-validation.npz', current)\n"
        "            contexts.remove((validator, validator_integrator))\n"
        "            del validator\n"
        "            del validator_integrator\n"
        "            gpu.loadCheckpoint((base / 'midpoint.chk').read_bytes())\n"
        "            restored = gpu.getState(getPositions=True, getVelocities=True)\n"
        "            restored_state = {\n"
        "                'positions': finite(np.asarray(restored.getPositions(asNumpy=True).value_in_unit(unit.nanometer))),\n"
        "                'velocities': finite(np.asarray(restored.getVelocities(asNumpy=True).value_in_unit(unit.nanometer / unit.picosecond))),\n"
        "                'box': finite(np.asarray(restored.getPeriodicBoxVectors(asNumpy=True).value_in_unit(unit.nanometer))),\n"
        "                'time': float(restored.getTime().value_in_unit(unit.picosecond)),\n"
        "            }\n"
        "            w.require(all(np.array_equal(restored_state[k], current[k]) for k in restored_state), 'Advancing context restoration differs from validator')\n"
        "            save('restored.npz', restored_state)\n"
        "            report['restoreForceObservationContext'] = 'separate discarded CUDA context'")
replace("    w, manifest = load_v4(args.bundle)\n    verify_packet(w, args.packet)",
        "    if not (args.worker and args.phase == 'resume' and args.baseline):\n"
        "        raise RuntimeError('This candidate permits only standalone --worker --phase resume; no supervisor or telemetry publishing')\n"
        "    w, manifest = load_v4(args.bundle)\n    verify_packet(w, args.packet)")

OUT = Path(__file__).resolve().parent
PACKET = OUT / 'packet'
PACKET.mkdir(exist_ok=True)
(PACKET / 'stress_parallel.py').write_text(source)
manifest = json.loads((SOURCE.parent / 'manifest.json').read_text())
manifest['candidateProtocol'] = 'isolated-restoration-observation-v1'
manifest['parentWorkerSourceSha256'] = EXPECTED
manifest['files']['stress_parallel.py'] = {'sha256': hashlib.sha256(source.encode()).hexdigest(), 'bytes': len(source.encode())}
(PACKET / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(OUT / 'candidate.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True), source.splitlines(True), fromfile='frozen/stress_parallel.py', tofile='candidate/stress_parallel.py')))
compile(source, str(PACKET / 'stress_parallel.py'), 'exec')
print(json.dumps({'candidateSha256': manifest['files']['stress_parallel.py']['sha256'], 'originalUnchanged': hashlib.sha256(SOURCE.read_bytes()).hexdigest() == EXPECTED, 'syntaxPassed': True}))
