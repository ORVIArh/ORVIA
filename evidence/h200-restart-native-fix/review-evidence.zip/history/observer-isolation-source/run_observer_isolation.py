#!/usr/bin/env python3
"""Run four bounded 20k checkpoint replays with restoration observations isolated."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import signal
import subprocess
import sys
import time

sys.dont_write_bytecode = True
JOB_ID = 'orvia-replay-observer-isolation-20261103'
REPLICAS = (('complex33', 1), ('complex33', 2), ('solvent33', 1), ('solvent33', 2))

def require(value, message):
    if not value:
        raise RuntimeError(message)

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def write(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle', type=Path, default=Path('/workspace/orvia-live-workflow-v4'))
    parser.add_argument('--original-output', type=Path, default=Path('/workspace/orvia-stress-20261102-02'))
    parser.add_argument('--engine-build-report', type=Path, default=Path('/workspace/orvia-native-double-build-r2/build-report.json'))
    parser.add_argument('--environment-binding', type=Path, default=Path('/workspace/orvia-live-engine-restore/environment-binding.json'))
    parser.add_argument('--output', type=Path, default=Path('/workspace') / JOB_ID)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    packet = root / 'packet'
    package = json.loads((root / 'packet-manifest.json').read_text())
    for name, record in package['files'].items():
        path = root / name
        require(path.is_file() and not path.is_symlink() and path.stat().st_size == record['bytes'] and sha(path) == record['sha256'], 'Candidate source identity differs: ' + name)
    inputs = json.loads((root / 'parent-evidence-files.json').read_text())
    def verify_parent():
        require(not args.original_output.is_symlink(), 'Unsafe parent directory')
        entries = list(args.original_output.rglob('*'))
        require(all(not path.is_symlink() for path in entries), 'Unsafe parent evidence symlink')
        found = {str(path.relative_to(args.original_output)) for path in entries if path.is_file()}
        require(found == set(inputs), 'Parent file inventory changed')
        for name, record in inputs.items():
            path = args.original_output / name
            require(path.stat().st_size == record['bytes'] and sha(path) == record['sha256'], 'Parent evidence differs: ' + name)
    verify_parent()
    require(sha(args.environment_binding) == inputs['environment-binding.json']['sha256'], 'Environment binding differs')
    require(sha(args.engine_build_report) == inputs['engine-build-report.json']['sha256'], 'Engine build report differs')
    spec = importlib.util.spec_from_file_location('observer_isolation', packet / 'stress_parallel.py')
    candidate = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(candidate)
    w, _ = candidate.load_v4(args.bundle)
    candidate.verify_packet(w, packet)
    engine, environment = w.engine_environment(args.engine_build_report)
    environment['PYTHONDONTWRITEBYTECODE'] = '1'
    args.output.mkdir(parents=True, exist_ok=False)
    tasks = []
    report = {'schema': 'orvia.observer-isolation-run.v1', 'jobId': JOB_ID, 'parentJobId': 'orvia-stress-20261102-02',
        'startedAt': w.utc(), 'passed': False, 'scientificAcceptance': False, 'diagnosticOnly': True,
        'newIntegrationStepsPlanned': 80000, 'stepsPerReplay': 20000, 'concurrency': 4, 'workerCutoffSeconds': 300,
        'sourceSha256': sha(Path(__file__)), 'packetManifestSha256': sha(root / 'packet-manifest.json'),
        'parentEvidenceManifestSha256': sha(root / 'parent-evidence-files.json'),
        'protocolChange': 'Restored energy and force observations in a separate discarded CUDA context; advancing context has state-only restore observation, then unchanged 100-step observation cadence.',
        'onChainReportSubmitted': False, 'automaticPodShutdown': False, 'telemetryPublished': False,
        'comparisonTolerances': candidate.configuration()['comparisonTolerances'],
        'restartContinuationTolerances': candidate.configuration()['restartContinuationTolerances'], 'phases': []}
    write(args.output / 'run-status.json', report)
    def kill_active():
        for task in tasks:
            if task['process'].poll() is None:
                try:
                    os.killpg(task['process'].pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
    def interrupted(signum, frame):
        kill_active()
        raise InterruptedError('Bounded observation-isolation run interrupted')
    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    started = time.monotonic()
    timed_out = False
    try:
        report['hardware'] = subprocess.check_output(['nvidia-smi', '--query-gpu=name,driver_version,memory.total', '--format=csv,noheader'], timeout=10, text=True).strip()
        require(len(report['hardware'].splitlines()) == 1 and 'H200' in report['hardware'], 'Expected one H200')
        for model, replica in REPLICAS:
            name = f'{model}-r{replica}'
            out = args.output / name
            command = [engine['python'], str(packet / 'stress_parallel.py'), '--worker', '--phase', 'resume',
                '--packet', str(packet), '--bundle', str(args.bundle), '--output', str(out), '--model', model,
                '--replica', str(replica), '--baseline', str(args.original_output / name / 'baseline'),
                '--engine-build-report', str(args.engine_build_report), '--environment-binding', str(args.environment_binding)]
            with (args.output / f'{name}.log').open('xb') as log:
                process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, env=environment, start_new_session=True)
            tasks.append({'name': name, 'out': out, 'process': process, 'steps': 0})
        next_sample = 0
        while any(task['process'].poll() is None for task in tasks):
            now = time.monotonic()
            if now - started >= 300:
                timed_out = True
                kill_active()
                break
            for task in tasks:
                path = task['out'] / 'progress.json'
                if path.exists():
                    task['steps'] = json.loads(path.read_text())['steps']
            write(args.output / 'progress.json', {'jobId': JOB_ID, 'updatedAt': w.utc(), 'steps': sum(task['steps'] for task in tasks), 'totalSteps': 80000, 'activeProcesses': sum(task['process'].poll() is None for task in tasks)})
            if now >= next_sample:
                try:
                    raw = subprocess.check_output(['nvidia-smi', '--query-gpu=utilization.gpu,memory.used,power.draw,temperature.gpu', '--format=csv,noheader,nounits'], timeout=3, text=True).strip()
                    with (args.output / 'gpu-samples.jsonl').open('a') as stream:
                        stream.write(json.dumps({'updatedAt': w.utc(), 'csvGpuPercentMemoryMiBPowerWTemperatureC': raw, 'scope': 'whole_device'}) + '\n')
                except subprocess.SubprocessError:
                    pass
                next_sample = now + 5
            time.sleep(0.5)
        for task in tasks:
            code = task['process'].wait(timeout=10)
            result_path = task['out'] / 'result.json'
            result = json.loads(result_path.read_text()) if result_path.exists() else {}
            progress_path = task['out'] / 'progress.json'
            progress = json.loads(progress_path.read_text()) if progress_path.exists() else {'steps': 0}
            report['phases'].append({'replica': task['name'], 'exitCode': code, 'passed': code == 0 and result.get('passed') is True,
                'integrationStepsExecuted': result.get('integrationStepsExecuted', progress['steps']),
                'resultSha256': sha(result_path) if result_path.exists() else None,
                'continuationComparison': result.get('continuationComparison'),
                'continuationForceComparison': result.get('continuationForceComparison'),
                'finalReferenceComparison': result.get('finalReferenceComparison'),
                'restoreMaxAbsoluteDifferences': result.get('restoreMaxAbsoluteDifferences'), 'error': result.get('error')})
        report['passed'] = not timed_out and len(report['phases']) == 4 and all(p['passed'] and p['integrationStepsExecuted'] == 20000 for p in report['phases'])
    except Exception as error:
        report['error'] = {'type': type(error).__name__, 'message': str(error)[:1000]}
        report['passed'] = False
    finally:
        kill_active()
        for task in tasks:
            task['process'].wait(timeout=10)
        report['workerWallSeconds'] = time.monotonic() - started
        report['timedOut'] = timed_out
        report['newIntegrationStepsExecuted'] = sum(p['integrationStepsExecuted'] for p in report['phases'])
        try:
            verify_parent()
            report['originalEvidenceUnchanged'] = True
        except Exception as error:
            report['originalEvidenceUnchanged'] = False
            report['passed'] = False
            report['parentVerificationError'] = str(error)[:1000]
        report['completedAt'] = w.utc()
        write(args.output / 'result.json', report)
        write(args.output / 'run-status.json', report)
        print(json.dumps({'jobId': JOB_ID, 'passed': report['passed'], 'steps': report['newIntegrationStepsExecuted'], 'timedOut': timed_out, 'output': str(args.output)}))
    return 0 if report['passed'] else 1

if __name__ == '__main__':
    raise SystemExit(main())
