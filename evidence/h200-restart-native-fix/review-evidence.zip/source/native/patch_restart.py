#!/usr/bin/env python3
"""Candidate: remove history-dependent CUDA neighbor lists in deterministic mode."""
import argparse
import difflib
import hashlib
import json
from pathlib import Path

REL='platforms/cuda/src/CudaNonbondedUtilities.cpp'
EXPECTED='5154eb531e8485ad3e6077d5840a3fd981359a1200132f19790f28acc9b80647'

def patch(text):
    old='''    // Compute the neighbor list.

    context.executeKernel(kernels.findBlockBoundsKernel'''
    new='''    // Compute the neighbor list.
    // ORVIA_DETERMINISTIC_RESTART_v1: cached padded neighbor lists can group
    // pairs differently from a freshly restored context.  Floating-point tile
    // sums are quantized before integer accumulation, so that grouping matters.
    // Rebuild from current coordinates when deterministic forces are requested.
    if (context.getPlatformData().deterministicForces)
        forceRebuildNeighborList = true;

    context.executeKernel(kernels.findBlockBoundsKernel'''
    if text.count(old)!=1: raise ValueError('Neighbor rebuild anchor mismatch')
    text=text.replace(old,new,1)
    old='''    else if (context.getStepsSinceReorder() > 25 && pinnedCountBuffer[0] > 1.1*tilesAfterReorder)'''
    new='''    // The adaptive reference count is not serialized in a checkpoint.  Keep
    // deterministic mode on the fixed reorder schedule, whose counter is saved.
    else if (!context.getPlatformData().deterministicForces && context.getStepsSinceReorder() > 25 && pinnedCountBuffer[0] > 1.1*tilesAfterReorder)'''
    if text.count(old)!=1: raise ValueError('Adaptive reorder anchor mismatch')
    return text.replace(old,new,1)

def main():
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--report',type=Path,required=True);a=p.parse_args()
    target=a.source/REL;before=target.read_bytes()
    if hashlib.sha256(before).hexdigest()!=EXPECTED: raise ValueError('Wrong pinned CUDA source')
    if a.report.exists(): raise FileExistsError(a.report)
    after=patch(before.decode()).encode();target.write_bytes(after)
    report={'schema':'orvia.restart-neighbor-determinism-candidate.v1','scientificAcceptance':False,'numericallyValidated':False,
            'scope':'Only CUDA DeterministicForces mode; physical equations, parameter values, cutoffs, PME, integration and tolerances unchanged',
            'files':{REL:{'beforeSha256':EXPECTED,'afterSha256':hashlib.sha256(after).hexdigest(),'bytes':len(after)}}}
    a.report.write_text(json.dumps(report,indent=2)+'\n')
    a.report.with_suffix('.patch').write_text(''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+REL,tofile='b/'+REL)))

if __name__=='__main__':main()
