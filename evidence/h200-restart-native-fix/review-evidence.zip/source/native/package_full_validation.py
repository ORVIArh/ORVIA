#!/usr/bin/env python3
"""After full pass, review explicit artifacts and package two public evidence archives."""
import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

VALIDATOR_SHA='b6fa2885f6e384a7eb0fb3f3622e31e9c4ac2a1a5cbbf05276d823377725e40a'
REVIEWER_SHA='bbc4ec4ce94b4be06ae51d74c53fcf13b5c401641feeb69164dd335326880f86'
MODELS=('complex33','solvent33')

def require(value,message):
    if not value:raise ValueError(message)
def sha(path):
    value=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):value.update(block)
    return value.hexdigest()
def write(path,value):Path(path).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def file_record(path):
    require(path.is_file() and not path.is_symlink(),'Missing or symlinked artifact: '+str(path))
    return {'bytes':path.stat().st_size,'sha256':sha(path)}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--job',type=Path,required=True)
    p.add_argument('--destination',type=Path,required=True)
    p.add_argument('--reviewer',type=Path,default=Path('/workspace/review_candidate_arrays.py'))
    a=p.parse_args();job=a.job.resolve();dest=a.destination.resolve()
    require(not dest.is_relative_to(job),'Packaging directory must be outside original job output')
    require(file_record(a.reviewer)['sha256']==REVIEWER_SHA,'Wrong independent array reviewer')
    parent=json.loads((job/'result.json').read_text());plan=json.loads((job/'plan.json').read_text())
    build=json.loads((job/'candidate-build-report.json').read_text())
    require(parent.get('schema')=='orvia.candidate-validation-run.v1' and parent.get('mode')=='full','Full validation only')
    require(parent.get('passed') is True and parent.get('candidateLongReplayPassed') is True and parent.get('candidateFilesUnchanged') is True,'Full candidate has not passed')
    require(parent.get('integrationStepsExecuted')==400000 and parent.get('workersStillRunning')==[],'Full workload not finished')
    require(parent.get('scientificAcceptance') is False and parent.get('onChainReportSubmitted') is False,'Unexpected scientific/chain scope')
    require(sha(job/'source.py')==VALIDATOR_SHA==parent.get('validatorSha256')==plan.get('validatorSha256'),'Wrong validator source')
    require(sha(job/'plan.json')==parent.get('planSha256'),'Plan binding differs')
    require(sha(job/'candidate-build-report.json')==parent.get('candidateBuildSha256')==plan.get('candidateBuildSha256'),'Build binding differs')
    require(plan.get('configuration')==parent.get('configuration'),'Configuration binding differs')
    expected={(m,r,phase) for m in MODELS for r in (1,2) for phase in ('baseline','resume')}
    require(len(parent['phases'])==8 and {(x['model'],x['replica'],x['phase']) for x in parent['phases']}==expected,'Eight distinct phases required')
    metadata={name:job/name for name in ('result.json','plan.json','source.py','candidate-build-report.json')}
    arrays={};checkpoints={}
    for item in parent['phases']:
        folder=job/f'{item["model"]}-r{item["replica"]}'/item['phase'];result=folder/'result.json'
        require(folder.resolve().is_relative_to(job),'Phase directory escapes explicit job output')
        require(item['passed'] is True and item['exitCode']==0 and sha(result)==item['resultSha256'],'Invalid phase status/binding')
        row=json.loads(result.read_text());require(all(row.get(k)==item[k] for k in ('model','replica','phase')),'Phase identity differs')
        metadata[str(result.relative_to(job))]=result
        names={'initial-cuda.npz','initial-reference.npz','midpoint.npz','final.npz','final-reference.npz'} if item['phase']=='baseline' else {'restored.npz','final.npz','final-reference.npz'}
        require(set(row['artifacts'])==names,'Unexpected state artifact names')
        for name in sorted(names):
            path=folder/name;rec=file_record(path);require(rec==row['artifacts'][name],'State artifact identity differs')
            arrays[str(path.relative_to(job))]=path
        for name,key in [('final.chk','finalCheckpointSha256')]+([('midpoint.chk','checkpointSha256')] if item['phase']=='baseline' else []):
            path=folder/name;rec=file_record(path);require(rec['sha256']==row[key],'Native checkpoint identity differs')
            checkpoints[str(path.relative_to(job))]=rec
    require(len(arrays)==32 and len(checkpoints)==12,'Wrong artifact totals')
    candidate=Path(build['libraryPrefix']).resolve().parent
    for name,key in [('precision-patch.json','precisionPatchSha256'),('restart-patch.json','restartPatchSha256')]:
        path=candidate/name;require(file_record(path)['sha256']==build[key],'Build patch record changed')
        metadata['build-proof/'+name]=path
    dest.mkdir(parents=True,exist_ok=False)
    review=dest/'independent-array-review.json'
    run=subprocess.run([build['python'],str(a.reviewer.resolve()),str(job),'--output',str(review)],capture_output=True,text=True,timeout=180)
    require(run.returncode==0,'Independent array review failed: '+run.stderr[-1500:])
    checked=json.loads(review.read_text())
    for key,value in {'reviewerSha256':REVIEWER_SHA,'parentResultSha256':sha(job/'result.json'),
                      'planSha256':parent['planSha256'],'validatorSha256':VALIDATOR_SHA,'candidateBuildSha256':parent['candidateBuildSha256'],
                      'mode':'full','integrationStepsExecuted':400000,'numericalComparisonsPassed':True,'allRetainedArraysFinite':True}.items():
        require(checked.get(key)==value,'Independent review mismatch: '+key)
    metadata['independent-array-review.json']=review
    metadata['tools/review_candidate_arrays.py']=a.reviewer.resolve()
    inventory={'schema':'orvia.full-validation-artifact-inventory.v1','job':str(job),'createdAt':dt.datetime.now(dt.timezone.utc).isoformat(),
               'validatorSha256':VALIDATOR_SHA,'candidateBuildSha256':parent['candidateBuildSha256'],'planSha256':parent['planSha256'],
               'metadata':{name:file_record(path) for name,path in metadata.items()},
               'arrays':{name:file_record(path) for name,path in arrays.items()},
               'nativeCheckpointsExcluded':checkpoints,'scientificAcceptance':False}
    write(dest/'artifact-inventory.json',inventory);metadata['artifact-inventory.json']=dest/'artifact-inventory.json'
    summary={'schema':'orvia.full-validation-evidence-packages.v1','fullValidationPassed':True,'independentArrayReviewPassed':True,
             'parentResultSha256':sha(job/'result.json'),'validatorSha256':VALIDATOR_SHA,'candidateBuildSha256':parent['candidateBuildSha256'],
             'arrayReviewerSha256':REVIEWER_SHA,'arrayReviewSha256':sha(review),'nativeCheckpointPayloadsIncluded':False,
             'scientificAcceptance':False,'archives':{}}
    for kind,files in [('metadata',metadata),('arrays-and-metadata',{**metadata,**arrays})]:
        archive=dest/(kind+'.tar.gz')
        with tarfile.open(archive,'w:gz',compresslevel=1) as tar:
            for name,path in sorted(files.items()):
                require(not path.is_symlink() and path.is_file(),'Artifact changed during packaging')
                tar.add(path,arcname=name,recursive=False)
        summary['archives'][kind]={'path':str(archive),**file_record(archive),'files':len(files)}
    for kind,paths in [('metadata',metadata),('arrays',arrays)]:
        for name,path in paths.items():
            if name=='artifact-inventory.json':continue
            require(file_record(path)==inventory[kind][name],'Artifact changed while archiving')
    write(dest/'packages.json',summary)
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
