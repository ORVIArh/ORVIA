#!/usr/bin/env python3
"""Independently check candidate result hashes, counters and numeric gate flags."""
import argparse
import hashlib
import json
import math
from pathlib import Path

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def require(v,msg):
    if not v:raise ValueError(msg)
def main():
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    parent=json.loads((a.root/'result.json').read_text());plan=json.loads((a.root/'plan.json').read_text());cfg=plan['configuration']
    require(parent['planSha256']==sha(a.root/'plan.json'),'Plan hash mismatch')
    require(parent['validatorSha256']==sha(a.root/'source.py')==plan['validatorSha256'],'Source hash mismatch')
    require(parent['candidateBuildSha256']==sha(a.root/'candidate-build-report.json')==plan['candidateBuildSha256'],'Build hash mismatch')
    require(parent['scientificAcceptance'] is False and parent['onChainReportSubmitted'] is False,'Wrong acceptance/submission flags')
    force={'energy_absolute_kJ_mol':.01,'force_max_absolute_kJ_mol_nm':.05,'force_relative_L2':5e-5}
    restart={'positions_max_abs_nm':1e-9,'velocities_max_abs_nm_ps':1e-8}
    require(cfg['forceTolerances']==force and cfg['restartTolerances']==restart,'Thresholds differ')
    rows=[];total=0;seen=set();all_passed=True
    def gate(row,limits):
        for k in limits:require(type(row[k]) in (int,float) and math.isfinite(row[k]) and row[k]>=0,'Invalid metric')
        passed=all(row[k]<=v for k,v in limits.items());require(row['passed'] is passed,'Incorrect gate flag');return passed
    for item in parent['phases']:
        identity=(item['model'],item['replica'],item['phase']);require(identity not in seen,'Duplicate phase');seen.add(identity)
        path=a.root/f'{item["model"]}-r{item["replica"]}'/item['phase']/'result.json'
        require(sha(path)==item['resultSha256'],'Child result hash mismatch');r=json.loads(path.read_text())
        require(r['configuration']==cfg and r['candidateBuildSha256']==plan['candidateBuildSha256'] and r['planSha256']==sha(a.root/'plan.json'),'Child lineage mismatch')
        total+=r['integrationStepsExecuted'];passed=r['passed'] and item['passed'] and item['exitCode']==0
        if r['passed']:
            required=cfg['baselineSteps'] if item['phase']=='baseline' else cfg['replaySteps'];require(r['integrationStepsExecuted']==required,'Incomplete phase marked passed')
            require(gate(r['finalReferenceComparison'],force),'Failed final Reference comparison')
            if item['phase']=='baseline':require(gate(r['initialComparison'],force),'Failed initial Reference comparison')
            else:
                require(set(r['restoreBitwiseExact'])=={'positions','velocities','box','time'} and all(v is True for v in r['restoreBitwiseExact'].values()),'Inexact checkpoint restore')
                for key,limits in [('restoreForceComparison',force),('continuationComparison',restart),('continuationForceComparison',force),('storedReferenceComparison',force)]:require(gate(r[key],limits),'Failed '+key)
                base=path.parent.parent/'baseline'/'result.json';require(r['baselineResultSha256']==sha(base),'Baseline binding mismatch')
            require(r['forceMarginObservations'] and all(v['passed'] is True and math.isfinite(v['maxAbsoluteForceKJMolNm']) and 0<=v['maxAbsoluteForceKJMolNm']<2**26 for v in r['forceMarginObservations']),'Force margin invalid')
        rows.append({'model':item['model'],'replica':item['replica'],'phase':item['phase'],'passed':passed,'steps':r['integrationStepsExecuted'],
                     'continuationComparison':r.get('continuationComparison'),'error':r.get('error')})
        all_passed=all_passed and passed
    expected={(m,r,phase) for m in ('complex33','solvent33') for r in range(1,cfg['replicasPerModel']+1) for phase in ('baseline','resume')}
    actual_passed=all_passed and seen==expected and total==cfg['totalIntegrationSteps']
    require(parent['passed'] is actual_passed,'Incorrect parent pass flag')
    require(parent['integrationStepsExecuted']==total,'Counter mismatch')
    out={'schema':'orvia.candidate-result-independent-review.v1','resultStructureAndGateReviewPassed':True,'candidatePassed':actual_passed,
         'mode':cfg['mode'],'totalIntegrationSteps':total,'scientificAcceptance':False,'parentResultSha256':sha(a.root/'result.json'),
         'independentArrayReviewPerformed':False,'scope':'Result hashes, lineage, counters and all reported numerical gate flags independently checked; NPZ arrays not recomputed by this tool.','phases':rows}
    a.output.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k] for k in ('resultStructureAndGateReviewPassed','candidatePassed','mode','totalIntegrationSteps')}))
if __name__=='__main__':main()
