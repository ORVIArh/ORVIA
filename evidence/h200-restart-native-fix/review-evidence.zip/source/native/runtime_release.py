#!/usr/bin/env python3
"""Promote only a fully validated isolated runtime; launch one bounded job."""
import argparse
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import sys
from types import SimpleNamespace

sys.dont_write_bytecode=True
VALIDATOR_SHA='b6fa2885f6e384a7eb0fb3f3622e31e9c4ac2a1a5cbbf05276d823377725e40a'
INPUT_MANIFEST_SHA='90c95d2ca4653384bce9ca11d8848ab80378740dbb2e00c50f5feb0667ff7b32'
ARRAY_REVIEWER_SHA='bbc4ec4ce94b4be06ae51d74c53fcf13b5c401641feeb69164dd335326880f86'
FORCE={'energy_absolute_kJ_mol':.01,'force_max_absolute_kJ_mol_nm':.05,'force_relative_L2':5e-5}
RESTART={'positions_max_abs_nm':1e-9,'velocities_max_abs_nm_ps':1e-8}

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()
def require(value,message):
    if not value:raise ValueError(message)
def write(path,value):
    path=Path(path);tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(path)
def gate(value,limits):
    return value.get('passed') is True and all(type(value.get(k)) in (int,float) and math.isfinite(value[k]) and 0<=value[k]<=v for k,v in limits.items())
def module(path):
    require(sha(path)==VALIDATOR_SHA,'Unapproved validator source')
    spec=importlib.util.spec_from_file_location('approved_candidate_validator',path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def approve(a):
    root=a.evidence.resolve();result=json.loads((root/'result.json').read_text())
    validator=root/'source.py';v=module(validator)
    require(result.get('mode')=='full' and result.get('configuration')==v.config('full'),'Only exact full validation is eligible')
    require(result.get('passed') is True and result.get('candidateLongReplayPassed') is True and result.get('candidateFilesUnchanged') is True,'Full validation did not pass')
    require(result.get('integrationStepsExecuted')==400000 and result.get('workersStillRunning')==[],'Full work incomplete')
    require(result.get('scientificAcceptance') is False and result.get('onChainReportSubmitted') is False,'Wrong approval scope')
    require(result.get('validatorSha256')==VALIDATOR_SHA and result.get('planSha256')==sha(root/'plan.json'),'Source/plan binding mismatch')
    require(result.get('candidateBuildSha256')==sha(a.candidate_report)==sha(root/'candidate-build-report.json'),'Candidate build binding mismatch')
    plan=json.loads((root/'plan.json').read_text());require(plan['configuration']==v.config('full') and plan['validatorSha256']==VALIDATOR_SHA,'Plan mismatch')
    require(plan.get('inputManifestSha256')==INPUT_MANIFEST_SHA,'Frozen input manifest mismatch')
    require(plan.get('candidateBuildSha256')==result['candidateBuildSha256'],'Plan candidate build mismatch')
    expected={(m,r,p) for m in ('complex33','solvent33') for r in (1,2) for p in ('baseline','resume')}
    require(len(result['phases'])==8 and {(x['model'],x['replica'],x['phase']) for x in result['phases']}==expected,'Eight complete phases required')
    require(a.array_review is not None,'Independent full-array review required')
    array_review=json.loads(a.array_review.read_text())
    for key,value in {'schema':'orvia.candidate-independent-array-review.v1','reviewerSha256':ARRAY_REVIEWER_SHA,
                      'parentResultSha256':sha(root/'result.json'),'planSha256':result['planSha256'],
                      'candidateBuildSha256':result['candidateBuildSha256'],'validatorSha256':VALIDATOR_SHA,
                      'mode':'full','integrationStepsExecuted':400000,'scientificAcceptance':False,
                      'numericalComparisonsPassed':True,'allRetainedArraysFinite':True}.items():
        require(array_review.get(key)==value,'Independent array review mismatch: '+key)
    require(len(array_review['rows'])==8 and {(x['model'],x['replica'],x['phase']) for x in array_review['rows']}==expected,
            'Independent array review phase set differs')
    evidence={str(root/'result.json'):sha(root/'result.json'),str(root/'plan.json'):sha(root/'plan.json')}
    for item in result['phases']:
        folder=root/f'{item["model"]}-r{item["replica"]}'/item['phase'];path=folder/'result.json';row=json.loads(path.read_text())
        require(item['passed'] is True and item['exitCode']==0 and sha(path)==item['resultSha256'],'Phase binding/final status failed')
        require(all(row.get(k)==item[k] for k in ('model','replica','phase')) and row.get('mode')=='full','Phase identity mismatch')
        require(row.get('passed') is True and row.get('configuration')==v.config('full') and row.get('planSha256')==result['planSha256'],'Wrong phase plan')
        require(row.get('candidateBuildSha256')==result['candidateBuildSha256'] and row.get('validatorSha256')==VALIDATOR_SHA,'Phase runtime mismatch')
        require(row.get('inputManifestSha256')==INPUT_MANIFEST_SHA and row.get('scientificAcceptance') is False and row.get('diagnosticOnly') is True,'Phase input/scope mismatch')
        require(row.get('integrationStepsExecuted')==(80000 if item['phase']=='baseline' else 20000),'Phase incomplete')
        require(gate(row['finalReferenceComparison'],FORCE),'Fresh Reference comparison failed')
        if item['phase']=='baseline':
            require(gate(row['initialComparison'],FORCE),'Initial Reference comparison failed')
            require(sha(folder/'midpoint.chk')==row['checkpointSha256'],'Midpoint checkpoint mismatch')
            evidence[str(folder/'midpoint.chk')]=row['checkpointSha256']
        else:
            require(row.get('baselineResultSha256')==sha(folder.parent/'baseline'/'result.json'),'Baseline result linkage mismatch')
            require(row['restoreBitwiseExact']=={k:True for k in ('positions','velocities','box','time')},'Checkpoint restore not exact')
            for key,limits in [('restoreForceComparison',FORCE),('continuationForceComparison',FORCE),('storedReferenceComparison',FORCE),('continuationComparison',RESTART)]:
                require(gate(row[key],limits),'Replay gate failed: '+key)
        require(sha(folder/'final.chk')==row['finalCheckpointSha256'],'Final checkpoint mismatch')
        evidence[str(folder/'final.chk')]=row['finalCheckpointSha256']
        require(row['forceMarginObservations'] and all(x['passed'] is True and 0<=x['maxAbsoluteForceKJMolNm']<2**26 for x in row['forceMarginObservations']),'Force margin failed')
        required={'initial-cuda.npz','initial-reference.npz','midpoint.npz','final.npz','final-reference.npz'} if item['phase']=='baseline' else {'restored.npz','final.npz','final-reference.npz'}
        require(set(row['artifacts'])==required,'Required phase artifact set mismatch')
        for name,rec in row['artifacts'].items():
            require(Path(name).name==name,'Unsafe evidence artifact path')
            file=folder/name;require(file.stat().st_size==rec['bytes'] and sha(file)==rec['sha256'],'State evidence artifact changed')
            evidence[str(file)]=rec['sha256']
        evidence[str(path)]=sha(path)
    eng,_=v.engine(SimpleNamespace(candidate_report=a.candidate_report))
    release_id=sha(root/'result.json')[:24];destination=a.releases.resolve()/release_id
    destination.mkdir(parents=True,exist_ok=False)
    retained=destination/'validate_candidate.py';retained.write_bytes(validator.read_bytes())
    retained_review=destination/'independent-array-review.json';retained_review.write_bytes(a.array_review.read_bytes())
    evidence[str(retained_review)]=sha(retained_review)
    descriptor={'schema':'orvia.validated-runtime-release.v1','status':'full-restart-validation-passed',
                'scope':'Full-model strict numerical restart validation; no equilibrium or binding-free-energy acceptance',
                'scientificAcceptance':False,'releaseId':release_id,'validator':str(retained),'validatorSha256':VALIDATOR_SHA,
                'candidateReport':str(a.candidate_report.resolve()),'candidateBuildSha256':sha(a.candidate_report),
                'python':eng['python'],'libraryPrefix':eng['libraryPrefix'],'pluginDirectory':eng['pluginDirectory'],
                'independentArrayReviewSha256':sha(retained_review),'arrayReviewerSha256':ARRAY_REVIEWER_SHA,
                'validationEvidence':evidence,'defaultMode':'screen','unboundedWorkerLoop':False,
                'telemetryPolicy':'A new website job needs its own explicitly configured profile and scoped telemetry token'}
    write(destination/'runtime.json',descriptor)
    if a.active.exists():
        (destination/'previous-active-runtime.json').write_bytes(a.active.read_bytes())
    write(a.active,{'schema':'orvia.active-runtime-pointer.v1','release':str(destination/'runtime.json'),'sha256':sha(destination/'runtime.json')})
    print(json.dumps({'activeRuntime':str(a.active),'release':str(destination/'runtime.json'),'libraryPrefix':eng['libraryPrefix']}))

def launch(a):
    pointer=json.loads(a.active.read_text());path=Path(pointer['release'])
    require(sha(path)==pointer['sha256'],'Active runtime descriptor changed')
    d=json.loads(path.read_text());require(d['schema']=='orvia.validated-runtime-release.v1' and d['scientificAcceptance'] is False,'Unexpected runtime release')
    require(sha(Path(d['candidateReport']))==d['candidateBuildSha256'],'Selected engine report changed')
    for file,digest in d['validationEvidence'].items():require(sha(Path(file))==digest,'Approval evidence changed')
    v=module(Path(d['validator']));eng,env=v.engine(SimpleNamespace(candidate_report=Path(d['candidateReport'])))
    require(not a.output.exists(),'New job output already exists; old data is preserved')
    mode=a.mode or d['defaultMode']
    argv=[eng['python'],d['validator'],'--candidate-report',d['candidateReport'],'--mode',mode,'--output',str(a.output.resolve())]
    print(json.dumps({'mode':mode,'selectedEngine':eng['libraryPrefix'],'output':str(a.output.resolve()),'bounded':True}),flush=True)
    os.execve(eng['python'],argv,env)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=('promote','launch'))
    p.add_argument('--active',type=Path,default=Path('/workspace/orvia-active-runtime.json'))
    p.add_argument('--releases',type=Path,default=Path('/workspace/orvia-runtime-releases'))
    p.add_argument('--evidence',type=Path);p.add_argument('--candidate-report',type=Path,default=Path('/workspace/orvia-restart-candidate-v1/build-report.json'))
    p.add_argument('--array-review',type=Path)
    p.add_argument('--output',type=Path);p.add_argument('--mode',choices=('screen','full'))
    a=p.parse_args()
    if a.action=='promote':require(a.evidence is not None,'Full evidence path required');approve(a)
    else:require(a.output is not None,'New bounded output path required');launch(a)
if __name__=='__main__':main()
