#!/usr/bin/env python3
"""Isolated pinned-source CUDA restart candidate; retains the exact Python wrapper."""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import threading
import time

PIN='b399af4725573963b46d6c1083fdcf7a37615857'
OLD_REPORT_SHA='82f3560f4ff7e0b780b65608f50d188e85d12a08b7bd5c14fba82d8236833f4f'

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def require(v,msg):
    if not v:raise ValueError(msg)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,default=Path('/workspace/orvia-restart-candidate-v1'))
    parser.add_argument('--old-root',type=Path,default=Path('/workspace/orvia-native-double-build-r2'))
    parser.add_argument('--jobs',type=int,default=12)
    parser.add_argument('--resume',action='store_true')
    args=parser.parse_args();packet=Path(__file__).resolve().parent
    require(not args.output.resolve().is_relative_to(args.old_root.resolve()),'Candidate must be isolated')
    prior_sha=None
    stamp=dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
    if args.resume:
        prior=args.output/'build-report.json';require(prior.is_file(),'No candidate build to resume')
        prior_sha=sha(prior);history=args.output/'attempts'/stamp;history.mkdir(parents=True,exist_ok=False)
        shutil.copy2(prior,history/'build-report.json')
    else:args.output.mkdir(parents=True,exist_ok=False)
    started=time.monotonic();proc=None
    report={'schema':'orvia.isolated-restart-candidate-build.v1','sourceCommit':PIN,'buildPassed':False,
            'numericalValidationPassed':False,'scientificAcceptance':False,'existingRuntimeModified':False,
            'buildSourceSha256':sha(__file__),'commands':[],'resumed':args.resume,'priorBuildReportSha256':prior_sha}
    def save(): (args.output/'build-report.json').write_text(json.dumps(report,indent=2)+'\n')
    def alarm(signum,frame):raise TimeoutError('Candidate build 720-second cutoff reached')
    signal.signal(signal.SIGTERM,alarm);signal.signal(signal.SIGINT,alarm)
    watchdog=threading.Timer(720,lambda:os.kill(os.getpid(),signal.SIGTERM));watchdog.daemon=True;watchdog.start()
    def run(cmd,cwd=None,env=None):
        nonlocal proc
        row={'argv':list(map(str,cmd)),'startedSeconds':time.monotonic()-started};report['commands'].append(row);save()
        log=args.output/((('resume-'+stamp+'-') if args.resume else '')+f'command-{len(report["commands"]):02d}.log')
        with log.open('w') as stream:
            proc=subprocess.Popen(row['argv'],cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
            proc.wait(timeout=max(1,710-(time.monotonic()-started)))
        row.update(exitCode=proc.returncode,endedSeconds=time.monotonic()-started);save()
        require(proc.returncode==0,'Build command failed: '+log.name)
    try:
        old_report=args.old_root/'build-report.json';require(sha(old_report)==OLD_REPORT_SHA,'Old engine identity changed')
        old=json.loads(old_report.read_text())
        for rel,rec in old['artifacts'].items():require(sha(args.old_root/rel)==rec['sha256'],'Old native artifact changed: '+rel)
        before={rel:sha(args.old_root/rel) for rel in old['artifacts']}
        (args.output/'old-native-inventory.json').write_text(json.dumps(before,indent=2)+'\n')
        source=args.output/'source';build=args.output/'build';prefix=args.output/'prefix'
        env={k:v for k,v in os.environ.items() if k not in ('ORVIA_WORKER_TOKEN','RUNPOD_API_KEY','NETLIFY_AUTH_TOKEN','PYTHONPATH','PYTHONOPTIMIZE') and not k.startswith('ORVIA_WALLET')}
        env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONUNBUFFERED='1')
        if not args.resume:
            run(['git','init',source],env=env)
            run(['git','remote','add','origin','https://github.com/openmm/openmm.git'],cwd=source,env=env)
            run(['git','fetch','--depth=1','origin',PIN],cwd=source,env=env)
            run(['git','checkout','--detach','FETCH_HEAD'],cwd=source,env=env)
        require(subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==PIN,'Wrong source commit')
        if not args.resume:
            run([sys.executable,packet/'model_repair_patch_native_pme.py','--source',source,'--report',args.output/'precision-patch.json'],env=env)
            run([sys.executable,packet/'patch_restart.py','--source',source,'--report',args.output/'restart-patch.json'],env=env)
            shutil.copytree(args.old_root/'prefix',prefix)
        else:
            expected=set()
            for file,key in [('precision-patch.json','patchedSha256'),('restart-patch.json','afterSha256')]:
                for rel,rec in json.loads((args.output/file).read_text())['files'].items():
                    require(sha(source/rel)==rec[key],'Resumed source differs: '+rel);expected.add(rel)
            changed=set(subprocess.check_output(['git','-C',str(source),'diff','--name-only'],text=True).splitlines())
            require(changed==expected,'Unexpected resumed source edits')
        # Build only the ABI-compatible core and CUDA plugin.  Other plugins and
        # the unmodified Python wrapper remain byte-identical to the old runtime.
        options=['-DCMAKE_BUILD_TYPE=Release','-DCMAKE_INSTALL_PREFIX='+str(prefix),
                 '-DOPENMM_BUILD_PYTHON_WRAPPERS=OFF','-DOPENMM_BUILD_CUDA_LIB=ON',
                 '-DOPENMM_BUILD_OPENCL_LIB=OFF','-DOPENMM_BUILD_CPU_LIB=OFF',
                 '-DOPENMM_BUILD_AMOEBA_PLUGIN=OFF','-DOPENMM_BUILD_DRUDE_PLUGIN=OFF','-DOPENMM_BUILD_RPMD_PLUGIN=OFF',
                 '-DBUILD_TESTING=OFF','-DOPENMM_BUILD_TESTS=OFF','-DOPENMM_BUILD_EXAMPLES=OFF']
        run(['cmake','-S',source,'-B',build,*options],env=env)
        run(['cmake','--build',build,'--target','OpenMMCUDA','--parallel',args.jobs],env=env)
        for name,dest in [('libOpenMM.so',prefix/'lib/libOpenMM.so'),('libOpenMMCUDA.so',prefix/'lib/plugins/libOpenMMCUDA.so')]:
            matches=[p for p in build.rglob(name) if p.is_file()]
            require(len(matches)==1,'Ambiguous built library '+name)
            shutil.copy2(matches[0],dest)
        env.update(LD_LIBRARY_PATH=str(prefix/'lib'),OPENMM_PLUGIN_DIR=str(prefix/'lib/plugins'))
        smoke='''import openmm,json,pathlib,hashlib
prefix=pathlib.Path(__import__('sys').argv[1]).resolve()
paths=sorted({line.split()[-1] for line in pathlib.Path('/proc/self/maps').read_text().splitlines() if 'libOpenMM' in line})
assert paths and all(pathlib.Path(p).resolve().is_relative_to(prefix) for p in paths),paths
assert openmm.version.full_version=='8.6.1.dev-b399af4'
names=[openmm.Platform.getPlatform(i).getName() for i in range(openmm.Platform.getNumPlatforms())]
assert 'CUDA' in names and 'Reference' in names
print(json.dumps({'platforms':names,'module':openmm.__file__,'nativeLibraries':paths}))
'''
        run([old['python'],'-c',smoke,prefix],env=env)
        after={rel:sha(args.old_root/rel) for rel in old['artifacts']};require(after==before,'Original runtime changed')
        report.update(buildPassed=True,python=old['python'],pythonWrapperRebuilt=False,
                      libraryPrefix=str(prefix),pluginDirectory=str(prefix/'lib/plugins'),originalNativeFilesUnchanged=True,
                      requiredEnvironment={'LD_LIBRARY_PATH':str(prefix/'lib'),'OPENMM_PLUGIN_DIR':str(prefix/'lib/plugins')},
                      artifacts={str(p.relative_to(args.output)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in prefix.rglob('*') if p.is_file() and (p.suffix=='.so' or '.so.' in p.name)},
                      precisionPatchSha256=sha(args.output/'precision-patch.json'),restartPatchSha256=sha(args.output/'restart-patch.json'))
    except Exception as error:
        report['error']={'type':type(error).__name__,'message':str(error)}
    finally:
        watchdog.cancel()
        if proc is not None and proc.poll() is None:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
        report['elapsedSeconds']=time.monotonic()-started;save();print(json.dumps({'buildPassed':report['buildPassed'],'error':report.get('error'),'elapsedSeconds':report['elapsedSeconds']}))
    return 0 if report['buildPassed'] else 1

if __name__=='__main__':sys.exit(main())
