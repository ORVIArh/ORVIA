#!/usr/bin/env python3
"""Publish actual bounded candidate-validation progress; never scientific acceptance."""
import argparse
import datetime as dt
import hashlib
import json
import math
import os
from pathlib import Path
import re
import signal
import subprocess
import time
import urllib.error
import urllib.request

JOB_ID = 'orvia-restart-validation-20261103-01'
VALIDATOR_SHA = 'b6fa2885f6e384a7eb0fb3f3622e31e9c4ac2a1a5cbbf05276d823377725e40a'
TOTAL = 400000
FORCE_LIMITS = {'energy_absolute_kJ_mol': .01, 'force_max_absolute_kJ_mol_nm': .05, 'force_relative_L2': 5e-5}
RESTART_LIMITS = {'positions_max_abs_nm': 1e-9, 'velocities_max_abs_nm_ps': 1e-8}
CONFIG = {'mode': 'full', 'experiment': 'ORVIA-ADP-PHOSPHATE-v0.3', 'replicasPerModel': 2,
    'baselineSteps': 80000, 'checkpointStep': 60000, 'replaySteps': 20000, 'totalIntegrationSteps': TOTAL,
    'timeStepPs': .0001, 'integrator': 'Verlet', 'initialVelocities': 'zero', 'precision': 'double',
    'deterministicForces': True, 'constraintTolerance': 1e-8, 'forceMarginKJMolNm': 2**26,
    'forceObservationIntervalSteps': 100, 'forceTolerances': FORCE_LIMITS,
    'restartTolerances': RESTART_LIMITS, 'maximumWallSeconds': 1200,
    'diagnosticOnly': True, 'scientificAcceptance': False}

def require(ok, message):
    if not ok:
        raise ValueError(message)

def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()

def write(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)

def comparison_passed(row, limits):
    return isinstance(row, dict) and row.get('passed') is True and all(
        type(row.get(key)) in (float, int) and math.isfinite(row[key]) and 0 <= row[key] <= limit
        for key, limit in limits.items())

def validated_completion(output):
    """Independently admit result summaries and their pinned artifacts; no scientific promotion."""
    result = json.loads((output/'result.json').read_text())
    require(result.get('schema') == 'orvia.candidate-validation-run.v1' and result.get('mode') == 'full', 'Wrong full-result identity')
    require(result.get('configuration') == CONFIG and result.get('integrationStepsExecuted') == TOTAL, 'Full workload incomplete or altered')
    require(result.get('passed') is True and result.get('candidateLongReplayPassed') is True and result.get('candidateFilesUnchanged') is True, 'Candidate validation failed')
    require(result.get('scientificAcceptance') is False and result.get('diagnosticOnly') is True and result.get('workersStillRunning') == [], 'Invalid acceptance or unfinished workers')
    require(result.get('validatorSha256') == VALIDATOR_SHA and result.get('planSha256') == sha(output/'plan.json'), 'Validator/plan identity differs')
    plan = json.loads((output/'plan.json').read_text())
    require(plan.get('configuration') == CONFIG and plan.get('validatorSha256') == VALIDATOR_SHA, 'Validation plan differs')
    require(sha(output/'source.py') == VALIDATOR_SHA, 'Archived validator differs')
    build_hash = sha(output/'candidate-build-report.json')
    require(plan.get('candidateBuildSha256') == build_hash and result.get('candidateBuildSha256') == build_hash, 'Candidate build identity differs')
    expected = {(model, replica, phase) for model in ('complex33','solvent33') for replica in (1,2) for phase in ('baseline','resume')}
    rows = result.get('phases', [])
    require(len(rows) == 8 and {(r.get('model'),r.get('replica'),r.get('phase')) for r in rows} == expected, 'Eight distinct phases required')
    checkpoints = {}
    for row in rows:
        require(row.get('passed') is True and row.get('exitCode') == 0, 'A validation phase failed')
        folder = output/f"{row['model']}-r{row['replica']}"/row['phase']
        phase_path = folder/'result.json'
        require(sha(phase_path) == row.get('resultSha256'), 'Phase evidence changed')
        phase = json.loads(phase_path.read_text())
        require(all(phase.get(key) == row[key] for key in ('model','replica','phase')) and phase.get('mode') == 'full', 'Phase identity differs')
        require(phase.get('passed') is True and phase.get('scientificAcceptance') is False and phase.get('diagnosticOnly') is True, 'Phase acceptance differs')
        require(phase.get('configuration') == CONFIG and phase.get('validatorSha256') == VALIDATOR_SHA and phase.get('candidateBuildSha256') == build_hash and phase.get('planSha256') == result['planSha256'], 'Phase binding differs')
        require(phase.get('integrationStepsExecuted') == (80000 if row['phase'] == 'baseline' else 20000), 'Phase steps incomplete')
        require(comparison_passed(phase.get('finalReferenceComparison'), FORCE_LIMITS), 'Final fresh Reference comparison failed')
        if row['phase'] == 'baseline':
            require(comparison_passed(phase.get('initialComparison'), FORCE_LIMITS), 'Initial Reference comparison failed')
            require(sha(folder/'midpoint.chk') == phase.get('checkpointSha256'), 'Midpoint checkpoint changed')
        else:
            require(phase.get('restoreBitwiseExact') == {k:True for k in ('positions','velocities','box','time')}, 'Checkpoint state restoration failed')
            require(comparison_passed(phase.get('restoreForceComparison'), FORCE_LIMITS) and comparison_passed(phase.get('continuationForceComparison'), FORCE_LIMITS) and comparison_passed(phase.get('storedReferenceComparison'), FORCE_LIMITS), 'Replay force comparison failed')
            require(comparison_passed(phase.get('continuationComparison'), RESTART_LIMITS), 'Replay coordinate/velocity tolerance failed')
        require(sha(folder/'final.chk') == phase.get('finalCheckpointSha256'), 'Final checkpoint changed')
        margins = phase.get('forceMarginObservations', [])
        require(margins and all(r.get('passed') is True and type(r.get('maxAbsoluteForceKJMolNm')) in (float,int) and math.isfinite(r['maxAbsoluteForceKJMolNm']) and 0 <= r['maxAbsoluteForceKJMolNm'] < 2**26 for r in margins), 'Force margin failed')
        artifacts = phase.get('artifacts', {})
        required = {'initial-cuda.npz','initial-reference.npz','midpoint.npz','final.npz','final-reference.npz'} if row['phase']=='baseline' else {'restored.npz','final.npz','final-reference.npz'}
        require(required.issubset(artifacts), 'Required phase artifact missing')
        for name, record in artifacts.items():
            require(Path(name).name == name, 'Unsafe artifact name')
            path = folder/name
            require(path.is_file() and not path.is_symlink() and path.stat().st_size == record['bytes'] and sha(path) == record['sha256'], 'Phase artifact changed')
        for path in folder.glob('*.chk'):
            checkpoints[str(path.relative_to(output))] = {'bytes':path.stat().st_size,'sha256':sha(path)}
    require(len(checkpoints)==12, 'Twelve native checkpoints required')
    write(output/'bridge-checkpoints.json', checkpoints)
    return sha(output/'result.json'), sha(output/'bridge-checkpoints.json')

class Publisher:
    def __init__(self, token, output):
        self.token, self.output = token, output
        self.sequence = 0
        self.pending = None
        self.last_steps = 0

    def post(self, path, payload):
        body = json.dumps(payload, separators=(',', ':'), allow_nan=False).encode()
        request = urllib.request.Request('https://orvia.fyi/api/orvia/'+path, data=body,
            headers={'Authorization':'Bearer '+self.token,'Content-Type':'application/json'}, method='POST')
        code = None
        try:
            with urllib.request.urlopen(request, timeout=3) as response:
                code = response.status
                answer = json.loads(response.read(4096))
                return code == 200 and answer.get('accepted') is True and answer.get('sequence') == payload['sequence']
        except urllib.error.HTTPError as error:
            code = error.code
        except (OSError, ValueError):
            pass
        finally:
            with (self.output/'delivery.jsonl').open('a') as stream:
                stream.write(json.dumps({'at':utc(),'endpoint':path,'sequence':payload['sequence'],'httpStatus':code})+'\n')
        return False

    def flush(self, deadline):
        while self.pending is not None and time.monotonic() < deadline:
            if self.post('worker', self.pending):
                self.sequence = self.pending['sequence']
                self.last_steps = self.pending['stepsCompleted']
                self.pending = None
                return True
            if time.monotonic()+1 >= deadline:
                break
            time.sleep(.5)
        return self.pending is None

    def emit(self, state, stage, steps, deadline, hashes=(None,None)):
        require(type(steps) is int and self.last_steps <= steps <= TOTAL, 'Invalid actual progress')
        if not self.flush(deadline):
            return False
        event = {'schemaVersion':1,'jobId':JOB_ID,'sequence':self.sequence+1,'state':state,'stage':stage,
            'stepsCompleted':steps,'stepsTotal':TOTAL,'updatedAt':utc(),'device':'NVIDIA H200',
            'diagnosticOnly':True,'scientificAcceptance':False,'resultSha256':hashes[0],'checkpointSha256':hashes[1]}
        write(self.output/f"event-{event['sequence']:05d}.json", event)
        self.pending = event
        return self.flush(deadline)

def children(pid):
    found = []
    try:
        direct = (Path('/proc')/str(pid)/'task'/str(pid)/'children').read_text().split()
    except OSError:
        return found
    for value in direct:
        child = int(value)
        found.append(child)
        found.extend(children(child))
    return found

def identity(pid):
    try:
        return (Path('/proc')/str(pid)/'stat').read_text().rsplit(')',1)[1].split()[19]
    except (OSError,IndexError):
        return None

def stop_owned(process):
    owned = {pid:identity(pid) for pid in children(process.pid)}
    if process.poll() is None:
        process.send_signal(signal.SIGTERM)
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)
    for pid, started in owned.items():
        if started is not None and identity(pid) == started:
            try:
                os.kill(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass

def actual_progress(output, minimum):
    path = output/'progress.json'
    if not path.is_file():
        return minimum, 'loading'
    progress = json.loads(path.read_text())
    steps = progress.get('steps')
    require(type(steps) is int and minimum <= steps <= TOTAL and progress.get('totalSteps') == TOTAL, 'Invalid validator progress')
    return steps, 'validating' if progress.get('stage') == 'validating' else 'simulating'

def sample_gpu(process, sequence):
    fields = subprocess.check_output(['nvidia-smi','--query-gpu=utilization.gpu,utilization.memory,memory.used,memory.total,power.draw,temperature.gpu','--format=csv,noheader,nounits'],timeout=3,text=True).strip().split(',')
    require(len(fields)==6, 'Expected one GPU metrics row')
    values = [None if value.strip() in ('N/A','[N/A]') else float(value) for value in fields]
    active = 0
    if process.poll() is None:
        for pid in children(process.pid):
            try:
                command = (Path('/proc')/str(pid)/'cmdline').read_bytes().split(b'\0')
                active += b'--worker' in command
            except OSError:
                pass
    return {'schemaVersion':1,'jobId':JOB_ID,'sequence':sequence,'updatedAt':utc(),'device':'NVIDIA H200',
        **dict(zip(('gpuUtilizationPercent','memoryUtilizationPercent','memoryUsedMiB','memoryTotalMiB','powerWatts','temperatureC'),values)),
        'activeWorkerProcesses':active}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--validator',type=Path,required=True)
    parser.add_argument('--token-file',type=Path,required=True)
    parser.add_argument('--output',type=Path,default=Path('/workspace/orvia-candidate-full-20261103-01'))
    parser.add_argument('--bridge-output',type=Path,default=Path('/workspace')/JOB_ID)
    args = parser.parse_args()
    require(args.validator.is_file() and sha(args.validator)==VALIDATOR_SHA, 'Unreviewed validator source')
    require(not args.output.exists() and not args.bridge_output.exists(), 'Preserve existing run; output already exists')
    require(args.token_file.is_file() and not args.token_file.is_symlink() and args.token_file.stat().st_mode & 0o077 == 0, 'Token file must be private and local')
    secret = args.token_file.read_text().strip()
    match = re.fullmatch(r'(?:export\s+)?ORVIA_WORKER_TOKEN\s*=\s*[\x27\x22]?([a-f0-9]{64})[\x27\x22]?',secret)
    token = match.group(1) if match else secret
    require(re.fullmatch('[a-f0-9]{64}',token) is not None, 'Invalid scoped token file')
    args.bridge_output.mkdir(parents=True,exist_ok=False)
    publisher = Publisher(token,args.bridge_output)
    require(publisher.emit('running','starting',0,time.monotonic()+12), 'Initial live telemetry not admitted; validator was not launched')
    environment = {key:value for key,value in os.environ.items() if key not in ('ORVIA_WORKER_TOKEN','RUNPOD_API_KEY','NETLIFY_AUTH_TOKEN','PYTHONPATH','PYTHONOPTIMIZE') and not key.startswith('ORVIA_WALLET')}
    environment.update(PYTHONUNBUFFERED='1',PYTHONDONTWRITEBYTECODE='1')
    process = None
    steps = 0
    metric_sequence = 0
    started = time.monotonic()
    summary = {'jobId':JOB_ID,'startedAt':utc(),'passed':False,'scientificAcceptance':False,'diagnosticOnly':True,
        'validatorSha256':VALIDATOR_SHA,'output':str(args.output),'onChainReportSubmitted':False,'automaticPodShutdown':False}
    def interrupted(signum,frame):
        raise InterruptedError('Bridge interrupted')
    signal.signal(signal.SIGTERM,interrupted)
    signal.signal(signal.SIGINT,interrupted)
    try:
        with (args.bridge_output/'validator.log').open('xb') as log:
            process = subprocess.Popen(['python3',str(args.validator),'--mode','full','--output',str(args.output)],stdout=log,stderr=subprocess.STDOUT,env=environment,start_new_session=True)
        next_update = 0
        while process.poll() is None:
            now = time.monotonic()
            if now-started > 1205:
                raise TimeoutError('Full validator exceeded its1200-second bound')
            if now >= next_update:
                steps,stage = actual_progress(args.output,steps)
                publisher.emit('running',stage,steps,time.monotonic()+3)
                try:
                    metric_sequence += 1
                    sample = sample_gpu(process,metric_sequence)
                    write(args.bridge_output/f'metric-{metric_sequence:05d}.json',sample)
                    publisher.post('gpu',sample)
                except (OSError,ValueError,subprocess.SubprocessError):
                    pass
                write(args.bridge_output/'bridge-status.json',{'jobId':JOB_ID,'updatedAt':utc(),'steps':steps,'validatorPid':process.pid,'telemetrySequenceAcknowledged':publisher.sequence})
                next_update = now+15
            time.sleep(.5)
        summary['exitCode'] = process.returncode
        steps,_ = actual_progress(args.output,steps)
        require(process.returncode==0, 'Full candidate validation failed')
        hashes = validated_completion(args.output)
        require(sha(args.validator)==VALIDATOR_SHA, 'Validator changed during execution')
        summary['passed'] = True
        summary['terminalTelemetryDelivered'] = publisher.emit('completed','finished',TOTAL,time.monotonic()+25,hashes)
    except Exception as error:
        summary['errorType'] = type(error).__name__
        summary['error'] = str(error)[:400]
        if process is not None:
            stop_owned(process)
        try:
            steps,_ = actual_progress(args.output,steps)
        except (ValueError,OSError):
            pass
        summary['terminalTelemetryDelivered'] = publisher.emit('failed','failed',steps,time.monotonic()+25)
    finally:
        if process is not None and process.poll() is None:
            stop_owned(process)
        summary.update(completedAt=utc(),steps=TOTAL if summary['passed'] else steps,elapsedSeconds=time.monotonic()-started)
        write(args.bridge_output/'bridge-result.json',summary)
        print(json.dumps(summary))
    return 0 if summary['passed'] and summary.get('terminalTelemetryDelivered') else 1

if __name__ == '__main__':
    raise SystemExit(main())
