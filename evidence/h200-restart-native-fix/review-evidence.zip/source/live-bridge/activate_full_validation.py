#!/usr/bin/env python3
"""Rotate this existing production workflow's scoped token and deploy reviewed admission.

Default: read-only plan. --apply: update exactly four production Functions values,
retain the existing RPC, and publish the already prepared local Netlify site.
Secrets remain in process memory and the private per-job file; never in output.

Runpod uploads may arrive on /workspace with fixed mode 0666 despite chmod.
Before launching, copy the uploaded token into /root/.orvia on the container's
local filesystem using exclusive creation with mode 0600, verify its mode and
exact bytes, then remove the uploaded staging copy. The bridge deliberately
rejects tokens on the shared volume when their permissions remain public.
"""
import argparse
import datetime as dt
import json
import os
from pathlib import Path
import re
import secrets
import subprocess
import time
import urllib.error
import urllib.request

SITE_ID = '3879f07b-38b6-4b0a-a45f-bc8d0fa01c95'
ACCOUNT_ID = '6ab50677d531fb1d245b798d'
JOB_ID = 'orvia-restart-validation-20261103-01'
PREVIOUS = 'orvia-stress-replay-20261102-03'
HISTORY = 'orvia-live-20261102-01,orvia-stress-20261102-02,orvia-stress-replay-20261102-03'
SITE = Path('/Users/abhijith/Documents/ChatGPT/AURA/sites/orvia')
CLI = Path('/Users/abhijith/.npm/_npx/b3ca12a867cd0704/node_modules/netlify-cli/bin/run.js')
PRIVATE = Path.home()/'.orvia/live-workflows'
TOKEN_FILE = PRIVATE/(JOB_ID+'.env')
EXPECTED = {'ORVIA_WORKFLOW_ID','ORVIA_WORKFLOW_STEPS','ORVIA_HISTORICAL_WORKFLOW_IDS','ORVIA_WORKER_TOKEN','ORVIA_RPC_URL'}

def require(value, message):
    if not value:
        raise RuntimeError(message)

def private_write(path, content):
    require(not path.is_symlink(), 'Refusing a symlink destination')
    fd = os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w') as stream:
        stream.write(content)

class API:
    def __init__(self):
        config=json.loads((Path.home()/'Library/Preferences/netlify/config.json').read_text())
        self.token=config['users'][config['userId']]['auth']['token']
        require(isinstance(self.token,str) and bool(self.token),'Existing Netlify CLI login unavailable')

    def call(self,method,path,body=None):
        request=urllib.request.Request('https://api.netlify.com/api/v1'+path,
            data=None if body is None else json.dumps(body).encode(),method=method,
            headers={'Authorization':'Bearer '+self.token,'Content-Type':'application/json'})
        try:
            with urllib.request.urlopen(request,timeout=30) as response:
                return json.load(response)
        except urllib.error.HTTPError as error:
            raise RuntimeError('Netlify '+method+' request failed with HTTP '+str(error.code)) from None
        except (OSError,ValueError):
            raise RuntimeError('Netlify '+method+' request did not complete') from None

    def variables(self):
        rows=self.call('GET',f'/accounts/{ACCOUNT_ID}/env?site_id={SITE_ID}')
        require(isinstance(rows,list),'Unexpected environment response')
        result={row['key']:row for row in rows}
        require(len(result)==len(rows) and EXPECTED.issubset(result),'Missing or duplicate ORVIA settings')
        for key in EXPECTED:
            row=result[key]
            require(row.get('scopes')==['functions'],'Existing Functions scope differs: '+key)
            require(len(row.get('values',[]))==1 and row['values'][0].get('context')=='production','Existing production context differs: '+key)
            require(row.get('is_secret') is (key in ('ORVIA_WORKER_TOKEN','ORVIA_RPC_URL')),'Existing secret flag differs: '+key)
        return result

    def set_production_value(self,key,value):
        require(key in EXPECTED-{'ORVIA_RPC_URL'},'Unapproved environment key')
        self.call('PATCH',f'/accounts/{ACCOUNT_ID}/env/{key}?site_id={SITE_ID}',{'context':'production','value':value})

def public_status():
    try:
        request=urllib.request.Request('https://orvia.fyi/api/orvia/status?activation='+str(time.time_ns()),headers={'Cache-Control':'no-cache'})
        with urllib.request.urlopen(request,timeout=20) as response:
            return json.load(response)
    except (OSError,ValueError):
        raise RuntimeError('Public status verification unavailable') from None

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--apply',action='store_true',help='Activate the prepared workflow and deploy production')
    args=parser.parse_args()
    require(json.loads((SITE/'.netlify/state.json').read_text()).get('siteId')==SITE_ID,'Local project is linked to a different site')
    require(CLI.is_file(),'Reviewed Netlify CLI unavailable')
    api=API()
    before=api.variables()
    old=before['ORVIA_WORKFLOW_ID']['values'][0].get('value')
    require(old in (PREVIOUS,JOB_ID),'Unexpected current workflow; preserve its configuration')
    plan={'apply':args.apply,'site':'https://orvia.fyi','siteId':SITE_ID,'previousWorkflow':old,'nextWorkflow':JOB_ID,
        'steps':400000,'history':HISTORY,'scope':'functions','context':'production','rpcChanged':False,
        'tokenFile':str(TOKEN_FILE),'uploadBasename':TOKEN_FILE.name,
        'remoteTokenFile':'/root/.orvia/'+TOKEN_FILE.name,
        'remoteTokenStaging':'Upload temporarily to /workspace, then exclusively copy into /root/.orvia with mode 0600 on the local container filesystem. Verify exact bytes and effective permissions before removing the staging copy. Do not launch against the shared-volume copy.',
        'deploymentCommand':['node',str(CLI),'deploy','--prod','--no-build','--dir','dist','--functions','netlify/functions','--skip-functions-cache','--timeout','120','--message','Connect full H200 restart validation','--json'],
        'remoteLaunch':['python3','/workspace/orvia-full-validation-bridge-v1/full_validation_bridge.py','--validator','/workspace/validate_candidate.py','--token-file','/root/.orvia/'+TOKEN_FILE.name]}
    if not args.apply:
        print(json.dumps(plan,indent=2))
        return
    live=public_status()
    require(live.get('gpu',{}).get('jobId') in (PREVIOUS,JOB_ID),'Live workflow differs from reviewed configuration')
    require(live['gpu'].get('state') not in ('running','queued'),'A workflow is active; preserve its token and job identity')
    if old==JOB_ID:
        require(TOKEN_FILE.is_file(),'Existing target workflow has no matching local token; do not rotate blindly')
    require(not PRIVATE.is_symlink(),'Unsafe private workflow directory')
    PRIVATE.mkdir(parents=True,exist_ok=True,mode=0o700)
    if TOKEN_FILE.exists():
        require(TOKEN_FILE.is_file() and not TOKEN_FILE.is_symlink() and TOKEN_FILE.stat().st_mode&0o077==0,'Unsafe existing per-job token file')
        match=re.fullmatch(r'ORVIA_WORKER_TOKEN=([a-f0-9]{64})\n?',TOKEN_FILE.read_text())
        require(match is not None,'Invalid existing per-job token file')
        scoped_token=match.group(1)
    else:
        scoped_token=secrets.token_hex(32)
        private_write(TOKEN_FILE,'ORVIA_WORKER_TOKEN='+scoped_token+'\n')
    changed=[]
    values={'ORVIA_HISTORICAL_WORKFLOW_IDS':HISTORY,'ORVIA_WORKFLOW_STEPS':'400000','ORVIA_WORKFLOW_ID':JOB_ID,'ORVIA_WORKER_TOKEN':scoped_token}
    for key,value in values.items():
        api.set_production_value(key,value)
        changed.append(key)
    after=api.variables()
    for key,value in values.items():
        if key!='ORVIA_WORKER_TOKEN':
            require(after[key]['values'][0].get('value')==value,'Environment value verification failed: '+key)
    for key,row in before.items():
        if key not in changed:
            require(after.get(key)==row,'An unrelated setting changed; deployment stopped')
    private_run=PRIVATE/JOB_ID
    require(not private_run.is_symlink(),'Unsafe private receipt directory')
    private_run.mkdir(exist_ok=True,mode=0o700)
    result=subprocess.run(plan['deploymentCommand'],cwd=SITE,capture_output=True,text=True,timeout=180,env={**os.environ,'NETLIFY_AUTH_TOKEN':api.token})
    stamp=dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    private_write(private_run/(stamp+'-deploy.stdout'),result.stdout)
    private_write(private_run/(stamp+'-deploy.stderr'),result.stderr)
    require(result.returncode==0,'Netlify deployment did not finish; private diagnostics retained at '+str(private_run))
    try:
        deployed=json.loads(result.stdout)
    except ValueError:
        raise RuntimeError('Netlify returned no structured deployment receipt; inspect private diagnostics') from None
    verified=None
    for attempt in range(6):
        try:
            state=public_status()
            if state.get('gpu',{}).get('jobId')==JOB_ID:
                verified=state
                break
        except RuntimeError:
            pass
        if attempt<5:
            time.sleep(3)
    receipt={**plan,'deployedAt':dt.datetime.now(dt.timezone.utc).isoformat(),'changedKeys':changed,
        'rpcPreserved':True,'deployId':deployed.get('deploy_id'),'deployUrl':deployed.get('deploy_url'),
        'publicWorkflowVerified':verified is not None,'localTokenPermissions':'0600','privateDiagnostics':str(private_run)}
    receipt.pop('deploymentCommand',None)
    output=Path(__file__).resolve().parent/('activation-'+stamp+'.json')
    output.write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))
    require(verified is not None,'Deployment completed, but live workflow verification is pending; do not launch until verified')

if __name__=='__main__':
    try:
        main()
    except Exception as error:
        # Only controlled messages are emitted; HTTP bodies and credential values are never logged.
        message=str(error) if isinstance(error,RuntimeError) else 'Activation stopped: '+type(error).__name__
        print(json.dumps({'activationSucceeded':False,'error':message}))
        raise SystemExit(1)
