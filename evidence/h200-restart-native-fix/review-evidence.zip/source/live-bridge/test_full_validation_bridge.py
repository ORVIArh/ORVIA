import importlib.util
import json
from pathlib import Path
import tempfile
import time
import unittest

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('bridge', ROOT/'full_validation_bridge.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)

def fixture(root):
    validator = ROOT.parent/'native-fix/validate_candidate.py'
    (root/'source.py').write_bytes(validator.read_bytes())
    (root/'candidate-build-report.json').write_text('{}')
    build = b.sha(root/'candidate-build-report.json')
    b.write(root/'plan.json', {'configuration':b.CONFIG,'validatorSha256':b.VALIDATOR_SHA,'candidateBuildSha256':build})
    plan = b.sha(root/'plan.json')
    rows = []
    force = dict.fromkeys(b.FORCE_LIMITS,0.0) | {'passed':True}
    restart = dict.fromkeys(b.RESTART_LIMITS,0.0) | {'passed':True}
    for model in ('complex33','solvent33'):
        for replica in (1,2):
            for phase in ('baseline','resume'):
                folder = root/f'{model}-r{replica}'/phase
                folder.mkdir(parents=True)
                (folder/'final.chk').write_bytes(b'fake checkpoint')
                value = {'model':model,'replica':replica,'phase':phase,'mode':'full','passed':True,
                    'scientificAcceptance':False,'diagnosticOnly':True,'configuration':b.CONFIG,
                    'validatorSha256':b.VALIDATOR_SHA,'candidateBuildSha256':build,'planSha256':plan,
                    'integrationStepsExecuted':80000 if phase=='baseline' else 20000,
                    'finalReferenceComparison':force,'initialComparison':force,'restoreForceComparison':force,
                    'continuationForceComparison':force,'storedReferenceComparison':force,'continuationComparison':restart,
                    'restoreBitwiseExact':dict.fromkeys(('positions','velocities','box','time'),True),
                    'finalCheckpointSha256':b.sha(folder/'final.chk'),
                    'forceMarginObservations':[{'passed':True,'maxAbsoluteForceKJMolNm':123.0}], 'artifacts':{}}
                artifacts = ['initial-cuda.npz','initial-reference.npz','midpoint.npz'] if phase=='baseline' else ['restored.npz']
                for name in artifacts+['final.npz','final-reference.npz']:
                    p = folder/name;p.write_bytes(b'fake arrays')
                    value['artifacts'][name]={'bytes':p.stat().st_size,'sha256':b.sha(p)}
                if phase=='baseline':
                    (folder/'midpoint.chk').write_bytes(b'fake checkpoint')
                    value['checkpointSha256']=b.sha(folder/'midpoint.chk')
                b.write(folder/'result.json',value)
                rows.append({'model':model,'replica':replica,'phase':phase,'passed':True,'exitCode':0,'resultSha256':b.sha(folder/'result.json')})
    result = {'schema':'orvia.candidate-validation-run.v1','mode':'full','configuration':b.CONFIG,
        'integrationStepsExecuted':400000,'passed':True,'candidateLongReplayPassed':True,'candidateFilesUnchanged':True,
        'scientificAcceptance':False,'diagnosticOnly':True,'workersStillRunning':[],
        'validatorSha256':b.VALIDATOR_SHA,'planSha256':plan,'candidateBuildSha256':build,'phases':rows}
    b.write(root/'result.json',result)
    return result

class CompletionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name);self.result=fixture(self.root)
    def tearDown(self):self.temp.cleanup()
    def test_full_bound_success_only(self):
        hashes=b.validated_completion(self.root)
        self.assertEqual(hashes[0],b.sha(self.root/'result.json'))
        self.assertEqual(len(json.loads((self.root/'bridge-checkpoints.json').read_text())),12)
    def test_partial_screen_failed_or_unfinished_results_rejected(self):
        for change in ({'integrationStepsExecuted':399900},{'mode':'screen'},{'passed':False},
                       {'scientificAcceptance':True},{'candidateFilesUnchanged':False},{'workersStillRunning':[123]}):
            b.write(self.root/'result.json',self.result|change)
            with self.assertRaises(ValueError):b.validated_completion(self.root)
    def test_artifact_tampering_rejected(self):
        (self.root/'complex33-r1/resume/final.npz').write_bytes(b'changed arrays')
        with self.assertRaises(ValueError):b.validated_completion(self.root)
    def test_claimed_pass_cannot_override_unchanged_tolerance(self):
        path=self.root/'complex33-r1/resume/result.json'
        value=json.loads(path.read_text());value['continuationComparison']['positions_max_abs_nm']=1e-7
        b.write(path,value)
        for row in self.result['phases']:
            if (row['model'],row['replica'],row['phase'])==('complex33',1,'resume'):row['resultSha256']=b.sha(path)
        b.write(self.root/'result.json',self.result)
        with self.assertRaisesRegex(ValueError,'tolerance'):b.validated_completion(self.root)
    def test_pending_events_retry_identically_before_advancing(self):
        publisher=b.Publisher('unused',self.root);sent=[]
        publisher.post=lambda path,payload:sent.append(json.dumps(payload,sort_keys=True)) or False
        self.assertFalse(publisher.emit('running','starting',0,time.monotonic()+.01))
        first=sent[0]
        publisher.post=lambda path,payload:sent.append(json.dumps(payload,sort_keys=True)) or True
        self.assertTrue(publisher.emit('running','simulating',100,time.monotonic()+1))
        self.assertEqual(first,sent[1]);self.assertEqual(publisher.sequence,2)
        self.assertFalse(json.loads(sent[-1])['scientificAcceptance'])

if __name__=='__main__':unittest.main()
