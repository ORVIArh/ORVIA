import importlib.util
from pathlib import Path
import tempfile
import unittest

spec=importlib.util.spec_from_file_location('activation',Path(__file__).with_name('activate_full_validation.py'))
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)

class SafetyTests(unittest.TestCase):
    def api(self):
        api=object.__new__(a.API)
        rows=[{'key':key,'scopes':['functions'],'is_secret':key in ('ORVIA_WORKER_TOKEN','ORVIA_RPC_URL'),
               'values':[{'context':'production','value':'placeholder'}]} for key in a.EXPECTED]
        api.call=lambda *args,**kwargs:rows
        return api,rows
    def test_exact_scope_and_context_required(self):
        api,rows=self.api();self.assertEqual(set(api.variables()),a.EXPECTED)
        rows[0]['scopes']=['functions','builds']
        with self.assertRaises(RuntimeError):api.variables()
        rows[0]['scopes']=['functions'];rows[0]['values'].append({'context':'all','value':'placeholder'})
        with self.assertRaises(RuntimeError):api.variables()
    def test_value_only_patch_cannot_mutate_rpc_or_scope(self):
        api,rows=self.api();calls=[];api.call=lambda *args:calls.append(args)
        api.set_production_value('ORVIA_WORKFLOW_ID',a.JOB_ID)
        self.assertEqual(calls[0][0],'PATCH')
        self.assertEqual(calls[0][2],{'context':'production','value':a.JOB_ID})
        self.assertIn('site_id='+a.SITE_ID,calls[0][1])
        with self.assertRaises(RuntimeError):api.set_production_value('ORVIA_RPC_URL','changed')
        self.assertEqual(len(calls),1)
    def test_private_writer_is_exclusive_and_rejects_symlinks(self):
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder)/'secret.env';a.private_write(p,'test')
            self.assertEqual(p.stat().st_mode&0o777,0o600)
            with self.assertRaises(FileExistsError):a.private_write(p,'replace')
            link=Path(folder)/'alias';link.symlink_to(p)
            with self.assertRaises(RuntimeError):a.private_write(link,'replace')

if __name__=='__main__':unittest.main()
