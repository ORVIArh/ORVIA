#!/usr/bin/env python3
"""Independent read-only validation of downloaded short restart evidence."""
import argparse
import hashlib
import json
import math
from pathlib import Path

SOURCE_SHA = 'f126b0ee8bdabc3063e42229d28335a85b5928dd45287d092660cc425ac6ac5e'
LIMITS = {'positions_max_abs_nm': 1e-9, 'velocities_max_abs_nm_ps': 1e-8,
          'energy_absolute_kJ_mol': .01, 'force_max_absolute_kJ_mol_nm': .05,
          'force_relative_L2': 5e-5}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def require(value, message):
    if not value:
        raise ValueError(message)

def gate(row):
    for key, limit in LIMITS.items():
        value = row.get(key)
        require(type(value) in (int,float) and math.isfinite(value) and value >= 0, 'Invalid metric '+key)
    actual = all(row[key] <= limit for key, limit in LIMITS.items())
    require(row.get('strictPassed') is actual, 'Stored comparison pass flag does not match unchanged thresholds')
    require(set(row.get('stateBitwiseExact',{})) == {'positions','velocities','box','time'}, 'Exact restore fields missing')
    require(all(type(value) is bool for value in row['stateBitwiseExact'].values()),'Exact restore flags invalid')
    return actual

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('root',type=Path)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args(); root=args.root
    parent=json.loads((root/'result.json').read_text())
    require(parent.get('schema')=='orvia.short-restart-investigation.v1','Wrong parent schema')
    require(parent.get('sourceSha256')==SOURCE_SHA and sha(root/'source.py')==SOURCE_SHA,'Wrong executed source')
    for key, expected in {'diagnosticOnly':True,'scientificAcceptance':False,'onChainReportSubmitted':False,
                          'automaticPodShutdown':False,'originalAttemptRemainsFailed':True,'diagnosticCompleted':True,
                          'originalEvidenceUnchanged':True,'plannedIntegrationSteps':1000,'maximumWallSeconds':280}.items():
        require(parent.get(key)==expected,'Parent mismatch: '+key)
    require(set(v['model'] for v in parent['models'])=={'complex33','solvent33'} and len(parent['models'])==2,'Wrong model list')
    rows=[]; strict=[]; total=0
    for item in parent['models']:
        model=item['model']; p=root/model/'result.json'; value=json.loads(p.read_text())
        require(sha(p)==item['sha256'] and value==item['result'],'Parent-child result binding failed')
        require(value.get('sourceSha256')==SOURCE_SHA,'Wrong child source')
        require(value.get('model')==model and value.get('mode')=='model','Wrong child identity')
        require(value.get('diagnosticCompleted') is True and value.get('scientificAcceptance') is False,'Wrong child completion')
        require(value.get('integrationStepsExecuted')==500,'Wrong child total steps')
        require(sha(root/model/'diagnostic-midpoint.chk')==value['diagnosticCheckpointSha256'],'Checkpoint hash mismatch')
        total+=value['integrationStepsExecuted']
        original_pass=gate(value['originalCheckpointRestore'])
        restore=all(value['originalCheckpointRestore']['stateBitwiseExact'].values())
        comparisons=value['comparisons']
        require(set(comparisons)=={'sameContext','newContext','freshProcess'},'Wrong comparison branches')
        metric_pass=[]
        for branch, stages in comparisons.items():
            require(set(stages)=={'0','1','10','100'},'Wrong observation stages')
            restore=restore and all(stages['0']['stateBitwiseExact'].values())
            for step, row in stages.items():
                metric_pass.append(gate(row))
                rows.append({'model':model,'branch':branch,'step':int(step),**row})
        expected=restore and original_pass and all(metric_pass)
        require(value.get('exactRestorationPassed') is restore,'Wrong exact restoration flag')
        require(value.get('strictReplayPassed') is expected,'Wrong model pass flag')
        fresh=json.loads((root/model/'fresh'/'result.json').read_text())
        require(fresh.get('mode')=='fresh' and fresh.get('model')==model and fresh.get('sourceSha256')==SOURCE_SHA,'Wrong fresh process')
        require(fresh.get('integrationStepsExecuted')==100 and fresh.get('diagnosticCompleted') is True,'Fresh process incomplete')
        strict.append(expected)
    require(total==1000,'Wrong aggregate step count')
    require(parent.get('strictReplayPassed') is all(strict),'Wrong aggregate pass flag')
    out={'schema':'orvia.short-restart-independent-review.v1','structuralReviewPassed':True,
         'strictReplayPassed':all(strict),'integrationStepsExecuted':total,'scientificAcceptance':False,
         'historicalFailedAttemptResolved':False,'sourceSha256':SOURCE_SHA,'parentSha256':sha(root/'result.json'),
         'originalEvidenceUnchangedReported':True,'independentOriginalEvidenceRehash':False,
         'scope':'Verifies source and result bindings and recomputes every threshold gate; original-preservation flag is worker-reported unless independently rehashed remotely.',
         'rows':rows}
    args.output.write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
    print(json.dumps({k:out[k] for k in ('structuralReviewPassed','strictReplayPassed','integrationStepsExecuted','scientificAcceptance')}))

if __name__=='__main__':
    main()
