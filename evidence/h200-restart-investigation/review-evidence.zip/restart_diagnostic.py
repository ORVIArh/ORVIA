#!/usr/bin/env python3
"""Bounded restart diagnosis. Never changes old evidence or submits chain reports."""
import argparse
import datetime as dt
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import sysconfig
import threading
import time

# Dynamic imports must never create caches in the frozen source directories.
sys.dont_write_bytecode = True

STRESS_SHA = '5b781a291219256f8450c6d016011b85a430f8bdc184a54256dba6b28276325b'
CHECKPOINTS = {'complex33': 'e9e27d89602d37d5148cb39596233d28892027b972599877fb17a0e796660bf9',
               'solvent33': 'c3febb92c8dc7cbee0a2f875308d206c5f92993e99b808022d08e6db9524ec4b'}
MIDPOINTS = {'complex33':'6fcab5822476b7af159eebc35db83081d03783dd3e333ca1977a05e04e9e2b77',
             'solvent33':'a2ee4dbce2f4a0b677c5177fe8a867f1a43f6bd1c1e05c5e8a86b52cfa322b01'}
STAGES = (0, 1, 10, 100)

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for block in iter(lambda: f.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()

def require(ok, message):
    if not ok:
        raise ValueError(message)

def write(p, value):
    p = Path(p)
    p.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')

def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat()

def load(args):
    p = args.original_packet/'stress_parallel.py'
    require(sha(p) == STRESS_SHA, 'Frozen stress source changed')
    spec = importlib.util.spec_from_file_location('frozen_stress_diagnostic', p)
    original = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(original)
    w, manifest = original.load_v4(args.bundle)
    original.verify_packet(w, args.original_packet)
    engine, env = w.engine_environment(args.engine_build_report)
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    return original, w, manifest, engine, env

def options(args, mode, output, model=None, checkpoint=None):
    result = [str(Path(__file__).resolve()), '--mode', mode, '--output', str(output)]
    for name in ('bundle', 'original_packet', 'original_output', 'engine_build_report', 'environment_binding'):
        result += ['--'+name.replace('_','-'), str(getattr(args,name))]
    if model: result += ['--model', model]
    if checkpoint: result += ['--checkpoint', str(checkpoint)]
    return result

def worker(args):
    original, w, manifest, engine, env = load(args)
    import numpy as np
    import openmm as mm
    from openmm import unit
    require(Path(sys.prefix).resolve() == Path(engine['python']).parent.parent.resolve(), 'Wrong Python environment')
    require(mm.version.full_version == '8.6.1.dev-b399af4' and np.__version__ == '2.5.4', 'Wrong engine versions')
    for name, record in json.loads((args.bundle/'engine-export-manifest.json').read_text())['files'].items():
        if name.startswith('python-site/'):
            p = Path(sysconfig.get_paths()['purelib'])/name[len('python-site/'):]
            require(p.is_file() and p.stat().st_size == record['bytes'] and sha(p) == record['sha256'], 'Runtime wrapper changed')
    binding = json.loads(args.environment_binding.read_text())
    require(binding['historicalBuildReportSha256'] == w.ENGINE_SHA, 'Engine binding differs')
    require(binding['exportManifestSha256'] == sha(args.bundle/'engine-export-manifest.json'), 'Export binding differs')
    args.output.mkdir(parents=True, exist_ok=False)
    report = {'schema':'orvia.short-restart-diagnostic.v1', 'model':args.model, 'mode':args.mode,
              'startedAt':utc(), 'diagnosticOnly':True, 'scientificAcceptance':False,
              'sourceSha256':sha(__file__), 'integrationStepsExecuted':0, 'contexts':[]}
    system = mm.XmlSerializer.deserialize((args.bundle/'inputs'/args.model/'system.xml').read_text())
    require(system.getNumParticles() == {'complex33':132935,'solvent33':151505}[args.model], 'Wrong full model')
    nb = [f for f in system.getForces() if isinstance(f,mm.NonbondedForce)]
    require(len(nb)==1 and nb[0].getNonbondedMethod()==mm.NonbondedForce.PME, 'Wrong PME system')
    contexts=[]
    def context():
        integrator = mm.VerletIntegrator(w.DT_PS*unit.picoseconds)
        integrator.setConstraintTolerance(1e-8)
        props={'Precision':'double','DeviceIndex':'0','UseCpuPme':'false','DeterministicForces':'true'}
        ctx=mm.Context(system,integrator,mm.Platform.getPlatformByName('CUDA'),props)
        actual={k:ctx.getPlatform().getPropertyValue(ctx,k) for k in ctx.getPlatform().getPropertyNames()}
        require(all(actual[k]==v for k,v in props.items()), 'CUDA settings changed')
        pme=nb[0].getPMEParametersInContext(ctx)
        alpha=pme[0].value_in_unit(1/unit.nanometer) if hasattr(pme[0],'value_in_unit') else float(pme[0])
        actual_pme=[float(alpha),*map(int,pme[1:])]
        require(actual_pme==manifest['models'][args.model]['pme'],'PME grid changed')
        report['contexts'].append({'properties':actual,'pme':actual_pme})
        contexts.append((ctx,integrator))
        return ctx,integrator
    def observe(ctx):
        s=ctx.getState(getPositions=True,getVelocities=True,getEnergy=True,getForces=True)
        obs={'positions':np.asarray(s.getPositions(asNumpy=True).value_in_unit(unit.nanometer)),
             'velocities':np.asarray(s.getVelocities(asNumpy=True).value_in_unit(unit.nanometer/unit.picosecond)),
             'forces':np.asarray(s.getForces(asNumpy=True).value_in_unit(unit.kilojoule_per_mole/unit.nanometer)),
             'energy':np.asarray(s.getPotentialEnergy().value_in_unit(unit.kilojoule_per_mole)),
             'kineticEnergy':np.asarray(s.getKineticEnergy().value_in_unit(unit.kilojoule_per_mole)),
             'box':np.asarray(s.getPeriodicBoxVectors(asNumpy=True).value_in_unit(unit.nanometer)),
             'time':np.asarray(s.getTime().value_in_unit(unit.picosecond))}
        require(all(np.isfinite(v).all() for v in obs.values()),'Nonfinite observation')
        require(float(np.max(np.abs(obs['forces']))) < w.FORCE_MARGIN,'Force margin failed')
        return obs
    def compare(ref,obs):
        delta=obs['forces']-ref['forces']
        value={'positions_max_abs_nm':float(np.max(np.abs(obs['positions']-ref['positions']))),
               'velocities_max_abs_nm_ps':float(np.max(np.abs(obs['velocities']-ref['velocities']))),
               'force_max_absolute_kJ_mol_nm':float(np.max(np.abs(delta))),
               'force_relative_L2':float(np.linalg.norm(delta))/max(float(np.linalg.norm(ref['forces'])),1e-12),
               'energy_absolute_kJ_mol':float(np.abs(obs['energy']-ref['energy']))}
        value['stateBitwiseExact']={k:bool(np.array_equal(ref[k],obs[k])) for k in ('positions','velocities','box','time')}
        value['forcesBitwiseExact']=bool(np.array_equal(ref['forces'],obs['forces']))
        value['strictPassed']=all(value[k]<=v for k,v in {**w.TOLERANCES,**w.RESTART_TOLERANCES}.items())
        return value
    def trajectory(label,ctx,integrator,reference=None):
        results={}; prior=0; comparisons={}
        for step in STAGES:
            if step:
                integrator.step(step-prior)
                report['integrationStepsExecuted']+=step-prior
            obs=observe(ctx); results[step]=obs; prior=step
            np.savez_compressed(args.output/f'{label}-{step}.npz',**obs)
            if reference is not None: comparisons[str(step)]=compare(reference[step],obs)
            write(args.output/'progress.json',{'stage':label,'step':step,'integrationStepsExecuted':report['integrationStepsExecuted'],'updatedAt':utc()})
        return results,comparisons
    if args.mode=='fresh':
        ctx,integrator=context(); ctx.loadCheckpoint(args.checkpoint.read_bytes())
        trajectory('fresh-process',ctx,integrator)
    else:
        base=args.original_output/f'{args.model}-r1'/'baseline'
        require(sha(base/'midpoint.chk')==CHECKPOINTS[args.model],'Original checkpoint changed')
        require(sha(base/'midpoint.npz')==MIDPOINTS[args.model],'Original midpoint arrays changed')
        ctx,integrator=context(); ctx.loadCheckpoint((base/'midpoint.chk').read_bytes())
        restored=observe(ctx)
        with np.load(base/'midpoint.npz',allow_pickle=False) as saved:
            report['originalCheckpointRestore']=compare(saved,restored)
        np.savez_compressed(args.output/'original-restored.npz',**restored)
        integrator.step(100); report['integrationStepsExecuted']+=100
        # Every continuation starts at this same new, explicitly recorded checkpoint.
        observe(ctx)
        checkpoint=args.output/'diagnostic-midpoint.chk'
        checkpoint.write_bytes(ctx.createCheckpoint())
        report['diagnosticCheckpointSha256']=sha(checkpoint)
        reference,_=trajectory('uninterrupted',ctx,integrator)
        ctx.loadCheckpoint(checkpoint.read_bytes())
        _,same=trajectory('same-context',ctx,integrator,reference)
        new,new_integrator=context(); new.loadCheckpoint(checkpoint.read_bytes())
        _,new_comparisons=trajectory('new-context',new,new_integrator,reference)
        subprocess.run([engine['python'],*options(args,'fresh',args.output/'fresh',args.model,checkpoint)],
                       env=env,check=True,timeout=120)
        fresh={}
        for step in STAGES:
            with np.load(args.output/'fresh'/f'fresh-process-{step}.npz',allow_pickle=False) as obs:
                fresh[str(step)]=compare(reference[step],obs)
        report['integrationStepsExecuted']+=100
        report['comparisons']={'sameContext':same,'newContext':new_comparisons,'freshProcess':fresh}
        report['exactRestorationPassed']=all(report['originalCheckpointRestore']['stateBitwiseExact'].values()) and all(
            all(mode['0']['stateBitwiseExact'].values()) for mode in report['comparisons'].values())
        report['strictReplayPassed']=report['exactRestorationPassed'] and report['originalCheckpointRestore']['strictPassed'] and all(
            row['strictPassed'] for mode in report['comparisons'].values() for row in mode.values())
    report.update(completedAt=utc(),diagnosticCompleted=True)
    write(args.output/'result.json',report)
    return 0

def supervise(args):
    for old in (args.bundle,args.original_output,args.original_packet,args.engine_build_report.parent,args.environment_binding.parent):
        require(not args.output.resolve().is_relative_to(old.resolve()),'Output must be outside all original evidence/source/runtime folders')
    started=time.monotonic(); args.output.mkdir(parents=True,exist_ok=False)
    def deadline(signum, frame):
        raise TimeoutError('Independent diagnostic wall-clock cutoff reached')
    signal.signal(signal.SIGTERM,deadline)
    signal.signal(signal.SIGINT,deadline)
    watchdog=threading.Timer(280,lambda:os.kill(os.getpid(),signal.SIGTERM))
    watchdog.daemon=True
    watchdog.start()
    report={'schema':'orvia.short-restart-investigation.v1','startedAt':utc(),'diagnosticOnly':True,
            'scientificAcceptance':False,'onChainReportSubmitted':False,'automaticPodShutdown':False,
            'originalAttemptRemainsFailed':True,'sourceSha256':sha(__file__),'models':[],
            'maximumWallSeconds':280,'plannedIntegrationSteps':1000,
            'scope':'Short diagnostic from historical checkpoints; a pass does not resolve the failed 20000-step continuation test'}
    def inventory():
        return {str(p.relative_to(args.original_output)):{'sha256':sha(p),'bytes':p.stat().st_size}
                for p in sorted(args.original_output.rglob('*')) if p.is_file()}
    proc=None
    try:
        original,w,manifest,engine,env=load(args)
        require(not any(p.is_symlink() for p in args.original_output.rglob('*')),'Unsafe original evidence')
        before=inventory(); write(args.output/'original-inventory.json',before)
        (args.output/'source.py').write_bytes(Path(__file__).read_bytes())
        for model in ('complex33','solvent33'):
            remaining=270-(time.monotonic()-started)
            require(remaining>0,'Diagnostic deadline reached')
            with (args.output/f'{model}.log').open('w') as log:
                proc=subprocess.Popen([engine['python'],*options(args,'model',args.output/model,model)],env=env,
                                      stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
                proc.wait(timeout=remaining)
            require(proc.returncode==0,f'{model} diagnostic worker failed; inspect saved log')
            result=json.loads((args.output/model/'result.json').read_text())
            report['models'].append({'model':model,'result':result,'sha256':sha(args.output/model/'result.json')})
        report['originalEvidenceUnchanged']=inventory()==before
        require(report['originalEvidenceUnchanged'],'Original evidence inventory changed')
        report['diagnosticCompleted']=True
        report['strictReplayPassed']=all(r['result']['strictReplayPassed'] for r in report['models'])
    except Exception as error:
        report['diagnosticCompleted']=False
        report['error']={'type':type(error).__name__,'message':str(error)[:1000]}
    finally:
        watchdog.cancel()
        if proc is not None and proc.poll() is None:
            os.killpg(proc.pid,signal.SIGKILL); proc.wait()
        report.update(completedAt=utc(),elapsedSeconds=time.monotonic()-started)
        write(args.output/'result.json',report)
        print(json.dumps({k:report.get(k) for k in ('diagnosticCompleted','strictReplayPassed','elapsedSeconds','error')}))
    return 0 if report.get('diagnosticCompleted') else 1

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name,default in (('bundle','/workspace/orvia-live-workflow-v4'),('original-packet','/workspace/orvia-h200-stress-v1'),
                         ('original-output','/workspace/orvia-stress-20261102-02'),('engine-build-report','/workspace/orvia-native-double-build-r2/build-report.json'),
                         ('environment-binding','/workspace/orvia-live-engine-restore/environment-binding.json')):
        parser.add_argument('--'+name,type=Path,default=Path(default))
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--mode',choices=('supervisor','model','fresh'),default='supervisor')
    parser.add_argument('--model',choices=('complex33','solvent33'))
    parser.add_argument('--checkpoint',type=Path)
    args=parser.parse_args()
    return supervise(args) if args.mode=='supervisor' else worker(args)

if __name__=='__main__':
    sys.exit(main())
