import * as THREE from 'three';
import { mergeVertices, mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { MarchingCubes } from 'three/addons/objects/MarchingCubes.js';

/* The ventricular, atrial and principal coronary surfaces are BodyParts3D
 * anatomy (CC BY 4.0). Major-vessel centerlines are reconstructed from that
 * atlas to remove coarse closed caps. Fine coronary branches and aortic arch
 * branches are illustrative anatomical refinements, not patient measurements.
 * Everything is baked once into the atlas's original world coordinate frame. */

const V = p => new THREE.Vector3(...p);

function weldedGeometry(input) {
  // GLTF positions share a stride-6 interleaved buffer with normals. Copy
  // through accessors before any packed-array smoothing; mergeVertices keeps
  // source interleaving, so deleting the normal attribute is insufficient.
  const geometry = new THREE.BufferGeometry();
  const source=input.attributes.position,packed=new Float32Array(source.count*3);
  for(let i=0;i<source.count;i++) {packed[i*3]=source.getX(i);packed[i*3+1]=source.getY(i);packed[i*3+2]=source.getZ(i);}
  geometry.setAttribute('position',new THREE.Float32BufferAttribute(packed,3));
  if(input.index)geometry.setIndex(input.index.clone());
  // Imported vertices split by old face normals are now welded by position.
  const welded = mergeVertices(geometry, 0.00004);
  geometry.dispose();
  return welded;
}

function smoothSurface(geometry, passes = 3, lambda = .27, mu = -.28, mask = null) {
  const p = geometry.attributes.position, ids = geometry.index.array;
  const neighbors = Array.from({ length:p.count }, () => new Set());
  for (let i = 0; i < ids.length; i += 3) {
    const a=ids[i], b=ids[i+1], c=ids[i+2];
    neighbors[a].add(b).add(c); neighbors[b].add(a).add(c); neighbors[c].add(a).add(b);
  }
  const adjacency=neighbors.map(s=>Array.from(s));
  const next=new Float32Array(p.array.length);
  for (let pass=0; pass<passes; pass++) for (const weight of [lambda,mu]) {
    for(let i=0;i<p.count;i++) {
      const list=adjacency[i];
      for(let k=0;k<3;k++) {
        let sum=0; for(const j of list)sum+=p.array[j*3+k];
        const current=p.array[i*3+k];
        next[i*3+k]=list.length?current+weight*(mask?mask[i]:1)*(sum/list.length-current):current;
      }
    }
    p.array.set(next);
  }
  p.needsUpdate=true;
  geometry.computeVertexNormals();
  geometry.computeBoundingBox();geometry.computeBoundingSphere();
  return geometry;
}

function curveStroke(points,radii,{startOpen=true,endOpen=true,segments=48}={}) {
  const curve=new THREE.CatmullRomCurve3(points.map(V),false,'centripetal');
  const sampled=curve.getPoints(segments);
  const rs=sampled.map((_,i)=>{
    const t=i/segments*(radii.length-1),n=Math.floor(t);
    return THREE.MathUtils.lerp(radii[n],radii[Math.min(n+1,radii.length-1)],t-n);
  });
  return {points:sampled,radii:rs,startOpen,endOpen};
}

const smoothMin=(a,b,k)=>{
  const h=Math.max(k-Math.abs(a-b),0)/k;
  return Math.min(a,b)-h*h*k*.25;
};

/* Smooth unions of swept circular lumens produce one continuous arterial
 * wall, including branch junctions. The lumen extends beyond cut planes:
 * visible vessel ends are actual holes with inner surfaces and annular rims. */
function hollowVessel(strokes,{resolution=96,wall=.047,blend=.055}={}) {
  const bounds=new THREE.Box3();
  for(const stroke of strokes)for(let i=0;i<stroke.points.length;i++) {
    const r=stroke.radii[i]+.16,p=stroke.points[i];
    bounds.expandByPoint(p.clone().addScalar(r));bounds.expandByPoint(p.clone().addScalar(-r));
  }
  const center=bounds.getCenter(new THREE.Vector3());
  const extent=bounds.getSize(new THREE.Vector3());
  const length=Math.max(extent.x,extent.y,extent.z)+.12,half=length/2;
  const origin=center.clone().addScalar(-half),step=length/resolution;
  const size=resolution**3,outer=new Float32Array(size).fill(10),inner=new Float32Array(size).fill(10);
  const n=resolution,n2=n*n;
  function rasterStroke(stroke,isInner) {
    const target=new Float32Array(size).fill(10);
    const ps=stroke.points.map(p=>p.clone()),rs=[...stroke.radii];
    if(isInner) {
      for(let i=0;i<rs.length;i++)rs[i]=Math.max(.025,rs[i]-wall);
      if(stroke.startOpen)ps.unshift(ps[0].clone().addScaledVector(ps[0].clone().sub(ps[1]).normalize(),.20)),rs.unshift(rs[0]);
      if(stroke.endOpen)ps.push(ps.at(-1).clone().addScaledVector(ps.at(-1).clone().sub(ps.at(-2)).normalize(),.20)),rs.push(rs.at(-1));
    }
    for(let s=0;s<ps.length-1;s++) {
      const a=ps[s],b=ps[s+1],dx=b.x-a.x,dy=b.y-a.y,dz=b.z-a.z;
      const len2=dx*dx+dy*dy+dz*dz,ra=rs[s],rb=rs[s+1],padding=Math.max(ra,rb)+blend+step*2;
      const x0=Math.max(1,Math.floor((Math.min(a.x,b.x)-padding-origin.x)/step));
      const x1=Math.min(n-2,Math.ceil((Math.max(a.x,b.x)+padding-origin.x)/step));
      const y0=Math.max(1,Math.floor((Math.min(a.y,b.y)-padding-origin.y)/step));
      const y1=Math.min(n-2,Math.ceil((Math.max(a.y,b.y)+padding-origin.y)/step));
      const z0=Math.max(1,Math.floor((Math.min(a.z,b.z)-padding-origin.z)/step));
      const z1=Math.min(n-2,Math.ceil((Math.max(a.z,b.z)+padding-origin.z)/step));
      for(let z=z0;z<=z1;z++)for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++) {
        const qx=origin.x+x*step-a.x,qy=origin.y+y*step-a.y,qz=origin.z+z*step-a.z;
        const t=Math.max(0,Math.min(1,(qx*dx+qy*dy+qz*dz)/len2));
        const ex=qx-dx*t,ey=qy-dy*t,ez=qz-dz*t;
        const d=Math.sqrt(ex*ex+ey*ey+ez*ez)-(ra+(rb-ra)*t),index=x+y*n+z*n2;
        if(d<target[index])target[index]=d;
      }
    }
    if(!isInner) {
      const start=ps[0],end=ps.at(-1),st=ps[1].clone().sub(start).normalize(),et=end.clone().sub(ps.at(-2)).normalize();
      for(let z=1;z<n-1;z++)for(let y=1;y<n-1;y++)for(let x=1;x<n-1;x++) {
        const index=x+y*n+z*n2;if(target[index]>.20)continue;
        const px=origin.x+x*step,py=origin.y+y*step,pz=origin.z+z*step;
        if(stroke.startOpen)target[index]=Math.max(target[index],(start.x-px)*st.x+(start.y-py)*st.y+(start.z-pz)*st.z);
        if(stroke.endOpen)target[index]=Math.max(target[index],(px-end.x)*et.x+(py-end.y)*et.y+(pz-end.z)*et.z);
      }
    }
    return target;
  }
  for(const stroke of strokes) {
    const o=rasterStroke(stroke,false),i=rasterStroke(stroke,true);
    for(let k=0;k<size;k++) {outer[k]=smoothMin(outer[k],o[k],blend);inner[k]=smoothMin(inner[k],i[k],blend*.65);}
  }
  const mc=new MarchingCubes(resolution,new THREE.MeshBasicMaterial(),false,false,130000);
  mc.isolation=0;
  for(let k=0;k<size;k++)mc.field[k]=-Math.max(outer[k],-inner[k]);
  mc.update();
  const result=new THREE.BufferGeometry();
  result.setAttribute('position',new THREE.Float32BufferAttribute(mc.geometry.attributes.position.array.slice(0,mc.count*3),3));
  result.scale(half,half,half);result.translate(center.x,center.y,center.z);
  mc.geometry.dispose();mc.material.dispose();
  const welded=weldedGeometry(result);result.dispose();
  return smoothSurface(welded,3,.30,-.31);
}

function taperedTube(points,radius,{segments=32,radialSegments=7,symmetric=false}={}) {
  const curve=new THREE.CatmullRomCurve3(points,false,'centripetal');
  const frames=curve.computeFrenetFrames(segments,false),position=[],normal=[],indices=[];
  for(let i=0;i<=segments;i++) {
    const t=i/segments,p=curve.getPointAt(t),r=radius*(symmetric?.12+.88*Math.pow(Math.sin(t*Math.PI),.55):.15+.85*Math.pow(1-t,.85));
    for(let j=0;j<=radialSegments;j++) {
      const a=j/radialSegments*Math.PI*2,n=frames.normals[i].clone().multiplyScalar(Math.cos(a)).addScaledVector(frames.binormals[i],Math.sin(a));
      position.push(p.x+n.x*r,p.y+n.y*r,p.z+n.z*r);normal.push(n.x,n.y,n.z);
      if(i<segments&&j<radialSegments){const k=i*(radialSegments+1)+j;indices.push(k,k+1,k+radialSegments+1,k+1,k+radialSegments+2,k+radialSegments+1);}
    }
  }
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(position,3));geometry.setAttribute('normal',new THREE.Float32BufferAttribute(normal,3));geometry.setIndex(indices);
  geometry.computeBoundingBox();geometry.computeBoundingSphere();return geometry;
}

// Optical coordinates are stable model-space annotations, not physiology.
// vesselOptics = (arc fraction, angle / 2PI, wall depth, nominal wall thickness).
// Depth is 0 at the outside, 1 at the lumen; normals retain their correct
// outward or lumen-facing orientation and are not modified here.
function addVesselOptics(geometry,strokes,wall) {
  const segments=[];
  for(const stroke of strokes) {
    const curve=new THREE.CatmullRomCurve3(stroke.points,false,'centripetal');
    const frames=curve.computeFrenetFrames(64,false);
    const cumulative=[0];
    for(let i=1;i<stroke.points.length;i++)cumulative.push(cumulative[i-1]+stroke.points[i].distanceTo(stroke.points[i-1]));
    const total=cumulative.at(-1);
    for(let i=0;i<stroke.points.length-1;i++) {
      const a=stroke.points[i],b=stroke.points[i+1];
      segments.push({a,dx:b.x-a.x,dy:b.y-a.y,dz:b.z-a.z,l2:a.distanceToSquared(b),r0:stroke.radii[i],r1:stroke.radii[i+1],arc0:cumulative[i]/total,arc1:cumulative[i+1]/total,frames});
    }
  }
  const p=geometry.attributes.position,values=new Float32Array(p.count*4);
  for(let i=0;i<p.count;i++) {
    const x=p.getX(i),y=p.getY(i),z=p.getZ(i);let best=Infinity,chosen=null;
    for(const seg of segments) {
      const qx=x-seg.a.x,qy=y-seg.a.y,qz=z-seg.a.z;
      const t=THREE.MathUtils.clamp((qx*seg.dx+qy*seg.dy+qz*seg.dz)/seg.l2,0,1);
      const ex=qx-seg.dx*t,ey=qy-seg.dy*t,ez=qz-seg.dz*t,dist=Math.hypot(ex,ey,ez),radius=THREE.MathUtils.lerp(seg.r0,seg.r1,t);
      if(dist-radius<best){best=dist-radius;chosen={seg,t,ex,ey,ez,dist,radius};}
    }
    const {seg,t,ex,ey,ez,dist,radius}=chosen;
    const u=THREE.MathUtils.lerp(seg.arc0,seg.arc1,t),f=u*64,j=Math.min(63,Math.floor(f)),fraction=f-j;
    const normal=seg.frames.normals[j].clone().lerp(seg.frames.normals[j+1],fraction).normalize();
    const binormal=seg.frames.binormals[j].clone().lerp(seg.frames.binormals[j+1],fraction).normalize();
    const angle=Math.atan2(ex*binormal.x+ey*binormal.y+ez*binormal.z,ex*normal.x+ey*normal.y+ez*normal.z);
    values[i*4]=u;values[i*4+1]=(angle/Math.PI/2+1)%1;
    values[i*4+2]=THREE.MathUtils.clamp((radius-dist)/wall,0,1);values[i*4+3]=wall;
  }
  geometry.setAttribute('vesselOptics',new THREE.Float32BufferAttribute(values,4));
  return geometry;
}

// Fine, irregular branching bundles occupy several depths within the vessel
// wall. They follow its actual curved centerline and stop at branch lumens.
// Their deliberately nonuniform density avoids an evenly striped pipe look.
function vesselFilaments(strokes,wall,{mobile=false,mainCount=30}={}) {
  const parts=[],seeded=n=>{const v=Math.sin(n*127.1+311.7)*43758.5453;return v-Math.floor(v);};
  function inOtherLumen(p,own) {
    for(let s=0;s<strokes.length;s++) {
      if(s===own)continue;
      const {points,radii}=strokes[s];
      for(let i=0;i<points.length-1;i++) {
        const a=points[i],b=points[i+1],dx=b.x-a.x,dy=b.y-a.y,dz=b.z-a.z;
        const qx=p.x-a.x,qy=p.y-a.y,qz=p.z-a.z;
        const t=THREE.MathUtils.clamp((qx*dx+qy*dy+qz*dz)/(dx*dx+dy*dy+dz*dz),0,1);
        const r=THREE.MathUtils.lerp(radii[i],radii[i+1],t)-wall+.007;
        if((qx-t*dx)**2+(qy-t*dy)**2+(qz-t*dz)**2<r*r)return true;
      }
    }
    return false;
  }
  function append(path,width,strength,{symmetric=true,radialSegments=5}={}) {
    if(path.length<5)return;
    const geometry=taperedTube(path,width,{segments:Math.max(8,path.length-1),radialSegments,symmetric});
    const count=geometry.attributes.position.count,colors=new Float32Array(count*3);
    for(let i=0;i<count;i++) {
      const t=Math.floor(i/(radialSegments+1))/(Math.max(8,path.length-1));
      const brightness=strength*(.72+.28*Math.sin(t*Math.PI));
      colors[i*3]=brightness;colors[i*3+1]=brightness;colors[i*3+2]=brightness;
    }
    geometry.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));parts.push(geometry);
  }
  for(let s=0;s<strokes.length;s++) {
    const stroke=strokes[s],curve=new THREE.CatmullRomCurve3(stroke.points,false,'centripetal');
    const frameCount=96,frames=curve.computeFrenetFrames(frameCount,false),samples=mobile?30:44;
    const count=s===0?(mobile?Math.ceil(mainCount*.60):mainCount):(mobile?6:10);
    function point(t,theta,depth) {
      const p=curve.getPointAt(t),rIndex=curve.getUtoTmapping(t)*(stroke.radii.length-1),lo=Math.floor(rIndex);
      const r=THREE.MathUtils.lerp(stroke.radii[lo],stroke.radii[Math.min(lo+1,stroke.radii.length-1)],rIndex-lo)-depth;
      const f=t*frameCount,j=Math.min(frameCount-1,Math.floor(f)),k=f-j;
      const n=frames.normals[j].clone().lerp(frames.normals[j+1],k).normalize();
      const b=frames.binormals[j].clone().lerp(frames.binormals[j+1],k).normalize();
      return p.addScaledVector(n,Math.cos(theta)*r).addScaledVector(b,Math.sin(theta)*r);
    }
    function run(start,end,steps,thetaAt,depthAt,width,strength,options) {
      let path=[];
      for(let i=0;i<=steps;i++) {
        const u=i/steps,t=THREE.MathUtils.lerp(start,end,u),p=point(t,thetaAt(t,u),depthAt(t,u));
        if(inOtherLumen(p,s)){append(path,width,strength,options);path=[];continue;}
        path.push(p);
      }
      append(path,width,strength,options);
    }
    for(let f=0;f<count;f++) {
      const seed=seeded(f+s*101),phase=seeded(f*7+s*41)*Math.PI*2;
      const theta0=(f+.34*(seed-.5))/count*Math.PI*2;
      const sweep=(f%3===0?-.42:.34)*(0.7+seed*.6);
      const thetaAt=t=>theta0+sweep*(t-.5)+(.13+.09*seed)*Math.sin(t*Math.PI*(1.3+seed)+phase)+.045*Math.sin(t*Math.PI*5.1+phase*.7);
      const depthBase=.010+.016*seed;
      const depthAt=t=>depthBase+.003*Math.sin(t*Math.PI*2.3+phase);
      const width=.0017+.0010*seed,strength=.72+.27*seed;
      const start=.018+.035*seed,end=.965+.018*seed;
      run(start,end,samples,thetaAt,depthAt,width,strength,{symmetric:true});
      // A second fine strand follows selected fascicles at a slightly deeper
      // plane. The separation varies, so they read as bundles, not a grid.
      if(f%4===0)run(start+.018,end-.025,samples,t=>thetaAt(t)+.025+.012*Math.sin(t*11+phase),t=>Math.min(wall-.007,depthAt(t)+.004),width*.56,strength*.74,{symmetric:true,radialSegments:4});
      // Short branches diverge from actual parent points and taper to fine
      // ends. Opposing handedness creates occasional natural crossings.
      if(f%2===0)for(let branch=0;branch<2;branch++) {
        const t0=.20+branch*.32+.07*seed,t1=Math.min(.96,t0+.20+.13*seed);
        const direction=(f%4===0?1:-1)*(branch===0?1:-1),spread=direction*(.30+.32*seed);
        const rootDepth=depthAt(t0);
        run(t0,t1,mobile?10:15,(t,u)=>thetaAt(t)+spread*(u*u*(3-2*u))+.06*Math.sin(u*Math.PI),(t,u)=>THREE.MathUtils.clamp(rootDepth+direction*.005*Math.sin(u*Math.PI),.007,wall-.008),width*.67,strength*.88,{symmetric:false,radialSegments:4});
      }
    }
  }
  const geometry=mergeGeometries(parts,false);parts.forEach(part=>part.dispose());
  geometry.computeBoundingBox();geometry.computeBoundingSphere();return geometry;
}

/** Return a new group of meshes; material/deformation assignment belongs to
 * heart-scene.js. Roles: shell | atrium | vessel | coronary | vessel-fiber | vessel-rim.
 * userData.mobility is 1 for beating tissue and 0.2 for great vessels. */
export function buildHeartAnatomy(gltfScene,{mobile=false}={}) {
  const group=new THREE.Group();group.name='refined-anatomical-heart';
  const placeholder=new THREE.MeshBasicMaterial({color:0xffffff,side:THREE.DoubleSide});
  const stats={source:'BodyParts3D CC BY 4.0',worldCoordinates:true,sourceSurfaces:0,refinedVessels:0,coronaryBranches:0,triangles:0};
  const original=new Map();gltfScene.updateMatrixWorld(true);
  gltfScene.traverse(node=>{if(node.isMesh)original.set(node.name,node.geometry.clone().applyMatrix4(node.matrixWorld));});
  function add(name,geometry,role,mobility=1) {
    const mesh=new THREE.Mesh(geometry,placeholder);mesh.name=name;mesh.userData={role,mobility};mesh.frustumCulled=false;group.add(mesh);return mesh;
  }
  let wallGeometry=null;
  for(const [name,input]of original) {
    if(name==='left-ventricle'||name==='right-ventricle'||/aorta|aortic|pulmonary|vena-cava/.test(name))continue;
    const coronary=name.includes('coronary');
    const role=coronary?'coronary':name.includes('atrium')?'atrium':'shell';
    const geometry=smoothSurface(weldedGeometry(input),coronary?2:8,coronary?.20:.33,coronary?-.205:-.34);
    if(name==='ventricular-wall') {
      // The atlas's basal boundary is an educational cut surface. Round only
      // this shoulder, retaining the observed ventricular body and apex. A
      // tiny convex lift replaces the broad, visibly planar basal highlight.
      const p=geometry.attributes.position,mask=new Float32Array(p.count);
      for(let i=0;i<p.count;i++) {
        const x=p.getX(i),y=p.getY(i),z=p.getZ(i);
        const t=THREE.MathUtils.smoothstep(y,-.22,.30);
        mask[i]=t;
        const dome=Math.exp(-((x+.03)**2/.33+(z-.32)**2/.38));
        p.setY(i,y+.065*t*dome);
      }
      smoothSurface(geometry,10,.42,-.40,mask);
    }
    add(name,geometry,role);stats.sourceSurfaces++;
    if(name==='ventricular-wall')wallGeometry=geometry;
  }
  if(!wallGeometry)throw new Error('The atlas ventricular wall is missing.');
  const resolution=mobile?78:104;
  // Centers/radii follow the imported ascending-aorta and aortic-arch profiles.
  const aorta=[
    curveStroke([[-.10,-.18,.12],[-.15,.15,.19],[-.30,.55,.24],[-.31,.88,.23],[-.21,1.13,.06],[-.06,1.20,-.30],[.04,1.09,-.72],[.05,.79,-1.03]],[.245,.245,.235,.22,.205]),
    curveStroke([[-.26,1.06,.12],[-.36,1.31,.16],[-.41,1.62,.22]],[.115,.105,.10],{segments:24}),
    curveStroke([[-.11,1.18,-.20],[-.10,1.44,-.17],[-.08,1.70,-.12]],[.10,.092,.088],{segments:24}),
    curveStroke([[.01,1.16,-.49],[.12,1.42,-.45],[.23,1.62,-.36]],[.10,.095,.087],{segments:24})
  ];
  add('continuous-aorta-and-arch-branches',addVesselOptics(hollowVessel(aorta,{resolution,wall:.042,blend:.045}),aorta,.042),'vessel',.2);stats.refinedVessels++;
  const pulmonary=[
    curveStroke([[.19,.20,.60],[.20,.43,.53],[.15,.69,.37],[.11,.92,.20]],[.245,.235,.21,.185]),
    curveStroke([[.12,.83,.24],[.38,.92,.13],[.68,.94,.09]],[.19,.16,.145],{segments:28}),
    curveStroke([[.11,.84,.22],[-.12,.85,.03],[-.43,.81,-.20]],[.17,.14,.125],{segments:28})
  ];
  add('continuous-pulmonary-trunk-and-branches',addVesselOptics(hollowVessel(pulmonary,{resolution:mobile?68:92,wall:.039,blend:.06}),pulmonary,.039),'vessel',.2);stats.refinedVessels++;
  const caval=[curveStroke([[-.74,.56,.04],[-.75,.84,.04],[-.73,1.10,.07],[-.72,1.31,.10]],[.215,.205,.20,.195])];
  add('superior-vena-cava',addVesselOptics(hollowVessel(caval,{resolution:mobile?58:76,wall:.042,blend:.035}),caval,.042),'vessel',.2);stats.refinedVessels++;
  stats.vesselFilamentTriangles=0;
  for(const [name,strokes,wall,mainCount]of [['aortic',aorta,.042,30],['pulmonary',pulmonary,.039,28],['caval',caval,.042,28]]) {
    const geometry=vesselFilaments(strokes,wall,{mobile,mainCount});
    add(`intramural-gold-filaments-${name}`,geometry,'vessel-fiber',.2);
    stats.vesselFilamentTriangles+=geometry.index.count/3;
  }

  // Thin gold tracings follow the inner edge of real cut lumens. These are
  // circular mesh cross-sections in each vessel's actual terminal plane;
  // they make the glass thickness legible without capping the openings.
  const rims=[
    ['brachiocephalic',[-.41,1.62,.22],[-.36,1.31,.16],.100,.042,.0024],
    ['left-carotid',[-.08,1.70,-.12],[-.10,1.44,-.17],.088,.042,.0022],
    ['left-subclavian',[.23,1.62,-.36],[.12,1.42,-.45],.087,.042,.0022],
    ['superior-caval',[-.72,1.31,.10],[-.73,1.10,.07],.195,.042,.0030],
    ['pulmonary-left',[.68,.94,.09],[.38,.92,.13],.145,.039,.0027],
    ['pulmonary-right',[-.43,.81,-.20],[-.12,.85,.03],.125,.039,.0025]
  ];
  for(const [name,end,previous,radius,thickness,lineWidth]of rims) {
    const center=V(end),axis=center.clone().sub(V(previous)).normalize();
    const geometry=new THREE.TorusGeometry(radius-thickness+.003,lineWidth,6,mobile?48:80);
    geometry.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,0,1),axis));
    center.addScaledVector(axis,.001);
    geometry.translate(center.x,center.y,center.z);
    geometry.computeBoundingBox();geometry.computeBoundingSphere();
    add(`vessel-lumen-rim-${name}`,geometry,'vessel-rim',.2);
  }
  stats.lumenRims=rims.length;

  // Delicate real tube branches grow from the actual coronary surfaces and
  // track the ventricular wall rather than floating on a spherical stand-in.
  const wallMesh=new THREE.Mesh(wallGeometry,new THREE.MeshBasicMaterial({side:THREE.DoubleSide}));
  wallMesh.updateMatrixWorld(true);
  const ray=new THREE.Raycaster();
  function pointOnWall(y,theta) {
    const apical=THREE.MathUtils.clamp((.48-y)/1.91,0,1),cx=.10+.36*apical,cz=.25+.08*apical;
    const radial=new THREE.Vector3(Math.cos(theta),0,Math.sin(theta));
    ray.set(new THREE.Vector3(cx,y,cz).addScaledVector(radial,3),radial.clone().negate());
    const hit=ray.intersectObject(wallMesh,false)[0];
    return hit?hit.point.clone().addScaledVector(hit.face.normal,.006):null;
  }
  const coronaryPositions=[...original].filter(([name])=>name.includes('coronary')).flatMap(([,geometry])=>{
    const p=geometry.attributes.position,out=[];
    for(let i=0;i<p.count;i+=2)out.push(new THREE.Vector3().fromBufferAttribute(p,i));return out;
  });
  const branchSeeds=mobile?8:14;
  for(let j=0;j<branchSeeds;j++) {
    const targetY=.12-(j%7)*.145,targetTheta=.54+(j%2)*1.35;
    let root=null,best=Infinity;
    for(const p of coronaryPositions) {
      const apical=THREE.MathUtils.clamp((.48-p.y)/1.91,0,1),theta=Math.atan2(p.z-(.25+.08*apical),p.x-(.10+.36*apical));
      const angular=Math.atan2(Math.sin(theta-targetTheta),Math.cos(theta-targetTheta));
      const score=(p.y-targetY)**2+angular**2*.13;
      if(score<best){best=score;root=p;}
    }
    if(!root)continue;
    const a=THREE.MathUtils.clamp((.48-root.y)/1.91,0,1),theta=Math.atan2(root.z-(.25+.08*a),root.x-(.10+.36*a));
    const points=[root.clone()];
    for(let k=1;k<=18;k++) {
      const t=k/18,y=root.y-(.30+.06*(j%3))*t;
      if(y< -1.31)break;
      const q=pointOnWall(y,theta+(j%2?-.46:.46)*t+.06*Math.sin(t*Math.PI));
      if(q)points.push(q);
    }
    if(points.length<5)continue;
    add(`fine-coronary-branch-${j+1}`,taperedTube(points,.0075+(j%3)*.0012,{segments:mobile?24:36,radialSegments:mobile?6:8}),'coronary');stats.coronaryBranches++;
  }
  wallMesh.material.dispose();
  for(const geometry of original.values())geometry.dispose();
  group.traverse(mesh=>{if(mesh.isMesh)stats.triangles+=(mesh.geometry.index?.count||mesh.geometry.attributes.position.count)/3;});
  stats.bounds=new THREE.Box3().setFromObject(group).getSize(new THREE.Vector3()).toArray();
  return {group,wallGeometry,stats};
}
