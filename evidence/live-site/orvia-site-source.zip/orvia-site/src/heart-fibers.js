import * as THREE from 'three';

/* ORVIA: artist-directed myocardial fiber geometry.
 * The wall is anatomical; these orientation fields, layers, and individual
 * strands are illustrative. They are not histology, DTI, or measured fibers. */
const TAU = Math.PI * 2;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const smooth = t => {t = clamp(t, 0, 1); return t * t * (3 - 2 * t);};
const cubic = (a, b, c, d, t) => b + .5*t*(c-a+t*(2*a-5*b+4*c-d+t*(3*(b-c)+d-a)));
function seededRandom(seed) {
  return () => {seed |= 0;seed = seed + 0x6D2B79F5 | 0;let t = Math.imul(seed ^ seed >>> 15, 1 | seed);t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;return ((t ^ t >>> 14) >>> 0) / 4294967296;};
}

/** Intersect the original wall rather than substituting a parametric heart.
 * Triangles are assigned only to the sections they cross, keeping dense input
 * geometry practical. Outermost radial intersections select epicardial skin. */
function makeWallSampler(geometry, mobile) {
  if (!geometry?.attributes?.position) throw new Error('A ventricular-wall geometry is required for myocardial fibers.');
  geometry.computeBoundingBox();
  const bounds = geometry.boundingBox;
  const height = bounds.max.y - bounds.min.y;
  const lo = bounds.min.y + height * .018;
  const hi = bounds.max.y - height * .035;
  const rows = mobile ? 88 : 112, cols = mobile ? 160 : 256;
  const dy = (hi - lo) / (rows - 1);
  const sections = Array.from({length: rows}, () => []);
  const pos = geometry.attributes.position, index = geometry.index;
  const triangleCount = (index ? index.count : pos.count) / 3;
  const xyz = new Float64Array(9);
  for (let f = 0; f < triangleCount; f++) {
    for (let k=0; k<3; k++) {const v=index ? index.getX(f*3+k) : f*3+k;xyz[k*3]=pos.getX(v);xyz[k*3+1]=pos.getY(v);xyz[k*3+2]=pos.getZ(v);}
    const aY=xyz[1],bY=xyz[4],cY=xyz[7];
    const first=Math.max(0,Math.ceil((Math.min(aY,bY,cY)-lo)/dy));
    const last=Math.min(rows-1,Math.floor((Math.max(aY,bY,cY)-lo)/dy));
    for(let r=first; r<=last; r++) {
      const y=lo+r*dy, hits=[];
      for(let e=0;e<3;e++) {
        const a=e*3,b=((e+1)%3)*3, delta=xyz[b+1]-xyz[a+1];
        if(Math.abs(delta)<1e-10)continue;
        const t=(y-xyz[a+1])/delta;
        if(t>=0 && t<1)hits.push([xyz[a]+(xyz[b]-xyz[a])*t,xyz[a+2]+(xyz[b+2]-xyz[a+2])*t]);
      }
      if(hits.length===2)sections[r].push(hits[0][0],hits[0][1],hits[1][0],hits[1][1]);
    }
  }
  const centers=sections.map(segment=>{
    let minX=Infinity,maxX=-Infinity,minZ=Infinity,maxZ=-Infinity;
    for(let i=0;i<segment.length;i+=2){minX=Math.min(minX,segment[i]);maxX=Math.max(maxX,segment[i]);minZ=Math.min(minZ,segment[i+1]);maxZ=Math.max(maxZ,segment[i+1]);}
    return Number.isFinite(minX)?[(minX+maxX)/2,(minZ+maxZ)/2]:[0,0];
  });
  // A softly varying local center prevents an artificial kink at slice joins.
  for(let pass=0;pass<3;pass++){
    const copy=centers.map(c=>c.slice());
    for(let r=1;r<rows-1;r++)for(let k=0;k<2;k++)centers[r][k]=copy[r][k]*.5+(copy[r-1][k]+copy[r+1][k])*.25;
  }
  let radii=new Float32Array(rows*cols);
  for(let r=0;r<rows;r++) {
    const [cx,cz]=centers[r],segments=sections[r];
    for(let c=0;c<cols;c++) {
      const theta=c/cols*TAU,dx=Math.cos(theta),dz=Math.sin(theta);let radius=0;
      for(let k=0;k<segments.length;k+=4){
        const ax=segments[k]-cx,az=segments[k+1]-cz;
        const sx=segments[k+2]-segments[k],sz=segments[k+3]-segments[k+1];
        const det=dx*sz-dz*sx;if(Math.abs(det)<1e-10)continue;
        const t=(ax*sz-az*sx)/det,u=(ax*dz-az*dx)/det;
        if(t>radius&&u>=0&&u<=1)radius=t;
      }
      radii[r*cols+c]=radius;
    }
  }
  // Fill tiny numerical misses from adjacent directions, never a distant ray.
  for(let pass=0;pass<3;pass++) {
    const next=radii.slice();
    for(let r=0;r<rows;r++)for(let c=0;c<cols;c++){
      const i=r*cols+c,a=radii[r*cols+(c+cols-1)%cols],b=radii[r*cols+(c+1)%cols];
      if(radii[i]===0)next[i]=(a+b)/2;
      else if(pass<2)next[i]=radii[i]*.72+(a+b)*.14;
    }
    radii=next;
  }
  function radial(t, theta) {
    const y=clamp(t,0,1)*(rows-1),r=Math.floor(y),fy=y-r;
    const x=((theta/TAU*cols)%cols+cols)%cols,c=Math.floor(x),fx=x-c;
    const line=[];
    for(let j=-1;j<=2;j++){
      const row=clamp(r+j,0,rows-1),offset=row*cols;
      const at=k=>radii[offset+(c+k+cols)%cols];
      line.push(cubic(at(-1),at(0),at(1),at(2),fx));
    }
    const radius=Math.max(.006,cubic(...line,fy));
    const center=[0,1].map(k=>cubic(centers[clamp(r-1,0,rows-1)][k],centers[r][k],centers[Math.min(r+1,rows-1)][k],centers[Math.min(r+2,rows-1)][k],fy));
    return {radius,center,y:lo+t*(hi-lo)};
  }
  function point(t,theta,depth=1) {
    const s=radial(t,theta);
    return new THREE.Vector3(s.center[0]+Math.cos(theta)*s.radius*depth,s.y,s.center[1]+Math.sin(theta)*s.radius*depth);
  }
  function sample(t,theta,depth=1) {
    const p=point(t,theta,depth);
    const around=point(t,theta+.008,depth).sub(point(t,theta-.008,depth));
    const along=point(Math.min(.999,t+.002),theta,depth).sub(point(Math.max(.001,t-.002),theta,depth));
    const normal=along.cross(around).normalize();
    const reference=new THREE.Vector3(Math.cos(theta),0,Math.sin(theta));
    if(normal.dot(reference)<0)normal.negate();
    return {p,normal};
  }
  return {sample,point,bounds:{lo,hi},rows,cols};
}

function bucket() {return {positions:[],normals:[],colors:[],indices:[],strands:0};}

/** Continuous elliptical tubes with rounded lighting normals and softened tips.
 * Slightly flattened cross-sections read as fine fascicles rather than wires. */
function appendStrand(target, path, radius, sides, tint, flatten=.70) {
  if(path.length<4)return;
  const count=path.length, offset=target.positions.length/3;
  let previousNormal=null;
  for(let i=0;i<count;i++) {
    const tangent=path[Math.min(count-1,i+1)].p.clone().sub(path[Math.max(0,i-1)].p).normalize();
    let normal=path[i].normal.clone().addScaledVector(tangent,-path[i].normal.dot(tangent)).normalize();
    if(normal.lengthSq()<.1)normal=new THREE.Vector3(0,1,0).cross(tangent).normalize();
    if(previousNormal){
      const transported=previousNormal.clone().addScaledVector(tangent,-previousNormal.dot(tangent)).normalize();
      if(normal.dot(transported)<0)normal.negate();
      if(transported.lengthSq()>.5)normal.lerp(transported,.72).normalize();
    }
    previousNormal=normal.clone();
    const binormal=new THREE.Vector3().crossVectors(tangent,normal).normalize();
    const u=i/(count-1);
    const taper=.035+.965*Math.pow(Math.sin(Math.PI*u),.44);
    const ends=smooth(u/.065)*smooth((1-u)/.085);
    const before=i>0?path[i].p.distanceTo(path[i-1].p):Infinity;
    const after=i<count-1?path[i].p.distanceTo(path[i+1].p):Infinity;
    const r=Math.min(radius*taper*(.3+.7*ends)*(1+.045*Math.sin(u*29+tint*17)),Math.min(before,after)*.22);
    const wide=r*1.15,thick=r*flatten;
    for(let j=0;j<sides;j++) {
      const angle=j/sides*TAU,co=Math.cos(angle),si=Math.sin(angle);
      const p=path[i].p.clone().addScaledVector(normal,co*thick).addScaledVector(binormal,si*wide);
      const n=normal.clone().multiplyScalar(co/flatten).addScaledVector(binormal,si/1.15).normalize();
      target.positions.push(p.x,p.y,p.z);target.normals.push(n.x,n.y,n.z);
      const value=tint*(.83+.17*Math.sin(Math.PI*u));target.colors.push(value,value*.975,value*.89);
    }
    if(i>0)for(let j=0;j<sides;j++) {
      const a=offset+(i-1)*sides+j,b=offset+(i-1)*sides+(j+1)%sides,c=offset+i*sides+j,d=offset+i*sides+(j+1)%sides;
      target.indices.push(a,b,c,b,d,c);
    }
  }
  target.strands++;
}

function makeMesh(data, role) {
  const geometry=new THREE.BufferGeometry();
  geometry.setAttribute('position',new THREE.Float32BufferAttribute(data.positions,3));
  geometry.setAttribute('normal',new THREE.Float32BufferAttribute(data.normals,3));
  geometry.setAttribute('color',new THREE.Float32BufferAttribute(data.colors,3));
  geometry.setIndex(data.indices);geometry.computeBoundingBox();geometry.computeBoundingSphere();
  const material=new THREE.MeshPhysicalMaterial({color:role==='fiber'?0xc3a364:0xd9bf85,metalness:.72,roughness:.34,vertexColors:true,clearcoat:.25});
  const mesh=new THREE.Mesh(geometry,material);
  mesh.name=role==='fiber'?'layered-myocardial-bundles':'fine-myocardial-striations';
  mesh.userData.role=role;
  mesh.userData.illustrative=true;
  mesh.userData.mobility=1;
  mesh.frustumCulled=false;
  return mesh;
}

export function createMyocardialFibers(wallGeometry,{mobile=false}={}) {
  const start=performance.now();
  const wall=makeWallSampler(wallGeometry,mobile),random=seededRandom(0x0a7f13);
  const main=bucket(),micro=bucket();
  const detail=mobile?42:62;
  const familyCount=mobile?24:44;
  const samplePath=(definition,segments)=>Array.from({length:segments+1},(_,i)=>{
    const u=i/segments;
    const t=definition.t0+(definition.t1-definition.t0)*u;
    // Increasing curvature toward the apex creates sweeping fascicles, rather
    // than a field of projected straight diagonals. Slow waviness is shared by
    // each bundle; its neighbouring strands gently diverge toward the base.
    const winding=.5-Math.pow(1-u,1.55);
    const theta=definition.angle+definition.turn*winding+definition.bend*Math.sin(Math.PI*u)+.025*Math.sin(u*TAU*1.3+definition.phase);
    const depth=definition.depth+.004*Math.sin(u*Math.PI+definition.phase);
    return wall.sample(t,theta,depth);
  });

  // Outer oblique fascicles: staggered bundles whose companion strands separate
  // gently along the ventricular contour. Golden-angle placement avoids a grid.
  for(let f=0;f<familyCount;f++) {
    const angle=f*2.399963229728653+(random()-.5)*.15;
    const base={angle,t0:.045+random()*.17,t1:.75+random()*.21,turn:1.85+random()*.95,bend:(random()-.5)*.50,depth:.994+random()*.011,phase:random()*TAU};
    const strands=mobile?2:4;
    for(let s=0;s<strands;s++) {
      const spread=s-(strands-1)*.5;
      const def={...base,angle:angle+spread*.014,t0:base.t0+random()*.035,t1:base.t1-random()*.045,depth:base.depth-spread*.0012,bend:base.bend+spread*.026};
      appendStrand(main,samplePath(def,detail),(.0031+random()*.0020)*(s===Math.floor(strands/2)?1.13:1),mobile?5:6,.92+random()*.08,.74);
    }
  }

  // Deeper counter-helical layer; visible through the translucent external wall.
  // These cross the outer field at different depth rather than forming a lattice.
  const innerCount=mobile?18:30;
  for(let f=0;f<innerCount;f++){
    const angle=f*2.399963229728653+.8+(random()-.5)*.3;
    const base={angle,t0:.12+random()*.24,t1:.68+random()*.23,turn:-1.3-random()*1.15,bend:(random()-.5)*.58,depth:.961+random()*.026,phase:random()*TAU};
    const strands=mobile?2:3;
    for(let s=0;s<strands;s++) {
      const spread=s-(strands-1)*.5;
      const def={...base,angle:angle+spread*.016,bend:base.bend+spread*.032,t0:base.t0+random()*.04};
      appendStrand(main,samplePath(def,detail-6),.0030+random()*.0018,mobile?5:6,.86+random()*.12,.75);
    }
  }

  // Shorter broad sweeps follow oblique circumferential arcs across the wall.
  const sweeps=mobile?18:36;
  for(let f=0;f<sweeps;f++){
    const angle=random()*TAU,center=.22+random()*.53,span=.9+random()*1.2,phase=random()*TAU;
    const path=Array.from({length:detail+1},(_,i)=>{
      const u=i/detail;
      const t=clamp(center+.10*Math.sin((u-.5)*Math.PI)+.018*Math.sin(u*TAU+phase),.11,.94);
      return wall.sample(t,angle+(u-.5)*span,.989+.009*Math.sin(u*Math.PI+phase));
    });
    appendStrand(main,path,.0025+random()*.0017,mobile?5:6,.90+random()*.09,.68);
  }

  // Small, fan-shaped bundles add the local curls and depth seen in the art
  // direction. Their staggered tips and variable lengths keep them from
  // reading as either a repeated spiral or a rectangular weave.
  const fans=mobile?4:10;
  for(let f=0;f<fans;f++){
    const angle=f*2.399963229728653+.5,low=.12+random()*.27,high=.60+random()*.25;
    const phase=random()*TAU,baseTurn=.85+random()*.65;
    for(let s=0;s<3;s++){
      const spread=s-1;
      const def={angle:angle+spread*.027,t0:low+random()*.035,t1:high-random()*.05,turn:baseTurn+spread*.09,bend:.23+random()*.16+spread*.035,depth:.998+spread*.002,phase};
      appendStrand(main,samplePath(def,detail),.0028+random()*.0015,mobile?5:6,.93+random()*.07,.72);
    }
  }

  // Microstriations are actual fine-scale geometry in this normalized
  // model, not a screen-space overlay or a physical size measurement. Short lengths and varying inclination
  // catch the light softly between the larger, flowing fascicles.
  const fineCount=mobile?125:360,fineSegments=mobile?26:36;
  for(let f=0;f<fineCount;f++){
    const startT=.06+random()*.66,len=.16+random()*.32;
    const def={angle:f*2.399963229728653+random()*.4,t0:startT,t1:Math.min(.97,startT+len),turn:(random()>.22?1:-1)*(.40+random()*.90),bend:(random()-.5)*.24,depth:.990+random()*.019,phase:random()*TAU};
    appendStrand(micro,samplePath(def,fineSegments),.00125+random()*.00115,mobile?4:5,.90+random()*.10,.72);
  }
  const group=new THREE.Group();group.name='illustrative-myocardial-fiber-layers';
  const mainMesh=makeMesh(main,'fiber'),fineMesh=makeMesh(micro,'microfiber');
  group.add(mainMesh,fineMesh);
  return {group,stats:{
    primaryStrands:main.strands,microStrands:micro.strands,
    triangles:(main.indices.length+micro.indices.length)/3,
    vertices:(main.positions.length+micro.positions.length)/3,
    drawCalls:2,layers:3,generatedMilliseconds:Math.round(performance.now()-start),
    method:'Wall-conforming, layered, tapered 3D fascicles; artistic fiber orientations, not measured fiber data.'
  }};
}
