import test from 'node:test';
import assert from 'node:assert/strict';
import { validateTrajectory, trajectoryURL, trajectoryRecordLabel } from './trajectory-data.js';
const hash='a'.repeat(64);
const source=Object.fromEntries(['systemSha256','positionsSha256','selectionSha256','topologySha256','runnerSha256','inputManifestSha256'].map(key=>[key,hash]));
function artifact(){return {schemaVersion:1,jobId:'diagnostic-1',modelId:'complex33',timeUnit:'fs',lengthUnit:'nm',diagnosticOnly:true,scientificAcceptance:false,fullAtomCount:132935,selectedAtomCount:2,atoms:[{index:4,element:'C',group:'protein'},{index:12,element:'O',group:'ligand'}],bonds:[],backboneLinks:[],frames:[{step:0,timeFs:0,positions:[[0,0,0],[1,1,1]],fullPositionsSha256:hash},{step:10,timeFs:1,positions:[[0.01,0,0],[1,1.02,1]],fullPositionsSha256:hash}],source};}
const metadata={jobId:'diagnostic-1',modelId:'complex33',atomCount:2,frameCount:2};
test('trajectory labels separate previous jobs from the actual stress duration',()=>{
 const record={label:'Complex',durationFs:8000,frameCount:101};
 assert.equal(trajectoryRecordLabel(record),'Current job · Complex · 8000 fs · 101 frames');
 assert.equal(trajectoryRecordLabel({...record,historical:true,durationFs:100}),'Previous job · Complex · 100 fs · 101 frames');
});
test('actual-coordinate shape preserves mapping, units and ordered time',()=>{const data=artifact();assert.equal(validateTrajectory(data,metadata),data);});
test('rejects wrong identities, units and scientific claim substitution',()=>{
 for(const mutate of [x=>x.jobId='different',x=>x.modelId='solvent33',x=>x.timeUnit='ps',x=>x.lengthUnit='angstrom',x=>x.scientificAcceptance=true,x=>x.diagnosticOnly=false]){const data=artifact();mutate(data);assert.throws(()=>validateTrajectory(data,metadata));}
});
test('rejects changed mapping, truncated coordinates and unordered snapshots',()=>{
 for(const mutate of [x=>x.atoms[1].index=4,x=>x.selectedAtomCount=3,x=>x.frames[1].positions.pop(),x=>x.frames[1].positions[0][0]=Infinity,x=>x.frames[1].step=0,x=>x.frames[1].timeFs=0,x=>x.frames[1].fullPositionsSha256='bad',x=>x.backboneLinks=[[0,1]],x=>x.bonds=[[0,9]]]){const data=artifact();mutate(data);assert.throws(()=>validateTrajectory(data,metadata));}
});
test('metadata dimensions and source bindings are required',()=>{assert.throws(()=>validateTrajectory(artifact(),{...metadata,frameCount:101}));const data=artifact();data.source={};assert.throws(()=>validateTrajectory(data,metadata));});
test('only the same-origin, hash-bound artifact route is fetchable',()=>{
 const record={jobId:'diagnostic-1',sha256:hash,url:`/api/orvia/trajectory?jobId=diagnostic-1&sha256=${hash}`};
 assert.equal(trajectoryURL(record,'https://orvia.fyi').origin,'https://orvia.fyi');
 for(const url of [`https://other.example/api/orvia/trajectory?jobId=diagnostic-1&sha256=${hash}`,`/api/orvia/worker?jobId=diagnostic-1&sha256=${hash}`,`/api/orvia/trajectory?jobId=other&sha256=${hash}`,`/api/orvia/trajectory?jobId=diagnostic-1&sha256=${hash}&redirect=anything`])assert.throws(()=>trajectoryURL({...record,url},'https://orvia.fyi'));
});
