const HASH = /^[a-f0-9]{64}$/i;
const finite = value => typeof value === 'number' && Number.isFinite(value);
export function trajectoryRecordLabel(record) {
  return `${record.historical === true ? 'Previous job' : 'Current job'} · ${String(record.label || record.modelId).slice(0,180)} · ${record.durationFs} fs · ${record.frameCount} frames`;
}
export function selectTrajectoryRecord(records, previousHash = '') {
  const previous = records.find(record => record.sha256 === previousHash);
  if (previous) return previous;
  const current = records.filter(record => record.historical !== true);
  const candidates = current.length ? current : records;
  if (!candidates.length) return null;
  const timestamp = record => Number.isFinite(Date.parse(record.uploadedAt)) ? Date.parse(record.uploadedAt) : -Infinity;
  const newest = candidates.reduce((selected, record) => timestamp(record) > timestamp(selected) ? record : selected);
  return candidates.find(record => record.jobId === newest.jobId && record.modelId === 'complex33') || newest;
}
export function validateTrajectory(data, metadata = {}) {
  const fail = message => { throw new Error(message); };
  if (!data || data.schemaVersion !== 1 || data.timeUnit !== 'fs' || data.lengthUnit !== 'nm' || data.diagnosticOnly !== true || data.scientificAcceptance !== false) fail('Unsupported trajectory identity or units');
  if (metadata.jobId && data.jobId !== metadata.jobId || metadata.modelId && data.modelId !== metadata.modelId) fail('Trajectory identity does not match its record');
  if (!Array.isArray(data.atoms) || data.atoms.length < 1 || data.atoms.length > 5000 || data.selectedAtomCount !== data.atoms.length) fail('Invalid selected atom count');
  if (!Number.isSafeInteger(data.fullAtomCount) || data.fullAtomCount < data.atoms.length) fail('Invalid full model count');
  if (!Array.isArray(data.frames) || data.frames.length < 2 || data.frames.length > 1001 || data.frames.length * data.atoms.length > 1000000) fail('Invalid frame count');
  if (metadata.frameCount && metadata.frameCount !== data.frames.length || metadata.atomCount && metadata.atomCount !== data.atoms.length) fail('Artifact dimensions differ from metadata');
  const identities = new Set();
  for (const atom of data.atoms) {
    if (!atom || !Number.isSafeInteger(atom.index) || atom.index < 0 || identities.has(atom.index) || !['protein','ligand'].includes(atom.group) || typeof atom.element !== 'string') fail('Invalid atom mapping');
    identities.add(atom.index);
  }
  for (const key of ['bonds','backboneLinks']) {
    if (!Array.isArray(data[key]) || data[key].length > 20000) fail('Invalid atom connections');
    for (const pair of data[key]) {
      if (!Array.isArray(pair) || pair.length !== 2 || !pair.every(n => Number.isInteger(n) && n >= 0 && n < data.atoms.length) || pair[0] === pair[1]) fail('Connection lies outside selected atoms');
      if (key === 'backboneLinks' && pair.some(n => data.atoms[n].group !== 'protein')) fail('Backbone guide must use protein atoms');
    }
  }
  let step = -1, time = -1;
  for (const frame of data.frames) {
    if (!Number.isSafeInteger(frame.step) || frame.step <= step || !finite(frame.timeFs) || frame.timeFs <= time || frame.timeFs < 0 || !HASH.test(frame.fullPositionsSha256)) fail('Frames must retain ordered steps, time and full-coordinate hashes');
    if (!Array.isArray(frame.positions) || frame.positions.length !== data.atoms.length || frame.positions.some(point => !Array.isArray(point) || point.length !== 3 || point.some(n => !finite(n) || Math.abs(n) > 1000000))) fail('Invalid frame coordinates');
    step=frame.step;time=frame.timeFs;
  }
  if (!data.source || Object.keys(data.source).length < 6 || Object.values(data.source).some(value => typeof value !== 'string' || !HASH.test(value))) fail('Missing source identity');
  return data;
}

export function trajectoryURL(record, origin) {
  if (!record || !HASH.test(record.sha256) || typeof record.url !== 'string') throw new Error('Invalid trajectory record');
  const url = new URL(record.url, origin);
  if (url.origin !== origin || url.pathname !== '/api/orvia/trajectory' || url.searchParams.get('sha256') !== record.sha256 || url.searchParams.get('jobId') !== record.jobId || [...url.searchParams.keys()].some(key => !['sha256','jobId'].includes(key))) throw new Error('Unexpected trajectory location');
  return url;
}
