import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { validateTrajectory, trajectoryURL, trajectoryRecordLabel, selectTrajectoryRecord } from './trajectory-data.js';

const $ = id => document.getElementById(id);
const canvas = $('trajectory-canvas');
const controlsIDs = ['trajectory-play','trajectory-frame','trajectory-fit','trajectory-focus','trajectory-reset','trajectory-initial','trajectory-final'];
const state = {records:[],data:null,record:null,frame:0,playing:false,lastTick:0,raf:0,loading:null,scene:null,renderer:null,camera:null,controls:null,contextLost:false,groups:[],ghosts:[],lines:[],ghostLines:[],viewCenter:new THREE.Vector3(),size:1};
const matrix = new THREE.Matrix4();
const quaternion = new THREE.Quaternion();
const vector = new THREE.Vector3();
const scale = new THREE.Vector3();
const up = new THREE.Vector3(0,1,0);
const atomColor = {H:0xe4e1d5,C:0x9c7b40,N:0x5885a4,O:0xc36f57,S:0xc4a849,P:0xb69059,F:0x87a66b,CL:0x75a26e};
let cancelFetch = null;
const colorTheme = () => document.documentElement.dataset.theme === 'dark';
const readable = value => String(value ?? '').slice(0,180);
const set = (id,value) => {$(id).textContent=value;};

function empty(message, detail) {
  $('trajectory-empty').hidden=false;
  $('trajectory-empty').querySelector('h3').textContent=message;
  $('trajectory-empty').querySelector('p').textContent=detail;
}
function enable(value) {
  for(const id of controlsIDs)$(id).disabled=!value;
  $('trajectory-options').disabled=!value;
}
function render() { if(state.renderer&&state.scene&&state.camera)state.renderer.render(state.scene,state.camera); }
function playbackStatus() {
  if(!state.data)return;
  const current=state.data.frames[state.frame],last=state.data.frames.at(-1);
  const status=state.playing?'Playing':state.frame===state.data.frames.length-1?'Playback finished':'Paused';
  set('trajectory-playback',`${status} · frame ${state.frame+1} of ${state.data.frames.length} · recorded time ${current.timeFs} / ${last.timeFs} fs`);
}
function stop() {
  state.playing=false;cancelAnimationFrame(state.raf);
  $('trajectory-play').textContent='Play frames ▷';$('trajectory-play').setAttribute('aria-pressed','false');
  playbackStatus();
}
function disposeScene() {
  for(const object of [...state.groups,...state.ghosts,...state.lines,...state.ghostLines]) {
    state.scene?.remove(object);object.geometry?.dispose();object.material?.dispose();
  }
  state.groups=[];state.ghosts=[];state.lines=[];state.ghostLines=[];
}
function theme() {
  if(!state.scene)return;
  state.scene.background=new THREE.Color(colorTheme()?0x142019:0xf4f3ee);
  for(const mesh of state.groups) if(mesh.userData.group==='protein')mesh.material.color.set(colorTheme()?0xcbb581:0x947740);
  for(const mesh of state.ghosts)mesh.material.color.set(colorTheme()?0x8ca399:0x7e8b85);
  for(const line of state.lines)line.material.color.set(line.userData.kind==='backbone'?(colorTheme()?0x9caa90:0x738369):0x9c8659);
  for(const line of state.ghostLines)line.material.color.set(colorTheme()?0x718d7d:0x8b9b91);
  render();
}
function initializeRenderer() {
  if(state.renderer)return;
  try {
    state.renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:false,powerPreference:'low-power'});
    state.renderer.setPixelRatio(Math.min(devicePixelRatio||1,1.5));
    state.renderer.outputColorSpace=THREE.SRGBColorSpace;
    state.scene=new THREE.Scene();
    state.camera=new THREE.PerspectiveCamera(42,1,.01,1000);
    state.controls=new OrbitControls(state.camera,canvas);
    state.controls.enableDamping=false;
    state.controls.screenSpacePanning=true;
    state.controls.minDistance=.2;state.controls.maxDistance=250;
    state.controls.addEventListener('change',render);
    state.scene.add(new THREE.HemisphereLight(0xffffff,0x545347,2.5));
    const light=new THREE.DirectionalLight(0xfff7e3,2.3);light.position.set(10,14,8);state.scene.add(light);
    const fill=new THREE.DirectionalLight(0xd5e3e2,1.3);fill.position.set(-8,-3,4);state.scene.add(fill);
    new ResizeObserver(()=>resize()).observe($('trajectory-stage'));
    theme();resize();
  } catch {
    state.renderer=null;
    throw new Error('WebGL is unavailable. Recorded coordinate data can still be downloaded.');
  }
}
function resize() {
  if(!state.renderer)return;
  const rect=$('trajectory-stage').getBoundingClientRect();
  state.renderer.setSize(rect.width,rect.height,false);state.camera.aspect=rect.width/rect.height;state.camera.updateProjectionMatrix();render();
}
function buildAtoms(group, ghost=false) {
  const indices=state.data.atoms.map((a,i)=>a.group===group?i:-1).filter(i=>i>=0);
  if(!indices.length)return;
  const geometry=new THREE.SphereGeometry(1,12,8);
  const material=new THREE.MeshStandardMaterial({color:group==='protein'?0x947740:0xffffff,roughness:.62,metalness:.05,transparent:ghost,opacity:ghost?.18:1,depthWrite:!ghost,wireframe:ghost});
  const mesh=new THREE.InstancedMesh(geometry,material,indices.length);
  mesh.frustumCulled=false;mesh.userData={group,indices,ghost};
  if(group==='ligand'&&!ghost)indices.forEach((index,i)=>mesh.setColorAt(i,new THREE.Color(atomColor[state.data.atoms[index].element.toUpperCase()]||0x9c7b40)));
  state.scene.add(mesh);(ghost?state.ghosts:state.groups).push(mesh);
}
function buildLinks(pairs,kind,ghost=false) {
  if(!pairs.length)return;
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.BufferAttribute(new Float32Array(pairs.length*6),3));
  const material=new THREE.LineBasicMaterial({color:kind==='backbone'?0x738369:0x9c8659,transparent:true,opacity:ghost?.18:kind==='backbone'?.68:.95,depthWrite:!ghost});
  const line=new THREE.LineSegments(geometry,material);line.frustumCulled=false;line.userData={pairs,kind,ghost};
  state.scene.add(line);(ghost?state.ghostLines:state.lines).push(line);
}
function updateGeometry(frameIndex) {
  const positions=state.data.frames[frameIndex].positions,initial=state.data.frames[0].positions;
  const protein=$('show-protein').checked,ligand=$('show-ligand').checked,ghost=$('show-initial').checked;
  const visible=state.data.atoms.some(atom=>atom.group==='protein'?protein:ligand);
  if(!visible)empty('All atoms are hidden.','Turn on an atom group below, or use Reset view to restore the molecule.');
  else if(!state.contextLost)$('trajectory-empty').hidden=true;
  for(const mesh of [...state.groups,...state.ghosts]) {
    const points=mesh.userData.ghost?initial:positions;
    mesh.visible=(mesh.userData.group==='protein'?protein:ligand)&&(!mesh.userData.ghost||ghost);
    mesh.userData.indices.forEach((index,i)=>{
      const p=points[index],isProtein=mesh.userData.group==='protein',element=state.data.atoms[index].element.toUpperCase();
      const radius=isProtein?.048:element==='H'?.048:.085;
      matrix.compose(vector.set(p[0],p[1],p[2]).sub(state.viewCenter),quaternion.identity(),scale.setScalar(radius));mesh.setMatrixAt(i,matrix);
    });mesh.instanceMatrix.needsUpdate=true;
  }
  for(const line of [...state.lines,...state.ghostLines]) {
    const points=line.userData.ghost?initial:positions;
    line.visible=(line.userData.kind==='backbone'?protein:ligand)&&(!line.userData.ghost||ghost);
    const buffer=line.geometry.attributes.position.array;
    line.userData.pairs.forEach(([a,b],i)=>{
      buffer.set([points[a][0]-state.viewCenter.x,points[a][1]-state.viewCenter.y,points[a][2]-state.viewCenter.z,points[b][0]-state.viewCenter.x,points[b][1]-state.viewCenter.y,points[b][2]-state.viewCenter.z],i*6);
    });line.geometry.attributes.position.needsUpdate=true;
  }
}
function frame(index) {
  if(!state.data)return;
  state.frame=Math.max(0,Math.min(state.data.frames.length-1,index));
  $('trajectory-frame').value=state.frame;
  const f=state.data.frames[state.frame],last=state.data.frames.at(-1);
  set('trajectory-time',`${f.timeFs.toLocaleString(undefined,{maximumFractionDigits:3})} fs`);
  set('trajectory-frame-label',`FRAME ${state.frame+1} / ${state.data.frames.length} · ${f.timeFs} fs`);
  set('trajectory-duration',`${state.data.frames[0].timeFs}–${last.timeFs} fs · discrete recorded frames`);
  playbackStatus();
  updateGeometry(state.frame);render();
}
function fit(ligandOnly=false) {
  if(!state.data)return;
  const box=new THREE.Box3();
  const points=state.data.frames[state.frame].positions;
  state.data.atoms.forEach((atom,i)=>{if(!ligandOnly||atom.group==='ligand')box.expandByPoint(vector.fromArray(points[i]).sub(state.viewCenter));});
  if(box.isEmpty())return;
  const center=box.getCenter(new THREE.Vector3()),size=box.getSize(new THREE.Vector3());
  const radius=Math.max(size.x,size.y,size.z,ligandOnly?1.4:3);
  const distance=radius/(2*Math.tan(THREE.MathUtils.degToRad(state.camera.fov/2)))*1.5;
  state.controls.target.copy(center);
  state.camera.position.copy(center).add(new THREE.Vector3(.65,.35,1).normalize().multiplyScalar(distance));
  state.camera.near=Math.max(.005,distance/1000);state.camera.far=Math.max(100,distance*50);state.camera.updateProjectionMatrix();state.controls.update();render();
}
function resetView() {
  if(!state.data)return;
  $('show-protein').checked=true;$('show-ligand').checked=true;$('show-initial').checked=false;
  updateGeometry(state.frame);
  const duration=state.data.frames.at(-1).timeFs-state.data.frames[0].timeFs;
  fit(duration<=100&&state.data.atoms.some(atom=>atom.group==='ligand'));
}
function populate(data,record,url) {
  initializeRenderer();stop();disposeScene();state.data=data;state.record=record;state.frame=0;
  const box=new THREE.Box3();data.frames[0].positions.forEach(p=>box.expandByPoint(vector.fromArray(p)));box.getCenter(state.viewCenter);
  buildAtoms('protein');buildAtoms('ligand');buildAtoms('protein',true);buildAtoms('ligand',true);
  buildLinks(data.backboneLinks,'backbone');buildLinks(data.bonds,'bond');buildLinks(data.backboneLinks,'backbone',true);buildLinks(data.bonds,'bond',true);
  $('trajectory-frame').max=data.frames.length-1;
  set('trajectory-model-label',readable(data.label||data.modelId).toUpperCase());
  set('trajectory-badge',record.historical===true?'Previous job · recorded frames':'Current job · recorded frames');
  const protein=data.atoms.filter(a=>a.group==='protein').length,ligand=data.atoms.filter(a=>a.group==='ligand').length;
  set('trajectory-selection',`Showing ${data.selectedAtomCount.toLocaleString()} selected atoms (${protein.toLocaleString()} protein Cα, ${ligand.toLocaleString()} ligand) from ${data.fullAtomCount.toLocaleString()} model atoms. Coordinates: nm. Time: fs.`);
  const first=data.frames[0].positions,last=data.frames.at(-1).positions;
  let max=0,sum=0;
  for(let i=0;i<first.length;i++){const d=first[i].reduce((v,n,j)=>v+(n-last[i][j])**2,0);max=Math.max(max,d);sum+=d;}
  set('trajectory-motion',`Initial → final selected-atom displacement: RMS ${(Math.sqrt(sum/first.length)*10).toFixed(4)} Å; maximum ${(Math.sqrt(max)*10).toFixed(4)} Å. No rotational alignment or motion amplification.`);
  const duration=data.frames.at(-1).timeFs-data.frames[0].timeFs;
  set('trajectory-scale-note',`This recording covers ${duration} fs (${duration/1000} ps) of molecular time. Maximum displayed-atom displacement: ${(Math.sqrt(max)*10).toFixed(3)} Å. ${duration<=100?'That is an extremely short interval, so real movement may look almost still. The initial view focuses on the ligand.':'Playback shows saved snapshots, not a live video stream.'} Frame and time counters confirm playback. Dragging changes the camera, not the molecule’s recorded coordinates.`);
  const source=$('trajectory-source');source.replaceChildren(document.createTextNode(`${record.historical===true?'Previous':'Current'} job: ${readable(record.jobId)} · Artifact SHA-256: ${record.sha256} · `));
  const link=document.createElement('a');link.href=url.href;link.textContent='Download recorded frames';link.setAttribute('download',`orvia-${data.modelId}-trajectory.json`);source.append(link);
  $('trajectory-empty').hidden=true;enable(true);theme();frame(0);fit(duration<=100&&ligand>0);
}
async function load(record) {
  if(state.loading===record.sha256||state.record?.sha256===record.sha256)return;
  stop();cancelFetch?.abort();cancelFetch=new AbortController();state.loading=record.sha256;enable(false);
  empty('Loading recorded coordinates.','Checking the artifact fingerprint before displaying the molecular frames.');set('trajectory-badge','Loading artifact');
  const requestController=cancelFetch;
  const timeout=setTimeout(()=>requestController.abort(),30000);
  try {
    const url=trajectoryURL(record,location.origin);
    const response=await fetch(url,{cache:'force-cache',credentials:'omit',signal:requestController.signal,headers:{Accept:'application/json'}});
    if(!response.ok)throw new Error('The recorded trajectory is unavailable.');
    if(Number(response.headers.get('content-length')||0)>4*1024*1024)throw new Error('Trajectory exceeds the supported size.');
    const buffer=await response.arrayBuffer();
    if(buffer.byteLength>4*1024*1024)throw new Error('Trajectory exceeds the supported size.');
    const digest=[...new Uint8Array(await crypto.subtle.digest('SHA-256',buffer))].map(x=>x.toString(16).padStart(2,'0')).join('');
    if(digest!==record.sha256.toLowerCase())throw new Error('Trajectory fingerprint does not match the published record.');
    const data=validateTrajectory(JSON.parse(new TextDecoder().decode(buffer)),record);
    if(state.loading!==record.sha256)return;
    populate(data,record,url);
  }catch(error){
    if(error.name!=='AbortError'){set('trajectory-badge','Artifact unavailable');empty('The frames could not be shown.',error.message||'The artifact did not pass the display checks.');}
  }finally{clearTimeout(timeout);if(state.loading===record.sha256)state.loading=null;}
}
function records(data) {
  const candidates=Array.isArray(data.trajectories)?data.trajectories.filter(record=>{try{trajectoryURL(record,location.origin);return record.diagnosticOnly===true&&record.scientificAcceptance===false;}catch{return false;}}):[];
  if(!candidates.length)return;
  const select=$('trajectory-model'),before=select.value;
  if(candidates.map(r=>`${r.sha256}:${r.historical===true}`).join(',')===state.records.map(r=>`${r.sha256}:${r.historical===true}`).join(',')){const selected=candidates.find(r=>r.sha256===select.value);if(selected&&!state.loading&&state.record?.sha256!==selected.sha256)load(selected);return;}
  state.records=candidates;
  select.replaceChildren(...candidates.map(record=>{const option=document.createElement('option');option.value=record.sha256;option.textContent=trajectoryRecordLabel(record);return option;}));
  select.disabled=false;
  const chosen=selectTrajectoryRecord(candidates,before);select.value=chosen.sha256;
  if(state.record?.sha256===chosen.sha256&&state.data)populate(state.data,chosen,trajectoryURL(chosen,location.origin));
  else load(chosen);
}
function play(now) {
  if(!state.playing)return;
  const interval=1000/Number($('trajectory-speed').value||10);
  if(now-state.lastTick>=interval){state.lastTick=now;if(state.frame>=state.data.frames.length-1){stop();return;}frame(state.frame+1);}
  state.raf=requestAnimationFrame(play);
}
function leavePage(event) {
  stop();
  // A page retained in the back-forward cache must keep its reusable GPU resources.
  if(event.persisted)return;
  cancelFetch?.abort();state.controls?.dispose();state.renderer?.dispose();
}
function restorePage(event) {
  if(!event.persisted)return;
  if(state.data&&state.renderer&&!state.contextLost){$('trajectory-empty').hidden=true;enable(true);resize();frame(state.frame);}
  window.dispatchEvent(new CustomEvent('orvia:trajectory-ready'));
}
$('trajectory-model').addEventListener('change',()=>{const record=state.records.find(r=>r.sha256===$('trajectory-model').value);if(record)load(record);});
$('trajectory-play').addEventListener('click',()=>{
  if(!state.data)return;if(state.playing){stop();return;}
  if(state.frame>=state.data.frames.length-1)frame(0);
  state.playing=true;state.lastTick=0;$('trajectory-play').textContent='Pause frames Ⅱ';$('trajectory-play').setAttribute('aria-pressed','true');playbackStatus();state.raf=requestAnimationFrame(play);
});
$('trajectory-frame').addEventListener('input',()=>{stop();frame(Number($('trajectory-frame').value));});
$('trajectory-initial').addEventListener('click',()=>{stop();frame(0);});
$('trajectory-final').addEventListener('click',()=>{stop();frame(state.data.frames.length-1);});
$('trajectory-fit').addEventListener('click',()=>fit());$('trajectory-focus').addEventListener('click',()=>fit(true));
$('trajectory-reset').addEventListener('click',resetView);
for(const id of ['show-protein','show-ligand','show-initial'])$(id).addEventListener('change',()=>{updateGeometry(state.frame);render();});
canvas.addEventListener('keydown',event=>{
  if(!state.controls||!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','+','=','-','0'].includes(event.key))return;
  event.preventDefault();
  if(event.key==='0'){fit();return;}
  const offset=state.camera.position.clone().sub(state.controls.target);
  if(['+','=','-'].includes(event.key))offset.multiplyScalar(event.key==='-'?1.12:.89);
  else if(['ArrowLeft','ArrowRight'].includes(event.key))offset.applyAxisAngle(up,event.key==='ArrowLeft'?.1:-.1);
  else {const right=new THREE.Vector3().crossVectors(offset,up).normalize();offset.applyAxisAngle(right,event.key==='ArrowUp'?.1:-.1);}
  state.camera.position.copy(state.controls.target).add(offset);state.controls.update();render();
});
canvas.addEventListener('webglcontextlost',event=>{event.preventDefault();state.contextLost=true;stop();enable(false);empty('The graphics view was interrupted.','The view will resume if the graphics context recovers. Reload the page if it stays unavailable.');});
canvas.addEventListener('webglcontextrestored',()=>{state.contextLost=false;if(state.data){$('trajectory-empty').hidden=true;enable(true);resize();frame(state.frame);}});
window.addEventListener('orvia:research-status',event=>records(event.detail));
window.addEventListener('orvia:theme',theme);
window.addEventListener('orvia:motion',event=>{if(event.detail?.paused)stop();});
document.addEventListener('visibilitychange',()=>{if(document.hidden)stop();});
window.addEventListener('pagehide',leavePage);
window.addEventListener('pageshow',restorePage);

window.dispatchEvent(new CustomEvent('orvia:trajectory-ready'));
