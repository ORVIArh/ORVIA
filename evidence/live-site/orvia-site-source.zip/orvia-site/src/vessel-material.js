/* Thin pearlescent arterial-wall shading for the ORVIA explanatory sculpture.
 * This is an art-directed single-scattering approximation, not a physical
 * tissue transport measurement. Geometry, lumens and internal filaments remain
 * three-dimensional, depth-tested and deform with the heartbeat. Layered alpha
 * membranes reveal the gold geometry without screen-space background refraction. */

export function createVesselUniforms() {
  return {theme:{value:0},scatter:{value:1}};
}

export function applyVesselTheme(material,uniforms,dark=false,fibers=true) {
  uniforms.theme.value=dark?1:0;
  uniforms.scatter.value=1;
  material.color.set(dark?0xe2d2ad:0xf6e6c8);
  material.metalness=0;
  material.transmission=0;
  material.roughness=dark?.24:.22;
  material.thickness=.042;
  material.ior=1.30;
  material.attenuationColor.set(0xf2dfba);
  material.attenuationDistance=2.5;
  material.clearcoat=.22;
  material.clearcoatRoughness=.30;
  material.specularIntensity=.65;
  material.envMapIntensity=dark?.75:.80;
  material.sheen=.24;
  material.sheenColor.set(dark?0xe8d5b0:0xffebcc);
  material.sheenRoughness=.68;
  material.emissive.set(0x000000);
  material.emissiveIntensity=0;
  material.transparent=true;
  material.opacity=fibers?(dark?.36:.43):.58;
  material.depthWrite=false;
  material.dithering=true;
}

const vertexDeclarations=`
attribute vec4 vesselOptics;
varying vec4 vVesselOptics;
varying vec2 vVesselAngle;
`;
const fragmentDeclarations=`
uniform float uVesselTheme;
uniform float uVesselScatter;
varying vec4 vVesselOptics;
varying vec2 vVesselAngle;
vec3 vesselPerturbNormal(vec3 surface,vec3 n,float height) {
  vec3 sx=dFdx(surface),sy=dFdy(surface);
  vec3 r1=cross(sy,n),r2=cross(n,sx);
  float det=dot(sx,r1);
  return normalize(abs(det)*n-sign(det)*(dFdx(height)*r1+dFdy(height)*r2));
}
`;

/** Call after the root's common deformation onBeforeCompile edits.
 * All vessel geometries must have a vec4 vesselOptics attribute:
 * longitudinal fraction, angular fraction, inner-wall fraction, wall thickness.
 * Use one uniform set per viewer (shared by its three main vessel materials).
 */
export function customizeVesselShader(shader,{uniforms=createVesselUniforms()}={}) {
  shader.uniforms.uVesselTheme=uniforms.theme;
  shader.uniforms.uVesselScatter=uniforms.scatter;
  shader.vertexShader=vertexDeclarations+'\n'+shader.vertexShader;
  shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>',
    '#include <begin_vertex>\nvVesselOptics=vesselOptics;\nvVesselAngle=vec2(sin(vesselOptics.y*6.28318530718),cos(vesselOptics.y*6.28318530718));');
  shader.fragmentShader=fragmentDeclarations+'\n'+shader.fragmentShader;
  shader.fragmentShader=shader.fragmentShader.replace('#include <roughnessmap_fragment>',`#include <roughnessmap_fragment>
    float vesselT=clamp(vVesselOptics.x,0.0,1.0);
    float vesselAngle=atan(vVesselAngle.x,vVesselAngle.y);
    float vesselInner=clamp(vVesselOptics.z,0.0,1.0);
    float vesselWall=clamp(vVesselOptics.w/0.042,0.65,1.4);
    float vesselFold=sin(vesselAngle*22.0+0.40*sin(vesselT*18.8495559215));
    float vesselFine=sin(vesselT*163.362817987+0.40*sin(vesselAngle*3.0));
    float vesselContinuity=1.0-smoothstep(0.012,0.055,fwidth(vesselT));
    roughnessFactor=clamp(roughnessFactor+vesselFold*0.009+vesselInner*0.025,0.24,0.40);
    diffuseColor.rgb*=1.0+0.008*vesselFold;
  `);
  shader.fragmentShader=shader.fragmentShader.replace('#include <normal_fragment_maps>',`#include <normal_fragment_maps>
    float vesselHeight=(vesselFold*0.000045+vesselFine*0.000018)*vesselContinuity*(1.0-0.5*vesselInner);
    normal=vesselPerturbNormal(-vViewPosition,normal,vesselHeight);
  `);
  shader.fragmentShader=shader.fragmentShader.replace('#include <opaque_fragment>',`
    // Light-dependent translucency over actual depth-tested interior geometry.
    // A restrained view-dependent veil keeps the wall soft at grazing angles.
    float vesselFacing=clamp(abs(dot(normal,normalize(vViewPosition))),0.0,1.0);
    float vesselGrazing=pow(1.0-vesselFacing,1.7);
    vec3 vesselIncident=(reflectedLight.directDiffuse+reflectedLight.indirectDiffuse)/max(diffuseColor.rgb,vec3(0.08));
    vec3 vesselBacklight=vec3(0.0);
    #ifdef USE_ENVMAP
      vesselBacklight=getIBLIrradiance(-normal)*0.31830988618;
    #endif
    vec3 vesselSoftLight=min(vesselIncident*0.58+vesselBacklight*0.42,vec3(2.0));
    vec3 vesselPearl=mix(vec3(0.98,0.90,0.74),vec3(0.87,0.76,0.55),uVesselTheme*0.48);
    float vesselScatterAmount=(0.035+0.060*vesselGrazing)*(1.0+0.13*vesselInner)/sqrt(vesselWall);
    outgoingLight+=vesselSoftLight*vesselPearl*vesselScatterAmount*uVesselScatter;
    diffuseColor.a=min(0.64,diffuseColor.a*mix(0.80,1.65,vesselGrazing));
    #include <opaque_fragment>
  `);
}
