import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { RectAreaLightUniformsLib } from 'three/addons/lights/RectAreaLightUniformsLib.js';
import { buildHeartAnatomy } from './heart-anatomy.js';
import { createMyocardialFibers } from './heart-fibers.js';
import { createVesselUniforms, customizeVesselShader, applyVesselTheme } from './vessel-material.js';

/* Art-directed geometry adapted from BodyParts3D. Surface layers, fibre paths
 * and contraction are explanatory constructions, not measured physiology. */
const deformationGLSL = `
uniform float uContraction;
uniform float uMobility;
varying vec3 vHeartPosition;
vec3 deformHeart(vec3 p) {
  float apex = clamp((0.48-p.y)/1.91,0.0,1.0);
  float c = uContraction*uMobility*(1.0-smoothstep(0.06,0.76,p.y));
  vec2 center = vec2(0.10+0.36*apex,0.25+0.08*apex);
  vec2 r = p.xz-center;
  float twist = c*(0.27*apex-0.045);
  float co=cos(twist),si=sin(twist);
  r = mat2(co,-si,si,co)*r;
  r *= vec2(1.0-0.115*c,1.0-0.10*c);
  return vec3(r.x+center.x,0.48+(p.y-0.48)*(1.0-0.105*c),r.y+center.y);
}
vec3 deformHeartNormal(vec3 p,vec3 n) {
  vec3 axis=abs(n.y)<.9?vec3(0,1,0):vec3(1,0,0);
  vec3 t=normalize(cross(axis,n)),b=normalize(cross(n,t)),q=deformHeart(p);
  return normalize(cross(deformHeart(p+t*.002)-q,deformHeart(p+b*.002)-q));
}`;
const detailGLSL = `
varying vec3 vHeartPosition;
float heartHash(vec3 p) {return fract(sin(dot(p,vec3(127.1,311.7,74.7)))*43758.5453);}
float heartNoise(vec3 p) {
  vec3 i=floor(p),f=fract(p);f=f*f*(3.0-2.0*f);
  return mix(mix(mix(heartHash(i),heartHash(i+vec3(1,0,0)),f.x),mix(heartHash(i+vec3(0,1,0)),heartHash(i+vec3(1,1,0)),f.x),f.y),mix(mix(heartHash(i+vec3(0,0,1)),heartHash(i+vec3(1,0,1)),f.x),mix(heartHash(i+vec3(0,1,1)),heartHash(i+vec3(1,1,1)),f.x),f.y),f.z);
}
vec3 heartBump(vec3 surf,vec3 n,float height) {
  vec3 sx=dFdx(surf),sy=dFdy(surf);
  vec3 r1=cross(sy,n),r2=cross(n,sx);
  float det=dot(sx,r1);
  return normalize(abs(det)*n-sign(det)*(dFdx(height)*r1+dFdy(height)*r2));
}`;

function heartbeatEnvelope(phase) {
  if(phase<.055||phase>.70)return 0;
  if(phase<.25){const t=(phase-.055)/.195;return t*t*(3-2*t);}
  const t=(phase-.25)/.45;return 1-t*t*(3-2*t);
}

function attachSurface(material,uniforms,mobility=1,detail=0,vesselUniforms=null) {
  material.onBeforeCompile=shader=>{
    shader.uniforms.uContraction=uniforms.contraction;
    shader.uniforms.uMobility={value:mobility};
    shader.vertexShader=deformationGLSL+'\n'+shader.vertexShader;
    shader.vertexShader=shader.vertexShader.replace('#include <beginnormal_vertex>','#include <beginnormal_vertex>\nobjectNormal=deformHeartNormal(position,objectNormal);');
    shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\nvHeartPosition=position;\ntransformed=deformHeart(position);');
    if(detail){
      shader.fragmentShader=detailGLSL+'\n'+shader.fragmentShader;
      shader.fragmentShader=shader.fragmentShader.replace('#include <roughnessmap_fragment>',`#include <roughnessmap_fragment>
        float tissueGrain=heartNoise(vHeartPosition*38.0);
        float tissueFold=sin(vHeartPosition.y*88.0+vHeartPosition.x*31.0+heartNoise(vHeartPosition*6.0)*8.0);
        roughnessFactor=clamp(roughnessFactor+(tissueGrain-.5)*.09,0.065,0.65);
        diffuseColor.rgb*=.96+.04*tissueGrain;
      `);
      shader.fragmentShader=shader.fragmentShader.replace('#include <normal_fragment_maps>',`#include <normal_fragment_maps>
        float tissueHeight=(tissueGrain*.0012+tissueFold*.00045)*${detail.toFixed(3)};
        normal=heartBump(-vViewPosition,normal,tissueHeight);
      `);
    }
  };
  const baseCompile=material.onBeforeCompile;
  if(vesselUniforms)material.onBeforeCompile=shader=>{baseCompile(shader);customizeVesselShader(shader,{uniforms:vesselUniforms});};
  material.customProgramCacheKey=()=>`orvia-layered-v5-${mobility}-${detail}-${!!vesselUniforms}`;
  return material;
}

// Real area-light reflections: broad softboxes and a narrow warm rim, baked into
// a floating-point environment map. All visible heart detail is mesh geometry.
function studioEnvironment(renderer) {
  const studio=new THREE.Scene();studio.background=new THREE.Color(.035,.038,.032);
  const resources=[];
  const panel=(color,intensity,x,y,z,w,h)=>{
    const geometry=new THREE.PlaneGeometry(w,h);
    const material=new THREE.MeshBasicMaterial({color:new THREE.Color(color).multiplyScalar(intensity),side:THREE.DoubleSide});
    const mesh=new THREE.Mesh(geometry,material);mesh.position.set(x,y,z);mesh.lookAt(0,0,0);studio.add(mesh);resources.push(geometry,material);
  };
  panel(0xfff4dd,1.6,0,-.1,5,4.5,5);
  panel(0xfff6df,2.0,-3.8,2.6,4,3.5,6);
  panel(0xffffff,1.4,3.4,3.2,1,2,5);
  panel(0xdac18f,2.0,1.5,.7,-3,1.2,5);
  panel(0xfff9eb,1.1,-1,5,-.5,4,2);
  panel(0xe1ece6,.3,0,-3,3,4,2);
  const generator=new THREE.PMREMGenerator(renderer);
  const target=generator.fromScene(studio,.035,.1,30);
  generator.dispose();resources.forEach(r=>r.dispose());return target;
}

function contactTexture() {
  const size=128,pixels=new Uint8Array(size*size*4);
  for(let y=0;y<size;y++)for(let x=0;x<size;x++){
    const r=Math.hypot((x/(size-1)-.5)*2,(y/(size-1)-.5)*2),i=(y*size+x)*4;
    pixels[i]=pixels[i+1]=pixels[i+2]=255;pixels[i+3]=Math.round(Math.pow(Math.max(0,1-r*r),4)*255);
  }
  const texture=new THREE.DataTexture(pixels,size,size);texture.needsUpdate=true;return texture;
}

export async function initHeartScene(canvas,options={}) {
  if(!canvas)throw new Error('Heart canvas is missing.');
  const media=matchMedia('(prefers-reduced-motion: reduce)');
  const mobile=matchMedia('(max-width: 700px)').matches;
  const state={theme:options.theme==='dark'?'dark':'light',paused:options.paused??media.matches,rate:72,phase:0,fibers:true,visible:true,dragging:false,rotationX:.26,rotationY:-.10,rotationZ:-.10,zoom:1};
  const uniforms={contraction:{value:0}};
  const vesselUniforms=createVesselUniforms(),vesselFiberMeshes=[];
  const renderer=new THREE.WebGLRenderer({canvas,alpha:true,antialias:true,powerPreference:'high-performance'});
  let shaderFailure=null;
  renderer.debug.onShaderError=(gl,program,vertex,fragment)=>{shaderFailure=new Error('Heart shader compilation failed: '+gl.getShaderInfoLog(vertex)+gl.getShaderInfoLog(fragment));};
  const pixelRatio=Math.min(devicePixelRatio||1,mobile?1.5:2);
  renderer.setPixelRatio(pixelRatio);renderer.setClearColor(0x000000,0);
  renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;
  renderer.transmissionResolutionScale=mobile?.65:1;
  const scene=new THREE.Scene();
  const camera=new THREE.PerspectiveCamera(32,1,.1,30);camera.position.set(0,.55,6.7);camera.lookAt(0,.10,0);
  const heart=new THREE.Group();heart.name='ORVIA layered anatomical heart';scene.add(heart);
  const environmentTarget=studioEnvironment(renderer);scene.environment=environmentTarget.texture;
  RectAreaLightUniformsLib.init();
  const key=new THREE.RectAreaLight(0xfff6e4,4,3.7,5.5);key.position.set(-3.5,3.5,4);key.lookAt(0,0,0);scene.add(key);
  const fill=new THREE.RectAreaLight(0xe3ebe6,1.3,3,4);fill.position.set(4,1.5,3);fill.lookAt(0,0,0);scene.add(fill);
  const rim=new THREE.RectAreaLight(0xf5d394,4,2,5);rim.position.set(2,2,-3);rim.lookAt(0,0,0);scene.add(rim);
  const hemi=new THREE.HemisphereLight(0xfff8e8,0x586153,.35);scene.add(hemi);
  const shadowMap=contactTexture(),shadowMaterial=new THREE.MeshBasicMaterial({map:shadowMap,color:0x514a38,transparent:true,opacity:.18,depthWrite:false});
  const shadow=new THREE.Mesh(new THREE.PlaneGeometry(3.5,1.5),shadowMaterial);shadow.rotation.x=-Math.PI/2;shadow.position.set(.1,-1.62,0);scene.add(shadow);
  const materials=new Set([shadowMaterial]);
  const cleanup=[];let fiberGroup,anatomyStats,fiberStats;
  let resizeObserver,intersectionObserver;
  let frame=0,lastTime=0,lastPhaseReport=-Infinity,destroyed=false,loaded=false,lastPointerX=0,lastPointerY=0;
  const on=(target,event,handler,opts)=>{target.addEventListener(event,handler,opts);cleanup.push(()=>target.removeEventListener(event,handler,opts));};
  const materialByRole={};
  function teardown(){
    destroyed=true;cancelAnimationFrame(frame);resizeObserver?.disconnect();intersectionObserver?.disconnect();cleanup.forEach(fn=>fn());
    heart.traverse(n=>n.geometry?.dispose());shadow.geometry.dispose();materials.forEach(m=>m.dispose());shadowMap.dispose();environmentTarget.dispose();renderer.dispose();
  }
  function makeMaterial(role,mobility,vertexColors=false){
    const glass=['shell','atrium','vessel'].includes(role);
    const gold=['coronary','fiber','microfiber','vessel-fiber','vessel-rim'].includes(role);
    const material=new THREE.MeshPhysicalMaterial({
      color:gold?0xcb9d46:0xf3ead5,metalness:gold?.82:0,
      roughness:gold?.27:.19,clearcoat:gold?.3:1,clearcoatRoughness:gold?.22:.15,
      transmission:glass?.72:0,thickness:glass?.16:0,ior:1.37,
      attenuationColor:0xd9bb7c,attenuationDistance:2.1,
      specularIntensity:glass?1:.7,envMapIntensity:glass?.9:1.15,
      side:THREE.FrontSide,vertexColors,sheen:role==='core'?.15:0,sheenColor:0xe6d6b2,sheenRoughness:.65,
    });
    attachSurface(material,uniforms,mobility,role==='vessel'?0:glass?.45:role==='core'?1:0,role==='vessel'?vesselUniforms:null);
    materials.add(material);(materialByRole[role]??=[]).push(material);return material;
  }
  try {
    const gltf=await new GLTFLoader().loadAsync(options.modelUrl||new URL('./assets/heart-anatomy.glb',import.meta.url).href);
    const anatomy=buildHeartAnatomy(gltf.scene,{mobile});anatomyStats=anatomy.stats;
    anatomy.group.traverse(mesh=>{if(!mesh.isMesh)return;mesh.material?.dispose();const role=mesh.userData.role||'shell';if(role==='vessel-fiber')vesselFiberMeshes.push(mesh);if(role==='vessel')mesh.renderOrder=5;if(role==='atrium')mesh.renderOrder=3;mesh.material=makeMaterial(role,mesh.userData.mobility??1,!!mesh.geometry.attributes.color);mesh.frustumCulled=false;});
    heart.add(anatomy.group);
    // A thin translucent lining inside each hollow wall adds optical depth.
    // It never fills the lumen and shares the vessel's deformation.
    anatomy.group.traverse(mesh=>{
      if(!mesh.isMesh||mesh.userData.role!=='vessel')return;
      const geometry=mesh.geometry.clone(),positions=geometry.attributes.position,normals=geometry.attributes.normal,optics=geometry.attributes.vesselOptics;
      for(let i=0;i<positions.count;i++){
        const depth=optics.getZ(i),offset=optics.getW(i)*(.62-.48*depth);
        positions.setXYZ(i,positions.getX(i)-normals.getX(i)*offset,positions.getY(i)-normals.getY(i)*offset,positions.getZ(i)-normals.getZ(i)*offset);
      }
      geometry.computeVertexNormals();
      const lamina=new THREE.Mesh(geometry,makeMaterial('vessel-lining',.2));lamina.name=mesh.name+'-inner-lamina';lamina.renderOrder=4;lamina.frustumCulled=false;heart.add(lamina);
    });
    const coreGeometry=anatomy.wallGeometry.clone();
    const p=coreGeometry.attributes.position;
    for(let i=0;i<p.count;i++)p.setXYZ(i,(p.getX(i)-.16)*.89+.16,(p.getY(i)+.48)*.95-.48,(p.getZ(i)-.22)*.89+.22);
    coreGeometry.computeVertexNormals();
    const core=new THREE.Mesh(coreGeometry,makeMaterial('core',1));core.name='subepicardial-pearl-core';heart.add(core);
    const fibers=createMyocardialFibers(anatomy.wallGeometry,{mobile});fiberGroup=fibers.group;fiberStats=fibers.stats;
    fiberGroup.traverse(mesh=>{if(!mesh.isMesh)return;mesh.material?.dispose();mesh.material=makeMaterial(mesh.userData.role||'fiber',1,!!mesh.geometry.attributes.color);mesh.frustumCulled=false;});
    heart.add(fiberGroup);loaded=true;
  }catch(error){teardown();throw error;}

  function syncPose(){heart.rotation.set(state.rotationX,state.rotationY,state.rotationZ);camera.position.z=6.7/state.zoom;camera.updateProjectionMatrix();}
  function phaseInfo(){return {phase:state.phase>.055&&state.phase<.43?'Systole':'Diastole',normalized:state.phase,contraction:uniforms.contraction.value,bpm:state.rate,paused:state.paused};}
  function render(time){
    frame=0;if(destroyed||!loaded||!state.visible||document.hidden)return;
    const dt=Math.max(0,(time-(lastTime||time))/1000);lastTime=time;
    if(!state.paused)state.phase=(state.phase+dt*state.rate/60)%1;
    uniforms.contraction.value=heartbeatEnvelope(state.phase);shadow.scale.setScalar(1-uniforms.contraction.value*.08);
    syncPose();renderer.render(scene,camera);
    if(time-lastPhaseReport>=250){lastPhaseReport=time;canvas.dataset.phase=state.phase.toFixed(4);canvas.dataset.contraction=uniforms.contraction.value.toFixed(4);options.onPhase?.(phaseInfo().phase);}
    if(!state.paused)wake();
  }
  function wake(){if(!frame&&!destroyed&&state.visible)frame=requestAnimationFrame(render);}
  function resize(){const b=canvas.getBoundingClientRect();renderer.setSize(Math.max(1,b.width),Math.max(1,b.height),false);camera.aspect=Math.max(1,b.width)/Math.max(1,b.height);camera.updateProjectionMatrix();wake();}
  function setTheme(theme){
    state.theme=theme==='dark'?'dark':'light';const dark=state.theme==='dark';
    scene.background=new THREE.Color(canvas.id==='heart-detail-canvas'?(dark?0x1b2821:0xf0f0e9):(dark?0x111a17:0xf6f5f1));
    for(const role of ['shell','atrium','vessel'])for(const mat of materialByRole[role]||[]){
      mat.color.set(dark?0xc5b99d:0xfff5e2);mat.metalness=0;mat.roughness=role==='vessel'?.12:.115;
      mat.transmission=state.fibers?(role==='vessel'?.96:.88):.50;
      mat.thickness=role==='vessel'?.075:.055;mat.attenuationColor.set(dark?0xc4a668:0xe4cfa5);
      mat.envMapIntensity=dark?.72:.85;mat.clearcoat=role==='vessel'?.25:.45;mat.clearcoatRoughness=.12;
    }
    for(const mat of materialByRole.core||[]){mat.color.set(dark?0x292d23:0xe6d9b7);mat.roughness=.52;mat.envMapIntensity=dark?.4:.85;mat.clearcoat=.15;mat.metalness=0;}
    for(const role of ['coronary','fiber','microfiber','vessel-fiber','vessel-rim'])for(const mat of materialByRole[role]||[]){
      mat.color.set(dark?0xdab366:role==='coronary'?0xd8ad52:0xe6bd60);mat.metalness=role==='coronary'?.72:.50;mat.emissive.set(dark?0x92632b:0x6a431b);mat.emissiveIntensity=role==='coronary'?0:dark?.13:.035;
      mat.roughness=role==='coronary'?.23:.27;mat.envMapIntensity=dark?1.2:1.0;
    }
    for(const mat of materialByRole.atrium||[]){mat.transmission=0;mat.transparent=true;mat.opacity=.40;mat.depthWrite=false;mat.roughness=.24;mat.clearcoat=.16;mat.specularIntensity=.55;mat.envMapIntensity=.65;}
    for(const mat of materialByRole['vessel-lining']||[]){mat.color.set(dark?0xbca67d:0xe6d5ae);mat.metalness=0;mat.roughness=.48;mat.clearcoat=0;mat.specularIntensity=.2;mat.envMapIntensity=.55;mat.transparent=true;mat.opacity=dark?.12:.15;mat.depthWrite=false;}
    for(const mat of materialByRole.vessel||[])applyVesselTheme(mat,vesselUniforms,dark,state.fibers);
    for(const mat of materialByRole['vessel-fiber']||[]){mat.color.set(dark?0xe6c789:0xf2dba5);mat.metalness=.22;mat.roughness=.34;mat.emissive.set(0xc99b4e);mat.emissiveIntensity=dark?.10:.07;mat.envMapIntensity=1.0;}
    for(const mat of materialByRole['vessel-rim']||[]){mat.color.set(dark?0xe1c388:0xcdb17b);mat.metalness=.58;mat.roughness=.30;mat.emissiveIntensity=0;}
    hemi.intensity=dark?.18:.45;key.intensity=dark?1.8:2.0;fill.intensity=dark?.35:.7;rim.intensity=dark?2.5:1.6;
    renderer.toneMappingExposure=dark?.9:.94;
    shadowMaterial.color.set(dark?0x000000:0x625d4d);shadowMaterial.opacity=dark?.32:.16;wake();
  }
  function setPaused(value){state.paused=!!value;lastTime=0;lastPhaseReport=-Infinity;wake();}
  function setRate(value){const n=Number(value);if(Number.isFinite(n))state.rate=Math.max(45,Math.min(110,n));lastPhaseReport=-Infinity;wake();}
  function setFibers(value){state.fibers=!!value;fiberGroup.visible=state.fibers;vesselFiberMeshes.forEach(mesh=>mesh.visible=state.fibers);setTheme(state.theme);}
  function reset(){state.rotationX=.26;state.rotationY=-.10;state.rotationZ=-.10;state.zoom=1;wake();}
  canvas.tabIndex=0;canvas.setAttribute('role','img');canvas.setAttribute('aria-label','Interactive adapted three-dimensional heart with translucent tissue, illustrative gold fibre bundles and contraction. Drag or use arrow keys to rotate. Plus and minus zoom; zero resets.');
  canvas.style.touchAction='pan-y';canvas.style.cursor='grab';
  on(canvas,'pointerdown',event=>{if(event.button!==0)return;state.dragging=true;lastPointerX=event.clientX;lastPointerY=event.clientY;canvas.setPointerCapture(event.pointerId);canvas.focus({preventScroll:true});canvas.style.cursor='grabbing';});
  on(canvas,'pointermove',event=>{if(!state.dragging)return;state.rotationY+=(event.clientX-lastPointerX)*.007;state.rotationX=Math.max(-.7,Math.min(.7,state.rotationX+(event.clientY-lastPointerY)*.006));lastPointerX=event.clientX;lastPointerY=event.clientY;wake();});
  const release=()=>{state.dragging=false;canvas.style.cursor='grab';};on(canvas,'pointerup',release);on(canvas,'pointercancel',release);on(canvas,'lostpointercapture',release);
  on(canvas,'keydown',event=>{let used=true;switch(event.key){case'ArrowLeft':state.rotationY-=.12;break;case'ArrowRight':state.rotationY+=.12;break;case'ArrowUp':state.rotationX=Math.max(-.7,state.rotationX-.1);break;case'ArrowDown':state.rotationX=Math.min(.7,state.rotationX+.1);break;case'+':case'=':state.zoom=Math.min(1.35,state.zoom+.08);break;case'-':state.zoom=Math.max(.75,state.zoom-.08);break;case'0':reset();break;default:used=false;}if(used){event.preventDefault();wake();}});
  on(media,'change',event=>setPaused(event.matches));on(document,'visibilitychange',()=>{lastTime=0;if(!document.hidden)wake();});
  on(canvas,'webglcontextlost',event=>{event.preventDefault();state.paused=true;cancelAnimationFrame(frame);frame=0;options.onError?.(new Error('Heart graphics context interrupted.'));});
  resizeObserver=new ResizeObserver(resize);resizeObserver.observe(canvas);
  intersectionObserver=new IntersectionObserver(entries=>{state.visible=entries[0].isIntersecting;lastTime=0;if(state.visible)wake();else{cancelAnimationFrame(frame);frame=0;}},{rootMargin:'80px'});intersectionObserver.observe(canvas);
  setTheme(state.theme);resize();syncPose();renderer.compile(scene,camera);renderer.render(scene,camera);
  if(shaderFailure){teardown();throw shaderFailure;}
  options.onPhase?.(phaseInfo().phase);
  canvas.dataset.renderer='layered-webgl';canvas.dataset.triangles=String(renderer.info.render.triangles);
  return {setTheme,setPaused,setRate,setFibers,reset,
    destroy:teardown,
    getState(){return {...state,...phaseInfo(),anatomy:anatomyStats,fiberGeometry:fiberStats,render:renderer.info.render};}
  };
}
