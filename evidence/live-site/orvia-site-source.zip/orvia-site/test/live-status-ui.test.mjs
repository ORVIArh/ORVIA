import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

// Exercise the actual render functions without starting a browser or polling a service.
const script = readFileSync(new URL('../dist/live/live.js', import.meta.url), 'utf8')
  .replace("import '../site.js';", '').split('\nfunction schedule(')[0];
const NOW = Date.parse('2026-11-03T00:00:00.000Z');
const endedAt = '2026-11-02T22:00:00.000Z';

function dashboard() {
  const nodes = new Map();
  class Node {
    dataset = {}; textContent = ''; hidden = false;
    children = [];
    replaceChildren(...children) { this.children = children; }
    querySelector() { return this.span ??= new Node(); }
  }
  const node = id => {
    if (!nodes.has(id)) nodes.set(id, new Node());
    return nodes.get(id);
  };
  const context = vm.createContext({
    document: { getElementById: node, createElement: () => new Node() },
    window: { dispatchEvent() {} },
    CustomEvent: class {}, Intl,
    Date: class extends Date { static now() { return NOW; } },
  });
  vm.runInContext(script + '\nglobalThis.renderStatus = render;', context);
  return { node, render: context.renderStatus };
}

function snapshot(state, updatedAt = endedAt) {
  return {
    generatedAt: new Date(NOW).toISOString(),
    chain: { available: true, contractCount: 256 }, contracts: [],
    gpu: { available: true, state, stage: state === 'completed' ? 'finished' : state,
      stale: false, device: 'NVIDIA H200', jobId: 'recorded-gpu-job', updatedAt,
      stepsCompleted: state === 'completed' ? 3000 : 1200, stepsTotal: 3000 },
  };
}

for (const state of ['completed', 'failed']) {
  test(`old ${state} event retains its outcome and ended time without a false heartbeat warning`, () => {
    const { node, render } = dashboard();
    render(snapshot(state));
    assert.equal(node('gpu-status').textContent.toLowerCase(), state);
    assert.equal(node('worker-badge').dataset.state, state);
    assert.match(node('gpu-description').textContent, /ended /);
    assert.match(node('worker-summary').textContent, /does not monitor/);
    assert.equal(node('status-notice').hidden, true);
    assert.equal(node('connection-status').span.textContent, `Chain checked · job ${state}`);
    render(snapshot(state), true);
    assert.equal(node('gpu-status').textContent.toLowerCase(), state);
    assert.match(node('status-notice').textContent, /status service could not be refreshed/);
    assert.doesNotMatch(node('status-notice').textContent, /No fresh worker update/);
  });
}

test('running work still requires a fresh heartbeat', () => {
  const { node, render } = dashboard();
  render(snapshot('running'));
  assert.equal(node('gpu-status').textContent, 'Last known');
  assert.match(node('status-notice').textContent, /No fresh worker update/);
  render(snapshot('running', new Date(NOW - 10000).toISOString()));
  assert.equal(node('gpu-status').textContent, 'Running');
  assert.equal(node('status-notice').hidden, true);
  render(snapshot('running', new Date(NOW - 10000).toISOString()), true);
  assert.equal(node('gpu-status').textContent, 'Last known');
});

test('device measurements retain their own observation time and stale state', () => {
  const {node,render}=dashboard(),data=snapshot('completed');
  data.gpuMetrics={available:true,stale:false,updatedAt:new Date(NOW-10000).toISOString(),gpuUtilizationPercent:92,memoryUtilizationPercent:40,memoryUsedMiB:12000,memoryTotalMiB:140000,powerWatts:null,temperatureC:65,activeWorkerProcesses:4};
  render(data);assert.match(node('worker-gpu-metrics').textContent,/GPU 92%/);assert.match(node('worker-gpu-metrics').textContent,/whole GPU, not only ORVIA/);
  data.gpuMetrics.updatedAt=endedAt;render(data);assert.match(node('worker-gpu-metrics').textContent,/sample is stale/);assert.equal(node('gpu-status').textContent,'Completed');
});
