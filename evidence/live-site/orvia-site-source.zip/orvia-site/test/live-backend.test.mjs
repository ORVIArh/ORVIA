import test from 'node:test';
import assert from 'node:assert/strict';
import { keccak256 } from 'ethers';
import evidence from '../server/data/evidence.mjs';
import { ABI, readChain, rpcReader } from '../server/chain.mjs';
import { appendEvent, readLatestGPU, validateEvent, authorize } from '../server/telemetry.mjs';
import { handleWorker } from '../server/http.mjs';
import { statusSnapshot } from '../server/status.mjs';

const NOW = new Date('2026-11-02T18:00:00.000Z');
const now = () => NOW;
const jobId = 'orvia-h200-workflow-20261102';
const token = 'ab'.repeat(32);
const event = (overrides = {}) => ({ schemaVersion: 1, jobId, sequence: 1, state: 'running', stage: 'starting',
  stepsCompleted: 0, stepsTotal: 3000, updatedAt: NOW.toISOString(), device: 'NVIDIA H200',
  diagnosticOnly: true, scientificAcceptance: false, resultSha256: null, checkpointSha256: null, ...overrides });
class MemoryStore {
  data = new Map();
  async get(key) { return this.data.get(key) ?? null; }
  async setJSON(key, value, options) {
    assert.equal(options.onlyIfNew, true, 'Every write must be create-only');
    if (this.data.has(key)) return { modified: false };
    this.data.set(key, structuredClone(value)); return { modified: true };
  }
  async list({ prefix }) { return { blobs: [...this.data.keys()].filter((k) => k.startsWith(prefix)).map((key) => ({ key })) }; }
}

test('worker auth rejects missing/wrong credentials without echoing values', () => {
  assert.throws(() => authorize(null, token), /unauthorized/);
  assert.throws(() => authorize('Bearer '+token, ''), /not_configured/);
  assert.throws(() => authorize('Bearer '+token.slice(1), token), /unauthorized/);
  assert.doesNotThrow(() => authorize('Bearer '+token, token));
});

test('strict event rejects job changes, added fields, scientific claims and malformed values', () => {
  const mutations = [
    { jobId: 'different-job' }, { privateKey: 'secret' }, { sequence: 10001 }, { sequence: 1.5 },
    { state: 'approved' }, { stage: 'http://evil.invalid' }, { stepsCompleted: -1 },
    { stepsTotal: 9999 }, { updatedAt: 'not a date' }, { device: 'local GPU' },
    { diagnosticOnly: false }, { scientificAcceptance: true }, { resultSha256: 'A'.repeat(64) },
    { resultSha256: 'a'.repeat(64) }, { checkpointSha256: '../secret' },
    { state: 'completed', stage: 'finished', stepsCompleted: 3000 },
  ];
  for (const changes of mutations) assert.throws(() => validateEvent(event(changes), jobId), /invalid_event/);
});

test('RTX 6000 Ada telemetry preserves the exact device identity throughout a job', async () => {
  const store = new MemoryStore(), device = 'NVIDIA RTX 6000 Ada Generation';
  await appendEvent({ store, input: event({ device }), jobId, now });
  await appendEvent({ store, input: event({ device, sequence: 2, stage: 'simulating', stepsCompleted: 100 }), jobId, now });
  assert.equal((await readLatestGPU({ store, jobId, now })).device, device);
  await assert.rejects(appendEvent({ store, input: event({ sequence: 3, stepsCompleted: 100 }), jobId, now }), /device_changed/);
  for (const unsupported of ['RTX 6000 Ada', 'NVIDIA RTX 6000 Ada Generation extra', 'NVIDIA RTX 6000']) {
    assert.throws(() => validateEvent(event({ device: unsupported }), jobId), /invalid_event/);
  }
});

test('immutable telemetry enforces sequence, progression, terminal state and retry identity', async () => {
  const store = new MemoryStore();
  const add = (input, clock = now) => appendEvent({ store, input, jobId, now: clock });
  assert.deepEqual(await add(event()), { accepted: true, duplicate: false, sequence: 1 });
  assert.equal((await add(event())).duplicate, true);
  await assert.rejects(add(event({ stage: 'environment' })), /sequence_conflict/);
  await assert.rejects(add(event({ sequence: 3 })), /missing_previous_event/);
  await add(event({ sequence: 2, stage: 'simulating', stepsCompleted: 100 }));
  await assert.rejects(add(event({ sequence: 3, stepsCompleted: 99 })), /progress_regressed/);
  await assert.rejects(add(event({ sequence: 3, stepsCompleted: 100, updatedAt: '2026-11-02T17:59:59.000Z' })), /timestamp_regressed/);
  await add(event({ sequence: 3, state: 'completed', stage: 'finished', stepsCompleted: 3000,
    resultSha256: 'a'.repeat(64), checkpointSha256: 'b'.repeat(64) }));
  await assert.rejects(add(event({ sequence: 4, stepsCompleted: 3000 })), /job_finished/);
  const final = await readLatestGPU({ store, jobId, now: () => new Date('2027-01-01T00:00:00.000Z') });
  assert.equal(final.state, 'completed'); assert.equal(final.stale, false); assert.equal(final.scientificAcceptance, false);
  assert.equal(store.data.size, 3);
});

test('concurrent identical retries create exactly one immutable event and conflict cannot overwrite', async () => {
  const store = new MemoryStore();
  const results = await Promise.all([1,2,3,4].map(() => appendEvent({ store, input: event(), jobId, now })));
  assert.equal(results.filter((r) => !r.duplicate).length, 1); assert.equal(store.data.size, 1);
  const conflicts = await Promise.allSettled([
    appendEvent({ store, input: event({ sequence: 2, stepsCompleted: 1 }), jobId, now }),
    appendEvent({ store, input: event({ sequence: 2, stepsCompleted: 2 }), jobId, now }),
  ]);
  assert.equal(conflicts.filter((r) => r.status === 'fulfilled').length, 1);
  assert.equal(store.data.size, 2);
});

test('telemetry distinguishes stale running work, missing jobs and storage failure', async () => {
  const store = new MemoryStore();
  assert.equal((await readLatestGPU({ store, jobId, now })).reason, 'no_telemetry');
  await appendEvent({ store, input: event(), jobId, now });
  assert.equal((await readLatestGPU({ store, jobId, now })).stale, false);
  assert.equal((await readLatestGPU({ store, jobId, now: () => new Date(NOW.getTime()+121000) })).reason, 'heartbeat_stale');
  const broken = { list() { throw new Error('private-token-do-not-expose'); } };
  const unavailable = await readLatestGPU({ store: broken, jobId, now });
  assert.equal(unavailable.reason, 'unavailable'); assert.equal(JSON.stringify(unavailable).includes('private-token'), false);
  await assert.rejects(appendEvent({ store: new MemoryStore(), input: event({ updatedAt: '2026-11-02T17:00:00.000Z' }), jobId, now }), /event_time_out_of_range/);
});

test('failed terminal telemetry retains its outcome without claiming current pod activity', async () => {
  const store = new MemoryStore();
  await appendEvent({ store, input: event(), jobId, now });
  await appendEvent({ store, input: event({ sequence: 2, state: 'failed', stage: 'failed' }), jobId, now });
  const failed = await readLatestGPU({ store, jobId, now: () => new Date(NOW.getTime() + 86400000) });
  assert.equal(failed.available, true);
  assert.equal(failed.state, 'failed');
  assert.equal(failed.stale, false);
  assert.equal(failed.updatedAt, NOW.toISOString());
  assert.equal(failed.podState, 'not_monitored');
  assert.equal(failed.scientificAcceptance, false);
});

test('replay-only telemetry counts 80000 new steps and cannot reuse the parent total',()=>{
  const replay='orvia-stress-replay-20261102-03';
  assert.doesNotThrow(()=>validateEvent(event({jobId:replay,stepsTotal:80000}),replay,80000));
  assert.throws(()=>validateEvent(event({jobId:replay,stepsTotal:400000}),replay,80000),/invalid_event/);
});

const request = (body = event(), extra = {}) => new Request('https://orvia.fyi/api/orvia/worker', {
  method: 'POST', headers: { 'content-type': 'application/json', authorization: 'Bearer '+token, ...extra }, body: JSON.stringify(body),
});
test('HTTP admission protects production, auth, browser origin and size before persistence', async () => {
  const store = new MemoryStore();
  const options = { context: { deploy: { context: 'production' } }, token, jobId, totalSteps: 3000, getStore: () => store, now };
  assert.equal((await handleWorker(request(), options)).status, 200);
  assert.equal((await handleWorker(request(), { ...options, context: { deploy: { context: 'deploy-preview' } } })).status, 403);
  assert.equal((await handleWorker(request(event(), { authorization: 'Bearer wrong' }), options)).status, 401);
  assert.equal((await handleWorker(request(event(), { origin: 'https://orvia.fyi' }), options)).status, 403);
  assert.equal((await handleWorker(request(event(), { 'content-length': '999999' }), options)).status, 413);
  assert.equal((await handleWorker(request('x'.repeat(5000)), options)).status, 413);
  assert.equal((await handleWorker(request(event(), { 'content-type': 'text/plain' }), options)).status, 415);
  const unavailable = await handleWorker(request(), { ...options, getStore: () => { throw Error('secret'); } });
  assert.equal(unavailable.status, 503); assert.equal(await unavailable.text(), '{"error":"unavailable"}');
  assert.equal(store.data.size, 1);
});

function mockRPC({ overrides = {}, reorg = false } = {}) {
  const reference = structuredClone(evidence);
  const code = '0x6001600055';
  reference.contracts[0].runtimeHash = keccak256(code);
  reference.contracts[143].runtimeHash = keccak256(code);
  const zero = '0x'+'0'.repeat(64), calls = [];
  const fields = {
    owner: reference.owner, operator: reference.operator, shardCount: 255, deploymentReady: true,
    shardFor: reference.report.shard,
    runInfo: [reference.report.experimentId, zero, zero, zero, reference.report.checkpointHash, reference.report.resultHash, zero, 1, 6, 0, 7, 7, 2, true],
    reportAt: [zero, reference.report.checkpointHash, reference.report.resultHash, reference.report.attestationDigest, 6, 123456, 7, 1],
    ...overrides,
  };
  const fetcher = async (_url, options) => {
    const input = JSON.parse(options.body); calls.push(input);
    let result;
    if (input.method === 'eth_chainId') result = overrides.chainId ?? '0x1237';
    else if (input.method === 'eth_getBlockByNumber') result = { number: '0x6391038', hash: '0x'+(reorg && input.params[0] !== 'latest' ? 'b' : 'a').repeat(64) };
    else if (input.method === 'eth_getCode') result = overrides.code ?? code;
    else if (input.method === 'eth_call') { const call = ABI.parseTransaction({ data: input.params[0].data }); result = ABI.encodeFunctionResult(call.name, [fields[call.name]]); }
    else throw Error('Forbidden method');
    return Response.json({ jsonrpc: '2.0', id: input.id, result });
  };
  return { reference, fetcher, calls };
}

test('read-only chain path binds runtime, report fields and one stable block', async () => {
  const mock = mockRPC();
  const result = await readChain({ url: 'https://rpc.invalid/private', ...mock, now });
  assert.equal(result.available, true); assert.equal(result.contractCount, 256); assert.equal(result.reportMatches, true);
  assert.equal(mock.calls.some((c) => /send|sign|estimate/.test(c.method)), false);
  const callBlocks = mock.calls.filter((c) => c.method === 'eth_call' || c.method === 'eth_getCode').map((c) => c.params[1]);
  assert.equal(new Set(callBlocks).size, 1);
  await assert.rejects(rpcReader('https://rpc.invalid', mock.fetcher)('eth_sendRawTransaction', []), /verification_failed/);
});

test('chain mismatch, runtime changes, altered report, reorg and provider error fail closed', async () => {
  for (const variant of [{ overrides: { chainId: '0x1' } }, { overrides: { code: '0x00' } }, { overrides: { shardCount: 254 } }, { overrides: { deploymentReady: false } }, { reorg: true }]) {
    const result = await readChain({ url: 'https://rpc.invalid/private', ...mockRPC(variant), now });
    assert.equal(result.available, false); assert.equal(result.reportMatches, false); assert.equal(result.contractCount, null);
  }
  const missing = await readChain({ now }); assert.equal(missing.reason, 'not_configured');
  const error = await readChain({ url: 'https://rpc.invalid/secret', fetcher: async () => { throw new Error('secret'); }, now });
  assert.equal(error.reason, 'unavailable'); assert.equal(JSON.stringify(error).includes('secret'), false);
});

test('public status keeps historical proof separate when live providers are unavailable', async () => {
  const value = await statusSnapshot({ now });
  assert.equal(value.chain.available, false); assert.equal(value.gpu.available, false);
  assert.equal(value.contracts.length, 256); assert.equal(value.reports[0].liveConfirmed, false);
  assert.equal(value.reports[0].retrospective, true); assert.equal(value.reports[0].scientificAcceptance, false);
  assert.equal(value.costs.onchainTotalEth, '0.004624545838076');
  assert.equal(BigInt(evidence.costs.deploymentEth.replace('.','')) > 0n, true);
  assert.equal(JSON.stringify(value).includes('privateKey'), false);
});
