import test from 'node:test';
import assert from 'node:assert/strict';
import { validateMetrics, appendMetrics, readMetrics, handleMetrics } from '../server/gpu-metrics.mjs';

const jobId='orvia-stress-20261102-02',token='ac'.repeat(32),at='2026-11-03T00:00:00.000Z',now=()=>new Date(at);
const sample=(change={})=>({schemaVersion:1,jobId,sequence:1,updatedAt:at,device:'NVIDIA H200',gpuUtilizationPercent:90,memoryUtilizationPercent:40,memoryUsedMiB:12000,memoryTotalMiB:140000,powerWatts:400,temperatureC:65,activeWorkerProcesses:4,...change});
class Store {
  data=new Map();
  async get(key){return this.data.get(key)??null;}
  async setJSON(key,value,{onlyIfNew}){assert.equal(onlyIfNew,true);if(this.data.has(key))return{modified:false};this.data.set(key,value);return{modified:true};}
  async list({prefix}){return{blobs:[...this.data.keys()].filter(key=>key.startsWith(prefix)).map(key=>({key}))};}
}
test('metric samples accept real nullable readings and reject claims, extra fields and impossible values',()=>{
  assert.doesNotThrow(()=>validateMetrics(sample({powerWatts:null}),jobId));
  for(const change of [{jobId:'other-job'},{gpuUtilizationPercent:101},{memoryUsedMiB:150000},{temperatureC:Infinity},{scientificAcceptance:true},{activeWorkerProcesses:4.5},{device:'local GPU'},{sequence:0},{updatedAt:'not-time'}])assert.throws(()=>validateMetrics(sample(change),jobId),/invalid_gpu_sample/);
});
test('immutable metric samples permit sequence gaps, preserve retries and age independently from job completion',async()=>{
  const store=new Store(),add=input=>appendMetrics({store,input,jobId,now});
  assert.equal((await add(sample())).duplicate,false);assert.equal((await add(sample())).duplicate,true);
  await assert.rejects(add(sample({powerWatts:500})),/sequence_conflict/);
  await add(sample({sequence:4,activeWorkerProcesses:0}));
  const result=await readMetrics({store,jobId,now});assert.equal(result.sequence,4);assert.equal(result.scope,'whole_device');assert.equal(result.stale,false);assert.equal(result.activeWorkerProcesses,0);
  const stale=await readMetrics({store,jobId,now:()=>new Date(Date.parse(at)+46000)});assert.equal(stale.stale,true);assert.equal(stale.available,true);
  await assert.rejects(add(sample({sequence:5,updatedAt:'2025-01-01T00:00:00.000Z'})),/sample_time_out_of_range/);
});
test('metrics endpoint requires production worker authorization and never accepts browser-origin uploads',async()=>{
  const store=new Store(),options={context:{deploy:{context:'production'}},token,jobId,getStore:()=>store,now};
  const request=(extra={})=>new Request('https://orvia.fyi/api/orvia/gpu',{method:'POST',headers:{'content-type':'application/json',authorization:'Bearer '+token,...extra},body:JSON.stringify(sample())});
  assert.equal((await handleMetrics(request(),options)).status,200);
  assert.equal((await handleMetrics(request({authorization:'Bearer wrong'}),options)).status,401);
  assert.equal((await handleMetrics(request({origin:'https://orvia.fyi'}),options)).status,403);
  assert.equal((await handleMetrics(request(),{...options,context:{deploy:{context:'deploy-preview'}}})).status,403);
  assert.equal((await handleMetrics(request({'content-length':'5000'}),options)).status,413);
  assert.equal((await handleMetrics(new Request('https://orvia.fyi/api/orvia/gpu'),options)).status,405);
});
