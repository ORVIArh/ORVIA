import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import * as THREE from 'three';
import {validateTrajectory,trajectoryURL,trajectoryRecordLabel,selectTrajectoryRecord} from '../src/trajectory-data.js';

// Run actual event handlers, geometry updates and frame timing without a WebGL context.
function viewer() {
  class Node extends EventTarget {
    value='10';checked=true;disabled=false;hidden=false;textContent='';dataset={};
    setAttribute(){}querySelector(selector){this.selectors??={};return this.selectors[selector]??=new Node();}getBoundingClientRect(){return{width:500,height:300};}
  }
  const nodes=new Map(),node=id=>{if(!nodes.has(id))nodes.set(id,new Node());return nodes.get(id);};
  const window=new EventTarget();
  const context=vm.createContext({THREE,validateTrajectory,trajectoryURL,trajectoryRecordLabel,selectTrajectoryRecord,window,
    document:{getElementById:node,documentElement:{dataset:{}},addEventListener(){}},CustomEvent,
    cancelAnimationFrame(){},requestAnimationFrame(){return 1;}});
  const source=readFileSync(new URL('../src/trajectory-viewer.js',import.meta.url),'utf8').replace(/^import .*;\n/gm,'');
  vm.runInContext(source+'\nglobalThis.viewerTest={state,frame,play,leavePage,restorePage};',context);
  const api=context.viewerTest;
  api.state.data={atoms:[{group:'ligand',element:'C'}],frames:[0,.01,.02].map((x,i)=>({timeFs:i,step:i*10,positions:[[x,0,0]]}))};
  let atomX=null;
  api.state.groups=[{userData:{group:'ligand',indices:[0]},instanceMatrix:{},setMatrixAt(i,matrix){atomX=matrix.elements[12];}}];
  api.frame(0);
  return{api,node,window,atomX:()=>atomX};
}

test('Play advances real recorded geometry and reports each frame without amplifying motion',()=>{
  const {api,node,atomX}=viewer();
  node('trajectory-play').dispatchEvent(new Event('click'));
  assert.equal(api.state.playing,true);
  assert.match(node('trajectory-playback').textContent,/Playing · frame 1 of 3/);
  api.play(1000);assert.equal(api.state.frame,1);assert.equal(atomX(),.01);
  assert.match(node('trajectory-playback').textContent,/Playing · frame 2 of 3 · recorded time 1 \/ 2 fs/);
  api.play(1100);assert.equal(atomX(),.02);
  api.play(1200);assert.equal(api.state.playing,false);
  assert.match(node('trajectory-playback').textContent,/Playback finished · frame 3 of 3/);
  node('trajectory-play').dispatchEvent(new Event('click'));assert.equal(api.state.frame,0);assert.equal(atomX(),0);
  node('trajectory-play').dispatchEvent(new Event('click'));assert.equal(api.state.playing,false);
  assert.match(node('trajectory-playback').textContent,/Paused/);
});

test('back-forward cache retains reusable graphics and restores the recorded frame',()=>{
  const {api,node,window}=viewer();let disposed=0,renders=0,ready=0;
  api.state.renderer={dispose(){disposed++;},setSize(){},render(){renders++;}};
  api.state.controls={dispose(){disposed++;}};
  api.state.camera={updateProjectionMatrix(){}};api.state.scene={};
  api.frame(1);api.state.playing=true;
  window.addEventListener('orvia:trajectory-ready',()=>ready++);
  api.leavePage({persisted:true});assert.equal(disposed,0);assert.equal(api.state.playing,false);
  const before=renders;api.restorePage({persisted:true});
  assert.ok(renders>before);assert.equal(api.state.frame,1);assert.equal(node('trajectory-play').disabled,false);assert.equal(ready,1);
  api.leavePage({persisted:false});assert.equal(disposed,2);
});

test('lost graphics remain disabled until the context is restored',()=>{
  const {api,node}=viewer();
  api.state.renderer={setSize(){},render(){}};api.state.camera={updateProjectionMatrix(){}};api.state.scene={};
  node('trajectory-canvas').dispatchEvent(new Event('webglcontextlost',{cancelable:true}));
  assert.equal(node('trajectory-play').disabled,true);assert.equal(api.state.contextLost,true);
  api.restorePage({persisted:true});assert.equal(node('trajectory-play').disabled,true);
  node('trajectory-canvas').dispatchEvent(new Event('webglcontextrestored'));
  assert.equal(api.state.contextLost,false);assert.equal(node('trajectory-play').disabled,false);
});

test('hidden atom groups explain the blank view and Reset view restores visibility and camera',()=>{
  const {api,node}=viewer();
  api.state.camera=new THREE.PerspectiveCamera(42,1,.01,100);
  api.state.camera.position.set(1000,1000,1000);
  api.state.controls={target:new THREE.Vector3(),update(){}};
  api.frame(1);
  node('show-protein').checked=false;node('show-ligand').checked=false;node('show-initial').checked=true;
  node('show-ligand').dispatchEvent(new Event('change'));
  assert.equal(api.state.groups[0].visible,false);
  assert.equal(node('trajectory-empty').hidden,false);
  assert.equal(node('trajectory-empty').querySelector('h3').textContent,'All atoms are hidden.');
  node('trajectory-reset').dispatchEvent(new Event('click'));
  assert.equal(node('show-protein').checked,true);assert.equal(node('show-ligand').checked,true);
  assert.equal(node('show-initial').checked,false);assert.equal(api.state.groups[0].visible,true);
  assert.equal(node('trajectory-empty').hidden,true);assert.equal(api.state.frame,1);
  assert.ok(api.state.camera.position.distanceTo(api.state.controls.target)<10);
});
