import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { handleTrajectory, saveTrajectory, trajectoryList, readableTrajectories, validateTrajectory } from '../server/trajectory.mjs';
import { readableWorkflowIds, workflowProfile } from '../server/workflows.mjs';

const jobId = 'orvia-live-20261102-01', token = 'af'.repeat(32);
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
function artifact() {
  return { schemaVersion: 1, jobId, modelId: 'solvent33', label: 'Solvent diagnostic', fullAtomCount: 151505, selectedAtomCount: 44,
    selection: 'Ligand heavy atoms', timeUnit: 'fs', lengthUnit: 'nm',
    atoms: Array.from({length:44},(_,index)=>({index,element:'C',name:'C'+index,residueName:'LIG',residueId:1,group:'ligand'})),
    bonds: [[0,1],[1,2]], backboneLinks: [],
    frames: Array.from({length:101},(_,index)=>({step:index*10,timeFs:index,positions:Array.from({length:44},(_,atom)=>[atom/10,index/100,1]),fullPositionsSha256:'a'.repeat(64)})),
    diagnosticOnly:true,scientificAcceptance:false,
    source:Object.fromEntries(['systemSha256','positionsSha256','selectionSha256','topologySha256','runnerSha256','inputManifestSha256'].map((key)=>[key,'b'.repeat(64)])),
    imaging:{method:'minimum-image initial chain and ligand unwrapping; per-atom temporal unwrapping; no alignment or interpolation',boxVectorsNm:[[10,0,0],[0,10,0],[0,0,10]],coordinateDecimals:6},
  };
}
class MemoryStore {
  data=new Map();
  async get(key){return this.data.get(key)??null;}
  async set(key,value,{onlyIfNew}){assert.equal(onlyIfNew,true);if(this.data.has(key))return{modified:false};this.data.set(key,value);return{modified:true};}
  async setJSON(...args){return this.set(...args);}
}
const now=()=>new Date('2026-11-02T18:00:00.000Z');

test('trajectory admission rejects scientific claims, invalid frame data, identities and unsafe metadata',()=>{
  assert.doesNotThrow(()=>validateTrajectory(artifact(),jobId));
  const mutations=[
    a=>a.scientificAcceptance=true, a=>a.diagnosticOnly=false, a=>a.modelId='other', a=>a.jobId='different-job',
    a=>a.selectedAtomCount=45, a=>a.fullAtomCount=151506, a=>a.source.token='secret',
    a=>a.source.runnerSha256='wrong', a=>a.source.runnerSha256=['b'.repeat(64)], a=>a.frames[0].fullPositionsSha256=['a'.repeat(64)], a=>a.atoms[1].index=0, a=>a.atoms[1].index=200000,
    a=>a.atoms[0].name='<img>', a=>a.bonds.push([0,1]), a=>a.bonds.push([0,44]),
    a=>a.backboneLinks.push([0,0]), a=>a.frames[5].step=51, a=>a.frames[5].timeFs=3,
    a=>a.frames[0].positions[0][1]=Infinity, a=>a.frames[0].positions.pop(), a=>a.frames.pop(),
    a=>a.imaging.method='synthetic interpolation', a=>a.label='<script>bad</script>', a=>a.url='https://evil.invalid',
  ];
  for(const change of mutations){const a=artifact();change(a);assert.throws(()=>validateTrajectory(a,jobId),/invalid_trajectory/);}
});

test('artifact is immutable per job/model and exact-byte hash bound',async()=>{
  const store=new MemoryStore(), data=artifact(), bytes=Buffer.from(JSON.stringify(data)), expectedHash=sha(bytes);
  const first=await saveTrajectory({store,data,bytes,expectedHash,jobId,now});assert.equal(first.duplicate,false);
  assert.equal((await saveTrajectory({store,data,bytes,expectedHash,jobId,now})).duplicate,true);
  await assert.rejects(saveTrajectory({store,data,bytes,expectedHash:'a'.repeat(64),jobId,now}),/hash_mismatch/);
  const changed=structuredClone(data);changed.frames[0].positions[0][0]=.1;
  const changedBytes=Buffer.from(JSON.stringify(changed));
  await assert.rejects(saveTrajectory({store,data:changed,bytes:changedBytes,expectedHash:sha(changedBytes),jobId,now}),/trajectory_already_recorded/);
  const listing=await trajectoryList(store,jobId);assert.equal(listing.length,1);assert.equal(listing[0].sha256,expectedHash);
  assert.equal(listing[0].durationFs,100);assert.equal(listing[0].scientificAcceptance,false);assert.equal(store.data.size,2);
});

test('authenticated POST and public GET never expose arbitrary blobs or cross-job artifacts',async()=>{
  const store=new MemoryStore(), data=artifact(), raw=JSON.stringify(data), hash=sha(raw);
  const options={context:{deploy:{context:'production'}},token,jobId,getStore:()=>store,now};
  const post=(extra={})=>new Request('https://orvia.fyi/api/orvia/trajectory',{method:'POST',headers:{'content-type':'application/json',authorization:'Bearer '+token,'x-orvia-sha256':hash,...extra},body:raw});
  assert.equal((await handleTrajectory(post(),options)).status,200);
  assert.equal((await handleTrajectory(post({authorization:'Bearer wrong'}),options)).status,401);
  assert.equal((await handleTrajectory(post({'content-length':'5000000'}),options)).status,413);
  assert.equal((await handleTrajectory(post(),{...options,context:{deploy:{context:'deploy-preview'}}})).status,403);
  assert.equal((await handleTrajectory(post({origin:'https://orvia.fyi'}),options)).status,403);
  const get=(query)=>handleTrajectory(new Request('https://orvia.fyi/api/orvia/trajectory?'+query),options);
  const served=await get(`jobId=${jobId}&sha256=${hash}`);assert.equal(served.status,200);assert.equal(await served.text(),raw);
  assert.equal(served.headers.get('etag'),`"${hash}"`);
  assert.equal((await get(`jobId=other-job&sha256=${hash}`)).status,404);
  assert.equal((await get(`jobId=${jobId}&sha256=${'a'.repeat(64)}`)).status,404);
  assert.equal((await get(`jobId=${jobId}&sha256=${hash}&key=private`)).status,400);
  assert.equal((await get(`jobId=${jobId}&sha256=${hash}&sha256=${hash}`)).status,400);
  store.data.set(`trajectory-data/${jobId}/${hash}`,'changed');
  assert.equal((await get(`jobId=${jobId}&sha256=${hash}`)).status,503);
});

test('stress profile admits exact 8ps frames and rejects the old schedule',()=>{
  const stress=artifact();stress.jobId='orvia-stress-20261102-02';
  Object.assign(stress.source, {runnerSha256:workflowProfile(stress.jobId).runnerSha256,inputManifestSha256:workflowProfile(stress.jobId).inputManifestSha256});
  assert.throws(()=>validateTrajectory(stress,stress.jobId),/invalid_trajectory/);
  stress.frames.forEach((f,i)=>{f.step=i*800;f.timeFs=i*80;});
  assert.doesNotThrow(()=>validateTrajectory(stress,stress.jobId));
  const substituted=structuredClone(stress);substituted.source.runnerSha256='f'.repeat(64);
  assert.throws(()=>validateTrajectory(substituted,substituted.jobId),/invalid_trajectory/);
  stress.frames[100].timeFs=8001;
  assert.throws(()=>validateTrajectory(stress,stress.jobId),/invalid_trajectory/);
  assert.throws(()=>validateTrajectory({...artifact(),jobId:'unreviewed-new-job'},'unreviewed-new-job'),/workflow_not_configured/);
});

test('explicit historical allowlist preserves reads without reopening historical writes',async()=>{
  const store=new MemoryStore(), data=artifact(), bytes=Buffer.from(JSON.stringify(data)), expectedHash=sha(bytes);
  await saveTrajectory({store,data,bytes,expectedHash,jobId,now});
  const current='orvia-stress-20261102-02';
  const options={context:{deploy:{context:'production'}},token,jobId:current,historicalIds:jobId,getStore:()=>store,now};
  const listing=await readableTrajectories(store,current,jobId);
  assert.equal(listing.length,1);assert.equal(listing[0].historical,true);assert.equal(listing[0].jobId,jobId);
  const get=new Request(`https://orvia.fyi/api/orvia/trajectory?jobId=${jobId}&sha256=${expectedHash}`);
  const served=await handleTrajectory(get,options);assert.equal(served.status,200);assert.equal(await served.text(),bytes.toString());
  assert.equal((await handleTrajectory(get,{...options,historicalIds:''})).status,404);
  const post=new Request('https://orvia.fyi/api/orvia/trajectory',{method:'POST',headers:{'content-type':'application/json',authorization:'Bearer '+token,'x-orvia-sha256':expectedHash},body:bytes});
  assert.equal((await handleTrajectory(post,options)).status,400);
  for(const invalid of ['*','other-job',jobId+','+jobId,jobId+',',current])assert.throws(()=>readableWorkflowIds(current,invalid),/invalid_history_configuration/);
});
