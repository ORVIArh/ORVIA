# ORVIA website

A responsive scientific presentation site for ORVIA, with an interactive WebGL heart adapted from an anatomical reference and a self-contained Three.js bundle.

## Run locally

```sh
python3 -m http.server 4173 --directory dist --bind 127.0.0.1
```

Open http://127.0.0.1:4173 for the static presentation and contract catalog. The live dashboard uses the Netlify functions described in `server/README.md`; a static server displays an honest unavailable state for live data. Browser assets use no external CDN. To change the heart renderer, run `npm ci` and `npm run build:heart`; its sources are `src/heart-scene.js`, `src/heart-anatomy.js`, `src/heart-fibers.js` and `src/vessel-material.js` and the committed browser bundle is `dist/heart-scene.js`.

## Experience

- Light mode by default, an explicit persistent dark-mode choice, shared appearance and motion controls, and paired custom anatomical heart artworks.
- An editorial Newsreader display family paired with Manrope for readable scientific copy and controls. Local WOFF2 fonts keep the experience independent of runtime font services.
- Finite section entrances, diagram stroke drawing, panel transitions and layered hover details share the motion pause and reduced-motion preferences; content remains visible if animation is unavailable.
- Adapted anatomical WebGL hearts in the hero and science explorer, translucent ivory/smoky glass and gold materials, atlas-based coronary geometry, GPU deformation, and illustrative three-dimensional myocardial fibre bundles.
- Drag/keyboard rotation, 45–110 bpm illustration-rate control, fibre visibility, pause/resume and reset. Offscreen rendering pauses and device pixel ratio is capped. Loading or graphics-context failures restore the themed hero artwork or the science section's geometry schematic.
- Three biological-scale views and a schematic reference/hypertrophic geometry comparison.
- Rotatable structure and binding-pocket views using deposited 9F6C coordinates.
- Six interactive proposed on-chain stages with a guided walkthrough.
- A clear scientific progression: question, declared model, two-environment calculation, convergence and uncertainty, then public evidence.
- Evidence-gated roadmap, source library, keyboard navigation, reduced-motion support and a persistent motion pause.
- Dedicated `/orvia/` proposed-utility page: commissioning experiments, reviewed treasury choices and useful contributions. A five-stage sponsored research walkthrough, funding explanations and FAQs remain informational; no wallet, funding order or transaction is accepted.

## Scientific boundaries

The reporting infrastructure is deployed on Robinhood mainnet: one coordinator and 255 report stores. `/contracts/` publishes all 256 addresses, their shared roles, source files and dated runtime-verification evidence. `/live/` reads the current coordinator and recorded diagnostic report through a server-side read-only RPC connection, separately from the historical full inventory.

The GPU workflow sends authenticated progress and actual selected-coordinate trajectories to the site. The 3D viewer verifies each downloaded artifact hash and plays discrete recorded frames; camera rotation, C-alpha trace guides and physical molecular motion are distinct. An unavailable worker, stale progress or missing trajectory is shown explicitly. The browser cannot start paid work, access the signing wallet, or submit a chain transaction. Public trajectory and telemetry validation establishes the expected data format and identity, not scientific correctness.

The active full model is the separately named ADP/phosphate experiment. Numerical diagnostics and operator signatures do not establish accepted parameters, production sampling, a binding-affinity result or patient outcomes. The original vanadate proposal remains separate. New worker results remain off chain until independently reviewed and accepted through a distinct signed reporting operation.

Run `node --test test/*.test.mjs src/trajectory-data.test.mjs` for the lightweight backend and viewer-admission checks. No molecular computation or wallet is used by these tests. The production service uses functions-scoped secrets; they are never included in `dist/`, the source archive, or the GPU package.

Structure data: RCSB PDB 9F6C (bovine cardiac myosin, chain A, with aficamten). Backbone and pocket rendering are simplified; pocket bonds are inferred for visualization. Deposited aficamten bonds are retained. This is not a simulated trajectory.

Scientific sources:
- https://github.com/ORVIArh/ORVIA
- https://www.nature.com/articles/s44161-024-00505-0
- https://www.rcsb.org/structure/9F6C
- https://doi.org/10.1021/acs.jmedchem.1c01290
- https://www.heart.org/professional/-/media/Files/Health-Topics/Answers-by-Heart/What-is-HCM.pdf

## Assets

The hero artwork was generated with built-in Imagegen; exact prompts are retained in `heart-hero-prompt.txt` and `heart-hero-dark-prompt.txt`. It is a conceptual illustration. Manrope fonts are distributed with the SIL Open Font License in `dist/assets/Manrope-LICENSE.txt`. Newsreader is distributed under the SIL Open Font License in `dist/assets/Newsreader-LICENSE.txt`, sourced from the official Google Fonts repository and served as local Latin WOFF2 subsets. All diagrams, interactions and the structure renderer are original site code.

## Hosting

The exact Sites project identity is retained in `.openai/hosting.json`. Publish through the Sites source workflow, preserving the existing audience. The Sites copy was created owner-private. The Netlify production project is `orvia-7ulo` (site ID `3879f07b-38b6-4b0a-a45f-bc8d0fa01c95`). Local `.netlify/` state is ignored. The user explicitly authorized public visitor access; Netlify sign-in protection has been removed for this project.


## Anatomical heart

`dist/assets/heart-anatomy.glb` contains 11 BodyParts3D anatomical groups prepared by OrganUI. The presentation hides cavity-volume meshes, retains atlas ventricular/atrial/coronary surfaces, welds normals and applies gentle volume-preserving smoothing. Coarse major-vessel geometry is reconstructed along atlas-based centreline trajectories as connected hollow surfaces with inner walls and open rims; aortic branch stubs are refined. Additional fine coronary detail uses surface-following tapered tubes attached to source coronary structures. Gold rim tracings and dense, branching three-dimensional filaments at several depths inside vessel walls add layered detail. These decorative vessel refinements are designed adaptations of the atlas, not additional measured anatomy or histology.

Upper vessels use alpha-blended three-dimensional membranes with soft surface highlights, an authored light-dependent scattering approximation and Fresnel-style edge opacity capped at 0.64. A separate thin inner lamina sits at variable depth within each hollow wall, alongside the gold filament geometry. The upper-vessel material does not use native glass transmission; Three.js transmission/refraction remains on the lower ventricular shell. These are display techniques for translucent tissue, not measured optical properties or a full simulation of light transport through tissue.

Fibre bundles are generated from outer ventricular contours sampled at horizontal cross-sections, with smoothed radial interpolation. Tapered elliptical tubes form three approximate orientation/depth families with varied lengths and curvature. These are constructed display geometry, not measured myocardial fibre directions or diffusion-imaging data.

Materials, lighting and a shared GPU deformation give the tissue, coronary structures and fibre bundles an illustrative contraction cycle. The 45–110 bpm control changes the animation rate; it is not a measurement, physiological solver or model of treatment response. The source anatomy, adapted surfaces and illustrative fibres are distinct from ORVIA's proposed molecular calculations. The original static reference and its provenance remain available in the distributed GLB and attribution file.

BodyParts3D © DBCLS, CC BY 4.0. Exact provenance and modifications are retained in `dist/assets/heart-anatomy-license.txt`; Three.js MIT license is in `dist/assets/three-LICENSE.txt`. The two generated heart artworks are fallback assets, with their original prompts preserved.

## Quality audit

Run `python3 quality/audit.py` for the 75 reproducible source checks and the 25 separately evidenced browser checks. The audit records actual outcomes and limitations, not a promise of complete cross-browser certification. Browser evidence covers desktop/mobile, both themes, keyboard controls, live WebGL interactions, reduced motion, intentional renderer-load failure and both page routes. See `quality/README.md` and the generated audit report.
