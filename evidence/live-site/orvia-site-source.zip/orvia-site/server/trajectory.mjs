import { createHash } from 'node:crypto';
import { authorize, validJob, TelemetryError } from './telemetry.mjs';
import { boundedBody, json } from './http.mjs';
import { workflowProfile, readableWorkflowIds } from './workflows.mjs';

const MAX_BYTES = 4 * 1024 * 1024;
const HASH = /^[a-f0-9]{64}$/;
const MODELS = { complex33: { full: 132935, selected: 794 }, solvent33: { full: 151505, selected: 44 } };
const ELEMENTS = new Set(['H', 'C', 'N', 'O', 'F', 'P', 'S', 'Cl', 'Br', 'I', 'Na', 'Mg', 'K', 'Ca', 'Zn', 'Fe']);
const TOP = ['schemaVersion','jobId','modelId','label','fullAtomCount','selectedAtomCount','selection','timeUnit','lengthUnit','atoms','bonds','backboneLinks','frames','diagnosticOnly','scientificAcceptance','source','imaging'];
const SOURCES = ['systemSha256','positionsSha256','selectionSha256','topologySha256','runnerSha256','inputManifestSha256'];
const ATOM = ['index','element','name','residueName','residueId','group'];
const need = (ok, status = 400, code = 'invalid_trajectory') => { if (!ok) throw new TelemetryError(status, code); };
const exact = (value, keys) => value && typeof value === 'object' && !Array.isArray(value) && Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key));
const safeText = (value, max) => typeof value === 'string' && value.length > 0 && value.length <= max && /^[\x20-\x7e]+$/.test(value) && !/[<>]/.test(value);
const xyz = (value) => Array.isArray(value) && value.length === 3 && value.every((v) => typeof v === 'number' && Number.isFinite(v) && Math.abs(v) < 10000);
const indexKey = (jobId, modelId) => `trajectory-index/${jobId}/${modelId}`;
const payloadKey = (jobId, sha256) => `trajectory-data/${jobId}/${sha256}`;

export function validateTrajectory(data, jobId) {
  need(validJob(jobId), 503, 'not_configured');
  const profile = workflowProfile(jobId);
  need(profile.trajectories !== false, 403, 'trajectory_not_supported');
  need(exact(data, TOP) && data.schemaVersion === 1 && data.jobId === jobId);
  const model = MODELS[data.modelId];
  need(model && data.fullAtomCount === model.full && data.selectedAtomCount === model.selected);
  need(safeText(data.label, 100) && safeText(data.selection, 250));
  need(data.timeUnit === 'fs' && data.lengthUnit === 'nm' && data.diagnosticOnly === true && data.scientificAcceptance === false);
  need(exact(data.source, SOURCES) && SOURCES.every((name) => typeof data.source[name] === 'string' && HASH.test(data.source[name])));
  if (profile.runnerSha256) need(data.source.runnerSha256 === profile.runnerSha256 && data.source.inputManifestSha256 === profile.inputManifestSha256);
  need(exact(data.imaging, ['method','boxVectorsNm','coordinateDecimals']));
  need(data.imaging.method === 'minimum-image initial chain and ligand unwrapping; per-atom temporal unwrapping; no alignment or interpolation' && data.imaging.coordinateDecimals === 6);
  need(Array.isArray(data.imaging.boxVectorsNm) && data.imaging.boxVectorsNm.length === 3 && data.imaging.boxVectorsNm.every(xyz));
  need(Array.isArray(data.atoms) && data.atoms.length === model.selected);
  const indices = new Set();
  for (const atom of data.atoms) {
    need(exact(atom, ATOM) && Number.isInteger(atom.index) && atom.index >= 0 && atom.index < model.full && !indices.has(atom.index));
    indices.add(atom.index);
    need(ELEMENTS.has(atom.element) && safeText(atom.name, 10) && safeText(atom.residueName, 10));
    need(Number.isInteger(atom.residueId) && Math.abs(atom.residueId) < 1e7 && ['protein','ligand'].includes(atom.group));
  }
  for (const field of ['bonds','backboneLinks']) {
    need(Array.isArray(data[field]) && data[field].length <= model.selected * 6);
    const seen = new Set();
    for (const pair of data[field]) {
      need(Array.isArray(pair) && pair.length === 2 && pair.every((n) => Number.isInteger(n) && n >= 0 && n < model.selected) && pair[0] !== pair[1]);
      const key = [...pair].sort((a,b)=>a-b).join(':');
      need(!seen.has(key)); seen.add(key);
    }
  }
  need(Array.isArray(data.frames) && data.frames.length === profile.frameCount);
  for (const [i, frame] of data.frames.entries()) {
    need(exact(frame, ['step','timeFs','positions','fullPositionsSha256']) && frame.step === i * profile.frameStep && frame.timeFs === i * profile.timeStepFs && typeof frame.fullPositionsSha256 === 'string' && HASH.test(frame.fullPositionsSha256));
    need(Array.isArray(frame.positions) && frame.positions.length === model.selected && frame.positions.every(xyz));
  }
  return data;
}

export async function saveTrajectory({ store, data, bytes, expectedHash, jobId, now = () => new Date() }) {
  need(HASH.test(expectedHash), 400, 'hash_required');
  const sha256 = createHash('sha256').update(bytes).digest('hex');
  need(sha256 === expectedHash, 400, 'hash_mismatch');
  validateTrajectory(data, jobId);
  const existing = await store.get(indexKey(jobId, data.modelId), { type: 'json', consistency: 'strong' });
  if (existing) {
    need(existing.sha256 === sha256, 409, 'trajectory_already_recorded');
    return { accepted: true, duplicate: true, sha256 };
  }
  await store.set(payloadKey(jobId, sha256), bytes.toString('utf8'), { onlyIfNew: true });
  const metadata = { jobId, modelId: data.modelId, label: data.label, sha256, byteLength: bytes.length,
    atomCount: data.selectedAtomCount, fullAtomCount: data.fullAtomCount, frameCount: data.frames.length,
    durationFs: data.frames.at(-1).timeFs, diagnosticOnly: true, scientificAcceptance: false,
    uploadedAt: now().toISOString(), source: data.source,
    url: `/api/orvia/trajectory?jobId=${encodeURIComponent(jobId)}&sha256=${sha256}` };
  const write = await store.setJSON(indexKey(jobId, data.modelId), metadata, { onlyIfNew: true });
  if (!write.modified) {
    const winner = await store.get(indexKey(jobId, data.modelId), { type: 'json', consistency: 'strong' });
    need(winner?.sha256 === sha256, 409, 'trajectory_already_recorded');
    return { accepted: true, duplicate: true, sha256 };
  }
  return { accepted: true, duplicate: false, sha256 };
}

export async function trajectoryList(store, jobId) {
  if (!store || !validJob(jobId)) return [];
  const entries = await Promise.all(Object.keys(MODELS).map((modelId) => store.get(indexKey(jobId, modelId), { type: 'json', consistency: 'strong' })));
  return entries.filter(Boolean).map((entry) => {
    need(entry.jobId === jobId && MODELS[entry.modelId] && HASH.test(entry.sha256), 503, 'unavailable');
    return entry;
  });
}

export async function readableTrajectories(store, jobId, historicalIds = '') {
  const jobs = readableWorkflowIds(jobId, historicalIds);
  const groups = await Promise.all(jobs.map(async id => (await trajectoryList(store, id)).map(entry => ({ ...entry, historical: id !== jobId }))));
  return groups.flat();
}

export async function handleTrajectory(request, { context, token, jobId, historicalIds = '', getStore, now } = {}) {
  try {
    if (request.method === 'POST') {
      need(context?.deploy?.context === 'production', 403, 'production_only');
      authorize(request.headers.get('authorization'), token);
      need(!request.headers.has('origin'), 403, 'worker_only');
      const { input, bytes } = await boundedBody(request, MAX_BYTES);
      return json(await saveTrajectory({ store: getStore(), data: input, bytes, expectedHash: request.headers.get('x-orvia-sha256'), jobId, now }));
    }
    if (request.method !== 'GET') return json({ error: 'method_not_allowed' }, 405);
    const params = new URL(request.url).searchParams;
    need([...params.keys()].length === 2 && params.getAll('jobId').length === 1 && params.getAll('sha256').length === 1, 400, 'invalid_query');
    const requestedJob = params.get('jobId');
    need(validJob(jobId) && readableWorkflowIds(jobId, historicalIds).includes(requestedJob) && HASH.test(params.get('sha256')), 404, 'not_found');
    const store = getStore(), sha256 = params.get('sha256');
    const entries = await trajectoryList(store, requestedJob);
    const entry = entries.find((item) => item.sha256 === sha256);
    need(entry, 404, 'not_found');
    const raw = await store.get(payloadKey(requestedJob, sha256), { type: 'text', consistency: 'strong' });
    need(typeof raw === 'string' && Buffer.byteLength(raw) === entry.byteLength && createHash('sha256').update(raw).digest('hex') === sha256, 503, 'unavailable');
    return new Response(raw, { headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'public, max-age=60',
      'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer', ETag: `"${sha256}"` } });
  } catch (error) {
    return error instanceof TelemetryError ? json({ error: error.code }, error.status) : json({ error: 'unavailable' }, 503);
  }
}
