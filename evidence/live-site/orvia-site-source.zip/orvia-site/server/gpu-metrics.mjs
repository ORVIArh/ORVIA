import { authorize, validJob, TelemetryError } from './telemetry.mjs';
import { boundedBody, json } from './http.mjs';

const KEYS = ['schemaVersion','jobId','sequence','updatedAt','device','gpuUtilizationPercent','memoryUtilizationPercent','memoryUsedMiB','memoryTotalMiB','powerWatts','temperatureC','activeWorkerProcesses'];
const need = (ok, status = 400, code = 'invalid_gpu_sample') => { if (!ok) throw new TelemetryError(status, code); };
const metric = (value, min, max) => value === null || typeof value === 'number' && Number.isFinite(value) && value >= min && value <= max;
const prefix = jobId => `gpu-metrics/${jobId}/`;
const key = (jobId, sequence) => prefix(jobId) + String(sequence).padStart(5, '0');

export function validateMetrics(input, jobId) {
  need(validJob(jobId), 503, 'not_configured');
  need(input && typeof input === 'object' && !Array.isArray(input) && Object.keys(input).length === KEYS.length && KEYS.every(k => Object.hasOwn(input, k)));
  need(input.schemaVersion === 1 && input.jobId === jobId && input.device === 'NVIDIA H200');
  need(Number.isInteger(input.sequence) && input.sequence >= 1 && input.sequence <= 10000);
  need(typeof input.updatedAt === 'string' && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(input.updatedAt) && Number.isFinite(Date.parse(input.updatedAt)) && new Date(input.updatedAt).toISOString() === input.updatedAt);
  need(metric(input.gpuUtilizationPercent, 0, 100) && metric(input.memoryUtilizationPercent, 0, 100));
  need(metric(input.memoryUsedMiB, 0, 1048576) && metric(input.memoryTotalMiB, 1, 1048576));
  need(input.memoryUsedMiB === null || input.memoryTotalMiB === null || input.memoryUsedMiB <= input.memoryTotalMiB);
  need(metric(input.powerWatts, 0, 2000) && metric(input.temperatureC, -50, 150));
  need(Number.isInteger(input.activeWorkerProcesses) && input.activeWorkerProcesses >= 0 && input.activeWorkerProcesses <= 64);
  return Object.fromEntries(KEYS.map(k => [k, input[k]]));
}

export async function appendMetrics({ store, input, jobId, now = () => new Date() }) {
  const sample = validateMetrics(input, jobId), sampleKey = key(jobId, sample.sequence);
  const existing = await store.get(sampleKey, { type: 'json', consistency: 'strong' });
  if (existing) {
    need(JSON.stringify(existing.sample) === JSON.stringify(sample), 409, 'sequence_conflict');
    return { accepted: true, duplicate: true, sequence: sample.sequence };
  }
  const receivedAt = now().toISOString(), age = Date.parse(receivedAt) - Date.parse(sample.updatedAt);
  need(age >= -60000 && age <= 600000, 400, 'sample_time_out_of_range');
  const write = await store.setJSON(sampleKey, { sample, receivedAt }, { onlyIfNew: true });
  if (!write.modified) {
    const winner = await store.get(sampleKey, { type: 'json', consistency: 'strong' });
    need(JSON.stringify(winner?.sample) === JSON.stringify(sample), 409, 'sequence_conflict');
  }
  return { accepted: true, duplicate: !write.modified, sequence: sample.sequence };
}

export async function readMetrics({ store, jobId, now = () => new Date() }) {
  const missing = reason => ({ available: false, stale: true, scope: 'whole_device', source: 'authenticated_nvidia_smi_sample', reason });
  if (!store || !validJob(jobId)) return missing('not_available');
  try {
    const { blobs } = await store.list({ prefix: prefix(jobId) });
    need(blobs.length <= 10000);
    const keys = blobs.map(b => b.key).filter(k => k.startsWith(prefix(jobId)) && /^\d{5}$/.test(k.slice(prefix(jobId).length))).sort();
    if (!keys.length) return missing('no_samples');
    const saved = await store.get(keys.at(-1), { type: 'json', consistency: 'strong' });
    const sample = validateMetrics(saved?.sample, jobId);
    need(key(jobId, sample.sequence) === keys.at(-1) && typeof saved.receivedAt === 'string' && Number.isFinite(Date.parse(saved.receivedAt)));
    const stale = now().getTime() - Date.parse(sample.updatedAt) > 45000;
    return { ...sample, available: true, stale, receivedAt: saved.receivedAt, scope: 'whole_device', source: 'authenticated_nvidia_smi_sample', reason: stale ? 'sample_stale' : null };
  } catch { return missing('unavailable'); }
}

export async function handleMetrics(request, { context, token, jobId, getStore, now } = {}) {
  try {
    if (request.method !== 'POST') return json({ error: 'method_not_allowed' }, 405);
    need(context?.deploy?.context === 'production', 403, 'production_only');
    authorize(request.headers.get('authorization'), token);
    need(!request.headers.has('origin'), 403, 'worker_only');
    const { input } = await boundedBody(request, 4096);
    return json(await appendMetrics({ store: getStore(), input, jobId, now }));
  } catch (error) { return error instanceof TelemetryError ? json({ error: error.code }, error.status) : json({ error: 'unavailable' }, 503); }
}
