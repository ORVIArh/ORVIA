// Public verified evidence snapshot. No private signing journal or credentials.
export default {
  "chainId": 4663,
  "coordinator": "0x3B188B4c5B76b009d80455D3bbB7597983E390f0",
  "owner": "0x2541a9e93B5C853E9208b0C5C7386dD458424c77",
  "operator": "0x2541a9e93B5C853E9208b0C5C7386dD458424c77",
  "contracts": [
    {
      "index": 0,
      "role": "coordinator",
      "lane": null,
      "address": "0x3B188B4c5B76b009d80455D3bbB7597983E390f0",
      "runtimeHash": "0xc1960bf3a1a049e6e55afc850e1d99e698e4857f89e29673a25aad62f41aa24d",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 1,
      "role": "report_shard",
      "lane": 0,
      "address": "0x79Fd3a2B487E166E7E9D72c9B2CE67867681444C",
      "runtimeHash": "0xf6aa5928aeb0a047e4faf233edb63836411016b9c3c1116fa2c640f579f40396",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 2,
      "role": "report_shard",
      "lane": 1,
      "address": "0xeeB4C5cB4148D27065a0645BFE5f94f9f2911207",
      "runtimeHash": "0xd52ae42169f1e181ef405070a34b5cab78dc261b53efe737431263e92593a11e",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 3,
      "role": "report_shard",
      "lane": 2,
      "address": "0xE01F5EFED3924Ab457232F052811BFDe40821eBE",
      "runtimeHash": "0xd45b6737c234bbce56da835216a8156a794f936d3a078f833d6f9cfe016416ed",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 4,
      "role": "report_shard",
      "lane": 3,
      "address": "0x119Dd78Fb1CC3673654Db20714D8701342a36698",
      "runtimeHash": "0xe826d76a9ff61388e03b833a5b9edf6867c79f05b2c7e371fb7f7892db2a74c8",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 5,
      "role": "report_shard",
      "lane": 4,
      "address": "0x83cEfC79084905668452412977AA9Dd01Cc9f808",
      "runtimeHash": "0xaed57d67ec55b29317fe4898936d96d1eea3cb2560c9e742f08d607065170f46",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 6,
      "role": "report_shard",
      "lane": 5,
      "address": "0xCdD4a640Bf7E7423B54b5Fb4bf8a702a1Db2dAc4",
      "runtimeHash": "0x6911b5860f6b023979da8cd6c0a48f73a38f43867ea91440f3e6e51b4542bfd4",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 7,
      "role": "report_shard",
      "lane": 6,
      "address": "0x0852dDf148755394E7F09100c7A2084cd645D766",
      "runtimeHash": "0x69c20e4b5b55684a2b5c67eb80498b68a5ac683c292c05bd6fa1425409e39e70",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 8,
      "role": "report_shard",
      "lane": 7,
      "address": "0xb14E26D6391675199F40eBE1d6698022c1A9E2D2",
      "runtimeHash": "0x1981c22cccf9d32525b74439f25fdb790966f84d263c7eec6fb5eb95bc1323e2",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 9,
      "role": "report_shard",
      "lane": 8,
      "address": "0x096052c7b8B7Bb6DC0526D8186F2eE279c34bfeA",
      "runtimeHash": "0x647c8322be19c5a4eb6b492a6c916d308a7076fcaf3958559df89f24fedec0c7",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 10,
      "role": "report_shard",
      "lane": 9,
      "address": "0xc7424d374C2a8A107eC0DdEc8c99c33e5E04DA60",
      "runtimeHash": "0xe8e6b790326652e1549686945010a8cb19e526fd2344e3c6003c4a83040a6f29",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 11,
      "role": "report_shard",
      "lane": 10,
      "address": "0xAa8b3dbB08e033AF51B1E7003Ae6FE65a5951723",
      "runtimeHash": "0x1e203be29e5dff9679e1c5419b6327f3b793b168c6630a6b7be9387d21704142",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 12,
      "role": "report_shard",
      "lane": 11,
      "address": "0xfB4a708f2f2d97A284618b02B8978e6513a49C25",
      "runtimeHash": "0xe0925bdb68a9b5aed28865295b4fe73660e695a6e5929126b411d9524380a75a",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 13,
      "role": "report_shard",
      "lane": 12,
      "address": "0x9f164414591c17E1BC0443A8286173a0183BF6b2",
      "runtimeHash": "0xbb8012d0917c865a984f17dd45f1fca2484edb68c8e7e7ece0247275ae7aa1d2",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 14,
      "role": "report_shard",
      "lane": 13,
      "address": "0xB4a87065348bA7471202C0001305bb7D3cC7774D",
      "runtimeHash": "0x0a1685eff7e35c22e4f3d6bdfcc061443c929756323c323d1bb8a94e0bf6ba36",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 15,
      "role": "report_shard",
      "lane": 14,
      "address": "0x9dEEc1cCEfDfE86eC67898433b5D2d62F02550E3",
      "runtimeHash": "0xb9feb72f1accadc0deb728228620dffffaf0dfd67c52d8dbca46d3d502619dfc",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 16,
      "role": "report_shard",
      "lane": 15,
      "address": "0x0924349B8423aaFAf3756c1305edd596b11EB5F9",
      "runtimeHash": "0xf06fa1fc09fa290067ba76c3c0788ebd0198677336c590d960c8a18bb13b3bd4",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 17,
      "role": "report_shard",
      "lane": 16,
      "address": "0x2A552fF1E1529015cf7744651C07A21CbBfBcDEc",
      "runtimeHash": "0xb1e5c9fa6dad1f5518b67ce1322b257514d658c043577252547abb7f580e9015",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 18,
      "role": "report_shard",
      "lane": 17,
      "address": "0x52cd22535262A30E2BF3c699B970AF320ff8db16",
      "runtimeHash": "0x06333b76bf581c8f066f03af19e5c1ad6b3fe9b9e46283747bdec1501671f9b9",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 19,
      "role": "report_shard",
      "lane": 18,
      "address": "0x558648B6A17819dDBBF5a72050ca31F421db59Df",
      "runtimeHash": "0x1674ab690128abf50c7b9ea0eb404630bfcc7db1672973c02ed64a337ea3f73b",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 20,
      "role": "report_shard",
      "lane": 19,
      "address": "0x7A63c1BcD00b764A4277E51d59964366f142286E",
      "runtimeHash": "0x2bedd58faeffe7ca98d73c2838674b1202b2ede30033bd5d1138980fd9345d7c",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 21,
      "role": "report_shard",
      "lane": 20,
      "address": "0xAbAbCcD7352970b1df5644B6DF9B0702a24F23Af",
      "runtimeHash": "0x3b198677addaa70adc1cac945723df706187927deba26560d4417a13d70b41f1",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 22,
      "role": "report_shard",
      "lane": 21,
      "address": "0x7F53092e54Bf8867C50256aD7C80599d8cCd57C6",
      "runtimeHash": "0x3058d233327204239860bd7b9877616cac78c6e760174a4d8edc47ddf0defa63",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 23,
      "role": "report_shard",
      "lane": 22,
      "address": "0x2128ed75Dcbf2E058976896b094a19d98DD276e7",
      "runtimeHash": "0xf8d6dfae0dd409bc3aa2129a23e7b0e03450e40f70cbf80a7d1044bc98c8c5c3",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 24,
      "role": "report_shard",
      "lane": 23,
      "address": "0xA34EDc2cA8298e4dd24489401090f7c6c5C2e152",
      "runtimeHash": "0x415adadd29ae4966d10740e0fda7a750d243a7c30458731939482578edfd2a44",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 25,
      "role": "report_shard",
      "lane": 24,
      "address": "0xF3fB8Af1A35A66905c177EBA28396B26f6959f8f",
      "runtimeHash": "0xe276dad998d9175bd11465aab242aea1f74e2d4d59bba9d088de583dc3e7f6e7",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 26,
      "role": "report_shard",
      "lane": 25,
      "address": "0x9E7fB3DE41a79613CAf25A2FD30cd10213a8C668",
      "runtimeHash": "0x61c837f681ec803001ef4f780e86c8fd91eb3c7a720dc5612ce54dd65c3ed731",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 27,
      "role": "report_shard",
      "lane": 26,
      "address": "0x9385aDd7f0fa036F507e16B04D13778B817D35b3",
      "runtimeHash": "0xd561241f05e9f24a0fe88f75feee982afc8e198e2523a20a4020d56bda4958c9",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 28,
      "role": "report_shard",
      "lane": 27,
      "address": "0x228aDE8fD45e4aDa7aa334d7fA135E22261957E1",
      "runtimeHash": "0x6dd3294afdaa27894aecf918c410a25ed5340f42ba5ddb7ec4c6bec97ebdf9ad",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 29,
      "role": "report_shard",
      "lane": 28,
      "address": "0x2B5AeA492fA0Fe81a4Ca42f546611AC4c031760b",
      "runtimeHash": "0x2bacd034fd9ad641e4cca2a1836895160cc3120630e83822acce7166de24f62f",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 30,
      "role": "report_shard",
      "lane": 29,
      "address": "0x1FC8B05C7B6A7f72654712513BA2bf66bF0372aF",
      "runtimeHash": "0xf0c7292f71ba549ddf5ffa324b65c7a06ebfea8a48e887e89163351f4ee90ace",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 31,
      "role": "report_shard",
      "lane": 30,
      "address": "0x673D369E1acC782d35aE9e2bd61EEaa5366f7790",
      "runtimeHash": "0x9f356b9b1497fc56ceddc6c34dc41aab8eb511eff97bd70ca647778061b66a7b",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 32,
      "role": "report_shard",
      "lane": 31,
      "address": "0x4546926E0Be56B33e9744f4EcDaCdF4cf4Dbbc36",
      "runtimeHash": "0x5d5c0875343c8af1981ef3c176e5e521515d3d0f5688a05a01c1d204ff41359d",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 33,
      "role": "report_shard",
      "lane": 32,
      "address": "0x9a37824e2900832419bb3802908F26f262Ef5a7c",
      "runtimeHash": "0xc78c27b52678b0e5bf1365586292a2bba1973d1330b981b5c1e04e749971fb56",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 34,
      "role": "report_shard",
      "lane": 33,
      "address": "0x5B9C23B6b066fBb3f6bD4B8128FCA1EADEd52444",
      "runtimeHash": "0x8f20654a0e5743b09ce0acd2fb6376f57fa7a656b134973ee06f541c85178b19",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 35,
      "role": "report_shard",
      "lane": 34,
      "address": "0x167F5b4b19A524B5B002E78a913A03666686609B",
      "runtimeHash": "0x17fd00b327c5d1ea368af716c10935f03822c88a86f1fb989bae6d079ffde99c",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 36,
      "role": "report_shard",
      "lane": 35,
      "address": "0x275CbfeB5c34aEb77c234879a866642df972A65c",
      "runtimeHash": "0x15ca7f7c5bdd53583fcf463ccdf607d47547634d12992761af5b2070a36d6f3b",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 37,
      "role": "report_shard",
      "lane": 36,
      "address": "0x091f5200f49c1fAC4B49b18d67391695CBC4F0AE",
      "runtimeHash": "0x91f17441902393767937f8338b28eabbdbe102f97e4c200852f7e180889ceac9",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 38,
      "role": "report_shard",
      "lane": 37,
      "address": "0x51CA464387074ba140Fa06065574D115a972bc5f",
      "runtimeHash": "0x72bc16e8177f86a504c8a7bc14ba81e714525ef7c3ad3fb62567016a7b9d2681",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 39,
      "role": "report_shard",
      "lane": 38,
      "address": "0x5038FD8Be3775d46F7A95B304d431D21a7d5f90a",
      "runtimeHash": "0x87537bf17e0d1379d4d345bda096f168711e9f7dc98a4db06a11ab02c06045cd",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 40,
      "role": "report_shard",
      "lane": 39,
      "address": "0xFd49D487Ee1F252187100849ffb89069192E335E",
      "runtimeHash": "0x78798475817948142393664dd46389ea696b218ea85f9e51ce5f1699a0df6961",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 41,
      "role": "report_shard",
      "lane": 40,
      "address": "0xbdE2143CA88D6A974ec6F58CAFfB0247D172f743",
      "runtimeHash": "0x09e1dcbccef3d135a2c4723eeb9b4c756b93b82306cf7a2adf7a5eaefaaa8244",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 42,
      "role": "report_shard",
      "lane": 41,
      "address": "0x664025DAce5Eb04C174f4fAbb6B84577FdBF978B",
      "runtimeHash": "0x388a51716f11bfad63897842666aac8eaa90754e9df81c420da8336b136a1c78",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 43,
      "role": "report_shard",
      "lane": 42,
      "address": "0x06DB0CC1138313fF5A96DCe79983e0d7Be2E466A",
      "runtimeHash": "0xfd5ec37524cf4f520b0015af191431b0cd86b3b728b6a28b5a15e1ba4a5f9aab",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 44,
      "role": "report_shard",
      "lane": 43,
      "address": "0x862DCEf4514299D0bef0F78BE0563aA0307AB8Fa",
      "runtimeHash": "0x08c347ee935c9e597c1736a9ccba5ec5b26abaee581772539c94cc64b1e18c9f",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 45,
      "role": "report_shard",
      "lane": 44,
      "address": "0x912530F61E56Ff658998b31DF5B69dE70BadF275",
      "runtimeHash": "0x993b8896faf1a90ed1cc2641e1cf90c63d7e6aa8ed90865ccc3f4f15cfcfb9be",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 46,
      "role": "report_shard",
      "lane": 45,
      "address": "0x4065198132119a44d4daf4A52E895F02A2cA57B2",
      "runtimeHash": "0x273fbf8e8310969aeb3f8485968025be8cce8c233f6bee6d261343426f966953",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 47,
      "role": "report_shard",
      "lane": 46,
      "address": "0xF3F55017b5Ccecb716358186CB3322A00eB27d1C",
      "runtimeHash": "0x6197e08a1c6dcffb620fd5bed45806cbc69bd2019925fb33966887c86c3b672a",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 48,
      "role": "report_shard",
      "lane": 47,
      "address": "0x2ea51D5CbA1FDEd31Ead316d2D53087f3853C880",
      "runtimeHash": "0x80520b87ca4aeb74bcdffcb48fda4d1afba5601f6e4bbf72e05e5e0e5b1abb21",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 49,
      "role": "report_shard",
      "lane": 48,
      "address": "0x6E18b70DDc32a5797aa36e6fF05d22252F13d45C",
      "runtimeHash": "0x7c6809b0a121c78413875a8d3b0ad9a118d7b141b5600a8b103174e03d68694a",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 50,
      "role": "report_shard",
      "lane": 49,
      "address": "0x9D24147b2e49DFb2Ea5a111ecd74Cf9c6f99F32A",
      "runtimeHash": "0xe61aebfd61a276d09ae12c8e3a4084862b40b22a4881fd17c6e0c77aa1efbb64",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 51,
      "role": "report_shard",
      "lane": 50,
      "address": "0x5aD0B66073b1b69CAff53f7B114bE477231BeD86",
      "runtimeHash": "0x4177ab72959295ae6cf563d8b71637112e0f30185d865501cc1c5f35677590d9",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 52,
      "role": "report_shard",
      "lane": 51,
      "address": "0x3A505E26e83494F5f3A33C8599d5A49c3C3A3411",
      "runtimeHash": "0x4bceb19598ecb6ea9989da60b3ec9f1246d97cabf68ff7f89fb215846b4b8fff",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 53,
      "role": "report_shard",
      "lane": 52,
      "address": "0x37368bd1f12848868333a09C47dB90184F4113b2",
      "runtimeHash": "0xbec6576083771f8f5b4cefce90cd61874ce76145b359ef0e9eff155e83caab2f",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 54,
      "role": "report_shard",
      "lane": 53,
      "address": "0xA178BA089BA3079A16A5885c67535aab19FcDc15",
      "runtimeHash": "0xb23b781e4fbb84af7bf39c589acc9bc56fde897f333900f7d9e144b8a2b89fe6",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 55,
      "role": "report_shard",
      "lane": 54,
      "address": "0x9A185c2c8B49D455aE1a3e7703CE3405E0034261",
      "runtimeHash": "0xa9ce458b3dd0a3e65bc5102561b24ca82d0ae85716668dda474ba2be78ca388a",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 56,
      "role": "report_shard",
      "lane": 55,
      "address": "0x26D5a7B5468289B7EBfC448E2F347F6c32ee9FF4",
      "runtimeHash": "0xd066858959e17dee5d4548dc78e4c295b08c8b3c2a34ee0ba31e4ff3c73c66f5",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 57,
      "role": "report_shard",
      "lane": 56,
      "address": "0x2dc322096fF3259Ec7CC8c4C6c96e968C62D667e",
      "runtimeHash": "0x7d2f96a12717e9b630d1db475298929696dc76c8cf51fe3ff410a1c475b000e6",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 58,
      "role": "report_shard",
      "lane": 57,
      "address": "0x114095b3143b1b11c55919c7a6DdF953217Ec39c",
      "runtimeHash": "0xd9b253f9a2a676381da8b170fea2ea9560b905b2d0e3f164f49ad4760d860602",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 59,
      "role": "report_shard",
      "lane": 58,
      "address": "0x8618C1204FbE037Cac5B9CcbE28828d387eb3C3b",
      "runtimeHash": "0xd14de94596193c6ead7aa4b86fccee501fec07f546f1c2a0a5b0cef03ce9be11",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 60,
      "role": "report_shard",
      "lane": 59,
      "address": "0x15e7f634DA2ae807EE77DC31C451884219006bEB",
      "runtimeHash": "0xda318a6c722dc82a3664d3591249f334e18eac2eb0f79de7c45cb5c7a92f78b8",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 61,
      "role": "report_shard",
      "lane": 60,
      "address": "0x88dD3e42cdA3Caaa29F6b350DdCC9d2E6AFf8981",
      "runtimeHash": "0x2c020cf5980a65958b2e2348b4eac2d85bd4acf725bf06b48b44335e98211423",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 62,
      "role": "report_shard",
      "lane": 61,
      "address": "0xb3cf8d7d22db3C68dB32f0933150e7f509591828",
      "runtimeHash": "0x04b9adcdd09a83ea40b06232e8110ea64191c904a8dbb072a7ae5de534f1878f",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 63,
      "role": "report_shard",
      "lane": 62,
      "address": "0x7D77D625FF867dDB803a765C57894d26e1983454",
      "runtimeHash": "0xa6473b5cdee6797ce0d0fe973dd755a98fed5fff8ce6631d0672509789434992",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 64,
      "role": "report_shard",
      "lane": 63,
      "address": "0x280d0Fb51189241e50586869B11cfd0e9e3B7ECc",
      "runtimeHash": "0x571804812b14e4719653786249821def975058f88c55ff518249edb0f48477fd",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 65,
      "role": "report_shard",
      "lane": 64,
      "address": "0x2e3aAe7315c2491bC8f0eDE5f6daFEd9cfdF3F6E",
      "runtimeHash": "0x6babe323a2e35fcb5055de89f0912d3bd09c0800a5f88f412ea2a3f51fd56628",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 66,
      "role": "report_shard",
      "lane": 65,
      "address": "0x05441B7116931a3347e0C36f4ad80795DE05D537",
      "runtimeHash": "0x6a3c096e84e4a8dee73c53c467bda79536e29d3bd85f93c320d517a736d4d55e",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 67,
      "role": "report_shard",
      "lane": 66,
      "address": "0x4FDDE1dB671C351648B804DFd3384Cb82FA1F0Ce",
      "runtimeHash": "0xc978bc7aef1674ca863aefabd9bcc8353dea6b52fc556743b8e9f240b9f8dddf",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 68,
      "role": "report_shard",
      "lane": 67,
      "address": "0x34808E13F7b37b7aD21FA7A2b50Ee68956Ec7E5F",
      "runtimeHash": "0xf14cfec61689b28bec8e98dcf75deb8428620bce6f249908c7349e756b95d482",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 69,
      "role": "report_shard",
      "lane": 68,
      "address": "0x145b660824A867b82824073469c9AAaAb2B09656",
      "runtimeHash": "0x02aba2056d3aeaecdff40a307e6ce6891775969bdeed03bf541d0ef51efceea4",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 70,
      "role": "report_shard",
      "lane": 69,
      "address": "0xB91B61d7139be9f05be42BC957B9D159cF0D3423",
      "runtimeHash": "0xc6136b591ab6bb8079a7d7cf08375dbf167514d5c32ba30f20aff1c4765f4daf",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 71,
      "role": "report_shard",
      "lane": 70,
      "address": "0xC13D0712927cBaB1B5dc6877fCc644F283a4c854",
      "runtimeHash": "0x654ef7acee67fd6c6f454ab8420cb0c4cdea3a59a20ad54a3e425ef9659682c0",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 72,
      "role": "report_shard",
      "lane": 71,
      "address": "0x44A72F82138c027aBDbb8B2b7b4fD898D455D1e5",
      "runtimeHash": "0xa7542eeb03ff27c481a732819094ef6a4e4abb5e7aaa4ec1fcfa4aa823115047",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 73,
      "role": "report_shard",
      "lane": 72,
      "address": "0x5d8C73Ff7773f105ddADA029234750C2739324A0",
      "runtimeHash": "0x3b61c1ae188a1a52b9f964a99b7132c6b97d8d656bbfa8dab33cda2316dc00ee",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 74,
      "role": "report_shard",
      "lane": 73,
      "address": "0x78d6995B456B9FC663a24Cb9262A7172CA2dc248",
      "runtimeHash": "0x0a24138bdaf9b6634e0f2dc926f13e51c23f906c353a8329f7382475bb4f821e",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 75,
      "role": "report_shard",
      "lane": 74,
      "address": "0xa3A3A9a70C61902A24aA2172738bAa1e0e823f42",
      "runtimeHash": "0x8ad2465bbac21ab3b3f76666e1f7e340255e197951bfea897895bc32b1808195",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 76,
      "role": "report_shard",
      "lane": 75,
      "address": "0xfe9405f1345de7A7cbBCA2F555b5AcC41872f7E2",
      "runtimeHash": "0xd3ca54f6fd9066f15fa43aaa20d915332ba3fb67c37bfcd602446fc9efd43989",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 77,
      "role": "report_shard",
      "lane": 76,
      "address": "0xD53b060020a24278267DC4d94c84c8523f3a6546",
      "runtimeHash": "0x45e7875b6d00f08cde5a3b181a3894f15e1d4f24504ad06c57283c9021a4d62d",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 78,
      "role": "report_shard",
      "lane": 77,
      "address": "0xeAaB070B7d732F1613c6B6E61Ad956f4cdFd0157",
      "runtimeHash": "0xa07f1408e4ca6e300d7dacb1fe9f234df6e82daeec43097ba445e5f7076e635b",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 79,
      "role": "report_shard",
      "lane": 78,
      "address": "0x7fEE33e2877e5a037289fE7b8fE45ddc7d01EcbE",
      "runtimeHash": "0xaba4ac3b6de37cdadda3fe2882a9e1a87e617cc654e6673bcba7c11fd5a2a7e0",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 80,
      "role": "report_shard",
      "lane": 79,
      "address": "0xBc93beD0706A50628950Ca402f95Da2696A3345b",
      "runtimeHash": "0xe5ba93ccd8f4e035feb81e09312ba9ae11dbe766d7e5012e2c7fcaef495e5f08",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 81,
      "role": "report_shard",
      "lane": 80,
      "address": "0x6f49d4670A596EC905f26b104adC0Cf23A7e787c",
      "runtimeHash": "0x8ca96949133220e1059ffcabc4d6c8b84166fbf42d5d44e21ee150a2be63bc7c",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 82,
      "role": "report_shard",
      "lane": 81,
      "address": "0xe9A912283C73eB4C599219b3f53ED7C4bb4Fb5ba",
      "runtimeHash": "0x38c8ed7f0082c5bf1b8ae9fb8ddee1b6674e9eabd89bb988f53ae18298ffc794",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 83,
      "role": "report_shard",
      "lane": 82,
      "address": "0xA77d27b4a6898e75d1D8ad0031aF192AF65D1544",
      "runtimeHash": "0x45f1a930edc30446b7e0db95ddf6386d3d946aa0d4b091d570ef870a84f1c097",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 84,
      "role": "report_shard",
      "lane": 83,
      "address": "0xd0c617D5248201e29E1e65c826d4Ad67A57d9Fe1",
      "runtimeHash": "0xe3375747b8509ad4e559bb5d0299cd79d1deb6d967553c165c0aece7eb63e60f",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 85,
      "role": "report_shard",
      "lane": 84,
      "address": "0x8B58D4f1e7e16cd8EF70ffaD54e791F81fF41030",
      "runtimeHash": "0x8920d247c1721b2755f1be0e1b01e95b230524d8418a773ad0bb2d5644c44070",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 86,
      "role": "report_shard",
      "lane": 85,
      "address": "0xfA8ae4494823407Dfc23d083a3d0D7000e0AAd60",
      "runtimeHash": "0xd58cb624bfab68844880dcf58b5b56277a54790bf4ca37304d4bc44953cde367",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 87,
      "role": "report_shard",
      "lane": 86,
      "address": "0x5f35dAd704ED7a73416C824B726D2FabEE5BD1e6",
      "runtimeHash": "0x9e7ff51cc3ed3d6bcffc89ef5298520aa2cd73ae0d16f767aae56e8f351b15ed",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 88,
      "role": "report_shard",
      "lane": 87,
      "address": "0x1C8a50C63A9dFFa299a49aA0E683211Ed8B663B9",
      "runtimeHash": "0x07b57299861fcceece759287290457656e93202d9a4193588bcf0a40109e0d19",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 89,
      "role": "report_shard",
      "lane": 88,
      "address": "0xeA7dD612f55B3d3D29B508A2DFAc7f5dBE425c8b",
      "runtimeHash": "0xe1a94a7e34365c43173f0f28c3acdea34e5649b69295587e9da8323c8529000f",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 90,
      "role": "report_shard",
      "lane": 89,
      "address": "0x72aD41D31baaD163D31bD0b6C97209f380eC4914",
      "runtimeHash": "0x94955b05f62f5963988c720f1cfe9ca041f5c5ac81feff72d1e3f90f700bd812",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 91,
      "role": "report_shard",
      "lane": 90,
      "address": "0x35AbBa1cb3dd88b13D41EC23C62016778363ef42",
      "runtimeHash": "0x5436fdc5794d45769f8c27609ecfe970e783973a2857b2d0920815475a10ff06",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 92,
      "role": "report_shard",
      "lane": 91,
      "address": "0xDb1092b46c479B696B7C9105b4211D723A595884",
      "runtimeHash": "0x936d36e770d8dca8f7f2683df5f259ab4128334766967a22e75a8fd904dfdb9d",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 93,
      "role": "report_shard",
      "lane": 92,
      "address": "0x73fd1C90DcA1a53fd9fA42d2f0282fDB0BEcE4ea",
      "runtimeHash": "0x3e9b66bac13be37f276e6c2fef9cc948cae82ac08877abce9ec9c6db48b113d9",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 94,
      "role": "report_shard",
      "lane": 93,
      "address": "0x31068Da9Af094c4FC5ED99E73FFc2cb6FB8479fd",
      "runtimeHash": "0x361b97062e090bcfa6461438674cb49d651434bc0581990a74fb71ae6e85283c",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 95,
      "role": "report_shard",
      "lane": 94,
      "address": "0x44Edea663cd5395e8Ed59A3617C42b7ba4770eba",
      "runtimeHash": "0x0d2933d429e51e1b565661c166ab8fde3140289d29a735512d3b8d9c0c741604",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 96,
      "role": "report_shard",
      "lane": 95,
      "address": "0xD8b0e6A94c44A0572B959fC870d7454e02e2F5dc",
      "runtimeHash": "0x60bf9fa860df371cc48ac370c6337bab4ba1422def358f56e9c4976f79f0d56d",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 97,
      "role": "report_shard",
      "lane": 96,
      "address": "0xa44F1A03B2a7F3665177133E6aE1DEDb8b334530",
      "runtimeHash": "0x4beb8b84fe1e3bd2c932255b89247d3bd5b5ad286c72d542858f93e4f3935dc8",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 98,
      "role": "report_shard",
      "lane": 97,
      "address": "0x2e032AeDED0f2729966F8DaF359c38D0582b94C6",
      "runtimeHash": "0x8239edea93a5dc0be14e60d81277e484b2919d60d1a68ed452e1ddbb71875407",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 99,
      "role": "report_shard",
      "lane": 98,
      "address": "0x2b2C0a455e07B5766396d3c7edbE6047812F6adA",
      "runtimeHash": "0x4854287d1f48cdb0272bb72894cec8b0397a9b4600f52e4955b20a44b9a363b6",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 100,
      "role": "report_shard",
      "lane": 99,
      "address": "0x4AF01B4D0f6508DEdF58B36FF0B975e37CaC2AF7",
      "runtimeHash": "0xeebe3abd3b6d5b78c819d8537f7a35a41fa0c601764cdf5cfbc5862c40d08637",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 101,
      "role": "report_shard",
      "lane": 100,
      "address": "0x1313FA428b249A6a96941A205af0Cf307f5eFb79",
      "runtimeHash": "0xc5a87198e89bb40190d2f6e42777348a5b6521b11cb5b433241e1b01c76c7ef4",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 102,
      "role": "report_shard",
      "lane": 101,
      "address": "0x7590183B792E1a8a0D843aB684751fd204622f13",
      "runtimeHash": "0x35246dc4aaff854538f4ae53e7320790064d4b76b617fa889c523f5df71a9d45",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 103,
      "role": "report_shard",
      "lane": 102,
      "address": "0x2D61929E1a169c12abb8Cc239a276CE367c560E4",
      "runtimeHash": "0x57ba98fa66a4ba388d07030eb41ecdd2331f3465b610a6dc6ebce31f1ec7b4de",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 104,
      "role": "report_shard",
      "lane": 103,
      "address": "0x398fcF33A65a4f589D779636BB1b2d487E2cCABf",
      "runtimeHash": "0x1ef5f7724cd858bad11eabedae5019106b1022d46618e74689f142c00af7353c",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 105,
      "role": "report_shard",
      "lane": 104,
      "address": "0x2d68D757dF439c8E1d6269bA4c19b5A980f359ac",
      "runtimeHash": "0xd361de16509617bb9c6b39b5e2b612fe1236d2267e44101aa633ceb5464dba8f",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 106,
      "role": "report_shard",
      "lane": 105,
      "address": "0xe5b91C94a8F8A5FC770641FDEA4Ca9877c0895c0",
      "runtimeHash": "0x89bb87c6726e4bb7f53f525ac0447b714a29d21b00e87a1d233e5f93f5d1df14",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 107,
      "role": "report_shard",
      "lane": 106,
      "address": "0xC94916c1Da27B5878d006D60188817568C1271a4",
      "runtimeHash": "0x4cb286ae9c938bda045fb913dbfe1fd1edf2c90dff07a240e6344a2ab208c6f8",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 108,
      "role": "report_shard",
      "lane": 107,
      "address": "0x199A83c5980b4A3776266409D4B9Af99456B3108",
      "runtimeHash": "0x4c9fe432e4588efdf7e96e03ff29bb7810154ce4d851273b7a47813753d07b05",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 109,
      "role": "report_shard",
      "lane": 108,
      "address": "0x912e6f88Dd48a48C0E572DD5071aF60889aA62AF",
      "runtimeHash": "0x3a0285455c1e4beda9e8296f87d5ed330da98518abc28908001c948350d0ae39",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 110,
      "role": "report_shard",
      "lane": 109,
      "address": "0xF43fc68AB4E2aeF19C81b0D37a1d553E59c535f1",
      "runtimeHash": "0x83de3dfff9aee976e719da61dbe9a7d1e4f4e9a8deff00db74bb3d061fda5e1c",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 111,
      "role": "report_shard",
      "lane": 110,
      "address": "0x1526EC5b057245C93869ea9b21bD5d1473B9a6d9",
      "runtimeHash": "0x8c74e09d19c002c5f32ba5c2b02deb94e71a46d332d5bc9c18dbc774e0bc92e1",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 112,
      "role": "report_shard",
      "lane": 111,
      "address": "0xFA892BFbab9f48636cda38c20f4CF60F0D43FbFd",
      "runtimeHash": "0xa0f2edd895ce02cad8a35b0048a5302cc59148b8cf44452e254bca2c4622f666",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 113,
      "role": "report_shard",
      "lane": 112,
      "address": "0xA93e531bcf6BDd7D898662E89f0234AD68A2DC7a",
      "runtimeHash": "0x4b3e8718a94ae718829344708021f0f45998c3a67181b62e2ed80746320be57a",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 114,
      "role": "report_shard",
      "lane": 113,
      "address": "0x7E0566831F89170E89766Df42d8EB308002baca7",
      "runtimeHash": "0x91606fbf687e733f232fcc1175df73ab7910686ebb81f51ef8b2d2c278a73156",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 115,
      "role": "report_shard",
      "lane": 114,
      "address": "0xb3c69f61186d3024B96dea70c54009263610D5ea",
      "runtimeHash": "0x1125a6b78f8d2ca580b32df742f020cc52a41f79fa297d3e556f36393d5e71b6",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 116,
      "role": "report_shard",
      "lane": 115,
      "address": "0x1440Fce3E02f7F282cfc5903ADb2312A78a3243F",
      "runtimeHash": "0xa8d73a99d0196c5b97d75e94fa1eff0c0098a40c4e6b4de7119ec890d5623bd3",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 117,
      "role": "report_shard",
      "lane": 116,
      "address": "0x8123b1E102E0AF736c2D50dED57BD4e32cb70119",
      "runtimeHash": "0xdf5cade6e12119dd3929cf63e60a53b0d0294716526b878d13da768273f99a0e",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 118,
      "role": "report_shard",
      "lane": 117,
      "address": "0x5AE3BE0B155A802Db32643d1203FAD64706Aa0Fa",
      "runtimeHash": "0x36a5242f8342f0b8ceae91a85d1ae4539e362fbd452d338cfb0e381399c92aab",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 119,
      "role": "report_shard",
      "lane": 118,
      "address": "0x548b6FBFF12d83D07cDFeaB048D5B039B515Be9F",
      "runtimeHash": "0x239e6b8232d539aa65ef9eac0e4562e922a23339e92499c19d902d3ec0ab74b6",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 120,
      "role": "report_shard",
      "lane": 119,
      "address": "0x49BA7724f4AD2d32E606010dAD283c88c2cF131d",
      "runtimeHash": "0x7320802a8da9d462c0e14ac181d257fb83b3a487a603b4502972faffe934ee91",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 121,
      "role": "report_shard",
      "lane": 120,
      "address": "0x41b10cf5295Afac5d97a81f4f4db43dd011019b0",
      "runtimeHash": "0x8a5973f9dd46bf9130c611b628dd979c91b06d5746e9c88f83506357c382084c",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 122,
      "role": "report_shard",
      "lane": 121,
      "address": "0xA9B987E796488487c9AC249d72708702888C49AC",
      "runtimeHash": "0x8201bd253bc061cb07c07b67b3c6389a361ef239ffddda397d0e32fffdb428c7",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 123,
      "role": "report_shard",
      "lane": 122,
      "address": "0xb5e181389ED07aFCc8793cFe28b4e0474eCb551A",
      "runtimeHash": "0x43d60f191d839d16e399bcd75133e72f7ce359b14858eae55225000aa94389f5",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 124,
      "role": "report_shard",
      "lane": 123,
      "address": "0xc459b78736F58dFC911bdAff503028396E01FEe9",
      "runtimeHash": "0x064ee4cd9d8ec390c1af3043b880088aed757152e83132938da45f4de67bf546",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 125,
      "role": "report_shard",
      "lane": 124,
      "address": "0x2d98693b2Afd924bBd0E7c700d8C81628259329a",
      "runtimeHash": "0xb1e43b034ae75d9d315f1b3fddfacf3dee1fbce5c11048100f66ea3380248163",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 126,
      "role": "report_shard",
      "lane": 125,
      "address": "0x04899e46E00975409B59C212880ba2Ad69490E07",
      "runtimeHash": "0xc7c8efffe06d5c51612c258f6d1b270a2b2749e30d6e43ed842b483c8bc9e70a",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 127,
      "role": "report_shard",
      "lane": 126,
      "address": "0xe16984d860AD60c7dC3DE2dB9bECCd398dCedCF1",
      "runtimeHash": "0xf7b30a4754f9bf964b4ad372e9e934ca5e8a4c6889b068a012474d87e7e0e52c",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 128,
      "role": "report_shard",
      "lane": 127,
      "address": "0x91Ed344aD688eF21Dd50Da55E9f237a5690a10C0",
      "runtimeHash": "0x7b81e6fcab9fc1067c33214b65c84b8d7aa89cd484c0156afeab4993d62cb692",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 129,
      "role": "report_shard",
      "lane": 128,
      "address": "0x6d4cA7ab975F1B9f7d578926b59C13A99Ab0CB8f",
      "runtimeHash": "0xf3fdac15aef7c825659044f2eb2f2b917041edb4d8f60bdd68db17b032128038",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 130,
      "role": "report_shard",
      "lane": 129,
      "address": "0xA2a024Fd434AC69c6081A101e309366028b56B09",
      "runtimeHash": "0x1f4464981516349ee02f4250710d8165f378493702ceb96290228668eb0e658b",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 131,
      "role": "report_shard",
      "lane": 130,
      "address": "0xc0ac991bD4bfCF3749Acc2e6A7931c6A52AE8bEe",
      "runtimeHash": "0x7689086d1077c4adb869d11f092d27c8503993742021da6970719ff25c189dfd",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 132,
      "role": "report_shard",
      "lane": 131,
      "address": "0x693E2EB495F78dDC3E36de7AC07b18bdE70c174d",
      "runtimeHash": "0xba3c9086c802e5c6f4821d9bdee06157fff8c13763958d030513f467a5ee6222",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 133,
      "role": "report_shard",
      "lane": 132,
      "address": "0x002E4c173822E692d870BC4C47dfb9807ff24fB1",
      "runtimeHash": "0x7b9c2a1e106024346e759b3bf5be6a4456d909a0818bd99ea1b58334a102eefd",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 134,
      "role": "report_shard",
      "lane": 133,
      "address": "0x5F5D066B16c0Ab0564315dB723B78ADde0AFBc30",
      "runtimeHash": "0x2b5810d9a0f3b9d417b0e9455ad79efcb4db19f6b37f87114e8296c2611baf02",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 135,
      "role": "report_shard",
      "lane": 134,
      "address": "0xd19855773e7ea3c3D5Ee9c6C50246a475AA45478",
      "runtimeHash": "0x546859a08baf0244c1ea48ec3f42967f416492b1c46d6df8f3a271e7b7a81c1d",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 136,
      "role": "report_shard",
      "lane": 135,
      "address": "0x64d2c5d0842aA255AB86BFe3753F1f3B3CAA727F",
      "runtimeHash": "0xa461288c4d8cd6f2edd6ec3a32b707bdf07ebab6d76da70509c3ab30476d1aba",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 137,
      "role": "report_shard",
      "lane": 136,
      "address": "0x02045A3AE19933e67Ae5BE24afe2df6a5726c3E2",
      "runtimeHash": "0x0886583fcbbd9d3917b3035c9246d07fbe31b8def7a3ab6a751b5378474c5718",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 138,
      "role": "report_shard",
      "lane": 137,
      "address": "0xac11978D79726b71F202d4a31C1E857A928e25F7",
      "runtimeHash": "0xe3dfec7feb4ba3004284d031896167254a77df355a495ac302a020bb5f8e4074",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 139,
      "role": "report_shard",
      "lane": 138,
      "address": "0xa7b9AC824B8e20Aa0a0993f3ACa117cb96C6E43c",
      "runtimeHash": "0xbcc753a749178bea8a1b8d9265ab06f0a27598ece0aead60e3b4d4666b707471",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 140,
      "role": "report_shard",
      "lane": 139,
      "address": "0xDD1a5e999B285D354f3ADb524AC7b82dBE9db7C1",
      "runtimeHash": "0x1c7a531e6df8cfefd33826f4e99a802bb39e0150aa5861f41a6685da67d84d60",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 141,
      "role": "report_shard",
      "lane": 140,
      "address": "0xC7a01C9f5E1B24B576492B7fFA9E8FAF0ce42351",
      "runtimeHash": "0x1a0e94e398532e953529a87c75751b1a0d67d5af86cfceaa232ecb3d856d78fc",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 142,
      "role": "report_shard",
      "lane": 141,
      "address": "0xE4270B1F3E6B3aA2826487BF7E3Ac5b1C0C311e0",
      "runtimeHash": "0x073f20cb7a9fb6a64d015b8ff0f1d8d910c5c8c4d416ac88cf1767c7683af328",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 143,
      "role": "report_shard",
      "lane": 142,
      "address": "0x2c3A4c11b5b416E3850dDB6e486757BAF93218b5",
      "runtimeHash": "0x93ad22e4fabfce27e089f58c39534d77376c57d4be64c64b65da3d857d009952",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 144,
      "role": "report_shard",
      "lane": 143,
      "address": "0xd9b9a9285d56d8f538b34BB7D232ed976356c76b",
      "runtimeHash": "0x7d5fe87423f75ff5a583cfaf90565e1c3dc69dfc1adb75adf3e2c96c19d636b5",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 145,
      "role": "report_shard",
      "lane": 144,
      "address": "0xd857069697e00747a95206BfC3458A4291EC71b7",
      "runtimeHash": "0xcce3dfa5d1176263eb3f1c71c3706dd6003e0ab798caaa684cbc1a711a946324",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 146,
      "role": "report_shard",
      "lane": 145,
      "address": "0x701BCd4CBB6cf4a5Cd8ccdF14E90a475cf5A057E",
      "runtimeHash": "0xa7a6cb943c8e1fdf6f6bde6731035ba1f4d1d6cc1f9cc50b2d44bb5e1195ea23",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 147,
      "role": "report_shard",
      "lane": 146,
      "address": "0xA37e115404Ad66E1E835c244dD20E17354c34DE0",
      "runtimeHash": "0xeb3540c2c0c37e5b7c212438012dd27ac5ae385283884ca9067a21391bbebf64",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 148,
      "role": "report_shard",
      "lane": 147,
      "address": "0xb3c609e94d3cE00ec66FC58528bD8FdfFC2AD744",
      "runtimeHash": "0xc6da53133352f16c8e64c093874e5e57a27dc7305585771f5768fd85f2036e62",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 149,
      "role": "report_shard",
      "lane": 148,
      "address": "0x4929A7a13e5916864315242BB21798c0c5dCf71F",
      "runtimeHash": "0x416016e80c5571698a27efd514216a736a7010918e918c04c13ce04b1846b5ea",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 150,
      "role": "report_shard",
      "lane": 149,
      "address": "0x2562AB4aB448ce7eCe052F7aeFD27d5F10001aC7",
      "runtimeHash": "0xed1b351f1adade77d0fd74294b9dc22f143e730e81b7db8c4359f287d7a778d1",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 151,
      "role": "report_shard",
      "lane": 150,
      "address": "0x6F8c1f0484d55101F32C44dEDf95BAC4c7b17e41",
      "runtimeHash": "0x63ac95336eaa5823ac509667c3a3f81eed42e8755c1b9f6d7e4fd7d122bb9dcc",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 152,
      "role": "report_shard",
      "lane": 151,
      "address": "0xAd4E2A24A9a668DCC74AE1136B4420DE8EA9809D",
      "runtimeHash": "0x2ece1246b0ef58a7f44be6e6172fa58f4392eecd72cdd35ccccb60c6890a849f",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 153,
      "role": "report_shard",
      "lane": 152,
      "address": "0x494BdaaD17c183FA7527A20a57526B3fA2F63fdB",
      "runtimeHash": "0x84c637d11b1136163ce4c3e280ddbfda2fb32eeb3c18da083fb90c87b0f86504",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 154,
      "role": "report_shard",
      "lane": 153,
      "address": "0x30bD0b8F616Eb3a9E230B4632D82599A8d164451",
      "runtimeHash": "0x93a6ddaea3ec1f5cd90e8be13c73ef59be9693683eed05cb7106b51ea490e519",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 155,
      "role": "report_shard",
      "lane": 154,
      "address": "0x77DD62A5338C2a663aaCB0FD6fB77b576e31C7df",
      "runtimeHash": "0xbca0325fbc8b2e6eafd7ae589cc7c2c1e865e60efeed84f26a13c9a1663d52c6",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 156,
      "role": "report_shard",
      "lane": 155,
      "address": "0x2e224E5fb3138cce77884B4C87933FE411F5E5F2",
      "runtimeHash": "0x7ff363c5476c0ffc7a011cb70048e9da3ea342d5caeb2dbdb5605615833b4523",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 157,
      "role": "report_shard",
      "lane": 156,
      "address": "0x422175e9a16CADA211020CB4D581218EdAF702F2",
      "runtimeHash": "0x9bafa06dab76930502ac1f704f1522099edcedaae1c6bdfe52f14420803d4a87",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 158,
      "role": "report_shard",
      "lane": 157,
      "address": "0x880BE12678EFc00499db4e7DcBba7E1f4e68BfA3",
      "runtimeHash": "0xa8ad0326b3f152b4109d1e67714aaf499327b4edd484ca0c13dff89a4e9297d3",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 159,
      "role": "report_shard",
      "lane": 158,
      "address": "0x00D98dFB0D6026C6ab1710ea9F5c9accc2D3ed8E",
      "runtimeHash": "0x7c9410e681b1620c324f16ae1407bdc8081342dbdfd5bfc98fb4c2c8803187a9",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 160,
      "role": "report_shard",
      "lane": 159,
      "address": "0xBee7Ae39e42BB96f19F412D5421BC6df405DB856",
      "runtimeHash": "0x022da0280f56f84a746e4105fc5d996747f4a0187245ffd34c040af8aa106b3f",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 161,
      "role": "report_shard",
      "lane": 160,
      "address": "0xA7488574a01b5dfAed7428Bb9e71798F65116F29",
      "runtimeHash": "0x00b90b7fafd892696da5164167ad5db03b65b655383004fea604fef640479c77",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 162,
      "role": "report_shard",
      "lane": 161,
      "address": "0x83D3524888FDcEE859C31F7c35762AEe3dB50dC6",
      "runtimeHash": "0x8a20d85d9ddb5ebe1eefaacc5f14fcb54aa5cf768fa06c988ec556ac7eb03446",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 163,
      "role": "report_shard",
      "lane": 162,
      "address": "0xa1ca7674876E126FfaD1334056A18fE956954B11",
      "runtimeHash": "0xa1c157aade15c8e0cf8dc9effb1c5bf7bb330f09ed28f6c822bb556056d188f2",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 164,
      "role": "report_shard",
      "lane": 163,
      "address": "0x0A91B15155A306AA7AbaFC9bA627D2315feB5BD9",
      "runtimeHash": "0x2f3bd538ac400736a6913f7400aa0e58642f58acbec24df795e431bd7da64f56",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 165,
      "role": "report_shard",
      "lane": 164,
      "address": "0xe45314e4F3AF5487CFDF3404F9c1434Ac7Fe255E",
      "runtimeHash": "0x6445d25dfe83a26ba4a052fc0a9f4bd451995c3dd141409473f041cd7807ec2b",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 166,
      "role": "report_shard",
      "lane": 165,
      "address": "0x8afB77CA00B226d254077fA2603A012afAD2B5Eb",
      "runtimeHash": "0x7f81846f00d5ffcb1e74581852c11d749a6aa66ae0154c761410d31d04b4b7e0",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 167,
      "role": "report_shard",
      "lane": 166,
      "address": "0x3d35d0DBB01d23fA9D0B731708B4E4c9b6E4A3F6",
      "runtimeHash": "0x1165b3f63a17e48129625d00b8c2b67df23fdf0347d9406941b95a62df518fea",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 168,
      "role": "report_shard",
      "lane": 167,
      "address": "0xc5ef5853536B58E598Ed1a3468EDab4bb38b1F99",
      "runtimeHash": "0x1a1367a7b2a3b6b185380a257a5caace78b8489a8471cd4a56ecb954d47c6efb",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 169,
      "role": "report_shard",
      "lane": 168,
      "address": "0x51F6E9D0E7E42b005283afE6064Be4E3EC33C628",
      "runtimeHash": "0xcfcfb6495aeb281e1821740bfabc853f8ed94780f96198d7378a64a9295cab9a",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 170,
      "role": "report_shard",
      "lane": 169,
      "address": "0x1E36a0EaC0F30FCf99F74000c150933d6Edf3FFF",
      "runtimeHash": "0xf45bad27d717e5ea10a70fbbce249634fc7cae1911ae94f43fb67d92c3ab86e9",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 171,
      "role": "report_shard",
      "lane": 170,
      "address": "0xa6dCdaEE6Ac3A84a0C9dF25C812E787AE5276Ce2",
      "runtimeHash": "0x65ef32da7c38cbef7777d5988b401c366cef703901c40e0652cc355298134cf0",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 172,
      "role": "report_shard",
      "lane": 171,
      "address": "0x756a5ccd2577BF3518334542170b3911d7023171",
      "runtimeHash": "0xc020aa09a3e0cc391ea0016a8d5c367d66277d8aca236bc6adf1257cb2f303bb",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 173,
      "role": "report_shard",
      "lane": 172,
      "address": "0x5Cf2402F7EA22f28Baa69C153234aeEb2c1D87DB",
      "runtimeHash": "0x81fc26cb2f3bd255406e646c6d4d3de7ecfb2213ac19c94f5cd8b5190963c8b4",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 174,
      "role": "report_shard",
      "lane": 173,
      "address": "0x78f8D134FF53BcDabCeBc7e7261747D28D45EC34",
      "runtimeHash": "0xc4728958f111ee048373d0e5e2a23647aa1875049853c5b6d637698b6a381229",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 175,
      "role": "report_shard",
      "lane": 174,
      "address": "0x3858B70C3f649AfC4b1c48A1F1fc6bdb8BC2DD24",
      "runtimeHash": "0x998b137572e113cbeb56a6f36984e85fe536986d53f5395bd0e58adb02b05412",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 176,
      "role": "report_shard",
      "lane": 175,
      "address": "0xD9B614b705e59a7EbcB5fbFd1aBcA19100106E12",
      "runtimeHash": "0xa8555798fe5ca323a6137b77de8fa589f655dc4622bd2e101276d538a6bcc73d",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 177,
      "role": "report_shard",
      "lane": 176,
      "address": "0xdbad32def73cf7659D30f43A4F4e395f75FE13f2",
      "runtimeHash": "0x13c6c487907bc5b96348bce7f8aac99318632d2d2d086fb7e995e0b5ed221ffe",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 178,
      "role": "report_shard",
      "lane": 177,
      "address": "0x83426054A36b7C26Ed1d5c1ae20bB83F1beb8830",
      "runtimeHash": "0xb310e2687d82defa63b23ac27ad70d5d034ef0d7691ed67dffa65b0547e1bccb",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 179,
      "role": "report_shard",
      "lane": 178,
      "address": "0x465282b50Ba25bb2d446AC388e3a40bc4Ffc66e3",
      "runtimeHash": "0xa5d5e7b39bc7989226704368ac57ac6f5c28e65c89ae4fbe495d1a1d94f55c45",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 180,
      "role": "report_shard",
      "lane": 179,
      "address": "0xF9bF150378081369aeDEE2930e693E7E655dc80E",
      "runtimeHash": "0x75b1c073c32988cc9d57bcd02a4e1a06be9eb030c1e6226433cd358467c72a87",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 181,
      "role": "report_shard",
      "lane": 180,
      "address": "0xE5d7402cAf8480A54b17a4ab2d1B2dbdF9fEF996",
      "runtimeHash": "0x5a785cb44942d3be36f07d2dc540116d9c978bc00aefd9abda307e10c4497ada",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 182,
      "role": "report_shard",
      "lane": 181,
      "address": "0xE6376F52ED3A0Caf68Ae1f46928a8C7BB9CaCF46",
      "runtimeHash": "0x743fa220c35412ca803efb48f07738d64f0f6f3a9953f64640934e03494cd371",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 183,
      "role": "report_shard",
      "lane": 182,
      "address": "0xB3d104580884C0577FC69851355b68b1f6218294",
      "runtimeHash": "0x8aedd2e1162318e5ce0fbe445a103561f61808c04fb25399d5ee6810a44e9ed5",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 184,
      "role": "report_shard",
      "lane": 183,
      "address": "0x329cc81152Bca6aC1873B77183f773C13392E526",
      "runtimeHash": "0xae89e62dd43d729829b188a95388106c308c1cd7a0cdf9e0844c1c1561c9e2fa",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 185,
      "role": "report_shard",
      "lane": 184,
      "address": "0x0b55DDFe662e1A555d98f49407F65BEd56d0Ed39",
      "runtimeHash": "0x9e5aae247b7478f08ef09359fe15fb96be22d47b2cfd1415e236a5c547a6c954",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 186,
      "role": "report_shard",
      "lane": 185,
      "address": "0x2c0B5AbFf87604C1a7cd7cAe7D19be52d7f5C26a",
      "runtimeHash": "0x4ee456d1b6c61edc5c84db68003817ae4c40e97a92e5f749543c1c0e8d108183",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 187,
      "role": "report_shard",
      "lane": 186,
      "address": "0x706548B5e10548667dA183b9DdFc472A204ba00D",
      "runtimeHash": "0x86d3cda6c74b8d6ea462208680b493ffaa9f64cba4f03c4fb1a1f24df8ac0e70",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 188,
      "role": "report_shard",
      "lane": 187,
      "address": "0xAe03386e6BEc9bE3554F3463BAf9c8DDB59e38fB",
      "runtimeHash": "0x002a67e0b61ac4f10e9fefb040a8f9883a09cb70a2374050589ae547d94cec49",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 189,
      "role": "report_shard",
      "lane": 188,
      "address": "0x9378aC369f7E68c6F0F917421eB07607fe903267",
      "runtimeHash": "0xc3eb503eb0e4369a1fcbefc3574e95d0d8cee7674d14a7bd5ae07f7ffbd3d99e",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 190,
      "role": "report_shard",
      "lane": 189,
      "address": "0x0c4D28f085397db61950eaB22c2458FFAAcbC8D5",
      "runtimeHash": "0x3435c81875e8087198bc5a1ab41d21f2a29d45485a5d633909381dd6af143ec1",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 191,
      "role": "report_shard",
      "lane": 190,
      "address": "0xbC6E5e4e4f85c35Aa2cA6B67661032F2D1Fb5E85",
      "runtimeHash": "0x185fc659bb0b701072c6bdb205d8de73134fc3180765113a5a4edf7b5d907fc8",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 192,
      "role": "report_shard",
      "lane": 191,
      "address": "0xA52a03F5C5763Bd6996aEB96DBeF88c6E379Fc50",
      "runtimeHash": "0x2d47d64930eb2f97e552eb71bde8e75bec0018116260b205e3994c6dfaa6183e",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 193,
      "role": "report_shard",
      "lane": 192,
      "address": "0x8F17cF77182fb0F3c90827191Bdb1eADAafA351A",
      "runtimeHash": "0xa8d3e5ad1593216531b1ef3d64fbbb1183ffc73dac92ba3ffc34ec9755ddd30d",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 194,
      "role": "report_shard",
      "lane": 193,
      "address": "0xACD296E57D22D62AfD44C15f67417DCe13300db9",
      "runtimeHash": "0xd4d517722fa0f35d326bdd251b6c16b3946e9fc38ec59da97b4c9848c11acf4d",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 195,
      "role": "report_shard",
      "lane": 194,
      "address": "0x246Cc5F20c548c43FA4524A55d99abcd12a4aE19",
      "runtimeHash": "0x56a7a35d6e4f2911a8a6c00992399615fc8077ebff84d5ce173e8bb9902f2ada",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 196,
      "role": "report_shard",
      "lane": 195,
      "address": "0x1F51f8Ef3Bd5FD53CE2C908d35463E55DE5cF366",
      "runtimeHash": "0xaf0af34809ea9d47d00a82b7d889fd348810c5287081d0014f5e68a94a272dc4",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 197,
      "role": "report_shard",
      "lane": 196,
      "address": "0x97bfd733E7f46C444B9E01B1446dc33df4227e46",
      "runtimeHash": "0xcb2fec70938551293db4edb0a796b6df002f70ed428f16253858c31afbc357bb",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 198,
      "role": "report_shard",
      "lane": 197,
      "address": "0x9c1027c32109bADbE2415906ca96632d5D9603aC",
      "runtimeHash": "0xb3d39783f3ce8d4b852a2eac796b5917af16a57fc1adbf94aef9c238fbba8ee3",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 199,
      "role": "report_shard",
      "lane": 198,
      "address": "0xFF72D29898bFCA6dB9A2BAAa490CD0397B6D1554",
      "runtimeHash": "0x3eafe95cb88a653f3392cf41c753ad3bd6c36f56155a6ae10e3799723f13d550",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 200,
      "role": "report_shard",
      "lane": 199,
      "address": "0x412a442EDDE27e8C6b3c630F03B50Ff57566669C",
      "runtimeHash": "0x31e00c43ce1e7b0ac6503c1731b6b770cb8495cdc0b4033051d610533911be54",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 201,
      "role": "report_shard",
      "lane": 200,
      "address": "0xd04441C9404A217216dbBd5bAaf01308A8D93583",
      "runtimeHash": "0x90ac74a8d7cec8eeea6b2320754ff12ec6450cc6a8ea8db97fda762e11afd66b",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 202,
      "role": "report_shard",
      "lane": 201,
      "address": "0x8ca7618DF2279d4f10fc32f5bF248A1EF3db005f",
      "runtimeHash": "0x1da2fb229f387fec03c716b678dbca1f728aa21b2214c84a4f3c8c5d05eeb93c",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 203,
      "role": "report_shard",
      "lane": 202,
      "address": "0xC2d6B9c2E8259BEE92bDB4E70949FCcdc3aD6e1c",
      "runtimeHash": "0xe1b589f66a91623113188a863a4035f03881039d1f9ead545c7ecb8d995ac3c9",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 204,
      "role": "report_shard",
      "lane": 203,
      "address": "0xc5Eb1e961bdb7739aa64dFf8eBb862C5123deE86",
      "runtimeHash": "0x0b0a1828277f6e019c88cb46c5cb692532d20775b2179e15433c97dc1ab9cdd3",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 205,
      "role": "report_shard",
      "lane": 204,
      "address": "0x6291386AaAA6B14d055F0eb4AE8754884AF49295",
      "runtimeHash": "0x3e10629f043fb0767a30c7529e49ad01100aef80be4b2a21ee818a3f78424e74",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 206,
      "role": "report_shard",
      "lane": 205,
      "address": "0xC32E62A78C6D45543483a9c56B67Aa0498345454",
      "runtimeHash": "0x9c55fc8d8e6a09d148e8f41d51f34f1826a989b04275c46cb20c805a3a620724",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 207,
      "role": "report_shard",
      "lane": 206,
      "address": "0xAaab524f99aB20C7224913A26114e9B0F26B73c2",
      "runtimeHash": "0xd859d8fc2f09e7b49d3f9d6163720198d5de767d5167c0ec4b7e8ee43e255261",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 208,
      "role": "report_shard",
      "lane": 207,
      "address": "0x74DE5aA2bbF6dD5DE5327D2754671BbAa643cbA6",
      "runtimeHash": "0x1b54dfb3453c4eba3b971e9fcae2662ba4291e469f8e4558bd6a04330df2c746",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 209,
      "role": "report_shard",
      "lane": 208,
      "address": "0xDC418A33A85803B2b0379d2dB8334111b1549c2E",
      "runtimeHash": "0x0fa3926e036a5c706d6926e3d9ac4421ac6234ac0f2a9cff60459a36f0403414",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 210,
      "role": "report_shard",
      "lane": 209,
      "address": "0xEd0212C6307c32B4d9Fb0C1Ae90A91701493C349",
      "runtimeHash": "0x3c079c5ffc203bc51a05e2469bdeae91b049f781b3b61f7832dfb0105bce6aea",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 211,
      "role": "report_shard",
      "lane": 210,
      "address": "0xC03f162443A332f7aC1230B7DC6D1ce6d043Ef76",
      "runtimeHash": "0xc5e1977be208f591ed66f7f72fb71ee2e4621bc1c65f3841a53a67eeb43c2fb3",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 212,
      "role": "report_shard",
      "lane": 211,
      "address": "0xc062b9E114C5C150E2b48bB8a2E1428E9eaf2D0D",
      "runtimeHash": "0x424cd8a19a2295e60e3adfb142af82eb7b736b9521d249a29aa6b1303148a2bb",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 213,
      "role": "report_shard",
      "lane": 212,
      "address": "0x5B960faAe34D9ff3Cc953EA3759ff47B4c1525D8",
      "runtimeHash": "0xcf7a39e4c400cf831e9b450c80b52c41328725d5108f7273ca1e6ba255e40cb7",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 214,
      "role": "report_shard",
      "lane": 213,
      "address": "0xE2Ea81bFD1e2cD71dE09f723aE974fA17CF5b9B3",
      "runtimeHash": "0x33c7da05a1c512d39288d96c6a1f154f4460931d29bd5d2fd21daf5a51f2872a",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 215,
      "role": "report_shard",
      "lane": 214,
      "address": "0xe54654e5835E61c1e09947353b584bA17568b07D",
      "runtimeHash": "0xe3756282ac3e4831faee728f9695681ff9bd73dfc136f98f138b7d892083f5c9",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 216,
      "role": "report_shard",
      "lane": 215,
      "address": "0x9AA6a0d632Be5B399e7964B8D0F97ABB6abc79c6",
      "runtimeHash": "0x9dfbe8764d62a4661012734b583df133bd685a77685a76c00a6131ebf35f50dd",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 217,
      "role": "report_shard",
      "lane": 216,
      "address": "0x4b26fa6423B2F889a4F5CC1e90A0b0A567b84A0C",
      "runtimeHash": "0xf999c0c77c6fc70f0ce39f466b9f82030e3f5bde55e6832fb60cc933b085960c",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 218,
      "role": "report_shard",
      "lane": 217,
      "address": "0x52C33383b3919446E633d301cC423B4E5f5549AB",
      "runtimeHash": "0x57873c7982e23846f06472d81c36c4fc0904471569d40601720bed95dd671a41",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 219,
      "role": "report_shard",
      "lane": 218,
      "address": "0x931E0f4705440A5Aa33edd30133Aa81D7ED83734",
      "runtimeHash": "0xd8fdc8fdad3673707bad8f38ac3e269df3b849f077c76dd1d57808f1a77170fe",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 220,
      "role": "report_shard",
      "lane": 219,
      "address": "0xE3500EDd0F0c3e08b61344Fb426D6441A8F9cd93",
      "runtimeHash": "0x3c4be394882d21a1650603e5d37634b8d21a238bf90fd0990378d1f4ff8b833f",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 221,
      "role": "report_shard",
      "lane": 220,
      "address": "0x81f9A63D9C4c977Cc4385491A801cc663A5c5e7A",
      "runtimeHash": "0x8f0ff59c408838d3124d5f5faa7707f8d5e84bdf97f0919683619150da187e8d",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 222,
      "role": "report_shard",
      "lane": 221,
      "address": "0x78a0FC0f2033F1B36154F39090b832DE16115221",
      "runtimeHash": "0x6f4723dadc2ed772966f1b5434ed3426ff464b169ab2ba1c2eceb6950bee63db",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 223,
      "role": "report_shard",
      "lane": 222,
      "address": "0x75269049022aeBC4f1964F51eDae3d4590b835D3",
      "runtimeHash": "0xf1c991f26671776f93dc4d780f7bfa418da98b2e9a1bd1d141a5ee6a05ea2538",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 224,
      "role": "report_shard",
      "lane": 223,
      "address": "0xa7D7f51871957795ACa96627000DA100d14edeD1",
      "runtimeHash": "0x7fa2f8861475883fafea27f7754d84ea023c33dc930ff34457b3dded1dab3abc",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 225,
      "role": "report_shard",
      "lane": 224,
      "address": "0xE54fD0188e76d6191F50093F159cBceF3cdFbD05",
      "runtimeHash": "0x7320503344a799a9d661236de8cc63f0b1d35c0ed8d1ce3c66d13b530d2238a6",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 226,
      "role": "report_shard",
      "lane": 225,
      "address": "0x010dFc17220A9897Ed903410728bB6De9FeF3C12",
      "runtimeHash": "0x88ccd40b3b1df2dfe9a9971b828eabc2b01d14c7d97cac6560d65dcb12e58232",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 227,
      "role": "report_shard",
      "lane": 226,
      "address": "0x82dF1c9E7f1E63fa7dc36826435EBBdd020DDe34",
      "runtimeHash": "0xa47c67a9941ce5d15cc5d69646f53634b2c5681692482c63e38feebda46b3292",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 228,
      "role": "report_shard",
      "lane": 227,
      "address": "0x054a8B66D561CBE48f2028F56e00212871828EC8",
      "runtimeHash": "0xf4afce7c3b1b10d29e96ea01cb09da7b3bc30d5c920d5c1c8851d1792e75ce73",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 229,
      "role": "report_shard",
      "lane": 228,
      "address": "0x1097935A46CFf248EB0fdCFd78058020dE3A2585",
      "runtimeHash": "0x16a7c66c0dd9fdadb3903cf5e94b2a6486b80dff3b46bae18c842486c0111d16",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 230,
      "role": "report_shard",
      "lane": 229,
      "address": "0x08831153F5a7A186a14a016708e4B5e8d9Da349b",
      "runtimeHash": "0x84e8672c0a12e4724246e50a5966913f3d0dfce9811e6eede5c55f42087360f6",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 231,
      "role": "report_shard",
      "lane": 230,
      "address": "0xCe53081200de979f89C7d0472F3552C451736066",
      "runtimeHash": "0xbc087f1f62b337f750a50455a4e06fd51d777025b1604606bf03c9d34f1f604e",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 232,
      "role": "report_shard",
      "lane": 231,
      "address": "0x0e374A1Bf7050c78616eA9C4c05fA16c7852ec0F",
      "runtimeHash": "0x70099a3884d4443319349d1fa8faffaab2e8dbd0bc5bb4c93ab686a30b82a0c8",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 233,
      "role": "report_shard",
      "lane": 232,
      "address": "0x21b3168f0500C2305974162C701008CFc7A8d0DE",
      "runtimeHash": "0xde1bde67aca21932a502352ce7e263903dc7a026af052b19498032e905632735",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 234,
      "role": "report_shard",
      "lane": 233,
      "address": "0xCD0d4bB027f2a2c818ec21434590CcD302f46986",
      "runtimeHash": "0x2d32c0f333d0cad0900b9a446094d6cba42c9533b767d2394c42be04e3dbc006",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 235,
      "role": "report_shard",
      "lane": 234,
      "address": "0x3bd3F36c2874c20E7386eaE55066f68819c49d3f",
      "runtimeHash": "0x3d265beb8f449be4705b99e4ba52715057c7de3577c8c465b433cf2ea686b308",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 236,
      "role": "report_shard",
      "lane": 235,
      "address": "0x2972BEeE649d01ABD542F198c6Cb692694062DDe",
      "runtimeHash": "0x38eb3b2b0a9a8e534cd2b59b4db9015a35edabc89d6079a11036726a1ff84236",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 237,
      "role": "report_shard",
      "lane": 236,
      "address": "0x2b771cd9Fc89826Fc29348BEB7Cb837727cEe491",
      "runtimeHash": "0x0ee46274ab87585ceb22a20e81f71d54bda9d69bf4c658f03d75f2f9832e77ba",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 238,
      "role": "report_shard",
      "lane": 237,
      "address": "0x2C49Eec024A325A50CafA3A410b3dAd515698182",
      "runtimeHash": "0x845741a1d86de6238e10079a5173a9dcd22f15dfd53a4c2f83bf5b5e95696ecd",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 239,
      "role": "report_shard",
      "lane": 238,
      "address": "0x46a43C07D13AebDd7A8baC4983730b093C748186",
      "runtimeHash": "0xdd640406ca9123c89a4bef19e29b98170e55e458c369b51888438649b886e74f",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 240,
      "role": "report_shard",
      "lane": 239,
      "address": "0x79511d797658da5c4D0b20f071802598Ec4e6655",
      "runtimeHash": "0x034dfb99c8898de175af8d74e26777cbefed52fdd5997bfeebb0978a08f0de60",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 241,
      "role": "report_shard",
      "lane": 240,
      "address": "0x92a11F1a42bE52B05f7493f0120DBaFfC30c916A",
      "runtimeHash": "0xab4adae3762c94b4e705da96a2a5dff330e2adff123fbb25593cdf9a5fc1bf4f",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 242,
      "role": "report_shard",
      "lane": 241,
      "address": "0x01366B71A3d40742c644f9b72CF8f111fb1aE8C0",
      "runtimeHash": "0x13e66f76c1ab228061850f24e3dc19c5ca2e09884c83eeb048df70d15ef5bd91",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 243,
      "role": "report_shard",
      "lane": 242,
      "address": "0xF1c6dE67d34C54c6F42186acd5bff95f0530cA95",
      "runtimeHash": "0xefbf08b095d024aa5df1076b0837594079628b999aec9dd2afb2bcc3b808190f",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 244,
      "role": "report_shard",
      "lane": 243,
      "address": "0x15e6249FA21B917A8Af2aBC3c56f4dF4BFdb80c2",
      "runtimeHash": "0x55ea4132c3eb372b8577d1f99328d25a98630efa876ce0f9320df777edef534b",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 245,
      "role": "report_shard",
      "lane": 244,
      "address": "0x9A578C451807141537a3d16e6F698Bc6BFcd9E86",
      "runtimeHash": "0x8142ba4c06b6c9dee1cd873f10d52fca743050bf57e9c2fd1d0e2e966e89fc89",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 246,
      "role": "report_shard",
      "lane": 245,
      "address": "0x881eF367d57EF3c39af81a64eAa88d37f3063E8c",
      "runtimeHash": "0xff95fdbd2c296023034c78220a2cf510533727c0057a10e61bb5b67f825e9192",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 247,
      "role": "report_shard",
      "lane": 246,
      "address": "0xB5ECAf0B5C858bAADEe99D8FaC6dD85608Ee4a90",
      "runtimeHash": "0xeb39b3571a7caedc9c40c5f34d729f0e2516c2cf25b43dfa3570e177756025b1",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 248,
      "role": "report_shard",
      "lane": 247,
      "address": "0x26Ba6D51Cd1A047C8e2938DF020C1Acd7D7eb902",
      "runtimeHash": "0x2dcfbeb4f0a478a1479da85c66f720f3a2ac3a3b84c0cf052d2fb65e4e3080c4",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 249,
      "role": "report_shard",
      "lane": 248,
      "address": "0xFc6f5a55C7BFcbDca52336E73d0d98481fd00325",
      "runtimeHash": "0xf0c0390af24ce9670c887382dd5b2c4585b39805c78c4b02c17e10108a9fc95b",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 250,
      "role": "report_shard",
      "lane": 249,
      "address": "0x0FB50E2240d9fC21861C6d154269C7540Daff45B",
      "runtimeHash": "0x1fcfa06b671e7ee8756b649d197882a02e325c346043ad8cd9438ecae1d3bc3e",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 251,
      "role": "report_shard",
      "lane": 250,
      "address": "0xE9DA3ea491D9c6ECf4E9EF573Ab517994bE3192c",
      "runtimeHash": "0x85eb97bbd3b9fb06763f24d1064d771d9fcab6ffc8eb38a0bbaa73ad68530cb7",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 252,
      "role": "report_shard",
      "lane": 251,
      "address": "0xe933674e2641a22d02065f36D968dA71827808db",
      "runtimeHash": "0x4a3b750a3b5118a6ef9dd2cbcbbd9f088e5a1e70bdb7852c516afd8d8bcfe97d",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 253,
      "role": "report_shard",
      "lane": 252,
      "address": "0x1AB75aEe8315Fb449A7DE8473574Dd4E3dC48B1e",
      "runtimeHash": "0x25c16460ba3dc1e96508ee75cdd0bc5d98f75c44ce716211bac5b8d5a93e31b5",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 254,
      "role": "report_shard",
      "lane": 253,
      "address": "0xAf31FA64Ed06bDaEb8a91063B982f80d4BEfDB63",
      "runtimeHash": "0x5bdb7cd02304beb3782b246fb1ea02b43202bce0f48103b2e4940596aab80cd3",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    },
    {
      "index": 255,
      "role": "report_shard",
      "lane": 254,
      "address": "0xF4318Bf9a6431601a1d6bE99007A9D50798C9262",
      "runtimeHash": "0xf932a3186c4259fa7e2a0d2b2a6883fd6eacd2ec04ce05ff7ff76a2d7607cea8",
      "verifiedAt": "2026-11-02T17:29:55.990Z"
    }
  ],
  "report": {
    "runId": "0x3b60f0204b50f6099581f18463a5796efab01e23e36744b9dffc76d08ca29c69",
    "experimentId": "0x4eeb96854ce18822ef54fe421ac1f7f8ee1f7a6b2aeace1abd857c66cfcfec61",
    "lane": 142,
    "shard": "0x2c3A4c11b5b416E3850dDB6e486757BAF93218b5",
    "sequence": "1",
    "completedComparisons": 6,
    "diagnosticOnly": true,
    "scientificAcceptance": false,
    "retrospective": true,
    "resultHash": "0xef01459ab92929285cdeb2284df6fcad5d73927fde23e3cd9c0e7c84c8dcf2b5",
    "checkpointHash": "0x5c12df660b0649fd1a50e421f4e8e06ac6902fee635d174551bff1c9ae3438cc",
    "attestationDigest": "0x5922d4f179dea632e51e6590275f41f846098ee0d3d543c79bfcab148ade678e",
    "verifiedAt": "2026-11-02T17:45:35.980Z",
    "transactions": [
      {
        "action": "registerExperiment",
        "hash": "0xbf0b568083f0fd3e0024b58b27d494a18c95401d9bfa39171df9a2ebd28ee4dd",
        "feeEth": "0.000003811763186",
        "gasUsed": "190531",
        "blockNumber": 104400660
      },
      {
        "action": "startRun",
        "hash": "0x6eeca7001961f138aa1dacf32ba7f2437bd9b9e3217113546d2203e188fc5c9a",
        "feeEth": "0.000003593789936",
        "gasUsed": "177752",
        "blockNumber": 104401023
      },
      {
        "action": "submitReport",
        "hash": "0xee696c70ceded53ff1a0ab3c215383b13205dbad2f30e2b236737e3e49244c1b",
        "feeEth": "0.00000426339528",
        "gasUsed": "211730",
        "blockNumber": 104401402
      }
    ]
  },
  "costs": {
    "deploymentEth": "0.004612876889674",
    "connectionEth": "0.000011668948402",
    "onchainTotalEth": "0.004624545838076",
    "transactions": 36,
    "gpuUsd": null,
    "scope": "Actual deployment and first report only; GPU billing and future work excluded"
  },
  "proofs": {
    "deploymentSha256": "5d13b49e65c5482fb53768d9114088c0f284f895778db494a66818ec59730cde",
    "reportSha256": "89168e2f08298ebae2f348d1bfb342c170ddde36ab79d7602a6a9c5c6807a66d"
  },
  "links": {
    "deployment": "https://github.com/ORVIArh/ORVIA/blob/research/mainnet-readiness/evidence/hybrid256/MAINNET_DEPLOYMENT.md",
    "report": "https://github.com/ORVIArh/ORVIA/tree/research/mainnet-readiness/evidence/hybrid256/gpu-connection",
    "repository": "https://github.com/ORVIArh/ORVIA/tree/research/mainnet-readiness"
  }
};
