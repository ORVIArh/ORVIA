# Live ORVIA reporting API

The public API displays the deployed coordinator/report state, the dated 256-address verification inventory, and authenticated remote-worker diagnostics. It has no transaction signing, GPU provisioning, funding or arbitrary RPC interface. Netlify never receives a wallet password or private key.

## Configuration

Set these in the Netlify project's **Functions** scope for the **production** context, then deploy:

- `ORVIA_RPC_URL`: HTTPS Robinhood mainnet RPC endpoint. Secret; never included in public output.
- `ORVIA_WORKER_TOKEN`: fresh 64-character lowercase hexadecimal bearer token. Secret; only authorizes diagnostic uploads for the configured job.
- `ORVIA_WORKFLOW_ID`: fixed identifier matching `[a-zA-Z0-9_-]{8,80}`.
- `ORVIA_WORKFLOW_STEPS`: `400000` for `orvia-stress-20261102-02`; the preceding `orvia-live-20261102-01` used `3000`.
- `ORVIA_HISTORICAL_WORKFLOW_IDS`: optional comma-separated read-only history allowlist. Set `orvia-live-20261102-01` for the current stress job. Only exact reviewed IDs in `workflows.mjs` are accepted; this never grants permission to upload to a historical job.

The Netlify Blobs production store is `orvia-worker-events-production-v1`. Production deployments retain its immutable event history. Preview deployments may read already-public data, but all upload routes explicitly reject non-production contexts. No preview should seed production state.

## Routes

`GET /api/orvia/status` returns the stable `schemaVersion:1` envelope consumed by `/live/`. `chain.available` is true only after a fresh chain-ID check, coordinator and selected-shard runtime checks, owner/operator/count checks, exact first-report comparison, and a stable pinned observation block. The complete 256-address inventory remains explicitly dated verification evidence, not 256 fresh code checks per browser refresh. The function keeps a 15-second warm cache; `generatedAt` and `chain.checkedAt` retain their actual observation timestamps. Provider failures return unavailable status alongside historical evidence, never synthetic live success.

`POST /api/orvia/worker` accepts only a production request with `Authorization: Bearer <token>`, JSON content type and no browser Origin. Maximum body: 4096 bytes. The exact fields are defined in `telemetry.mjs`; additional keys, changed job IDs, scientific acceptance, regressing progress and malformed timestamps are rejected. Sequence starts at 1. Each event is an immutable create-only blob; a same-payload retry is idempotent, a conflicting retry is rejected. There is no mutable latest pointer or read-modify-write counter. The public reader selects the highest accepted sequence for the configured workflow. Running telemetry older than two minutes is marked stale. Completed job status says nothing about Runpod allocation: `gpu.podState` is `not_monitored`. A pod may remain running between jobs.

`POST /api/orvia/trajectory` uses the same scoped authentication and accepts an exact-byte SHA-256 header `X-ORVIA-SHA256`. Body maximum: 4 MiB. The protocol accepts one immutable trajectory for each declared model, with exact particle/subset counts, 101 frames, finite nanometre coordinates, original particle indices, source hashes and explicit periodic imaging metadata. The previous profile spans steps 0–1000 and 0–100 fs. The stress profile spans steps 0–80000 and 0–8000 fs, with exact runner and input-manifest hashes pinned in `workflows.mjs`. Its two representative trajectories do not visualize all four parallel replicas. Arrays describe a selected molecular subset; solvent water and the remainder of the protein are not all rendered. Schema and hash validation do not establish numerical or scientific correctness.

`GET /api/orvia/trajectory?jobId=<readable-job>&sha256=<registered-hash>` serves only a previously admitted artifact for the current workflow or the explicit historical allowlist. Arbitrary blob keys, URLs, jobs and files are never accepted. The response bytes are verified against the recorded SHA-256. The public status lists available artifacts and their fixed same-origin URLs; records from earlier jobs carry `historical:true` and the viewer labels them as previous-job frames.

`POST /api/orvia/gpu` accepts optional actual `nvidia-smi` measurements with the same production-only scoped authorization and a 4096-byte maximum. Exact numeric fields are defined in `gpu-metrics.mjs`; no arbitrary labels or error text are admitted. Samples are immutable by job and sequence, with identical retries allowed and sequence gaps tolerated. Status exposes the latest sample as `gpuMetrics`, marked stale after 45 seconds. GPU utilization, memory traffic, VRAM, power and temperature describe the whole device, not exclusively ORVIA. Unsupported numeric readings remain null. Samples neither prove the scientific result nor monitor Runpod allocation. Failure to publish measurements must not stop numerical work.

All accepted GPU data remains `diagnosticOnly:true` and `scientificAcceptance:false`. Worker report hashes are separate from the retrospective operator-signed report already accepted on chain. New worker artifacts do not become on-chain reports automatically.

## Validation

Run `npm run test:live-backend` for bounded local tests. The tests use in-memory blob objects and simulated read-only RPC replies; they never unlock a wallet, send a chain transaction, start a GPU or run molecular calculations. Production deployment additionally requires a real read-only endpoint check and a genuine worker upload. Do not publish synthetic test events to the production store.
