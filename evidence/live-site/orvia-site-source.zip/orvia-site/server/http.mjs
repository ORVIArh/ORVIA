import { MAX_EVENT_BYTES, TelemetryError, authorize, appendEvent } from './telemetry.mjs';

export const headers = { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store',
  'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer' };
export const json = (body, status = 200) => new Response(JSON.stringify(body), { status, headers });

export async function boundedBody(request, maxBytes = MAX_EVENT_BYTES) {
  if (!/^application\/json(?:;|$)/i.test(request.headers.get('content-type') || '')) throw new TelemetryError(415, 'json_required');
  const contentLength = request.headers.get('content-length');
  if (contentLength !== null && (!/^\d+$/.test(contentLength) || Number(contentLength) > maxBytes)) throw new TelemetryError(413, 'body_too_large');
  if (!request.body) throw new TelemetryError(400, 'invalid_event');
  const reader = request.body.getReader(), parts = [];
  let size = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > maxBytes) { await reader.cancel(); throw new TelemetryError(413, 'body_too_large'); }
      parts.push(value);
    }
    const raw = Buffer.concat(parts);
    try { return { bytes: raw, input: JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(raw)) }; }
    catch { throw new TelemetryError(400, 'invalid_json'); }
  } finally { reader.releaseLock(); }
}

export async function handleWorker(request, { context, token, jobId, totalSteps, getStore, now } = {}) {
  try {
    if (request.method !== 'POST') return json({ error: 'method_not_allowed' }, 405);
    if (context?.deploy?.context !== 'production') return json({ error: 'production_only' }, 403);
    authorize(request.headers.get('authorization'), token);
    // No CORS, cookies or browser credentials. This endpoint is a scoped worker sink.
    if (request.headers.has('origin')) return json({ error: 'worker_only' }, 403);
    const { input } = await boundedBody(request);
    return json(await appendEvent({ store: getStore(), input, jobId, totalSteps, now }));
  } catch (error) {
    return error instanceof TelemetryError ? json({ error: error.code }, error.status) : json({ error: 'unavailable' }, 503);
  }
}
