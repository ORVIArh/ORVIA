import { Interface, keccak256 } from 'ethers';
import evidence from './data/evidence.mjs';

export const ABI = new Interface([
  'function owner() view returns (address)',
  'function operator() view returns (address)',
  'function shardCount() view returns (uint16)',
  'function deploymentReady() view returns (bool)',
  'function shardFor(bytes32) view returns (address)',
  'function runInfo(bytes32) view returns (tuple(bytes32 experimentId,bytes32 configurationHash,bytes32 runConfigHash,bytes32 initialCheckpointHash,bytes32 latestCheckpointHash,bytes32 latestResultHash,bytes32 cancellationReason,uint64 sequence,uint64 completedSteps,uint32 requiredChecks,uint32 allowedChecks,uint32 latestChecks,uint8 status,bool diagnosticOnly))',
  'function reportAt(bytes32,uint64) view returns (tuple(bytes32 previousCheckpointHash,bytes32 checkpointHash,bytes32 resultHash,bytes32 attestationDigest,uint64 completedSteps,uint64 acceptedAt,uint32 checks,uint8 outcome))',
]);
const METHODS = new Set(['eth_chainId', 'eth_getBlockByNumber', 'eth_getCode', 'eth_call']);
const HASH = /^0x[0-9a-fA-F]{64}$/;
const QUANTITY = /^0x(?:0|[1-9a-fA-F][0-9a-fA-F]*)$/;
class ReadError extends Error { constructor(code) { super(code); this.code = code; } }
const need = (ok, code = 'verification_failed') => { if (!ok) throw new ReadError(code); };

// The client never supplies an RPC method, contract address or calldata.
export function rpcReader(url, fetcher = fetch, signal = undefined) {
  let endpoint;
  try { endpoint = new URL(url); } catch { throw new ReadError('not_configured'); }
  need(endpoint.protocol === 'https:' && !endpoint.username && !endpoint.password, 'not_configured');
  let id = 0;
  return async (method, params = []) => {
    need(METHODS.has(method));
    const requestId = ++id;
    const reply = await fetcher(endpoint.href, {
      method: 'POST', redirect: 'error', signal,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ jsonrpc: '2.0', id: requestId, method, params }),
    });
    need(reply.ok, 'unavailable');
    const raw = await reply.text();
    need(raw.length <= 250_000, 'unavailable');
    let json;
    try { json = JSON.parse(raw); } catch { throw new ReadError('unavailable'); }
    need(json.jsonrpc === '2.0' && json.id === requestId && !json.error && Object.hasOwn(json, 'result'), 'unavailable');
    return json.result;
  };
}

export async function readChain({ url, fetcher = fetch, now = () => new Date(), timeoutMs = 8_000, reference = evidence } = {}) {
  const expected = reference;
  const base = {
    available: false, checkedAt: now().toISOString(), blockNumber: null,
    chainId: expected.chainId, name: 'Robinhood mainnet', coordinator: expected.coordinator,
    owner: expected.owner, operator: expected.operator,
    contractCount: null, shardCount: null, deploymentReady: false, reportMatches: false,
    reason: null, lastVerifiedAt: expected.report.verifiedAt,
  };
  if (!url) return { ...base, reason: 'not_configured' };
  try {
    const rpc = rpcReader(url, fetcher, AbortSignal.timeout(timeoutMs));
    const chain = await rpc('eth_chainId');
    need(QUANTITY.test(chain) && BigInt(chain) === BigInt(expected.chainId), 'chain_mismatch');
    const block = await rpc('eth_getBlockByNumber', ['latest', false]);
    need(block && QUANTITY.test(block.number) && HASH.test(block.hash));
    const number = Number(BigInt(block.number));
    need(Number.isSafeInteger(number) && number >= 104402579);
    const call = async (name, args = []) => {
      const result = await rpc('eth_call', [{ to: expected.coordinator, data: ABI.encodeFunctionData(name, args) }, block.number]);
      return ABI.decodeFunctionResult(name, result)[0];
    };
    const [code, shardCode, owner, operator, count, ready, shard, run, report] = await Promise.all([
      rpc('eth_getCode', [expected.coordinator, block.number]),
      rpc('eth_getCode', [expected.report.shard, block.number]),
      call('owner'), call('operator'), call('shardCount'), call('deploymentReady'),
      call('shardFor', [expected.report.runId]), call('runInfo', [expected.report.runId]),
      call('reportAt', [expected.report.runId, 1]),
    ]);
    need(keccak256(code) === expected.contracts[0].runtimeHash);
    need(keccak256(shardCode) === expected.contracts[expected.report.lane + 1].runtimeHash);
    need(owner === expected.owner && operator === expected.operator && count === 255n && ready === true);
    need(shard === expected.report.shard && run.experimentId === expected.report.experimentId);
    need(run.sequence === 1n && run.completedSteps === 6n && run.status === 2n && run.diagnosticOnly === true);
    need(run.latestCheckpointHash === expected.report.checkpointHash && run.latestResultHash === expected.report.resultHash && run.latestChecks === 7n);
    need(report.checkpointHash === expected.report.checkpointHash && report.resultHash === expected.report.resultHash);
    need(report.attestationDigest === expected.report.attestationDigest && report.completedSteps === 6n && report.checks === 7n && report.outcome === 1n);
    const again = await rpc('eth_getBlockByNumber', [block.number, false]);
    need(again?.hash === block.hash);
    return { ...base, available: true, checkedAt: now().toISOString(), blockNumber: number,
      contractCount: 256, shardCount: 255, deploymentReady: true, reportMatches: true };
  } catch (error) {
    return { ...base, reason: error instanceof ReadError ? error.code : 'unavailable' };
  }
}
