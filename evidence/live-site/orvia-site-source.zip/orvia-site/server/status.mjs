import evidence from './data/evidence.mjs';
import { readChain } from './chain.mjs';
import { emptyGPU, readLatestGPU } from './telemetry.mjs';
import { readableTrajectories } from './trajectory.mjs';
import { readMetrics } from './gpu-metrics.mjs';

export async function statusSnapshot({ rpcUrl, store, jobId, totalSteps = 3000, historicalIds = '', fetcher = fetch, now = () => new Date() } = {}) {
  const [chain, gpu, trajectories, gpuMetrics] = await Promise.all([
    readChain({ url: rpcUrl, fetcher, now }),
    store ? readLatestGPU({ store, jobId, totalSteps, now }) : Promise.resolve(emptyGPU('unavailable', jobId)),
    readableTrajectories(store, jobId, historicalIds).catch(() => []),
    readMetrics({ store, jobId, now }),
  ]);
  return {
    schemaVersion: 1, generatedAt: now().toISOString(), refreshAfterSeconds: 30,
    chain, gpu, gpuMetrics, trajectories, reports: [{ ...evidence.report, liveConfirmed: chain.reportMatches }],
    contracts: evidence.contracts, costs: evidence.costs,
    gates: [
      { id: 'deployment', label: '256-contract deployment', status: 'passed', detail: 'All 256 runtime identities and registrations independently verified; full inventory is dated evidence.' },
      { id: 'numerical-diagnostic', label: 'Full-model numerical diagnostic', status: 'passed', detail: 'Six H200/CPU comparisons passed unchanged tolerances; the first diagnostic report is recorded on mainnet.' },
      { id: 'parameters', label: 'Scientific parameter validation', status: 'open', detail: 'Independent parameter and method checks remain unresolved. Worker telemetry cannot change scientific acceptance.' },
      { id: 'recovery', label: 'Fresh-run checkpoint recovery', status: 'open', detail: 'The current bounded GPU run is diagnostic. Completion and artifact hashes require independent review.' },
      { id: 'sampling', label: 'Production sampling and uncertainty', status: 'open', detail: 'No accepted production sampling campaign or free-energy result is available.' },
    ],
    links: evidence.links,
  };
}
