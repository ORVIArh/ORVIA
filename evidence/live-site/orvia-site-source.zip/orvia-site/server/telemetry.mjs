import { createHash, timingSafeEqual } from 'node:crypto';

export const MAX_EVENT_BYTES = 4096;
export const MAX_SEQUENCE = 10000;
export const STORE_NAME = 'orvia-worker-events-production-v1';
const KEYS = ['schemaVersion', 'jobId', 'sequence', 'state', 'stage', 'stepsCompleted', 'stepsTotal', 'updatedAt', 'device', 'diagnosticOnly', 'scientificAcceptance', 'resultSha256', 'checkpointSha256'];
const STATES = new Set(['queued', 'running', 'completed', 'failed']);
const STAGES = new Set(['starting', 'environment', 'loading', 'validating', 'simulating', 'checkpointing', 'finished', 'failed']);
const TERMINAL = new Set(['completed', 'failed']);
const DEVICES = new Set(['NVIDIA H200', 'NVIDIA RTX 6000 Ada Generation']);
const HASH = /^[a-f0-9]{64}$/;
export class TelemetryError extends Error {
  constructor(status, code) { super(code); this.status = status; this.code = code; }
}
const need = (ok, status = 400, code = 'invalid_event') => { if (!ok) throw new TelemetryError(status, code); };
export const validJob = (value) => typeof value === 'string' && /^[a-zA-Z0-9_-]{8,80}$/.test(value);
export const eventKey = (jobId, sequence) => `${jobId}/${String(sequence).padStart(5, '0')}`;

export function authorize(header, token) {
  need(typeof token === 'string' && HASH.test(token), 503, 'not_configured');
  const provided = typeof header === 'string' && header.startsWith('Bearer ') ? header.slice(7) : '';
  const expectedHash = createHash('sha256').update(token).digest();
  const actualHash = createHash('sha256').update(provided).digest();
  need(provided.length === token.length && timingSafeEqual(actualHash, expectedHash), 401, 'unauthorized');
}

export function validateEvent(input, jobId, totalSteps = 3000) {
  need(validJob(jobId), 503, 'not_configured');
  need(Number.isSafeInteger(totalSteps) && totalSteps >= 1 && totalSteps <= 1e9, 503, 'not_configured');
  need(input && typeof input === 'object' && !Array.isArray(input));
  need(Object.keys(input).length === KEYS.length && KEYS.every((key) => Object.hasOwn(input, key)));
  need(input.schemaVersion === 1 && input.jobId === jobId && validJob(input.jobId));
  need(Number.isInteger(input.sequence) && input.sequence >= 1 && input.sequence <= MAX_SEQUENCE);
  need(STATES.has(input.state) && STAGES.has(input.stage));
  need(Number.isSafeInteger(input.stepsCompleted) && input.stepsCompleted >= 0 && input.stepsCompleted <= totalSteps && input.stepsTotal === totalSteps);
  need(DEVICES.has(input.device) && input.diagnosticOnly === true && input.scientificAcceptance === false);
  need(typeof input.updatedAt === 'string' && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(input.updatedAt));
  need(Number.isFinite(Date.parse(input.updatedAt)) && new Date(input.updatedAt).toISOString() === input.updatedAt);
  need(input.resultSha256 === null || (typeof input.resultSha256 === 'string' && HASH.test(input.resultSha256)));
  need(input.checkpointSha256 === null || (typeof input.checkpointSha256 === 'string' && HASH.test(input.checkpointSha256)));
  need((input.state === 'completed') === (input.stage === 'finished'));
  need((input.state === 'failed') === (input.stage === 'failed'));
  if (input.state === 'queued') need(input.stage === 'starting' && input.stepsCompleted === 0);
  if (input.state === 'completed') need(input.stepsCompleted === totalSteps && input.resultSha256 !== null && input.checkpointSha256 !== null);
  if (!TERMINAL.has(input.state)) need(input.resultSha256 === null);
  return Object.fromEntries(KEYS.map((key) => [key, input[key]]));
}

// Each event is an immutable object. No mutable latest pointer, counter, balance,
// read-modify-write blob or implicit overwrite is used.
export async function appendEvent({ store, input, jobId, totalSteps = 3000, now = () => new Date() }) {
  const event = validateEvent(input, jobId, totalSteps);
  const key = eventKey(jobId, event.sequence), canonical = JSON.stringify(event);
  const existing = await store.get(key, { type: 'json', consistency: 'strong' });
  if (existing) {
    need(JSON.stringify(existing.event) === canonical, 409, 'sequence_conflict');
    return { accepted: true, duplicate: true, sequence: event.sequence };
  }
  const receivedAt = now().toISOString(), age = Date.parse(receivedAt) - Date.parse(event.updatedAt);
  need(age >= -60_000 && age <= 600_000, 400, 'event_time_out_of_range');
  if (event.sequence === 1) {
    need(['queued', 'running'].includes(event.state) && event.stepsCompleted === 0, 409, 'invalid_initial_event');
  } else {
    const previous = await store.get(eventKey(jobId, event.sequence - 1), { type: 'json', consistency: 'strong' });
    need(previous?.event, 409, 'missing_previous_event');
    need(!TERMINAL.has(previous.event.state), 409, 'job_finished');
    need(event.device === previous.event.device, 409, 'device_changed');
    need(event.stepsCompleted >= previous.event.stepsCompleted && event.stepsTotal === previous.event.stepsTotal, 409, 'progress_regressed');
    need(Date.parse(event.updatedAt) >= Date.parse(previous.event.updatedAt), 409, 'timestamp_regressed');
    need(!(previous.event.state === 'running' && event.state === 'queued'), 409, 'state_regressed');
  }
  const result = await store.setJSON(key, { event, receivedAt }, { onlyIfNew: true });
  if (!result.modified) {
    const winner = await store.get(key, { type: 'json', consistency: 'strong' });
    need(JSON.stringify(winner?.event) === canonical, 409, 'sequence_conflict');
    return { accepted: true, duplicate: true, sequence: event.sequence };
  }
  return { accepted: true, duplicate: false, sequence: event.sequence };
}

export function emptyGPU(reason = 'no_telemetry', jobId = null) {
  return { available: false, source: 'authenticated_worker_telemetry', podState: 'not_monitored', state: 'unknown', stage: null,
    jobId: validJob(jobId) ? jobId : null, device: null, sequence: null, stepsCompleted: null, stepsTotal: null,
    updatedAt: null, receivedAt: null, stale: true, diagnosticOnly: true, scientificAcceptance: false,
    resultSha256: null, checkpointSha256: null, reason };
}

export async function readLatestGPU({ store, jobId, totalSteps = 3000, now = () => new Date() }) {
  if (!validJob(jobId)) return emptyGPU('not_configured');
  try {
    const { blobs } = await store.list({ prefix: `${jobId}/` });
    need(blobs.length <= MAX_SEQUENCE, 503, 'unavailable');
    const keys = blobs.map(({ key }) => key).filter((key) => key.startsWith(`${jobId}/`) && /^\d{5}$/.test(key.slice(jobId.length + 1))).sort();
    if (!keys.length) return emptyGPU('no_telemetry', jobId);
    const saved = await store.get(keys.at(-1), { type: 'json', consistency: 'strong' });
    const event = validateEvent(saved?.event, jobId, totalSteps);
    need(eventKey(jobId, event.sequence) === keys.at(-1));
    need(typeof saved.receivedAt === 'string' && Number.isFinite(Date.parse(saved.receivedAt)));
    const stale = !TERMINAL.has(event.state) && now().getTime() - Date.parse(saved.receivedAt) > 120_000;
    return { available: true, source: 'authenticated_worker_telemetry', podState: 'not_monitored', ...event,
      receivedAt: saved.receivedAt, stale, reason: stale ? 'heartbeat_stale' : null };
  } catch { return emptyGPU('unavailable', jobId); }
}
