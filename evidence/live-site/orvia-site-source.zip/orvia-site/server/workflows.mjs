import { TelemetryError } from './telemetry.mjs';

// Public, reviewed job identities. History can only grant read access to these jobs.
export const WORKFLOWS = Object.freeze({
  'orvia-live-20261102-01': Object.freeze({ totalSteps: 3000, frameCount: 101, frameStep: 10, timeStepFs: 1 }),
  'orvia-stress-20261102-02': Object.freeze({ totalSteps: 400000, frameCount: 101, frameStep: 800, timeStepFs: 80,
    runnerSha256: '5b781a291219256f8450c6d016011b85a430f8bdc184a54256dba6b28276325b',
    inputManifestSha256: '90c95d2ca4653384bce9ca11d8848ab80378740dbb2e00c50f5feb0667ff7b32' }),
});

export function workflowProfile(jobId) {
  if (!Object.hasOwn(WORKFLOWS, jobId)) throw new TelemetryError(503, 'workflow_not_configured');
  return WORKFLOWS[jobId];
}

export function readableWorkflowIds(jobId, historicalIds = '') {
  if (historicalIds === undefined || historicalIds === null || historicalIds === '') return [jobId];
  if (typeof historicalIds !== 'string' || historicalIds.length > 500) throw new TelemetryError(503, 'invalid_history_configuration');
  const ids = historicalIds.split(',').map(value => value.trim());
  if (ids.length > 8 || ids.some(id => !Object.hasOwn(WORKFLOWS, id) || id === jobId) || new Set(ids).size !== ids.length) {
    throw new TelemetryError(503, 'invalid_history_configuration');
  }
  return [jobId, ...ids];
}
