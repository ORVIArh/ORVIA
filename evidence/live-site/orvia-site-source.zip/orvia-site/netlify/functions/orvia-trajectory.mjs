import { getStore } from '@netlify/blobs';
import { handleTrajectory } from '../../server/trajectory.mjs';
import { STORE_NAME } from '../../server/telemetry.mjs';

export default async (request, context) => handleTrajectory(request, {
  context, token: Netlify.env.get('ORVIA_WORKER_TOKEN'), jobId: Netlify.env.get('ORVIA_WORKFLOW_ID'),
  historicalIds: Netlify.env.get('ORVIA_HISTORICAL_WORKFLOW_IDS') || '',
  getStore: () => getStore({ name: STORE_NAME, consistency: 'strong' }),
});

export const config = { path: '/api/orvia/trajectory', method: ['GET', 'POST'] };
