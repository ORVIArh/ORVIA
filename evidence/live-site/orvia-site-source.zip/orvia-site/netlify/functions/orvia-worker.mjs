import { getStore } from '@netlify/blobs';
import { handleWorker } from '../../server/http.mjs';
import { STORE_NAME } from '../../server/telemetry.mjs';

export default async (request, context) => handleWorker(request, {
  context, token: Netlify.env.get('ORVIA_WORKER_TOKEN'),
  jobId: Netlify.env.get('ORVIA_WORKFLOW_ID'),
  totalSteps: Number(Netlify.env.get('ORVIA_WORKFLOW_STEPS') || '3000'),
  getStore: () => getStore({ name: STORE_NAME, consistency: 'strong' }),
});

export const config = { path: '/api/orvia/worker', method: ['POST'] };
