import { getStore } from '@netlify/blobs';
import { handleMetrics } from '../../server/gpu-metrics.mjs';
import { STORE_NAME } from '../../server/telemetry.mjs';

export default async (request, context) => handleMetrics(request, {
  context, token: Netlify.env.get('ORVIA_WORKER_TOKEN'), jobId: Netlify.env.get('ORVIA_WORKFLOW_ID'),
  getStore: () => getStore({ name: STORE_NAME, consistency: 'strong' }),
});

export const config = { path: '/api/orvia/gpu', method: ['POST'] };
