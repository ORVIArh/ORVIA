import { getStore } from '@netlify/blobs';
import { statusSnapshot } from '../../server/status.mjs';
import { STORE_NAME } from '../../server/telemetry.mjs';
import { json } from '../../server/http.mjs';

let cache = null, pending = null;
export default async (request) => {
  if (request.method !== 'GET') return json({ error: 'method_not_allowed' }, 405);
  if (cache && Date.now() - cache.time < 15_000) return json(cache.value);
  if (!pending) pending = (async () => {
    let store;
    try { store = getStore({ name: STORE_NAME, consistency: 'strong' }); } catch { store = null; }
    const value = await statusSnapshot({
      rpcUrl: Netlify.env.get('ORVIA_RPC_URL'), store,
      jobId: Netlify.env.get('ORVIA_WORKFLOW_ID'),
      totalSteps: Number(Netlify.env.get('ORVIA_WORKFLOW_STEPS') || '3000'),
      historicalIds: Netlify.env.get('ORVIA_HISTORICAL_WORKFLOW_IDS') || '',
    });
    cache = { time: Date.now(), value };
    return value;
  })().finally(() => { pending = null; });
  try { return json(await pending); } catch { return json({ error: 'unavailable' }, 503); }
};

export const config = { path: '/api/orvia/status', method: ['GET'] };
